
[Obsidian Jira Issue | Obsidian Jira Issue](https://marc0l92.github.io/obsidian-jira-issue/)





```jira-search
query: status = 'In Progress' order by priority DESC
columns: key, summary, status, notes
```





