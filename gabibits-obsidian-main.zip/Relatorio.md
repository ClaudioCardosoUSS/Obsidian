```dataview
TABLE tags
```