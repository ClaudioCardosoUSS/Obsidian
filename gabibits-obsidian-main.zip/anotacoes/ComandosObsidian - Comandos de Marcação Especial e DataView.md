---
type: Comandos
fonte: Obsidian
tags:
  - nota
  - ComandosObsidian
  - DataView
  - MarcacaoEspecial
Título: ComandosObsidian - Comandos de Marcação Especial e DataView
---
---
Tópico: Nota Permanente
Título: ComandosObsidian - Comandos de Marcação Especial e DataView
---

Tópico:: Nota Permanente
Links::

---

ComandosObsidian - Comandos de Marcação Especial e DataView

# Comandos de Marcação Especial

- `%%+ texto`: Adiciona texto oculto expansível
- `==*texto*==`: Combina destaque com itálico
- `**==texto==**`: Combina negrito com destaque
- `:::warning`: Bloco de aviso personalizado
- `:::info`: Bloco de informação personalizado
- `:::success`: Bloco de sucesso personalizado
- `:::error`: Bloco de erro personalizado

# Comandos de DataView

- `TABLE`: Criar tabela dinâmica
- `LIST`: Criar lista dinâmica
- `TASK`: Listar tarefas
- `FROM`: Definir fonte dos dados
- `WHERE`: Filtrar dados
- `SORT`: Ordenar resultados
- `GROUP BY`: Agrupar resultados

# Comandos de Expressões Matemáticas

- `$\sqrt{x}$`: Raiz quadrada
- `$\frac{x}{y}$`: Fração
- `$\sum_{i=1}^{n}$`: Somatório
- `$\prod_{i=1}^{n}$`: Produtório
- `$\int_{a}^{b}$`: Integral
- `$\lim_{x \to \infty}$`: Limite

# Comandos de Diagrama (Mermaid)

```
graph TD
A[Início] --> B[Fim]
```

```
sequenceDiagram
A->>B: Mensagem
```

```
gantt
    title Projeto
    section Tarefas
    Tarefa 1 :a1, 2024-01-01, 30d
```

# Comandos de Properties

```yaml
---
aliases: []
tags: []
created: {{date}}
modified: {{date}}
status: active/archived
priority: high/medium/low
---
```

# Comandos de Callouts Avançados

```
> [!FAQ]- Pergunta
> Resposta

> [!EXAMPLE]+ Exemplo
> Conteúdo

> [!SUCCESS] Sucesso
> Mensagem

> [!FAILURE] Falha
> Mensagem
```

# Comandos de Templating Avançado

- `<%tp.file.folder()%>`: Pasta atual
- `<%tp.file.creation_date()%>`: Data de criação
- `<%tp.file.last_modified_date()%>`: Última modificação
- `<%tp.web.random_picture()%>`: Imagem aleatória
- `<%tp.system.clipboard()%>`: Conteúdo da área de transferência

# Comandos de Busca Avançada

- `path:`: Buscar por caminho
- `file:`: Buscar por nome de arquivo
- `tag:`: Buscar por tag
- `line:`: Buscar por linha
- `block:`: Buscar por bloco
- `content:`: Buscar por conteúdo
- `section:`: Buscar por seção

# Comandos de Graph View

- `Ctrl + Click`: Expandir nó
- `Shift + Click`: Selecionar múltiplos nós
- `Alt + Click`: Filtrar por nó
- `Ctrl + Alt + F`: Abrir filtros do grafo

Lembre-se que a disponibilidade e funcionamento desses comandos pode depender:
1. Da versão do Obsidian que você está usando
2. Dos plugins instalados
3. Das configurações personalizadas
4. Do sistema operacional

É recomendado testar cada comando no seu ambiente específico para verificar a compatibilidade.