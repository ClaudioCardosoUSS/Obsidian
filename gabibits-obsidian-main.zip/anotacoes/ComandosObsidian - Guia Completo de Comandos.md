---
type: Comandos
fonte: Obsidian
tags:
  - nota
  - ComandosObsidian
  - formatacaoTextos
  - "#DataView"
Título: ComandosObsidian - Formatação de TextosGuia Completo de Comandos
---
---
Tópico: Nota Permanente
Título: ComandosObsidian - Guia Completo de Comandos
---

Tópico:: Nota Permanente
Links::

---
ComandosObsidian - Guia Completo de Comandos
# Guia Completo de Comandos do Obsidian #obsidian
path: anotacoes/ComandosObsidian

## Comandos Básicos de Edição #comando/basico

### Gerenciamento de Arquivos #comando/basico/arquivo
- **Ctrl + N**: Criar uma nova nota
- **Ctrl + S**: Salvar manualmente a nota atual
- **Ctrl + W**: Fechar o painel atual
- **Ctrl + Shift + N**: Criar uma nova nota em um novo painel
- **Ctrl + O**: Quick switcher (troca rápida entre arquivos)
- **Ctrl + P**: Abrir a paleta de comandos

### Edição de Texto #comando/basico/edicao
- **Ctrl + F**: Buscar dentro da nota atual
- **Ctrl + Shift + F**: Buscar em todas as notas do vault
- **Ctrl + H**: Buscar e substituir
- **Ctrl + Z**: Desfazer
- **Ctrl + Y** ou **Ctrl + Shift + Z**: Refazer
- **Ctrl + X**: Recortar
- **Ctrl + C**: Copiar
- **Ctrl + V**: Colar

## Formatação Markdown #comando/markdown

### Texto Básico #comando/markdown/texto
- **Ctrl + B**: Negrito (**texto**)
- **Ctrl + I**: Itálico (*texto*)
- **Ctrl + K**: Inserir link
- **~~texto~~**: Texto riscado
- **==texto==**: Texto destacado
- **^texto^**: Texto sobrescrito
- **~texto~**: Texto subscrito
- **++texto++**: Texto sublinhado

### Títulos #comando/markdown/titulos
- **#**: Título nível 1
- **##**: Título nível 2
- **###**: Título nível 3
- **####**: Título nível 4
- **#####**: Título nível 5
- **######**: Título nível 6

### Listas e Tarefas #comando/markdown/listas
- **-** ou **+** ou **\***: Criar lista com marcadores
- **1.**: Criar lista numerada
- **- [ ]**: Criar tarefa não concluída
- **- [x]**: Marcar tarefa como concluída
- **- [>]**: Tarefa transferida
- **- [<]**: Tarefa agendada
- **- [!]**: Tarefa importante
- **Tab**: Aumentar indentação
- **Shift + Tab**: Diminuir indentação

## Navegação e Visualização #comando/navegacao

### Navegação Básica #comando/navegacao/basica
- **Alt + ←**: Voltar para a nota anterior
- **Alt + →**: Avançar para a próxima nota
- **Alt + Tab**: Alternar entre painéis abertos
- **Ctrl + E**: Alternar entre modos de edição e visualização
- **Ctrl + Click**: Abrir link em novo painel
- **Alt + Click**: Abrir nota em novo painel

### Visualização Avançada #comando/navegacao/avancada
- **Ctrl + Mouse Wheel**: Ajustar zoom
- **Alt + P**: Alternar modo de apresentação
- **Alt + L**: Alternar modo de leitura
- **Ctrl + Alt + ←/→**: Navegar no histórico global

## Links e Referências #comando/links

### Links Internos #comando/links/internos
- **[[**: Iniciar link interno
- **[[Nome da nota|Texto]]**: Link interno com texto alternativo
- **[[Nome da nota#seção]]**: Link para seção específica
- **[[#]]**: Link para cabeçalho atual
- **[[#^id]]**: Link para bloco específico

### Links Externos e Mídia #comando/links/externos
- **[texto](URL)**: Link externo
- **![[imagem.png]]**: Inserir imagem
- **![[arquivo.pdf#page=n]]**: Incorporar página específica de PDF
- **[^1]**: Criar nota de rodapé

## Callouts e Blocos Especiais #comando/callouts

### Callouts #comando/callouts/tipos
```markdown
> [!INFO] 
> Informação importante

> [!NOTE]
> Nota relevante

> [!WARNING]
> Aviso importante

> [!TIP]
> Dica útil

> [!FAQ]
> Perguntas frequentes

> [!EXAMPLE]
> Exemplo

> [!SUCCESS]
> Sucesso

> [!FAILURE]
> Falha
```

### Blocos de Código #comando/blocos
- **\`código\`**: Código inline
- **\```linguagem**: Bloco de código com sintaxe destacada
- **>**: Criar citação
- **>>>**: Citação aninhada

## Plugins Core e Funcionalidades Avançadas #comando/plugins

### Plugins Essenciais #comando/plugins/core
- **Ctrl + Alt + B**: Abrir backlinks
- **Ctrl + G**: Abrir visualização de gráfico
- **Ctrl + Alt + G**: Abrir gráfico local
- **Ctrl + Alt + T**: Abrir painel de tags

### Graph View #comando/graph
- **Ctrl + Click**: Expandir nó
- **Shift + Click**: Selecionar múltiplos nós
- **Alt + Click**: Filtrar por nó
- **Ctrl + Alt + F**: Abrir filtros do grafo

### Canvas #comando/canvas
- **Ctrl + Click e Arrastar**: Criar seta
- **Shift + Click**: Selecionar múltiplos itens
- **Alt + Arrastar**: Duplicar item

## Comandos de Data e Templates #comando/data

### Data e Hora #comando/data/tempo
- **@**: Inserir timestamp atual
- **{{date}}**: Data atual
- **{{time}}**: Hora atual
- **{{title}}**: Nome da nota atual

### Templates Avançados #comando/templates
- **<%tp.date.now()%>**: Data atual em template
- **<%tp.file.title%>**: Título do arquivo
- **<%tp.file.folder()%>**: Pasta atual
- **<%tp.file.creation_date()%>**: Data de criação
- **<%tp.file.last_modified_date()%>**: Última modificação
- **<%tp.web.random_picture()%>**: Imagem aleatória
- **<%tp.system.clipboard()%>**: Conteúdo da área de transferência

## Plugins Populares e Suas Funcionalidades #comando/plugins/externos

### DataView #comando/dataview
- **TABLE**: Criar tabela dinâmica
- **LIST**: Criar lista dinâmica
- **TASK**: Listar tarefas
- **FROM**: Definir fonte dos dados
- **WHERE**: Filtrar dados
- **SORT**: Ordenar resultados
- **GROUP BY**: Agrupar resultados

### Expressões Matemáticas (Math Plugin) #comando/math
- **$\sqrt{x}$**: Raiz quadrada
- **$\frac{x}{y}$**: Fração
- **$\sum_{i=1}^{n}$**: Somatório
- **$\prod_{i=1}^{n}$**: Produtório
- **$\int_{a}^{b}$**: Integral
- **$\lim_{x \to \infty}$**: Limite

### Mermaid Diagramas #comando/mermaid
```markdown
graph TD
A[Início] --> B[Fim]

sequenceDiagram
A->>B: Mensagem

gantt
    title Projeto
    section Tarefas
    Tarefa 1 :a1, 2024-01-01, 30d
```

## Dicas Extras e Boas Práticas #comando/boas-praticas

### Metadados YAML #comando/metadata
```yaml
---
aliases: []
tags: []
created: {{date}}
modified: {{date}}
status: active/archived
priority: high/medium/low
---
```

### Comandos de Busca Avançada #comando/busca/avancada
- **path::** Buscar por caminho
- **file::** Buscar por nome de arquivo
- **tag::** Buscar por tag
- **line::** Buscar por linha
- **block::** Buscar por bloco
- **content::** Buscar por conteúdo
- **section::** Buscar por seção

### Workspace e Sincronização #comando/workspace
- **Ctrl + Shift + Layout**: Salvar layout atual
- **Ctrl + Alt + Layout**: Carregar layout
- **Ctrl + Alt + S**: Sincronizar agora
- **Ctrl + Alt + V**: Verificar versões
- **Ctrl + Alt + C**: Resolver conflitos

Nota: Alguns comandos podem variar dependendo do sistema operacional (Windows/Mac/Linux) e da configuração personalizada do Obsidian. Além disso, alguns recursos podem requerer plugins específicos ou configurações adicionais.