---
type: Comandos
fonte: Obsidian
tags:
  - nota
  - ComandosObsidian
  - formatacaoTextos
Título: ComandosObsdian - Formatação de Textos
---
---
Tópico: Nota Permanente
Título: ComandosObsidian - Formatação de Textos
---

Tópico:: Nota Permanente
Links::

---
ComandosObsidian - Formatação de Textos
# Títulos e Subtítulos

- `# Título`: Cria um título de nível 1 (mais importante)
- `## Subtítulo`: Cria um título de nível 2
- `### Subtítulo`: Título nível 3 
- `#### Subtítulo`: Título nível 4
- `##### Subtítulo`: Título nível 5
- `###### Subtítulo`: Título nível 6 (menos importante)

# Formatação de Texto

- `**texto**` ou `__texto__`: **Negrito**
- `*texto*` ou `_texto_`: *Itálico*
- `***texto***`: ***Negrito e itálico***
- `~~texto~~`: ~~Texto riscado~~
- `==texto==`: ==Texto destacado==
- `^texto^`: ^Texto sobrescrito^
- `~texto~`: ~Texto subscrito~

# Listas

- `- item`: Lista com marcadores
- `1. item`: Lista numerada
- `- [ ]`: Lista de tarefas vazia
- `- [x]`: Lista de tarefas marcada
- Use Tab para criar subitens

# Links e Referências

- `[[Nome da nota]]`: Link interno para outra nota
- `[[Nome da nota|Texto visível]]`: Link interno com texto personalizado
- `[texto](URL)`: Link externo
- `![[imagem.png]]`: Inserir imagem
- `[^1]`: Criar nota de rodapé
- `^referência`: Criar bloco de referência

# Blocos de Código

- ``` `código` ```: Código inline
- ```````linguagem`: Bloco de código com sintaxe destacada
- `> texto`: Criar citação
- `>>> texto`: Citação aninhada

# Tabelas

```
| Coluna 1 | Coluna 2 |
|----------|----------|
| Item 1   | Item 2   |
```

# Divisores e Espaçamento

- `---` ou `***`: Cria uma linha horizontal
- `\`: Quebra de linha forçada
- Dois espaços no final da linha: Quebra de linha suave

# Callouts (Destaque de Informações)

```
> [!INFO] 
> Informação importante

> [!NOTE]
> Nota relevante

> [!WARNING]
> Aviso importante

> [!TIP]
> Dica útil
```

# Tags e Metadados

- `#tag`: Criar uma tag
- `#tag/subtag`: Criar hierarquia de tags
- Use `---` no início da nota para criar um bloco YAML com metadados

# Comandos Especiais

- `<%`: Inserir template
- `$$`: Fórmulas matemáticas (LaTeX)
- `::texto::`: Criar destaque personalizado
- `%%texto%%`: Comentário oculto na visualização

Lembre-se que alguns desses recursos podem requerer plugins específicos ou configurações adicionais no Obsidian para funcionar.