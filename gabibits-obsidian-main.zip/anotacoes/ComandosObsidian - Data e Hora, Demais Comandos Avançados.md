---
type: Comandos
fonte: Obsidian
tags:
  - nota
  - ComandosObsidian
  - ObsidianDataHora
  - ObsidianCmdAvancados
Título: ComandosObsidian - Data e Hora, Demais Comandos Avançados
---
---
Tópico: Nota Permanente
Título: ComandosObsidian - Data e Hora, Demais Comandos Avançados
---

Tópico:: Nota Permanente
Links::

---
ComandosObsidian - Data e Hora, Demais Comandos Avançados
# Comandos de Data/Hora

- `@`: Inserir timestamp atual
- `{{date}}`: Data atual
- `{{time}}`: Hora atual
- `{{title}}`: Nome da nota atual

# Formatação Avançada

- `++texto++`: ++Texto sublinhado++
- `__*texto*__`: Combinar sublinhado com itálico
- `**~~texto~~**`: Combinar negrito com tachado
- ````ad-info`: Criar um bloco de informação avançado
- `- (x)`: Criar checkbox circular
- `- [>]`: Tarefa transferida
- `- [<]`: Tarefa agendada
- `- [!]`: Tarefa importante

# Embeds Avançados

- `![[Nota^bloco]]`: Incorporar bloco específico de outra nota
- `![[Nota#seção]]`: Incorporar seção específica
- `![[Nota::bloco]]`: Referência transclusa
- `![[arquivo.pdf#page=n]]`: Incorporar página específica de PDF

# Aliases e Identificadores

- `alias`: Criar um alias para a nota atual
- `ID`: Identificador único da nota
- `uid`: Gerar ID único
- `path`: Caminho completo da nota

# Formatação de Links

- `[[#]]`: Link para cabeçalho atual
- `[[#^id]]`: Link para bloco específico
- `[[Nota#^id|Texto]]`: Link personalizado para bloco
- `[[Nota#Seção]]`: Link para seção específica

# Comandos de Canvas

- `Ctrl + Click e Arrastar`: Criar seta no canvas
- `Shift + Click`: Selecionar múltiplos itens
- `Alt + Arrastar`: Duplicar item no canvas

# Comandos de Visualização

- `Ctrl + Mouse Wheel`: Ajustar zoom
- `Alt + P`: Alternar modo de apresentação
- `Alt + L`: Alternar modo de leitura
- `Ctrl + Alt + ←/→`: Navegar no histórico global

# Plugins Core

- `Ctrl + Alt + B`: Abrir backlinks
- `Ctrl + G`: Abrir visualização de gráfico
- `Ctrl + Alt + G`: Abrir local graph
- `Ctrl + Alt + T`: Abrir tag pane

# Comandos de Workspace

- `Ctrl + Shift + Layout`: Salvar layout atual
- `Ctrl + Alt + Layout`: Carregar layout
- `Alt + Tab`: Alternar entre abas
- `Ctrl + Alt + ↑/↓`: Mover painel atual

# Comandos de Sincronização

- `Ctrl + Alt + S`: Sincronizar agora
- `Ctrl + Alt + V`: Verificar versões
- `Ctrl + Alt + C`: Resolver conflitos

# Atalhos de Produtividade

- `Ctrl + O`: Quick switcher aprimorado
- `Ctrl + Shift + O`: Busca por tags
- `Ctrl + Alt + O`: Busca por cabeçalhos
- `Ctrl + Alt + F`: Buscar e substituir em todo vault

# Comandos de Templating

- `<%tp.date.now()%>`: Data atual em template
- `<%tp.file.title%>`: Título do arquivo em template
- `<%tp.web.daily_quote()%>`: Quote diária em template

# Comandos de Desenvolvimento

- `Ctrl + Shift + I`: Abrir ferramentas de desenvolvedor
- `Ctrl + Alt + I`: Inspecionar elemento
- `Ctrl + R`: Recarregar aplicação

Lembre-se que alguns destes comandos podem requerer plugins específicos ou configurações personalizadas. Além disso, os atalhos podem variar dependendo do seu sistema operacional e configuração do Obsidian.