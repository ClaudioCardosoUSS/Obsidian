---
type: Comandos
fonte: Obsidian
tags:
  - nota
  - ComandosObsidian
Título: ComandosObsdian - Basicos
---
---
Tópico: Nota Permanente
Título: ComandosObsidian - Basicos
---

Tópico:: Nota Permanente
Links::

---
ComandosObsidian - Basicos
# Comandos Básicos de Edição

- **Ctrl + N**: Criar uma nova nota. Este é um dos comandos mais fundamentais que você usará frequentemente para iniciar novos documentos no Obsidian.

- **Ctrl + S**: Salvar manualmente a nota atual, embora o Obsidian já possua salvamento automático por padrão. Útil para garantir que suas alterações foram registradas.

- **Ctrl + F**: Buscar dentro da nota atual. Permite encontrar rapidamente palavras ou frases específicas no documento que você está editando.

# Formatação Markdown

- **Ctrl + B**: Aplicar negrito ao texto selecionado (**texto**). Muito útil para destacar palavras ou frases importantes em suas notas.

- **Ctrl + I**: Aplicar itálico ao texto selecionado (*texto*). Ideal para dar ênfase sutil ou marcar termos específicos.

- **Ctrl + K**: Inserir link. Você pode vincular tanto para páginas web externas quanto para outras notas dentro do seu vault.

# Navegação e Visualização

- **Ctrl + P**: Abrir a paleta de comandos, que dá acesso rápido a todas as funcionalidades do Obsidian.

- **Ctrl + E**: Alternar entre os modos de edição e visualização. Permite ver como sua nota ficará formatada.

- **Alt + ←**: Voltar para a nota anterior, similar ao botão "voltar" do navegador.

# Comandos Avançados

- **Ctrl + Shift + F**: Buscar em todas as notas do vault. Essencial para encontrar informações em todo seu banco de conhecimento.

- **Alt + Click**: Em um link interno, abre a nota em um novo painel, permitindo visualizar múltiplas notas simultaneamente.

- **[[**: Iniciar a criação de um link interno para outra nota. O Obsidian sugerirá notas existentes conforme você digita.

# Gerenciamento de Painéis

- **Ctrl + W**: Fechar o painel atual. Útil para manter sua área de trabalho organizada.

- **Ctrl + Shift + N**: Criar uma nova nota em um novo painel, mantendo a nota atual aberta.

- **Alt + Tab**: Alternar entre painéis abertos, facilitando a navegação entre múltiplas notas.

# Dicas Extras

- Use `Ctrl + Click` em um link para abrir a visualização rápida de uma nota sem sair da nota atual.

- O comando `/` no início de uma linha abre um menu de formatação com várias opções.

- Para criar uma lista de tarefas, use `- [ ]` no início da linha.

Estes comandos podem variar ligeiramente dependendo do seu sistema operacional (Windows/Mac/Linux) e da sua configuração personalizada do Obsidian.