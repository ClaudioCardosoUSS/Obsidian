**Tópico**:: [#oracle](app://obsidian.md/index.html#oracle)  
**Status**:: #concluido  
**Url**:: [https://cursos.alura.com.br/](https://cursos.alura.com.br/)

- [[Oracle Cloud Infrastructure - 1 - Implantação de uma aplicação na nuvem]]
- [[Oracle Cloud Infrastructure - 2 - banco de dados e infraestrutura como código]]
- 

