**Tópico**:: [#MySQL](app://obsidian.md/index.html#MySQL)  
**Status**:: #concluido  
**Url**:: [https://cursos.alura.com.br/](https://cursos.alura.com.br/)

- [[MySQL -1- Conectando o Workbench ao MySQL no Linux]]
- [[MySQL -2- SQL com MySQL - manipule e consulte dados]]
- [[MySQL -3- Consultas SQL avançando no SQL com MySQL]]
- [[MySQL -4-Comandos DML - manipulação de dados com MySQL]]
- [[MySQL -5-Procedures SQL - executando código no MySQL]]
- [[MySQL -6-Administração do MySQL segurança e otimização do banco]]

