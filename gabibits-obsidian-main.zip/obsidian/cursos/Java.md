
**Tópico**:: [#Java](app://obsidian.md/index.html#Java)  
**Status**:: #concluido  
**Url**:: [https://cursos.alura.com.br/](https://cursos.alura.com.br/)

[[Spring Boot 3 2 aplique boas práticas e proteja uma API Rest]]
[[Spring Boot 3 1 desenvolva uma API Rest em Java]]
[[Spring Boot 3 3 documente, teste e prepare uma API para o deploy]]
[[Spring Boot 04_Praticando Spring Framework Challenge Fórum Hub]]
[[Spring Boot 06_Spring AI integre uma aplicação Spring com a OpenAI]]
