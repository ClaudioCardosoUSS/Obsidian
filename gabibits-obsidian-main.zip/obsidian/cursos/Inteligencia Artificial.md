---
type: "9"
fonte: https://www.alura.com.br/
tags:
  - nota/curso
---

Tópico:: #curso
**Tópico**:: #Inteligencia_Artifical #IA_generativa
**Status**:: #andamento 
**Url**:: https://cursos.alura.com.br/formacao-ia-java-grupo7-one

--- 
[[I.A. 01_ChatGPT e programação aumente sua produtividade]]
[[I.A. 02_Integrando aplicações Java com OpenAI]]
[[Spring Boot 06_Spring AI integre uma aplicação Spring com a OpenAI]]


