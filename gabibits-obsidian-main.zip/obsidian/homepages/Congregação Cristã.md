<br/>

```button
name Adicionar ccb
type command
action QuickAdd: Adicionar ccb
```

<br/>

[[CCB-CCLimp]]
[[CCB-Manutenção]]
[[CCB-Reuniões]]

```dataview 
table without id file.link as Setor, Status, Tópico, Url
from "obsidian/ccb" 
sort file.name asc
```
