<br/>

```button
name Adicionar curso
type command
action QuickAdd: Adicionar curso
```

<br/>

- [[Java]]
- [[MySQL]]
- [[Node.js]]
- [[Inteligencia Artificial]]
- [[IA Generativa]]
- [[Oracle Cloud Infrastructure]]
```dataview 
table without id file.link as Curso, Status, Tópico, Url
from "obsidian/cursos" 
sort file.name asc
```
