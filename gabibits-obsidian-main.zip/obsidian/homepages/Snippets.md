<br/>

```button
name Adicionar snippet
type command
action QuickAdd: Adicionar snippet
```

<br/>


```dataview 
table without id file.link as Snippet, Linguagem
from "obsidian/snippets" 
sort file.name asc
```

