<br>

```button
name Adicionar novo livro
type command
action QuickAdd: Adicionar livro
```

<br>
<br>

- [[14 Hábitos de Desenvolvedores Altamente Produtivos]]
- [[Cavalo de Troia 1 - Jerusalém]]
- [[Cavalo de Troia 2 - Massada]]
- [[Cavalo de Troia 3 - Saidan]]
- [[Cavalo de Troia 4 - Nazaré]]
- [[Cavalo de Troia 5 - Cesareia]]
- [[Cavalo de Troia 6- Hermon]]
- [[Cavalo de Troia 7 - Nahum]]
- [[Cavalo de Troia 8 - Jordão]]
- [[Cavalo de Troia 9 - Caná]]
- [[Cavalo de Troia 10 - O Dia do Relampago]]
- [[Cavalo de Troia 11 - O Diario de Eliseo]]
- [[Cavalo de Troia 12 - Belem]]
- [[A Rebelião de Lúcifer]]
- [[Gilgamesh]]
- [[Star Wars - Marcas da Guerra - 1º da Trilogia Aftermath]]
- [[O livro do cemitério HQ vol.1]]
- [[O livro do cemitério HQ vol.2]]
- [[Martini Seco - Fernando Sabino]]
- [[Menino de asas - Homero Homem - Coleção Vaga-Lume]]
- [[Descobrindo o Método Zettelkasten - Como Organizar Pensamentos e Transformar Ideias em Ação (Descobrindo Técnicas de Estudo)]]
- [[Pare de se sabotar e dê a volta por cima - Como se livrar dos comportamentos que atrapalham sua vida]]

```dataview 
table without id ("![coverimg|100](" + Capa + ")") as Capa, file.link as Título, Autor, Status, (Páginas + " p.") as Páginas, Nota, ( "![progresso + " + (round((páginasLidas/Páginas)*100)) + " %](https://progress-bar.dev/" + (round((páginasLidas/Páginas)*100)) + "/)" ) AS Progresso
from "obsidian/livros" 
sort file.name asc
```