
<br/>

```button
name Adicionar nota
type command
action QuickAdd: Adicionar nota
```

<br/>


* [[ComandosObsidian - Comandos de Marcação Especial e DataView]]
* [[ComandosObsidian - Data e Hora, Demais Comandos Avançados]]
* [[ComandosObsidian - Formatação de Textos]]
* [[ComandosObsidian - Guia Completo de Comandos]]
* [[ComandosObsidian - Basicos]]





```dataview 
TABLE rows.file.link as "Título" 
from "anotacoes"
FLATTEN Tópico
Group by Tópico
```
