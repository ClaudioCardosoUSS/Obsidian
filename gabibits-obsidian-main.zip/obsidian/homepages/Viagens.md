<br>

```button
name Adicionar nova viagem
type command
action QuickAdd: Adicionar Lugares
```

<br>
<br>

- [[Brasil - Porto Seguro - BA]]

```dataview 
table without id ("![coverimg|100](" + Capa + ")") as Capa, file.link as Destino, diasViagem as "Dias", Status, DataInício as "Início", DataConclusão as "Fim", Nota
from "obsidian/Lugares" 
sort file.name asc
```