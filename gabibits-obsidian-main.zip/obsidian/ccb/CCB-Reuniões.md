**Tópico**:: [#CCB-Reuniões](app://obsidian.md/index.html#CCB-Reuniões)  
**Status**:: [#andamento](app://obsidian.md/index.html#andamento)  
**Url**:: [[SIGA](https://siga.congregacao.org.br/)]([SIGA](https://siga.congregacao.org.br/))

[[Reunião Encarregado Manutenção]]
[[Reunião Trimestral Pereira Barreto]]
