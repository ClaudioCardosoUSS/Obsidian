**Tópico**:: [#CCB-CCLimp](app://obsidian.md/index.html#CCB-CCLimp)  
**Status**:: [#andamento](app://obsidian.md/index.html#andamento)  
**Url**:: [[[HomeCCB](https://congregacao.sharepoint.com/sites/setorlapa/SitePages/HomeCCB.aspx)]([[HomeCCB](https://congregacao.sharepoint.com/sites/setorlapa/SitePages/HomeCCB.aspx))

- [[Pedidos CCLimp]]
