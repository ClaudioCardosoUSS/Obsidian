---
type: 
fonte: 
tags:
  - viagens
  - travel
---

Tópico:: #Lugares #viagens 


Lugar::
Status:: 
diasViagem:: 
data_inicio::
data_conclusao:
Nota:: 
Capa:: 
Destinos Visitados::
Hospedagem:: [nome e detalhes da hospedagem] 
Transporte:: [como você se locomoveu] 
Gastronomia:: [pratos e restaurantes marcantes] 
Pontos Altos:: [melhores experiências] 
Pontos Baixos:: [experiências que não valeram a pena] 
Orçamento:: [estimativa de gastos] 
Dicas:: [recomendações para futuras viagens]
---