---
uuid: <% tp.date.now("YYYYMMDDHHmmss") %>
created: <% tp.file.creation_date("YYYY-MM-DDTHH:mm:ss") %>
updated: <% tp.file.last_modified_date("YYYY-MM-DDTHH:mm:ss") %>
alias: 
---


# 📋 Tarefas
```tasks
not done
due before in 1 week
sort by due
```

<br>

---

<br>

🗓️ Progresso Semanal

```dataview
TABLE WITHOUT ID
"Progresso da Semana" as "Resumo",
string(round(length(rows.file) / 7 * 100)) + "%" as "Progresso",
"<progress style='height:15px;width:200px' value='" + 
string(round(length(rows.file) / 7 * 100)) + 
"' max='100'></progress>" as "Barra"
FROM "obsidian/journal/dailynote"
WHERE date(file.name) >= date(today) - dur(7d)
GROUP BY "semana"
```

<br>

---

<br>
📅 Notas Diárias

```dataview
TABLE WITHOUT ID
file.link as "Dia"
FROM "obsidian/journal/dailynote"
WHERE date(file.name) >= date(today) - dur(7d)
AND date(file.name) <= date(today) + dur(7d)
SORT file.name ASC
```

<br>

---

<br>

# 🌻 Reflexão da Semana

## 3 coisas legais nessa semana
- 
- 
- 

## O que fazer diferente na semana que vem?
- 
- 