---
type: 
fonte: 
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor::
Status:: 
páginasLidas:: 
Páginas:: 
Genero:: 
data_inicio::
data_conclusao:
Nota:: 
Capa:: 

---