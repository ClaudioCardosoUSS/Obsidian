---
creation date: <% tp.file.creation_date() %>
modification date: <%+ tp.file.last_modified_date("dddd Do MMMM YYYY HH:mm:ss") %>
week: <% tp.date.now("YYYY-WW") %>

---


<< [[<% tp.date.now("YYYY-MM-DD", -1, tp.file.title, "YYYY-MM-DD") %>]] | [[<% tp.date.now("YYYY-MM-DD", 1, tp.file.title, "YYYY-MM-DD") %>]]>>

<br>

```dataviewjs
/// Obtém a data do título da nota
const noteDate = moment(dv.current().file.name, "YYYY-MM-DD");

// Função para verificar se uma data é hoje
const isToday = (date) => {
    return moment(date).isSame(moment(), 'day');
}

// Definição dos momentos temporais baseados na data da nota
const startOfDay = moment(noteDate).startOf('day');
const endOfDay = moment(noteDate).endOf('day');
const now = isToday(noteDate) ? moment() : moment(noteDate);

let progressHTML = '';

// Se for uma data futura
if (noteDate.isAfter(moment(), 'day')) {
    progressHTML = '**PROGRESSO DO DIA**\nAinda não iniciado (data futura)';
}
// Se for uma data passada
else if (noteDate.isBefore(moment(), 'day')) {
    progressHTML = `**PROGRESSO DO DIA**   
    <progress style="height:10px;width:50%" value="100" max="100"></progress>    **100%**\nConcluído`;
}
// Se for hoje, calcula normalmente
else {
    const minutesElapsed = now.diff(startOfDay, 'minutes');
    const totalMinutes = endOfDay.diff(startOfDay, 'minutes');
    const percentage = ((minutesElapsed/totalMinutes) * 100).toFixed(1);

    progressHTML = `**PROGRESSO DO DIA**   
    <progress style="height:10px;width:50%" value="${minutesElapsed}" max="${totalMinutes}"></progress>    **${percentage}%**`;

    // Adiciona informação de tempo restante apenas se for hoje
    if (isToday(noteDate)) {
        const hoursRemaining = Math.floor((totalMinutes - minutesElapsed) / 60);
        const minutesRemaining = Math.floor((totalMinutes - minutesElapsed) % 60);
        if (hoursRemaining > 0 || minutesRemaining > 0) {
            progressHTML += `\nTempo restante: ${hoursRemaining}h ${minutesRemaining}min`;
        }
    }
}

// Renderiza o resultado
dv.paragraph(progressHTML);
```


## Tarefas para hoje
```tasks
due on today
hide backlink
hide due date
hide edit button
not done
```

<br>

## Agenda


<br>

## Hábitos

**Leitura**:: [[]]
**Sono**:: 0
**Exercicio**:: 0
**Água**:: 0