**Linguagem**::  
**Links**::

---

# Código
```js

```