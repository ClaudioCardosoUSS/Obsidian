---
type: 
fonte: 
tags:
  - obsidian/projetos
---

Tópico:: #projetos




**Status**:: 

# Tarefas

- [ ] 1
- [ ] 2
- [ ] 3

# Visão  Geral



