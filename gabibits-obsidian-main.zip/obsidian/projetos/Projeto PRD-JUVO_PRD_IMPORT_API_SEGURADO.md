---
type: projeto
"tarefasCompletas:": 9
"totalTarefas:": 9
status: "100"
---

**Status**:: 100

# Tarefas

- [x] 1
- [x] 2
- [x] 3
- [x] 4
- [x] 5
- [x] 6
- [x] 7
- [x] 8
- [x] 9

# Visão  Geral

# API Integration Juvo - Spring Boot

## 📋 Visão Geral

A **API Integration Juvo** é uma aplicação Spring Boot desenvolvida para migrar o processo de integração do **Kettle/Pentaho Data Integration** para uma solução nativa Java. O sistema processa dados da tabela `TB_JUVO_PAYLOAD_CARGA_SEGURADO` e envia payloads JSON para a API externa da Juvo.

---

## 🏗️ Arquitetura do Sistema

### Componentes Principais

```mermaid
graph TD
    A[TB_JUVO_PAYLOAD_CARGA_SEGURADO] --> B[JuvoPayloadRepository]
    B --> C[RealProcessingService]
    C --> D[ApiClientService]
    D --> E[API Juvo Externa]
    
    F[IntegrationScheduler] --> C
    G[IntegrationController] --> C
    
    H[EnvironmentService] --> C
    I[ApplicationConfig] --> D
```

### Estrutura de Diretórios

```
src/main/java/com/tempoassist/apiintegration/
├── controller/
│   └── IntegrationController.java
├── entity/
│   ├── JuvoPayload.java
│   └── SeguradorPayload.java
├── repository/
│   └── JuvoPayloadRepository.java
├── service/
│   ├── ApiClientService.java
│   ├── EnvironmentService.java
│   ├── IntegrationService.java
│   ├── IntegrationScheduler.java
│   └── RealProcessingService.java
├── config/
│   ├── ApplicationConfig.java
│   ├── AppConfig.java
│   └── DatabaseConfig.java
└── ApiIntegrationApplication.java
```

---

## 🗄️ Modelo de Dados

### Tabela Principal: TB_JUVO_PAYLOAD_CARGA_SEGURADO

|Campo|Tipo|Descrição|
|---|---|---|
|`ID_JSONPAYLOAD`|NUMBER(15,0)|Chave primária|
|`ID_ITEMCOBERTOJSON`|NUMBER(15,0)|ID do item coberto|
|`APOLICE`|VARCHAR2(40)|Número da apólice|
|`APOLICEITEM`|VARCHAR2(5)|Item da apólice|
|`NUMEROCARTAO`|VARCHAR2(30)|Número do cartão|
|`JSON`|CLOB|Payload JSON|
|`STATUS_RETORNO`|VARCHAR2(4000)|Status da resposta|
|`DESC_RETORNO`|VARCHAR2(4000)|Descrição do retorno|
|`DT_CARGA`|DATE|Data de carga|
|`METODO`|VARCHAR2(20)|Método HTTP (POST/PUT/DELETE)|
|`ID_ESTRUTURA`|NUMBER|ID da estrutura|
|`ID_CLIENTECORPORATIVO`|NUMBER|ID do cliente corporativo|
|`ID_CONTRATO`|NUMBER|ID do contrato|
|`ID_TIPOCARTEIRA`|NUMBER|Tipo da carteira|
|`DT_PROCESSAMENTO_API`|DATE|Data de processamento|
|`CPF_CNPJ`|VARCHAR2(14)|CPF/CNPJ|
|`TPOPERACAO`|VARCHAR2(2)|Tipo de operação|

---

## ⚙️ Configurações

### Ambientes Suportados

#### 🟦 Produção (`production`)

```properties
# Banco de Dados
spring.datasource.url=jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=racassist-scan.tempopar.intranet)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=PROD)))
spring.datasource.username=processamento
spring.datasource.password=abn5398

# API Juvo
api.juvo.base-url=http://integracao.juvo.com.br/api-itemcoberto
api.juvo.timeout=90000
api.juvo.max-retries=3

# Processamento
app.batch-size=5000
app.max-concurrent-requests=10
app.scheduler.enabled=true
app.scheduler.auto-process.enabled=true
```

#### 🟨 Homologação (`homologacao`)

```properties
# Banco de Dados
spring.datasource.url=jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.2.0.102)(PORT=1522))(CONNECT_DATA=(SERVICE_NAME=JUVOAUD)(INSTANCE_NAME=JUVOAUD)))

# API Juvo
api.juvo.base-url=http://integracao-hml.juvo.com.br/api-itemcoberto
api.juvo.timeout=60000
api.juvo.max-retries=5

# Processamento
app.batch-size=100
app.scheduler.enabled=false
app.debug.enabled=true
```

### Configurações de Performance

|Parâmetro|Produção|Homologação|Descrição|
|---|---|---|---|
|`app.batch-size`|5000|100|Registros por lote|
|`app.max-concurrent-requests`|10|5|Requisições simultâneas|
|`api.juvo.timeout`|90000ms|60000ms|Timeout das requisições|
|`spring.datasource.hikari.maximum-pool-size`|30|15|Pool de conexões|

---

## 🔄 Fluxo de Processamento

### 1. Identificação de Registros

```sql
-- Registros pendentes de processamento
SELECT * FROM TB_JUVO_PAYLOAD_CARGA_SEGURADO 
WHERE DT_PROCESSAMENTO_API IS NULL
ORDER BY DT_CARGA ASC
```

### 2. Processamento por Método HTTP

#### POST - Criação de ItemCoberto

- **URL**: `http://integracao.juvo.com.br/api-itemcoberto/itemCoberto`
- **Condição**: `METODO = 'POST'` e `DT_PROCESSAMENTO_API IS NULL`
- **Ação**: Criação de novo item coberto

#### PUT - Atualização de ItemCoberto

- **URL**: `http://integracao.juvo.com.br/api-itemcoberto/itemCoberto/{ID_ITEMCOBERTOJSON}`
- **Condição**: `METODO = 'PUT'` e `ID_ITEMCOBERTOJSON IS NOT NULL`
- **Ação**: Atualização de item existente

#### DELETE - Exclusão de ItemCoberto

- **URL**: `http://integracao.juvo.com.br/api-itemcoberto/itemCoberto/{ID_ITEMCOBERTOJSON}`
- **Condição**: `METODO = 'DELETE'` e `ID_ITEMCOBERTOJSON IS NOT NULL`
- **Ação**: Exclusão de item existente

### 3. Headers da Requisição

```json
{
  "Content-Type": "application/json",
  "Accept": "application/json",
  "idItemCoberto": "{ID_ITEMCOBERTOJSON}",
  "apolice": "{APOLICE}",
  "item": "{APOLICEITEM}",
  "cartao": "{NUMEROCARTAO}",
  "idClienteCorporativo": "{ID_CLIENTECORPORATIVO}",
  "idTipoCarteira": "{ID_TIPOCARTEIRA}"
}
```

### 4. Atualização de Status

Após o processamento, os seguintes campos são atualizados:

- `STATUS_RETORNO`: Código de status HTTP
- `DESC_RETORNO`: Resposta da API ou mensagem de erro
- `DT_PROCESSAMENTO_API`: Data/hora do processamento

---

## 📡 Endpoints da API

### Informações Gerais

|Endpoint|Método|Descrição|
|---|---|---|
|`/api/integration`|GET|Página inicial|
|`/api/integration/info`|GET|Informações do sistema|
|`/api/integration/health`|GET|Status de saúde|

### Processamento Manual

|Endpoint|Método|Descrição|
|---|---|---|
|`/api/integration/process`|POST|Processa um lote de registros|
|`/api/integration/process-all`|POST|Processa todos os registros pendentes|
|`/api/integration/process-posts`|POST|Processa apenas registros POST|
|`/api/integration/process-puts`|POST|Processa apenas registros PUT|
|`/api/integration/process-deletes`|POST|Processa apenas registros DELETE|

### Monitoramento

|Endpoint|Método|Descrição|
|---|---|---|
|`/api/integration/stats`|GET|Estatísticas de processamento|
|`/api/integration/pending-counts`|GET|Contadores de registros pendentes|

### Exemplo de Resposta

```json
{
  "message": "Processamento concluído",
  "totalProcessed": 150,
  "successful": 145,
  "failed": 5,
  "batchSize": 5000,
  "duration": "00:02:15",
  "timestamp": "2025-08-08T10:30:00",
  "status": "SUCCESS"
}
```

---

## 📅 Agendamento Automático

### Configuração do Scheduler

```java
@Component
@EnableScheduling
public class IntegrationScheduler {
    
    // Executa a cada 5 minutos
    @Scheduled(cron = "0 */5 * * * *")
    public void processScheduledIntegration() {
        // Processamento automático
    }
    
    // Executa diariamente às 02:00
    @Scheduled(cron = "0 0 2 * * *")
    public void purgeOldRecords() {
        // Expurgo de registros antigos
    }
}
```

### Propriedades de Controle

```properties
# Habilitar/desabilitar agendador
app.scheduler.enabled=true
app.scheduler.auto-process.enabled=true
app.scheduler.auto-purge.enabled=true

# Configurações de processamento
app.scheduler.post-priority.enabled=false
```

---

## 🔍 Logs e Monitoramento

### Níveis de Log

#### Produção

```properties
logging.level.root=INFO
logging.level.com.tempoassist.apiintegration=INFO
logging.level.com.tempoassist.apiintegration.service.RealProcessingService=INFO
```

#### Homologação

```properties
logging.level.root=INFO
logging.level.com.tempoassist.apiintegration=DEBUG
logging.level.org.springframework.web.reactive.function.client=DEBUG
```

### Estrutura dos Logs

```
2025-08-08 10:30:15.123 [integration-scheduler-1] INFO  RealProcessingService - 🚀 Iniciando processamento: 150 registros encontrados
2025-08-08 10:30:15.124 [integration-scheduler-1] INFO  RealProcessingService - 📊 Distribuição: POST=75, PUT=45, DELETE=30
2025-08-08 10:30:16.789 [integration-scheduler-1] INFO  RealProcessingService - ✅ POST processado: ID=12345, Status=201, Tempo=1.2s
2025-08-08 10:30:17.456 [integration-scheduler-1] ERROR RealProcessingService - ❌ PUT falhou: ID=67890, Status=500, Erro=Timeout
2025-08-08 10:32:30.789 [integration-scheduler-1] INFO  RealProcessingService - 🏁 Processamento concluído: 145/150 sucessos (96.7%)
```

### Arquivo de Log

```properties
logging.file.name=logs/api-integration.log
logging.file.max-size=10MB
logging.file.max-history=30
```

---

## 🛠️ Desenvolvimento e Deploy

### Pré-requisitos

- **Java 17+**
- **Spring Boot 3.x**
- **Oracle Database** (PROD/HML)
- **Maven 3.6+**

### Dependências Principais

```xml
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-webflux</artifactId>
    </dependency>
    <dependency>
        <groupId>com.oracle.database.jdbc</groupId>
        <artifactId>ojdbc11</artifactId>
    </dependency>
</dependencies>
```

### Build e Execução

```bash
# Build da aplicação
mvn clean package

# Execução com profile de produção
java -jar -Dspring.profiles.active=production target/api-integration-juvo.jar

# Execução com profile de homologação
java -jar -Dspring.profiles.active=homologacao target/api-integration-juvo.jar
```

### Variáveis de Ambiente

```bash
# Definir profile ativo
export SPRING_PROFILES_ACTIVE=production

# Configurações de JVM
export JAVA_OPTS="-Xmx2g -Xms1g -XX:+UseG1GC"

# Timezone
export TZ=America/Sao_Paulo
```

---

## 🔄 Migração do Kettle/Pentaho

### Comparativo de Funcionalidades

|Funcionalidade|Kettle/Pentaho|Spring Boot|
|---|---|---|
|**Conexão DB**|Configuração visual|application.properties|
|**Processamento**|Steps/Transformations|Services/Repositories|
|**HTTP Requests**|REST Client Step|WebClient|
|**Agendamento**|Kitchen/Pan|@Scheduled|
|**Logs**|Arquivo de log|SLF4J/Logback|
|**Monitoramento**|Spoon IDE|Actuator endpoints|
|**Deploy**|Servidor Kettle|JAR executável|

### Benefícios da Migração

1. **Performance**: Processamento mais eficiente com WebClient reativo
2. **Manutenibilidade**: Código Java versionado e testável
3. **Monitoramento**: Métricas integradas com Spring Actuator
4. **Escalabilidade**: Pool de conexões otimizado
5. **Deploy**: JAR autocontido, deploy simplificado

---

## 📊 Métricas e Performance

### Indicadores de Performance

- **Throughput**: ~5000 registros/lote em produção
- **Latência**: ~90s timeout por requisição
- **Concurrent Requests**: 10 requisições simultâneas
- **Success Rate**: >95% em condições normais

### Monitoramento com Actuator

```properties
management.endpoints.web.exposure.include=health,info,metrics,prometheus
management.endpoint.health.show-details=when-authorized
management.metrics.enable.jvm=true
```

### Endpoints de Métricas

- **Health**: `/actuator/health`
- **Metrics**: `/actuator/metrics`
- **Info**: `/actuator/info`
- **Prometheus**: `/actuator/prometheus`

---

## 🚨 Troubleshooting

### Problemas Comuns

#### 1. Timeout de Conexão

```
Causa: Rede lenta ou sobrecarga da API
Solução: Aumentar api.juvo.timeout e api.juvo.read-timeout
```

#### 2. Pool de Conexões Esgotado

```
Causa: Muitas conexões simultâneas
Solução: Ajustar spring.datasource.hikari.maximum-pool-size
```

#### 3. Falha de Processamento em Lote

```
Causa: Batch size muito grande
Solução: Reduzir app.batch-size
```

#### 4. JSON Malformado

```
Causa: Dados inválidos na coluna JSON
Solução: Validar dados na origem ou implementar sanitização
```

### Comandos de Diagnóstico

```bash
# Verificar logs em tempo real
tail -f logs/api-integration.log

# Verificar status da aplicação
curl http://localhost:8080/actuator/health

# Verificar estatísticas
curl http://localhost:8080/api/integration/stats

# Forçar processamento manual
curl -X POST http://localhost:8080/api/integration/process
```

---

## 🔐 Segurança

### Configurações de Segurança

1. **Senhas**: Armazenadas em application.properties (considerar externalização)
2. **CORS**: Configurado para aceitar todas as origens (revisar para produção)
3. **Endpoints**: Expostos sem autenticação (considerar Spring Security)

### Recomendações

- Implementar Spring Security para endpoints sensíveis
- Externalizar senhas usando Spring Cloud Config
- Configurar CORS mais restritivo
- Implementar rate limiting
- Adicionar logs de auditoria

---

## 📚 Referências

### Documentação Técnica

- [Spring Boot Reference](https://docs.spring.io/spring-boot/docs/current/reference/html/)
- [Spring Data JPA](https://docs.spring.io/spring-data/jpa/docs/current/reference/html/)
- [Spring WebFlux](https://docs.spring.io/spring-framework/docs/current/reference/html/web-reactive.html)
- [Oracle JDBC Driver](https://docs.oracle.com/en/database/oracle/oracle-database/21/jjdbc/)

### Links Úteis

- **API Juvo**: `http://integracao.juvo.com.br/api-itemcoberto`
- **Swagger/OpenAPI**: (se disponível)
- **Monitoramento**: `/actuator/health`

---

## 👥 Equipe e Contatos

### Responsáveis

- **Desenvolvimento**: Equipe de Integração
- **Infraestrutura**: Equipe de DevOps
- **Database**: DBA Oracle

### Suporte

- **Ambiente**: São Paulo, SP, Brasil (GMT-3)
- **Horário**: Segunda a Sexta, 8h às 18h
- **Emergências**: 24/7 para ambiente de produção

---

_Última atualização: 08 de Agosto de 2025_





