---
type: livro
fonte: Google Play Livros - Ebook
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor:: J.J Benitez
Status:: #nao-iniciado  
páginasLidas:: 0
Páginas:: 472
Genero:: #ficção #religioso
data_inicio::
data_conclusao:
Nota:: 7/10
Capa:: https://images.dlivros.org/J-J-Benitez/dia-relampago-benitez_large.webp

A Operação Cavalo de Troia terminou, mas o que de fato aconteceu com o Major quando retornou a 1973? O que é a 'Raio Negro'? O general Curtiss foi realmente um traidor? Eliseu morreu com a queda do 'berço' no mar Morto ou ele arrumou uma maneira de retornar ao tempo de Jesus? Como os famosos diários do Major entraram para a posteridade? Ao ler O dia do relâmpago, você viverá 101 dias trepidantes. E, mesmo que tente, jamais conseguirá imaginar o que acontecerá em 29 de agosto de 2027... Com este livro, você 'viverá o não vivido'.