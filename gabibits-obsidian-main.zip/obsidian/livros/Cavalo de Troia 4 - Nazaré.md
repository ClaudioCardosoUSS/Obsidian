---
type: livro
fonte: Google Play Livros - Ebook
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor:: J.J Benitez
Status:: #andamento 
páginasLidas:: 10
Páginas:: 356
Genero:: #ficção #religioso
data_inicio::30/05/2025
data_conclusao:
Nota:: 7/10
Capa:: https://images.dlivros.org/J-J-Benitez/nazare-operacao-cavalo-troia-4-benitez_large.webp

Mais uma vez, a audácia de J. J. Benítez materializa um capítulo ausente dos Evangelhos e conta a história de Jesus de Nazaré quando jovem adolescente. No quarto volume dessa excepcional série, o major apresenta uma investigação sobre os "anos ocultos" de Jesus Cristo, o período dos quatorze aos vinte anos que foi totalmente ignorado pelos evangelistas.

Cavalo de Tróia 4 narra a vida de Jesus Cristo dos quatorze aos vinte e seis anos, os chamados "anos ocultos" do Mestre, decisivos para entender a experiência humana do Filho do Homem. O cenário é a aldeia de Nazaré e seus habitantes, onde o Galileu passou grande parte de sua vida e onde descobriu sua verdadeira missão na terra e sua natureza divina.  
Aos quinze anos, após a morte de José, seu pai terreno, o jovem Jesus assume a responsabilidade de um chefe de família, cumprindo seu papel como primogênito. Um adolescente que não se intimidou diante da sábia, embora incompreensível violência do destino, que o apresentou a inúmeras situações, como a morte de José e a do irmão Amós, ainda muito criança. Mas o jovem artesão amava seu trabalho e mantinha a numerosa família – a mamãe Maria e os oito irmãos – como o pai o fazia.  
Foram trinta e seis anos de vida, dos quais pouco se sabia. Mas, como filho de um Deus, Jesus imaginou e brincou como um menino, sofreu e se rebelou como um adolescente, trabalhou e se angustiou como um trabalhador sem fortuna e, finalmente, aceitou corajosamente o papel de "revelador de seu Pai". Quem pode duvidar da experiência humana do Filho do Homem?