---
type: livro
fonte: Google Play Livros - Ebook
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor:: J.J Benitez
Status:: #concluido 
páginasLidas:: 419
Páginas:: 419
Genero:: #ficção #religioso
data_inicio::24/08/2023
data_conclusao:28/05/2024
Nota:: 7/10
Capa:: https://images.dlivros.org/J-J-Benitez/saidan-operacao-cavalo-troia-3-benitez_large.webp

Cavalo de Tróia 3', J. J. Benítez transcreve a terceira parte do Diário do Major, que narra as novas aparições do Mestre a seus discípulos na praia de Saidan, às margens do Tiberíades, com a análise do Corpo Glorioso, o misterioso corpo ressuscitado do rabi. É revelada sua infância e adolescência, suas primeiras brincadeiras, seu gosto pela música, pelo desenho e pelos animais. Assiste-se à morte de José, seu pai terreno, quando ele tinha apenas 14 anos, e como então ele precisou assumir o posto de chefe da família, um papel destinado ao primogênito.