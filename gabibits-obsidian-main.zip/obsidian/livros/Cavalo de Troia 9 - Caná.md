---
type: livro
fonte: Google Play Livros - Ebook
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor:: J.J Benitez
Status:: #nao-iniciado  
páginasLidas:: 0
Páginas:: 1040
Genero:: #ficção #religioso
data_inicio::
data_conclusao:
Nota:: 7/10
Capa:: https://images.dlivros.org/J-J-Benitez/cana-operacao-cavalo-troia-09-benitez_large.webp

Neste último volume, a Operação parte da aldeia de Caná, na Galileia, o local onde o Mestre realizou seu primeiro milagre, transformando água em vinho. Esse é um dos eventos narrados no livro a partir da perspectiva do Major, Jasão. Ele conta também como os 12 apóstolos foram escolhidos por Jesus e como era o verdadeiro temperamento de cada um deles, além de mostrar em detalhes a relação entre Jesus e seus familiares e como foi o triste fim de João Batista. Com um final bastante comovente, o livro continua passando uma mensagem que vai permitir inúmeras reflexões por parte dos leitores.