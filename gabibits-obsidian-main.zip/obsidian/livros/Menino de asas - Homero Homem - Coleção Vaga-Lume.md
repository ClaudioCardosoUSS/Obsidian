---
type: livro
fonte: Amazon Books
tags:
  - obsidian/livros
---

Tópico:: #Livro  #Kindle


Autor:: Homero Homem
Status:: #andamento 
páginasLidas:: 0
Páginas:: 80
Genero:: Ficção, Aventura, Infantil e Infantojuvenil
data_inicio:: 
data_conclusao: 
Nota:: 4,5/10
Capa:: http://rubens1.files.wordpress.com/2011/01/livro-homero-homem-6.jpg

Este livro pertence à Série Vaga-lume. Sua primeira edição aconteceu no início da década de 197. O jornalista Homero Homem (1921-1991) conta a história de um menino que nasceu com asas em lugar de braços. Até os sete anos, numa cidade do interior, ele viveu em casa com os pais, sem contato com outras pessoas. Mas quando teve de ir à escola, sofreu a rejeição dos pais dos outros alunos que exigiram que ele saísse da escola ou que se lhe cortasse as asas. Assim, ele teve de ter aulas particulares. Quando já crescido, vai para o Rio de Janeiro a fim de procurar trabalho. E sofre uma nova onda de preconceitos e perseguições, mas encontra também amizade e amor. É um história que fala sobre a precariedade da vida, a violência e as marginalizações nas grandes cidades além dos oportunismos da imprensa.

Cansado da discriminação de sua pequena cidade, um **menino** que tem **asas** no lugar dos braços se muda para uma cidade grande, disposto a vencer a rejeição. Nesse percurso, cheio de contratempos e aventuras, ele descobre a amizade dos meninos de rua.
