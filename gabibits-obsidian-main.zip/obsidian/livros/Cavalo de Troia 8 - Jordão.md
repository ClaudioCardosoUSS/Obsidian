---
type: livro
fonte: Google Play Livros - Ebook
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor:: J.J Benitez
Status:: #nao-iniciado  
páginasLidas::0
Páginas:: 463
Genero:: #ficção #religioso
data_inicio::
data_conclusao:
Nota:: 7/10
Capa:: https://images.dlivros.org/J-J-Benitez/operacao-cavalo-troia-8-jordao-benitez_large.webp

Dando continuidade à coleção 'Operação Cavalo de Tróia', sucesso entre os amantes de aventura, em 'Cavalo de Tróia 8', J. J. Benítez consegue se superar a cada página. Ninguém, até hoje, narrou com tantos detalhes o suposto batismo de Jesus de Nazaré. Assim como ninguém havia se atrevido a relatar, com semelhante crueza, o que aconteceu naquela histórica jornada em um dos afluentes do rio Jordão. Você sabia que o Mestre nunca se retirou para o deserto e nem foi tentado pelo diabo?