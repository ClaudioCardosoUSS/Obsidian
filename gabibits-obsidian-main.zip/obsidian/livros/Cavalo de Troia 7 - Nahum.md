---
type: livro
fonte: Google Play Livros - Ebook
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor:: J.J Benitez
Status:: #nao-iniciado  
páginasLidas:: 0
Páginas:: 216
Genero:: #ficção #religioso
data_inicio::
data_conclusao:
Nota:: 7/10
Capa:: https://images.dlivros.org/J-J-Benitez/operacao-cabalo-troia-07-benitez_large.webp

  
O sétimo volume da consagrada série Operação Cavalo de Tróia narra os preparativos da vida pública de Jesus de Nazaré e desmistifica personagens fundamentais como Virgem Maria e Judas, que não entendiam a missão de Jesus e esperavam dele um homem revolucionário, o Messias que iria libertar o povo judeu dos Romanos. Descreve quem foi de fato o revolucionário João Batista, pregador de um deus vingativo e cruel, tão diferente do Deus Pai de Jesus. Revela ainda para quem foi feito o anúncio de seu nascimento, se operava milagres, se realmente foi o Anunciador de Jesus e se era um louco.

A obra trata da ação anulatória da sentença arbitral doméstica como importante mecanismo de equilíbrio entre o judiciário e arbitragem, bem como de preservação das garantias fundamentais das partes. Dentre os principais temas relativos ao objeto do estudo, após a análise preliminar do sistema arbitral, bem como do exercício de poder jurisdicional pelos árbitros e as suas consequências, três tópicos são destacados para análise aprofundada: a preservação das garantias fundamentais do processo em contraposição à flexibilidade do procedimento arbitral; o controle da violação à ordem pública; e os limites da atuação judicial na análise da demanda anulatória. A autora busca subsídios no direito comparado, analisando o sistema de quatro países de culturas diferentes no que tange ao controle judicial da arbitragem (portugal, frança, inglaterra e estados unidos). Por fim, os temas escolhidos são analisados à luz da doutrina e jurisprudência brasileiras, com inserções colhidas do estudo do direito comparado a fim de bem analisar a problemática.