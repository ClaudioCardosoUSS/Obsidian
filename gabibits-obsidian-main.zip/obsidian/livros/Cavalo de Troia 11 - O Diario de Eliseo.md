---
type: livro
fonte: Google Play Livros - Ebook
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor:: J.J Benitez
Status:: #nao-iniciado  
páginasLidas:: 0
Páginas:: 816
Genero:: #ficção #religioso
data_inicio::
data_conclusao:
Nota:: 7/10
Capa:: https://cdn.kobo.com/book-images/7c8733d5-ff2e-4ed6-a5c0-7ad0d79bf9ac/353/569/90/False/el-diario-de-eliseo-caballo-de-troya-11.jpg

O livro que resolverá todos os enigmas de uma das sagas mais vendidas da história: Cavalo de Troia. Saga Cavalo de Troia 11. Eliseu, segundo piloto da operação secreta Cavalo de Troia, se une ao grupo do Mestre e os acompanha durante dois anos e três meses, assistindo a conversas e prodígios que não constam nos textos evangélicos. Mas sua verdadeira missão é outra. Advertência: algumas cenas podem ferir sua sensibilidade. Se você leu Cavalo de Troia, O diário de Eliseu o deixará atônito.