---
type: livro
fonte: Google Play Livros - Ebook
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor:: Zeno Rocha
Status:: #em-progresso 
páginasLidas:: 56
Páginas:: 135
Genero:: #progração #desenvolvimento-pessoal
data_inicio::
data_conclusao:
Nota:: 8/10
Capa:: https://m.media-amazon.com/images/I/41Xkqy2rMDL.jpg