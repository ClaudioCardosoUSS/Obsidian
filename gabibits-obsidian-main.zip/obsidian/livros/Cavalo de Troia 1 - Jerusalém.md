---
type: livro
fonte: Google Play Livros - Ebook
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor:: J.J Benitez
Status:: #concluido 
páginasLidas:: 822
Páginas:: 822
Genero:: #ficção #religioso
data_inicio::15/07/2023
data_conclusao:24/08/2023
Nota:: 9/10
Capa::https://images.dlivros.org/J-J-Benitez/jerusalem-operacao-cavalo-troia-1-benitez_large.webp

Conta a historia dos últimos suplícios de Jesus.
Historia rica em detalhe e com uma narrativa dinâmica e com muitos apêndices de detalhes minuciosos.

Em 1980, J.J.Benítez foi contactado por um Major da Força Aérea dos Estados Unidos que dizia ter em seu poder um documento ultra-secreto. Foi só depois de ter ganho a confiança do oficial que o escritor recebeu uma série de indicações enigmáticas que o levou aos manuscritos do Diário do Major.  
Cavalo de Tróia 1 é a transcrição da primeira parte desse documento que mudou a história. O misterioso norte-americano relata em seus escritos os detalhes de uma operação secreta dos EUA, que, em 1973, transportou dois astronautas à Palestina de Jesus de Nazaré. O objetivo era bastante claro: conhecer em primeira mão a vida, a obra e o pensamento do Filho do Homem.  
Os protagonistas desta viagem são Eliseu, um piloto que durante os "saltos" ao passado permanece quase o tempo todo no módulo espacial instalado no monte das Oliveiras, e Jasão - o próprio Major -, que se torna testemunha ocular da Vida, Paixão, Morte, Ressurreição e "Ascensão" do Galileu.  
J.J.Benítez complementa a volumosa documentação deixada pelo Major com vasto material de pesquisa. A transcrição, por enquanto, está dividida em oito volumes, somando 4.500 páginas, com um total de 1.227 notas de rodapé, 14 mil fontes e mais de 3 mil informações sobre o Mestre. Esses números fazem da série Cavalo de Tróia a maior obra sobre a vida de Jesus de Nazaré, apresentado da forma mais humana e completa já realizada.