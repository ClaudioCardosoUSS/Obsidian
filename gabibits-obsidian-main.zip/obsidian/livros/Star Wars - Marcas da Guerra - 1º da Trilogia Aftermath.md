---
type: livro
fonte: Amazon Books - Kindle
tags:
  - obsidian/livros
---

Tópico:: #Livro  #Kindle


Autor:: Chuck Wendig
Status:: #andamento 
páginasLidas:: 220
Páginas:: 464
Genero:: Ficção, Aventura
data_inicio:: 15/11/2024
data_conclusao: 
Nota:: 4,5/10
Capa:: https://nerdaocubo.com.br/cdn/shop/files/swm.png?v=1684950890&width=900

O que aconteceu depois da destruição da segunda Estrela da Morte? Qual o destino dos remanescentes do Império Galáctico e dos antigos Rebeldes, agora responsáveis pela fundação da Nova República? Marcas da guerra é o primeiro livro do cânone oficial a mostrar o que acontece depois do clássico Episódio VI: O retorno de Jedi, dando pistas sobre o que podemos esperar da nova trilogia que se inicia com o O despertar da Força, a ser lançado nos cinemas em dezembro. Nesse novo panorama galáctico, vamos descobrir que a guerra ainda não chegou ao fim... e que os traumas deixados por ela ainda serão sentidos por muitos e muitos ciclos. Capitão Wedge Antilles, almirante Ackbar, almirante Sloane, o garoto Temmin e a mãe, Norra Wexley, a caçadora de recompensas Jas Emari, o antigo agente imperial Sinjir: novos personagens e velhos conhecidos dos amantes da saga, que sempre estiveram envolvidos na luta, agora devem escolher o lado a que deverão jurar lealdade. Deverão colocar-se ao lado da Nova República, procurando estabelecer um novo governo democrático na galáxia? Ou juntar-se às fileiras imperiais, na tentativa de voltar ao poder absoluto depois das mortes dos lordes Sith Palpatine e Darth Vader?