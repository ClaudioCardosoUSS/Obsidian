---
type: livro
fonte: Google Play Livros - Ebook
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor:: J.J Benitez
Status:: #concluido 
páginasLidas:: 608
Páginas:: 608
Genero:: #ficção #religioso
data_inicio::24/08/2023
data_conclusao:15/10/2023
Nota:: 8/10
Capa::https://images.dlivros.org/J-J-Benitez/massada-operacao-cavalo-troia-2-benitez_large.webp


Cavalo de Tróia 2 é a transcrição da segunda parte do Diário do Major da Força Aérea dos Estados Unidos a que J. J. Benítez teve acesso com exclusividade em 1980. Jasão - o próprio Major - e seu co-piloto Eliseu voltam à Palestina de Jesus de Nazaré no ano 30 de nossa era como parte da operação ultra-secreta batizada de Cavalo de Tróia.  
Partindo da meseta de Massada, ao sul de Israel, dessa vez os astronautas assistem às aparições de Jesus depois da Ressurreição, testemunham o desespero dos discípulos após a morte do Mestre e descobrem inúmeros fatos omitidos pelos quatro evangelistas.  
Entre as revelações impressionantes de Cavalo de Tróia 2, está a do conteúdo da gravação realizada durante a Última Ceia de Jesus com seus discípulos. As palavras do Galileu foram registradas como proferidas naquele dia que ficou marcado para sempre. Mas o testemunho do Major não se esgota aí e traz detalhes do casamento de Maria e José, do nascimento de Jesus e de sua relação com seus oito irmãos.  
J.J.Benítez complementa a volumosa documentação deixada pelo Major com vasto material de pesquisa. A transcrição, por enquanto, está dividida em oito volumes, somando 4.500 páginas, com um total de 1.227 notas de rodapé, 14 mil fontes e mais de 3 mil informações sobre o Mestre. Esses números fazem da série Cavalo de Tróia a maior obra sobre a vida de Jesus de Nazaré, apresentado da forma mais humana e completa já realizada.

Conta a historia sobre a ressureição de Jesus, últimos relatos da Santa Ceia, Santo Sudário, Entrevista com Maria, e Problemas de saúde relacionados a viagem no tempo. "Cavalo de Troia 2 – Massada: você sabia, por exemplo, que na chamada “última ceia” muitas das palavras do Galileu foram manipuladas e ignoradas pelos sucessores de São Pedro? Sabia que as aparições do Mestre depois de sua ressurreição foram mais numerosas que as relatadas pelos Evangelhos? Imaginava que Maria, a mãe do Filho do Homem, teria sido qualificada hoje como “nacionalista”?