---
type: livro
fonte: Google Play Livros - Ebook
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor:: J.J Benitez
Status:: #nao-iniciado  
páginasLidas:: 0
Páginas:: 500
Genero:: #ficção #religioso
data_inicio::
data_conclusao:
Nota:: 7/10
Capa:: https://http2.mlstatic.com/D_NQ_NP_2X_674273-CBT75689099724_042024-F.webp

  
No sexto volume da série, entre milhares de dados técnicos e históricos rigorosamente comprovados, descobre-se que Jesus, depois de sua morte e Ressurreição, apareceu perante centenas de testemunhas em dezenove ocasiões, muitas mais do que as aceitas pela Igreja Católica. A suspeita do autor é que algo semelhante tenha ocorrido quanto à sua vida pública. Operação Cavalo de Tróia 6 apresenta a terceira viagem no tempo de Jasão e Eliseu, um novo salto que os situa na Palestina de agosto do ano 25, o tempo e o lugar do começo da pregação.