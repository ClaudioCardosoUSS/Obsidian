---
type: livro
fonte: Google Play Livros - Ebook
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor:: J.J Benitez
Status:: #nao-iniciado  
páginasLidas:: 0
Páginas:: 288
Genero:: #ficção #religioso
data_inicio::
data_conclusao:
Nota:: 7/10
Capa:: https://http2.mlstatic.com/D_NQ_NP_2X_634055-MLB79718910938_102024-F-belen-caballo-de-troya-12-de-j-j-benitez-editorial-boo.webp

Belén, J. J. Benítez termina a série Cavalo de Troia. Uma aventura literária que começou em 1984 com a publicação do primeiro volume

Caná. Cavalo de Troia 9 foi publicado em 2011, mas incompleto. Por razões técnicas, algumas das páginas do diário do major da USAF foram retiradas pela editora. Agora são publicadas em sua totalidade. Durante seis meses -- entre abril e outubro do ano 27 da nossa era -- Jesus foi obrigado a fugir para não ser capturado pelo Sinédrio. O que aconteceu nesse tempo? Não perca... Irá surpreendê-lo e emocioná-lo. Uma nova e emocionante entrega da série que conquistou milhões de leitores em todo o mundo.