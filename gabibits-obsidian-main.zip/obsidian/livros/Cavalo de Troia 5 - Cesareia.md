---
type: livro
fonte: Google Play Livros - Ebook
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor:: J.J Benitez
Status:: #nao-iniciado  
páginasLidas:: 0
Páginas:: 344
Genero:: #ficção #religioso
data_inicio::
data_conclusao:
Nota:: 7/10
Capa:: https://images.dlivros.org/J-J-Benitez/cesareia-operacao-cavalo-troia-5-benitez_large.webp

No quinto volume, Benítez corajosamente abre a porta do mundo sobre o qual os evangelistas evitaram falar, descrevendo as aparições de Jesus Cristo após a ressurreição.

Em 1973, numa operação ultrassecreta chamada Cavalo de Troia, dois astronautas voltaram no tempo e presenciaram a Vida, Paixão, Morte, Ressurreição e 'Ascensão' de Jesus de Nazaré. Nessa emocionante viagem, o leitor é transportado à Palestina do ano 30 e compartilha todos os riscos e os intrincados e incríveis acontecimentos, como testemunha ocular dessa grande aventura que envolve a verdadeira história do Mestre. Em Cavalo de Troia 5, J. J. Benítez segue a transcrição do Diário do Major da Força Aérea dos Estados Unidos. Jasão o Major , enterrado vivo, consegue libertar-se e retoma sua missão em Nazaré e depois ruma à Cesareia para reencontrar o governador romano Pôncio Pilatos. O objetivo é aprofundar-se na perturbada personalidade do carrasco de Jesus de Nazaré, o homem que julgou e mudou o rumo dos acontecimentos para sempre... E em sua terceira aparição na Galileia, o Mestre rememora sua mais importante mensagem: 'Amai aos homens com o mesmo amor com que vos amei. E servi vossos semelhantes como eu os servi. Servi a eles com o exemplo... e ensinai os homens com os frutos espirituais de vossa vida. Ensinai-lhes a grande verdade... Levai-os a crer que o homem é um filho de Deus... um filho de Deus! O homem é um filho de Deus e todos, portanto, sois irmãos... Meu amor vos envolverá. Meu Espírito e minha Paz reinarão sobre vós. Que a paz seja convosco.