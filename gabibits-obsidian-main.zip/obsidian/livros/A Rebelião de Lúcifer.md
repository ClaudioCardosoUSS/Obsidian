---
type: livro
fonte: Google Play Livros - Ebook
tags:
  - obsidian/livros
---

Tópico:: #Livro  


Autor:: J.J Benitez
Status:: #concluido 
páginasLidas:: 753
Páginas:: 753
Genero:: #ficção #religioso
data_inicio::18/10/2023
data_conclusao:19/12/2023
Nota:: 5/10
Capa:: https://images.dlivros.org/J-J-Benitez/rebeliao-lucifer-benitez_large.webp

  
“Aprendamos a sonhar, senhores, e então, pode ser que encontre¬mos a Verdade.” Essa recomendação lapidar do insigne químico alemão Kekulé, que chegou ao descobrimento da fórmula do benzeno graças a um sonho, revolucionando assim a química orgânica, acabou por convencer-me de que, na vida, a Verdade passa muitas vezes ante os seres humanos…disfarçada. Ou talvez porque os inimigos da Verdade sejam ainda tão numerosos que chegam a nublar a face da Terra, elegi para Rebelião de Lúcifer a intangível e arcana roupagem da fantasia. Só aqueles que não tenham perdido a capacidade de sonhar poderão compreender-me. Nesse caso, como eu, talvez descubram através dos sonhos algumas das múltiplas faces dessa surpreendente Verdade. **Rebelião de Lúcifer - J. J. benítez**

Faz uma mesclagem sobre uma historia ficticia  e o Livro de Urantia, conta em detalhes O universo do 
Mundo Celestial e o Julgamento de Lucifer (tem uma visão revolucionaria e não de trevas como é contado
no nosso muito atual. Lucifer nunca teve envolvimento com a decadencia de nosso planeta.
achei que este livro enrolou demais em alguns pontos, deixando a leitura cansativa.
Detalhou muito como funciona o universo celestial, ficando meio confuso o erredo deste livro.
O Final deixou um pouco a desejar, lembrando que há ainda muita coisa por vir neste enigmatico livro.
Livro de #Urantia
