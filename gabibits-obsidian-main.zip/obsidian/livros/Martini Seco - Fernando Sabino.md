---
type: livro
fonte: PDF, Epub
tags:
  - obsidian/livros
---

Tópico:: #Livro  #Kindle


Autor:: Fernando Sabino
Status:: #concluido  
páginasLidas:: 64
Páginas:: 64
Genero:: Drama, Policial
data_inicio:: 15/03/2025
data_conclusao: 16/03/2025
Nota:: 5/10
Capa:: https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjNi4rM1bQar0WttFypkqDR3hel0lySWc870xhfKm6PpJCeuyl7cKo5sv0eZNz3QLeu3rEt2TFNISBgoxiO07towxx5WEnPImgxT233yOj_YH2XAmXGDO96uhgXQ3NQ2dAkqOxAyHQpsYzQ/s1600/MARTINI_SECO_1244488479B.jpg

Recentemente passei por uma ressaca literária, e para o meu azar, não consegui iniciar leitura alguma, então, fui a Biblioteca Municipal de minha cidade em busca de alguma obra que me despertasse interesse. Depois, de quase uma hora vasculhando o acervo da biblioteca encontrei "Martini Seco", um livro fininho, mas que prometia uma bela história policial recheada de bom humor e de final surpreendente, logo, ele foi o escolhido, e além de me proporcionar uma leitura agradável ele ainda curou a minha ressaca.  
     A história se inicia quando um casal entra num bar, sentam-se na mesa e pedem dois martinis. Logo em seguida a mulher, Carmem, vai ao telefone e o homem, Amadeu, ao toalete, quando retornam, Carmem toma a sua bebida e cai morta no chão. No meio do caos, a polícia chega e se inicia a investigação, de início, pensam ser suicídio, pois, foi encontrado uma dose mortal de estricnina na bebida da mulher, mas, ao desenrolar dos fatos o marido, Amadeu, se torna o principal suspeito, chegando até a ser preso, porém, não encontraram nenhuma prova e ele foi absolvido da acusação.  
  
     Cinco anos depois, Maria, segunda esposa de Amadeu Miraglia, vai a delegacia apresentar queixa contra o marido, alegando que ele pretende a envenenar, como fez com a outra. Por sua vez, Amadeu nega tudo no interrogatório e acrescenta ainda que Maria pretende se suicidar para botar a culpa nele. Para se decidir de quem diz a verdade, o comissário, decide fazer uma reconstituição do que aconteceu cinco anos atrás, e assim, começa a trama policial de "Martini Seco", onde várias hipóteses são levantadas a fim de encerrar o caso Miraglia.
      "Martini Seco" é um livro que pode muito bem ser lido em apenas uma hora, mas, isso não o deixa menos digno, pelo contrário, achei fantástica a forma que o autor conduziu a história, mesclando comédia com o romance policial clichê. Quando iniciei a leitura ouvi muitos comentários sobre o final, e na minha humilde opinião, achei tão inusitado e tão surpreendente que ainda não consegui decidir se gostei ou não dele.  
   Durante a leitura é impossível não criar hipóteses do que aconteceu no bar: Amadeu matou Carmem? Carmem tentou matar Amadeu, mas morreu por engano? Será que o garçom tem culpa? Taças Trocadas? Enfim... Todo esse suspense criado por Fernando Sabino me agradou muito, tanto que fiquei presa á história do início ao fim e só larguei o livro quando cheguei na última página.  
   "Martini Seco" é mais um exemplo de livros policiais no estilo quebra cabeça, onde naturalmente imaginamos mil e uma possibilidades de desfecho. E se você quer saber quem matou Carmem  e se Maria é realmente uma vítima... Vá ler o livro!  
    Leitura mais que recomendada!