---
type: HQ-Comics
fonte: Amazon Books - Kindle
tags:
  - obsidian/livros
---

Tópico:: #Livro  #Kindle


Autor:: Neil Gaiman
Status:: #concluido  
páginasLidas:: 175
Páginas:: 175
Genero:: Ficção, Aventura
data_inicio:: 19/01/2024
data_conclusao: 10/02/2024 
Nota:: 4,8/10
Capa:: https://rocco.com.br/app/uploads/2022/12/9786555320633.jpg

Ninguém Owens, também chamado de Nin, é um garoto normal. Ele seria totalmente normal se não morasse em um cemitério, não fosse criado por fantasmas, nem tivesse um guardião que não pertence ao mundo dos vivos nem dos mortos.

Há aventuras para ele no cemitério – um antigo homem anil, um portal para a cidade abandonada dos ghouls, o horrível e estranho executor. No entanto, se sair do cemitério, não estará protegido do homem chamado Jack – que matou a família de Nin.

Cada capítulo nesta adaptação de P. Craig Russell é ilustrado por um astro diferente do mundo dos quadrinhos, apresentando uma variedade de estilos de uma grande gama de artistas. Juntos, eles dão nova vida ao romance best-seller e premiado O livro do cemitério, escrito por Neil Gaiman, nesta adaptação em quadrinhos lindamente ilustrada, dividida em dois volumes.

O Volume Um vai do Capítulo Um ao Interlúdio e o Volume Dois vai do Capítulo Seis ao fim.

O Volume Dois contém ilustrações de:  
  
Capítulo 6 - David Lafuente  
  
Capítulo 7 - Scott Hampton  
  
Capítulo 8 - P. Craig Russell, Kevin Nowlan e Galen Showman

*A Editora Rocco informa que o e-book em questão foi produzido em formato layout fixo e, portanto, sua leitura é recomendada apenas para tablets. A editora recomenda o download da amostra antes da compra, para garantir compatibilidade entre device e e-book.