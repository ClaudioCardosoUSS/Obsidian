---
type: "9"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
fonte_curso: https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql
Url_video_curso: https://cursos.alura.com.br/extra/alura-mais/como-instalar-o-mysql-no-linux-c1158
---

Tópico:: #MySQL #DataBase
- Saiba instalar e acessar o banco de dados MySQL
- Realize consultas com SELECT e filtre com WHERE
- Adicionando dados no banco com o INSERT
- Atualize e apague dados com UPDATE e DELETE
- Estruture suas tabelas com CREATE TABLE e ALTER TABLE

- Conhecemos um pouco da história do SQL como linguagem de banco de dados relacional;
- Vimos um pouco da história e características do banco de dados MySQL;
- Aprendemos a instalar o MySQL e o Workbench.

- A acessar e navegar pelo Workbench;
- A criar um banco de dados por linha de SQL ou pelo assistente;
- Como apagar um banco de dados por linha de SQL ou pelo assistente;
- Como acessar uma tabela por linha de comando ou pelo assistente;
- Os tipos de dados que compõem uma tabela;
- Como criar uma tabela, tanto por script como por assistente;
   - Como apagar uma tabela.

Nesta aula, aprendemos:

- Aprendemos a incluir dados em uma tabela, de diversas formas;
- Vimos como alterar um dado já existente na tabela;
- Vimos como apagar uma linha da tabela;
- Conhecemos a importância das chaves primárias e o cuidado que devemos ter ao criá-las;
- Aprendemos a manipular campos do tipo lógicos e do tipo date.

- Como visualizar os dados de uma tabela;
- Como segregar a seleção de dados;
- A usar as condições de maior e menor na seleção de dados da tabela;
- Como filtrar dados através de datas.
- Como implementamos filtros compostos.
-----------------------------------------------------------------------

https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54321

## Transcrição

Boas-vindas! Me chamo Victorino Vila e serei o instrutor do curso de **SQL com MySQL: manipule e consulte dados.**

Para alinharmos as suas expectativas referente a esse treinamento, o nosso principal objetivo é apresentar o SQL para quem nunca teve contato antes. Por isso, abordaremos vários conceitos, mas sem nos aprofundar muito em cada um deles.

Isso por termos como propósito apresentar, para quem nunca viu banco de dados ou usou SQL, o primeiro contato com a ferramenta e também com o conceito da linguagem.

Aqui na plataforma Alura temos outro curso chamado [SQL Server: introdução ao SQL com Microsoft SQL Server 2017 neste link](https://cursos.alura.com.br/course/sql-com-sql-server-2017), que possui o mesmo treinamento que o curso que vamos realizar, com a diferença que este é para o banco MySQL.

Vamos iniciar esse treinamento efetuando o download e a instalação do MySQL. Vou contar um pouco também sobre o histórico do banco de dados, como surgiu, quais as principais características e vantagens, entre outros assuntos.

Iremos instalar os programas necessários e, para nos comunicar com o banco de dados, utilizaremos uma IDE, do inglês _Integrated Development Environment_ (ambiente de desenvolvimento integrado), que é uma interface gráfica da própria MySQL chamada MySQL _Workbench_.

Dentro dessa interface, iremos aprender diversos conceitos da linguagem SQL, começando com como criar tabelas, compreendendo, por exemplo, o que é um campo, quais as categorias de campos que o MySQL suporta e o que é uma linha. Em seguida, vamos aprender como inserir, substituir e apagar os dados nas tabelas já criadas.

Após conhecermos todos esses processos de inclusão, alteração e exclusão de dados em tabelas, iremos aprender como consultá-los. A partir disso, vamos realizar uma carga de dados nas tabelas que estamos usando nesse curso e elaborar algumas seleções, sendo que essas podem ser simples ou de todos os campos. Também aprenderemos, por exemplo, a limitar essa seleção utilizando a cláusula _WHERE_.

Caso já conheça a linguagem SQL e gostaria de relembrar alguns conceitos, esse curso também é indicado. Mas se quiser se aprofundar mais, o recomendado é partir para os próximos cursos sobre esse tema, já que é deles em diante que vamos nos investigar mais sobre a manipulação, a consulta, como fazer programação e administrar o ambiente.

-----------------------------------------------------------------------
# Slides do curso

 [Próxima Atividade](https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/124582/next)

- [](https://cursos.alura.com.br/suggestions/new/mysql-manipule-dados-com-sql/124582/question)

Boas-vindas!

Tudo pronto para começar o curso **SQL com MySQL: manipule e consulte dados** da Alura?

Para melhor acompanhamento dos vídeos, atividades e poder retomar o aprendizado adquirido após conquistar o certificado de conclusão da Alura ao final deste curso, no link a seguir você pode [fazer download dos slides do curso](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/01/Apresentacao_INTROD_MYSQL.pptx).

https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/01/Apresentacao_INTROD_MYSQL.pptx

-----------------------------------------------------------------------
História do SQL
https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54322

## Transcrição

Vamos iniciar contando a história da linguagem SQL, para compreendermos quais foram os motivos, como surgiu e o seu histórico.

A linguagem SQL foi desenvolvida no começo dos anos 70, na cidade de São José, Califórnia, em um projeto chamado _System R_ da IBM, do inglês _International Business Machines_, cujo objetivo era comprovar a viabilidade da implementação de um modelo relacional, que um estudioso chamado Codd estava propondo.

Esse estudioso elaborou uma forma estruturada de realizar consultas nos bancos de dados que estavam surgindo, chamados “bancos de dados relacionais”.

Naquela época, os bancos de dados ainda não possuíam relacionamento entre as tabelas nas quais os dados eram armazenados. Era a categoria de banco de dados mais antigo, a sequencial, que efetuava a consulta dos registros de maneira sequencial, ou seja, um após o outro.

Com o surgimento dos bancos de dados relacionais (ou DBMS, do inglês, _Data Base Management System_, “Sistema de Gerenciamento de Banco de Dados"), Codd considerou criar uma linguagem que facilitasse a extração e manipulação de dados, além da manipulação das estruturas desse banco aproveitando a característica de relacionamento entre eles.

Porém, não era apenas a IBM que estava trabalhando com os novos bancos de dados relacionais. Por volta dos anos 80, a Oracle, dentre outras empresas, também estava buscando maneiras mais fáceis de manipular essas novas estruturas.

Mais para o final dos anos 80 e início dos 90, o órgão americano, o **ANSI** (da sigla _American National Standard Institute_), estabeleceu alguns padrões para as consultas dos bancos de dados relacionais.

Então, foi criada a linguagem _SQL_, do inglês _Structured English Query Language_, que traduzindo seria algo como “linguagem de consulta estruturada em inglês”. No inglês, geralmente, é pronunciado _SEQUEL_ e não SQL, soletrando as letras - diferentemente do português, em que normalmente lemos como “ésse quê éle”.

O principal objetivo da linguagem SQL é padronizar a maneira como os registros são consultados nos bancos de dados relacionais. Atualmente, os bancos relacionais aderem ao padrão SQL, que vai além das consultas: é usado também, na criação, alteração, estruturação e manipulação do banco de dados, além da maneira como banco de dados interage com a segurança, entre outros usos.

Entre as vantagens do banco de dados relacional, a primeira é que essa padronização utilizando a linguagem SQL tem um custo reduzido do **_aprendizado_**. Por exemplo, o profissional com conhecimento sobre o SQL da Oracle conseguirá manipular facilmente o MySQL ou SQL Server da Microsoft. Por mais que existam diferenças - principalmente na parte de funções -, a adaptação do profissional não é uma questão complicada.

Outra vantagem, é a **_portabilidade_**. Por exemplo, é mais simples migrar sistemas que usam Oracle para SQL Server ou para MySQL, ou vice-versa. Lembrando que quanto mais for utilizado o SQL Standard definido pelo ANSI, mais fácil será essa portabilidade no futuro. Então, é útil evitar as funções específicas do banco de dados e permitir que o programa realize essa tarefa.

Já a **_longevidade_** é a garantia de que os seus relatórios ou processos utilizando o SQL irão funcionar por um longo período, já que estarão sempre adaptados ao padrão ANSI. Ou seja, ao efetuar um upgrade de banco de dados o seu sistema não ficará fora de serviço.

Outro benefício é a **_comunicação_**. O fato da maioria utilizar SQL permite a facilidade de comunicação entre os sistemas. Como, por exemplo, processos de ETL, (_extract, transform and load_), ou de integração entre sistemas que ficam mais simples de serem desenvolvidos, já que ambos utilizam o SQL padrão.

Por último temos a **_liberdade de escolha_**. Por existir um padrão de linguagem, se a empresa for optar pelo uso de um banco de dados relacional não ficará presa à linguagem de comunicação, por exemplo, já que são bem semelhantes. Ao tomar essa decisão, a corporação irá utilizar outros critérios de escolha, como performance, hardware, custo, entre outros.

Contudo, essa padronização não possui apenas vantagens, há algumas desvantagens - ainda que poucas. A primeira é a privação da **_criatividade_**. O SQL possui limitações que podem não atender às novas demandas no mercado na linguagem SQL, principalmente com o surgimento das redes sociais e dos enormes volumes de dados, o chamado _big data_. Ou seja, há uma carência nas coletas de dados que estão trafegando na internet.

Para tal, estão surgindo outros bancos que usam padrões diferentes dos bancos de dados relacionais, o chamado _NoSQL_. Estes atendem de forma mais eficiente as demandas de tabelas de _big data_ , como no caso das redes sociais. Lembrando que estamos nos referindo a estruturas que escapam do padrão ANSI e que, por isso, exigem um aprendizado mais específico.

Outro ponto é a escassez de estruturação da linguagem SQL, já que ela não possui _if_, _for_ e _when_, isto é, comandos condicionais como as demais linguagens de programação.

Para conseguir suprir essa carência da estruturação, os bancos de dados relacionais da Oracle, SQL e MySQL criaram suas linguagens próprias internas que realizam esse conjunto de estruturação usando a linguagem SQL, mas que acaba se afastando um pouco do padrão ANSI.

Falando um pouco sobre o padrão ANSI, este possui três grupos de comandos. O primeiro, é o **_DDLs_**, ou _Data Definition Language_ (linguagem de definição de dados). Os DDLs são a parte da linguagem SQL que permite a manipulação das estruturas do banco de dados. Como, por exemplo, criar um banco, tabelas, índices, apagar as tabelas e alterar a política de crescimento de índice. Ou seja, os comandos que envolvem a estrutura do banco de dados relacionais são os comandos do tipo DDL.

O segundo grupo de comandos são os chamados **_DML_**, ou _Data Manipulation Language_ (linguagem de manipulação de dados). Esse grupo visa gerenciar os dados: incluindo, alterando e excluindo informações nas estruturas do banco, como as tabelas. Além disso, realizam as consultas, buscam as informações das estruturas e exibem para o usuário.

Finalmente, chegamos nos comandos **_DCL_**, ou _Data Control Language_ ("linguagem de controle de dados"). Este grupo nos permite administrar o banco de dados como, por exemplo, o controle de acesso, o gerenciamento do usuário, gerenciar o que cada usuário(a) pode ou não visualizar, gerenciar o banco ao nível de estrutura (como a política de crescimento, como e onde será armazenado no disco), administrar os processos, saber quantos processos estão sendo executados, controle de log e assim por diante.

Nesse vídeo quis mostrar uma visão geral para vocês, não somente a história do SQL, mas também as suas características, vantagens, desvantagens e comandos dessa linguagem.

-----------------------------------------------------------------------
História do MySQL
https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54323

## Transcrição

Agora, iremos entender sobre **a história do MySQL** e mencionar algumas de suas características.

Já conversamos um pouco sobre a história do SQL, quando os bancos relacionais estavam começando a ser popularizados. À época, três desenvolvedores, o David Axmark, Allan Larsson e Michael Widenius, buscaram elaborar uma interface SQL que fosse compatível com o que estava surgindo no mercado de banco de dados.

No início, eles utilizaram APIs de terceiros para efetuar os comandos SQL que buscavam informações de alguns outros bancos de dados de mercado. Porém, não obtiveram um retorno satisfatório e, por esse motivo, começaram a desenvolver sua própria API de consulta - e não apenas isso, também o seu próprio banco de dados, utilizando a linguagem C++.

Foi a partir disso que se iniciou o projeto MySQL. Ele se tornou bastante popular, primeiramente por ser apresentado como um software livre (_open source_), isto é, a comunidade teria acesso ao código-fonte para realizar alterações e contribuir com melhorias para o banco de dados. Além disso, se mostrou um banco de dados bastante ágil para a época, mais rápido que os concorrentes, além de apresentar um excelente mecanismo de multitarefas e de multiusuário.

Com isso, o MySQL mostrou que o seu servidor poderia ser usado e suportava bem a escalabilidade robusta em missão crítica, como, por exemplo, em um banco que nunca pode parar a operação dos serviços prestados.

> **Missão crítica:** todo sistema tecnológico fundamental para que os serviços de uma empresa continuem operando sem interrupções.

Como consequência, o MySQL se popularizou como software livre, inclusive de modo corporativo. No ano de 2008, o **MySQL AB**, empresa que gerenciava o código desse banco de dados, foi comprada por um bilhão de dólares por uma empresa chamada _Sun Microsystems_, uma empresa grande que a princípio atuava na área de hardware e depois começou a entrar para o ramo de software. Essa companhia também era responsável pela criação do Java.

Em 2009, após um ano da compra do MySQL, a _Sun Microsystems_ foi comprada pela Oracle, que passou a ter propriedade sobre todos os produtos. Por esse motivo, a Oracle é hoje dona do Java e do MySQL. Houve uma grande movimentação no mercado naquele tempo, já que a Oracle possuía o seu banco de dados relacional robusto e o MySQL estava se mostrando um concorrente à altura.

Quando o MySQL foi vendido, a comunidade _open source_ criou outro banco de dados, o **MariaDB**, que se tornou o sucessor em código aberto do MySQL.

Devido à sua popularidade, sendo uma opção de baixo custo para as empresas do mercado corporativo e de mercado online (que vinha crescendo bastante a partir dos 2009 e 2010), a Oracle manteve o desenvolvimento do MySQL.

A Oracle permitiu que os usuários pudessem escolher entre usar o programa como produto _open source_, sob os termos da licença GNU _(GNU's Not Unix!)_ ou comprar a licença padrão comercial do MySQL. Para esse último caso, a Oracle oferecia algumas vantagens para as empresas que comprassem o MySQL de forma corporativa, como suporte mais rápido e acesso à alguma documentação específica.

Porém, a licença oferecida de forma aberta ainda mantém a eficiência e características apresentadas antes do MySQL ser comprado por essas empresas gigantes da área de tecnologia.

Lembrando que o MySQL é um banco de dados relacional e compatível com a linguagem SQL. Por isso, vamos aprender nesse treinamento o SQL utilizando o MySQL.

O servidor do MySQL é robusto até certo ponto, já que deriva de características de multiacesso, integridade de dados, efetua o relacionamento entre tabelas, trabalha a concorrência quando vários usuários tentam acessar o mesmo dado na mesma tabela, realiza o controle de transações, entre outros processos. Essa robustez é uma característica importante no que diz respeito ao **servidor** do MySQL.

Outro aspecto importante é a **_portabilidade_** do banco de dados. O MySQL pode ser transacionado entre diversos sistemas. Isso significa que consigo desenvolver o banco de dados MySQL em Windows e posteriormente utilizar no Linux ou Unix, sendo assim, interplataforma.

Ademais, o banco MySQL provém várias APIs que permitem acessar os dados do MySQL usando .Net, Java, Python, PHP, JavaScript e JQuery, por exemplo. Isto é, as linguagens de programação que são mais usadas no mercado possuem APIs nativas para acesso ao MySQL.

Outro atributo importante é o **_multithreads_**. O MySQL usa uma programação de _threads_ utilizando diretamente o _Kernel_ do sistema operacional, permitindo aumentar a velocidade de transações, além de facilitar a integração da ferramenta com hardwares, possibilitando a escalabilidade da performance. Isto quer dizer que, caso tenha um MySQL usando um servidor com determinado número de CPUs, é possível acrescentar mais CPUs que o banco de dados se adapta usando o máximo do hardware disponível.

O banco de dados MySQL atua com diversas **formas de armazenamento** que se adaptam às características das suas necessidades. Por exemplo, algumas formas priorizam a velocidade, enquanto outras o alto volume de armazenamento, tudo dependendo do objetivo pelo qual você utiliza o MySQL. Discutiremos mais sobre isso em treinamentos futuros, quando abordarmos a parte de administração.

A **_velocidade_** é outro aspecto fundamental. O MySQL é considerado um dos bancos mais rápidos do mercado, sobretudo quando são utilizadas funcionalidades ligadas à internet. Como exemplo, podemos citar sites de e-commerce e de aplicações de internet, já que as nuvens da Amazon, do Google e da Microsoft (Azure) disponibilizam instâncias de MySQL com uma alta escalabilidade.

Já sobre **_segurança_**, o banco de dados MySQL possui internamente diversos mecanismos de segurança, o que o torna bastante seguro para o mercado. Além disso, permite a segregação dos dados por usuários de acesso, isto é, a pessoa possui acesso somente ao que lhe for permitido.

O MySQL também permite o armazenamento de uma quantidade enorme de dados, tornando a sua **_capacidade_** alta, a depender das formas de armazenamento. Se for escolhida uma forma que prioriza o volume de dados, há um limite hoje de até 65 mil terabytes de dados armazenados. Claro, recuperar e manipular esse volume de informação pode ser um pouco difícil e depender de muito hardware. A maioria das aplicações corporativas não precisam desse tamanho todo de armazenamento para trabalharem.

Já referente à **_aplicabilidade_**, o MySQL não se aplica somente a utilidades de internet - apesar de ser preferido por desenvolvedores web -, mas também aplicações de desktop ou corporativas, essas chamadas de _On Premises_, nas quais o banco de dados é instalado no próprio servidor da empresa. Esses bancos possuem o que chamamos ODBCs _(Open Database Connectivity_, comum em bancos baseados em Windows) ou JDBCs _(Java Database Connectivity_, comum em bancos baseados em Java), que permitem realizar acessos rápidos ao banco de dados MySQL em aplicações desktop.

Finalmente, falaremos um pouco sobre o **_log_**. No MySQL há um forte gerenciamento de log, que registra tudo o que fazemos no banco. Isso é um ponto interessante quando é necessário realizar uma recuperação de dados ou se for preciso fazer o que é chamado réplica de servidores, técnica bastante usada quando temos um servidor chamado _master_ e outro _slave_, existindo uma sincronização de dados entre eles.

Por esse motivo, é um dos bancos de dados mais usados em nuvem, já que esse tipo de banco possui diversas replicações em diferentes lugares do planeta para que, caso um CPD (Centro de Processamento de Dados) caia, outro continue operando e a aplicação siga tendo alta disponibilidade de acesso.

Isso é um pouco da história e características do banco MySQL, que vamos usar nesse treinamento para mostrar como funciona a linguagem SQL.


-----------------------------------------------------------------------
Instalando o MySQL Server
https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54324

## Transcrição

Vamos então fazer a instalação do MySQL. É possível realizar essa instalação tanto no sistema operacional Windows quanto no Linux. No caso, irei utilizar a primeira opção.

Iremos também, instalar a IDE chamada _Workbench_, um programa que permite a visualização dos objetos do banco de uma maneira mais gráfica. Quando estamos trabalhando com o MySQL, utilizamos linhas de comando. Mas, com uma IDE é possível fazer várias consultas na mesma tela e configurar as tabelas de forma gráfica.

O _WorkBench_ é uma IDE fornecida pelo próprio MySQL, há outras IDEs no mercado, mas para esse curso usaremos a que o banco de dados proporciona. Inclusive, o pacote de instalação já vem com a IDE, e não apenas o servidor MySQL.

Vamos iniciar a instalação. Abriremos no navegador a [página SQL Downloads](https://www.mysql.com/downloads/) e procuraremos a opção gratuita que é a _MySQL Community Edition (GPL) Downloads_. Em seguida, selecionamos o [botão de download do MySQL Installer](https://dev.mysql.com/downloads/installer/) ao lado de `mysql-intaller-web-community-8.0.15.0.msi` que é a versão mais recente no momento da gravação do curso.

Selecionando download, será pedido um login no site da Oracle, sendo uma etapa fundamental para baixarmos e/ou comprarmos produtos da Oracle. Caso ainda não possua cadastro, basta selecionar o botão de "Sign Up", se já tiver é só escolher a opção "Login".

![Imagem quadrada com dois botões na parte superior, à esquerda o botão azul login: using my Oracle Web account. à direita, o botão verde Sign Up: for an Oracle Web account. Abaixo uma explicação para que serve cada botão.](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/Transcri%C3%A7%C3%A3o/Imagens/mysql.PNG)

No caso, vamos selecionar o botão de "Login", para quem já possui cadastro, inserindo o usuário e senha e selecionando "Iniciar Sessão" e, em seguida, "Download Now".

Esse download é considerado um arquivo pequeno, já que depois tudo que instalarmos, ele fará o download da internet no momento da instalação.

Selecionamos o arquivo baixado. Irá aparecer uma escolha opcional, perguntando se queremos verificar se há upgrade a ser realizado, para fazer a instalação não somente da versão que escolhemos mas também dos upgrades mais atuais. Vamos selecionar o botão "Sim" e aguardar o download do instalador com os upgrades.

Após aguardar o carregamento, iniciaremos a instalação, primeiramente, aceitando os termos da licença selecionando "I accept the lisense terms" e, logo após, "Next". Na tela seguinte, escolheremos a opção "Developer Default", que serve para instalar o servidor e conectores necessários para o funcionamento do MySQL, e mais uma vez clicaremos em "Next"

Na próxima tela nos pergunta se queremos realizar um conector com Python. Por não ser o nosso objetivo, clicaremos em "Next" e, em seguida, no botão "Yes". Na próxima página nos é apresentado tudo o que será baixado, perceba que um dos itens é o _Workbench_, a IDE do MySQL, selecione "Execute" e, a partir disso, se iniciam os downloads dos módulos que serão utilizados para a instalação.

Após o término do download dos componentes, clicaremos em "Next" para dar continuidade na instalação. Selecionamos "Next" novamente e, nesta página há duas categorias de estrutura de bancos de dados que trabalharemos, vamos usar a _"Standalone MySQL Server / Classic MySQL Replication"_. Mais uma vez clicamos em "Next", note que nesta tela são as configurações de porta e a forma de comunicação entre cliente e servidor, vamos manter as configurações já selecionadas e, outra vez, selecionar "Next".

Já na próxima tela é como vamos usar a autentificação, há dois tipos: a primeira é a senha criptografada e a outra usa a segurança do MySQL mais antigo. Manteremos a primeira opção, _Use Strong ´Password Encryption for Authentication_, selecionada e mais uma vez pressionamos o botão "Next".

Na próxima página será solicitado a criação de uma senha do **_usuário root_**, isto é, o usuário padrão do banco de dados MySQL. Não iremos criar outros usuários, na parte _"MySQL User Accounts"_, já que estaremos utilizando o padrão, vamos usar para acessar o banco MySQL e realizar os exercícios práticos.

Novamente, selecionaremos "Next", nesta página temos o nome do serviço, já que o MySQL é um serviço do Windows e será sempre inicializado quando a máquina for efetuar o boot, isto é, quando a máquina voltar a funcionar o banco de dados retorna junto. Na parte inferior encontramos qual usuário vai gerenciar o serviço, não vamos alterar nada nessa parte. Na próxima tela é tudo o que o banco vai executar durante a instalação, selecionaremos "Execute".

Com isso, ira iniciar a instalação, o banco de dados, o servidor, entre outras instalações. Após o término, selecione "Finish" e em seguida "Next", para o banco efetuar outras configurações, no momento não iremos alterar nada, selecione "Finish" e "Next", novamente.

Na tela seguinte temos a conexão com o servidor, _Connect To Server_, vamos inserir a senha do usuário root e selecionar "Check", aguarde aparecer a mensagem _"All conections succeeded"_, que significa que a conexão foi realizada com sucesso, selecione "Next" e, logo após, "Execute", para executar a segunda parte da instalação.

Selecione "Finish", para o banco fazer novas configurações.Finalmente, ao selecionarmos o último "Finish", será inicializado o Workbench, sendo a interface da IDE que nos permite manipular o banco de dados MySQL.

Perceba que já foi criado uma conexão local da máquina de forma automática. Em cada máquina há um servidor e um cliente, e o Workbench já vem com essa conexão pré-configurada.

Selecionando a conexão local irá aparecer uma tela solicitando a senha criada para o nosso usuário root, opte por selecionar _"Save password in vaul"_ para salvar a senha e pronto, estamos com o MySQL Workbench configurado e instalado.

Agora que finalizamos, podemos começar o nosso treinamento MySQL.


-----------------------------------------------------------------------
Preparando o ambiente: Linux e Mac

Se você estiver utilizando o sistema operacional Linux ou Mac, temos um excelente artigo que explica de forma detalhada o processo de instalação do MySQL. Recomendamos que você siga os passos descritos neste artigo antes de continuar com o curso:

- [MySQL: da instalação até a configuração](https://www.alura.com.br/artigos/mysql-instalacao-configuracao)

Caso surjam dúvidas durante o processo de instalação, não hesite em procurar assistência no fórum ou no Discord da Alura. Estamos aqui para ajudar você a ter uma experiência de aprendizado tranquila e produtiva.

Desejamos a você ótimos estudos e sucesso em sua jornada de aprendizado!

-----------------------------------------------------------------------
Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Acesse o seu Browser e busque por MySQL Downloads. Acesse o link [http://www.mysql.com/downloads](http://www.mysql.com/downloads)

2) Procure pelo link MySQL Community Edition (GPL) / Community (GPL) downloads.

3) Vá para MySQL on Windows (Installer & Tools) / Downloads.

4) Clique em _MySQL Installer_.

5) Clique no botão de download ao lado da opção Windows (x86-32 Bits), MSI Installer (mysql-installer-web-community-8.0.15.0.msi).

6) Faça um login no site da Oracle. Se você não possuir um login, faça um cadastro.

7) Após o Login, clique em _Download Now_.

8) Execute o programa que foi baixado.

9) Clique em _I Accept the license terms_ e depois em _Next_.

10) Escolha a instalação _Developer Default_. Clique em Next duas vezes.

11) Clique em Execute para o download e instalação do banco e seus componentes.

12) Clique em Next duas vezes.

13) Mantenha a escolha _StandAlone MySQL Server_ / _Classic MySQL Replication_.

14) Mantenha as propriedades padrões do serviço e da porta de comunicação. Clique _Next_.

15) Mantenha a opção _Use Strong Encryption for Authentication_ .... Clique em _Next_.

16) Inclua a senha do usuário root duas vezes. Clique em _Next_.

17) Mantenha as propriedades padrões. Clique em _Next_.

18) Clique Execute para iniciar a instalação.

19) Sempre selecione _Next_ e _Finish_ na medida que outras caixas de diálogo forem sendo exibidas. Se houver a pergunta sobre a senha do usuário root digite a senha configurada anteriormente na instalação.

20) Automaticamente o _Workbench_ será aberto. Clique na conexão que está configurada. Você então acessará o ambiente com o MySQL no ar.

-----------------------------------------------------------------------
Definições

## Transcrição

O objetivo nesse treinamento, como já mencionado, é apresentar para o(a) estudante o primeiro contato com a linguagem SQL.

Então, primeiramente, para compreender como o SQL funciona é preciso entender como trabalha o banco de dados. Visto que a maneira que o banco de dados é organizado está diretamente relacionado a forma que vamos criar os comandos SQL. Sendo assim, considerado um pré-requisito entender como opera um banco de dados.

Lembrando que nesse treinamento estamos usando o MySQL para mostrar como funciona a linguagem SQL, poderíamos utilizar Oracle ou SQL Server da Microsoft, por exemplo. Mas como esse curso faz parte de uma carreira mais completa de MySQL, utilizaremos esse banco de dados.

Vamos entender como é organizado o banco de dados. Os conceitos que vou apresentar podem até serem aplicados em outros bancos, como o da Oracle e SQL Server.

Conheceremos agora um pouco mais sobre esses conceitos.

O **_banco de dados_** é um repositório que armazena dados que podem ser consultados, fica armazenado no disco rígido, como o SSD ou HDD, de outro modo, ocupa espaço no disco como, por exemplo, um arquivo word ou uma planilha de Excel. Ou seja, conseguimos no ambiente ir para um diretório específico e visualizar um ou mais arquivos que representam o banco de dados. Percebe-se, com isso, que a entidade maior é o próprio banco de dados.

No banco de dados há diversas **_entidades_**, estruturas que organizam como os dados são armazenados. Uma das principais entidades é a **_tabela_**, podendo conter várias no mesmo banco de dados.

Uma tabela, fazendo uma analogia, é como uma planilha no Excel — que há colunas e linhas. Mas, diferente da planilha de Excel, que ao gerar uma nova conseguimos visualizar uma série de colunas e linhas em branco, no momento de criação da tabela é preciso já estabelecer as **_definições_** do que ela abrangerá.

Algumas dessas definições é a quantidade e categoria de cada **_campo_**. O campo seria a coluna, então podemos ter, por exemplo, campos da categoria `texto`, `número`, que podemos ter com casas decimais ou inteiros, `lógico`(verdadeiro ou falso), `binário`, que há bites armazenados que podem representar uma imagem ou algum outro arquivo diferente do formato texto e assim por diante. Portando, ao criar uma tabela, é necessário já definir quantos e as categorias de cada coluna.

Os valores de uma mesma coluna não podem ser de grupos diferentes, isto é, se o campo foi estabelecido como `numérico`, podemos apenas a armazenar números nesse campo. Se incluirmos algo que fuja muito, tipo um texto, o banco de dados retorna erro.

Já as linhas das tabelas, são chamadas **_registros_**. Este, diferente dos campos, possui número infinito - a depender do espaço em disco disponível para o banco de dados expandir. Inclusive, ao gerar um banco de dados podemos determinar políticas de crescimento ou o limite máximo que ele pode ampliar.

Outro conceito importante referente a tabela, é a **_chave primária_** (_primary key_). No momento de criar uma tabela, não obrigatoriamente, podemos estabelecer uma chave primária, isso significa que os valores de um campo específico não podem se repetir em uma linha.

Por exemplo, vamos supor que a tabela seja a "tabela_cadastro_clientes" e temos na primeira coluna o "CPF" dos clientes e na terceira o "Nome". Se escolhermos o CPF como chave primária, isso quer dizer que não podemos ter dois registros (linhas) na tabela que tenham os mesmos valores na coluna "CPF". Isso faz sentido, já que ninguém possui CPF idênticos, já o nome é possível repetir, por não ser considerado chave primária.

Já se tivermos uma **_chave primária composta_**, o que não pode repetir é a combinação entre as colunas. Portando, chave primária são os valores de campos ou combinação entre campos — chave primária composta — que não podem se repetir nos registros da tabela.

No banco de dados podemos ter várias tabelas, cada uma possui fragmento da informação armazenada, podendo essas tabelas se relacionarem através da **_chave estrangeira_** (_foreign key_). Como na "tabela_cadastro_clientes" que um campo é o "CPF" e o outro é "Nome" e na outra tabela que representa as vendas de produto para cada cliente, "tabela_vendas", e nesta também temos o campo "CPF".

Ao criarmos uma chave estrangeira entre os campos "CPF" da "tabela_vendas" e da "tabela_cadastro_clientes", isso significa que teremos uma ligação entre elas. Como mencionado em vídeos anteriores, o SQL surgiu da necessidade de manipular e armazenar dados em um banco de dados relacional, que possui relações entre as tabelas, isto é, possuem chaves estrangeiras. Isso faz com o que a informação tenha **_integridade_**, visto que não seria possível ter um cliente comprando um produto sem estar pré-cadastrado na tabela de clientes.

Anteriormente aos bancos de dados relacionais, eram utilizados os **_transacionais_**. Em outras palavras, não possuíam essa ligação entre as tabelas, podendo assim, registrar o CPF de um cliente na "tabela_vendas" que não esteja, necessariamente, pré-cadastrado na "tabela_cadastro_clientes". Isso gera um problema de integridade do dado, por isso, os bancos de dados relacionais surgiram para melhorar a qualidade da informação armazenada.

Nas tabelas também podemos encontrar os **_índices_**. Estes permitem encontrar informações da tabela de maneira mais rápida. Como exemplo, vamos imaginar que queremos obter todos os clientes que começam com o nome Victorino, se não tivermos um índice, o banco de dados relacional terá de percorrer registro por registro até encontrar o nome solicitado pela primeira vez e, após encontrar, informar e seguir buscando até o término das linhas para verificar se há mais de um cliente com esse nome.

Agora, se tivermos um índice para o campo "Nome" temos um algoritmo interno - como se já estivesse ordenado alfabeticamente os elementos da coluna "Nome". Isto é, já sabemos que o nome Victorino consta nos últimos registros com a inclusão do índice, não precisando percorrer todas as linhas até encontrar o primeiro nome com a letra **V**.

> O índice permite, neste caso, que a busca se inicie nas linhas que os nomes começam com a letra **V** e a partir disso, procurar o nome Victorino, tornando a busca mais rápida. Portanto, o índice serve para facilitar e agilizar a procura.

> Quando temos uma chave estrangeira, automaticamente o banco de dados cria índices nos campos que se interrelacionam, para que seja viável, por exemplo, ao cadastrar um cliente na "tabela_vendas" o banco de dados, internamente, verifique se o cliente consta na "tabela_cadastro_clientes" e para encontrar rápido é proveitoso que a tabela original já possua índice.

Recapitulando, no banco de dados há diversas tabelas, composta por campos (colunas) e registros (linhas), essas tabelas possuem chaves estrangeiras, primárias e podem conter índices.

Já quando estamos nos referindo a **_esquemas_** (_Schemas_), é o conjunto de tabelas que representam o mesmo assunto. As tabelas de esquemas diferentes podem se relacionar, transformar em _Schemas_ é apenas uma forma de agrupar as tabelas por tema, sendo mais utilizado no sentido de organização.

O banco de dados possui também a chamada **_View_** (visão), um agrupamento de tabelas. Vamos aprender mais adiante nesse curso sobre query (consulta), e essa consulta pode me retornar não apenas as informações de uma determinada tabela, mas de duas os mais através das chaves estrangeiras. Após conseguir unir duas ou mais tabelas e gerar um resultado para essa consulta, podemos transformar-lá em uma **view**.

Isso significa que a view possui um comportamento similar a tabela, mas que por trás dela já há uma consulta estabelecida com as regras de negócio para agrupar as informações solicitadas.

Em SQL, tratamos as views como tabelas já existentes, contudo, na verdade, é uma lógica por trás. Algumas views podem ter _performances_ não muito ágeis caso seja construída por comandos SQL muito custosos ou rebuscado.

Como já mencionado, temos no SQL comandos de consultas (_queries_) e ao realizar essa consulta precisamos definir em quais tabelas gostaríamos de buscar essas informações. Caso esses dados que queremos, esteja apenas em uma tabela, basta incluir o nome dela. Já se essas informações estiverem em mais de uma tabela, será necessário utilizar a cláusula `Join`.

O `Join` uni as tabelas através de um critério, ao elaborar essa consulta que junta tabelas podemos definir filtros, tal como clientes apenas no sexo masculino e/ou que moram apenas na região Sul. Essa consulta que aplicamos o filtro pode ser uma view.

Internamente, o banco de dados possuem as **_procedures_**. No começo desse treinamento havia mencionado que a linguagem SQL não é estruturada, mas a partir disso os estudiosos de banco de dados MySQL, Oracle e SQL Server criaram linguagens que não estão mais no padrão **ANSI**, mas linguagens proprietárias que permitem utilizar comando SQL para fazer algum tipo de lógica estruturada com _if_, _while_, entre outros comandos de repetições, por exemplo. Como se tivéssemos um programa em uma linguagem nativa do banco de dados utilizando comando SQL.

Nas _procedures_, podemos ter as **_funções_**. Estas são cálculos montados com campos que podemos usar dentro de um comando de consulta. Podemos criar uma função que facilite uma visualização ou contabilização e usa-lá para realizar as consultas.

O próprio banco MySQL possui um catálogo de funções: como tirar espaços em branco do registro, transformar letra maiúscula em minúscula, efetuar cálculos complexos como de datas — quantos dias tem entre determinadas datas, entre outras funções.

No banco de dados, também, temos o **_trigger_**. Este é um aviso programado caso algo ocorra no banco de dados ou tabela. Como, se quisermos ser avisados caso alguém realize alguma alteração ou delete informações nas tabelas. Este aviso poder ser uma função, uma _procedure_ ou um único comando SQL, que será executado quando a condição da _trigger_ for satisfeita.

Exemplificando, se tivermos duas tabelas "tabela_clientes" e a "tabela_taxas". Todo cliente cadastrado é preciso ir à tabela taxas e criar uma taxa com o valor zero na "tabela_taxas". Podemos ter uma _trigger_ que toda vez que criado um cadastro na tabela de cliente, irá à tabela de taxas inserir o código do cliente e mais uma taxa _default_ (padrão).

Com isso, estamos garantindo que ao incluir um novo cliente, ele(a) já terá um valor de taxa, mesmo que seja zero. O _trigger_ pode ser utilizado para diversas outras situações no banco de dados.

Então, o banco de dados possui todos esses componentes: tabelas, _views_, _procedures_ e funções. Espero que esses conceitos sejam úteis para incentivar vocês a conhecer mais sobre o que é um banco de dados.

-----------------------------------------------------------------------
Conhecendo o Workbench
https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54326

## Transcrição

> > Nessa aula, o instrutor utiliza o banco Word e Sakila, para exemplificar consultas SQL. Porém, infelizmente nas versões atuais do MySQL esses bancos não estão contidos na instalação. Informamos que, caso você não tenha acesso, a utilização do Word e Sakila não é necessária para seguir com o curso e o **uso é apenas demonstrativo.** Caso queria utilizar o banco Word e Sakila, você pode seguir os passos de instalação descritos [nesse tópico do fórum.](https://cursos.alura.com.br/forum/topico-bug-na-aba-schemas-so-aparece-a-opcao-sys-nao-tem-a-word-e-sakila-282120)

Como o foco desse treinamento é conhecer um pouco como funciona o SQL, instalamos com o MySQL uma interface gráfica chamada MySQL _Workbench_, que vamos usar para aprender SQL.

Vamos compreender um pouco sobre o funcionamento do _Workbench_. Para abrir clicaremos em "Windows" e no campo de busca escreveremos "Workbench", irá aparecer `MySQL Workbench 8.0 CE`, versão mais atual durante a gravação do curso.

Selecionando essa opção, será mostrado a tela principal _Welcome to MySQL Workbench_, que na parte inferior temos várias conexões disponíveis. Clicando no `+` ao lado de _"MySQL Connection"_ mostrará uma tela _"Setup New Connection"_ em que é possível configurar uma nova conexão. Isto é, o Workbench faz o papel do cliente e, posso acessar com o mesmo _Workbench_ diferentes servidores MySQL. Neste caso, já estamos conectados no servidor MySQL da própria máquina.

Não vamos criar uma conexão, então clicaremos em "Cancel" na tela _"Setup New Connection"_. Vamos usar apenas a conexão criada durante a instalação para nos conectar com o MySQL que está no nosso ambiente.

Iremos selecionar a conexão _"Local instance MySQL80"_ e será aberta uma janela inicial do MySQL _Workbench_. Clicaremos em _"Schemas"_, nessa aba temos outros bancos de dados, tais como _sakila_, _world_ e _sys_. Os dois primeiros são _**bancos de dados exemplos**_ que o MySQL instala, já o _sys_ é um banco de dados utilizado pelo sistema, como o nome já diz.

Veremos mais para frente, talvez em outros treinamentos, que as configurações internas do MySQL também são tabelas em **bancos de dados internos** - diferente dos que vamos trabalhar.

Do lado esquerdo no banco de dados MySQL em _world_ clique em "Tables" (tabelas), note ser possível observar o cadastro das `colunas`, dos `índices`, das `chaves estrangeiras` e `triggers`. Se selecionarmos os campos, por exemplo, conseguimos visualizar o `nome` de cada coluna que compõe a tabela _city_.

Na área central da tela, que no momento está vazia, é o local que vamos digitar nossos comandos SQL - consulta, inclusão, alteração de informação ou exclusão de campos e/ou tabelas. Vamos analisar melhor mais para frente o que isso significa, mas apenas exemplificando para facilitar a compreensão: insira no espaço em branco o comando `select * from city` e em seguida dê um duplo clique no banco de dados _world_ para rodar, note que ficou em negrito (_bold_), isso quer dizer que os comandos inseridos na área de código estão relacionados ao banco de dados selecionado.

> `select * from city`. Neste comando estamos selecionando (_select_) todos os campos (`*`) (asterisco) da tabela _city_.

É por esse motivo que o SQL surgiu do termo "linguagem estruturada em inglês", visto que seus comandos são escritos nesse idioma.

- Select (selecionar)
- From (de)
- Em negrito são os componentes do banco de dados
- Em azul-claro são os comandos da linguagem SQL

Neste caso, _select_ e _from_ são comandos SQL, já (`*`) e _city_ não. Isso está relacionado com a seleção que estou fazendo.

Para executar a consulta, clique no ícone de raio na parte superior da área que escrevemos o código, como resultado obtemos todas as informações da tabela, como as colunas ("_ID_", "_Name_" (nome),"_CountryCode_" (código do país),"_District_" (Distrito),"_Population_" (população)) e as linhas.

Tabela gerada:

> Para melhorar visualização, alguns elementos da tabela foram omitidos.

| Id | Name | CountryCode | District | Population | |---- |---------------- |------------- |--------------- |------------ | | 1 | Kabul | AFG | Kabol | 1780000 | | 2 | Qandahar | AFG | Qandahar | 2375500 | | 3 | Herat | AFG | Herat | 186800 | | 4 | Mazar-e-Sharif | AFG | Balkh | 127800 | | 5 | Amsterdam | NLD | Noord-Holland | 731200 |

Acrescentando o comando `select * from country` na interface, é preciso inserir um ponto e vírgula (`;`) ao final dos comandos para que o programa identifique o encerramento de um e execute o próximo.

```sql
SELECT * FROM CITY;
SELECT * FROM COUNTRY;
```

Clicando para executar os comandos novamente, temos como resultado duas abas. A primeira aba é a `City 2`, da tabela gerada anteriormente e a outra `Country 3` é o retorno do segundo comando da tabela _country_, com todos os seus elementos.

Se tirarmos o ponto e vírgula do final do primeiro comando, a própria IDE nos retorna um erro, com um **X** (xis) em vermelho, informando haver um erro na segunda linha. Passando o mouse por cima desse aviso, será mostrado o motivo, no caso aparece a mensagem "`"SELECT" is not valid at this position, expecting : EOF, ';'"`, isto é, a seleção é inválida nesta posição e é esperado um ponto e vírgula ou um EOF (End-of-file), em português, fim de arquivo.

Se tentarmos rodar esse comando com o aviso, será mostrado o erro no lugar do retorno da tabela esperada, no caso aparecerá a seguinte mensagem `select * from city select * from country`. Porém, há uma forma de executar apenas um dos comandos, selecionando com o mouse somente a linha que quero executar e, novamente, clicar no ícone de raio para rodar. Isso ocorre pelo fato do _Workbench_ entender que deve executar apenas o comando selecionado e ignorar os outros. Por isso, não é necessário colocar o ponto e vírgula ao usar essa forma de execução.

Com a finalidade de explorar um pouco mais com vocês essa área, vamos inserir o nome errado da coluna com o comando `select * from countryxxx;` , perceba que quando erramos nomes que não estão relacionadas com as palavras chaves do SQL, como o nome da tabela, a IDE não consegue identificar que esse **nome** não existe. Retornando o erro `Erro code: 1146. Table 'world.countryxxx'doesn't exist` apenas após a execução do código, mas note que o primeiro comando segue funcionando normalmente.

Tudo isso que foi mostrado para vocês é apenas uma introdução de como trabalhamos o _Workbench_.

-----------------------------------------------------------------------
Criando um banco de dados
https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54327

## Transcrição

> > [Você pode fazer o download completo do código realizado neste vídeo para criar o banco de dados neste link](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/02/SQL_01.sql).

> > [Você pode acessar a documentação MySQL usada para a explicação dessa aula neste link](https://dev.mysql.com/doc/refman/8.0/en/create-database.html)

Agora que estamos com as instalações necessárias e sabemos usar o _Workbench_, vamos começar a manipular os bancos de dados. Para isso, primeiro, é preciso criar um banco de dados, além dos exemplos que já temos que vieram junto no momento da instalação do MySQL.

A sintaxe para criar o banco de dados é o comando `create database`, note ser possível gerar um _database_ ou um _schema_.

> Lembrando que no banco de dados relacional, o agrupamento de tabelas é chamado de _schema_, já no MySQL _database_ e _schema_ são sinônimos.

Então, podemos utilizar `CREATE {DATABASE | SCHEMA}` para criar um banco de dados. Outra parte que pode ser acrescentada no comando é o `[IF NOT EXISTS] db_name`, isto é, se não for encontrado o nome atribuído ao banco de dados, será criado e, caso exista não será feita nenhuma execução.

Código completo:

```csharp
CREATE {DATABASE | SCHEMA} [IF NOT EXISTS] db_name
      [create_specification]

   create_specification:
            [DEFAULT] CHARACTER SET [=] charset_name
            [DEFAULT] COLLATE [=] collation_name
            DEFAULT ENCRYPTION [=] { 'Y' | 'N'}
```

Analisando as informações em `create_specification`, perceba que se não for indicado o _character set_, como, do tipo **UTF-8** ou **UTF-16**, o código utiliza o padrão (_default_).

- **UTF-8** - UCS Transformation Format 8 (formato de transformação UCS 8)
- **UTF-16**- 16-bit Unicode Transformation Format (formato de Transformação Unicode)

> No nosso computador possuímos uma tabela interna chamada **ASCII** (da sigla _American Standard Code for Information Interchange_, "Código Padrão Americano para o Intercâmbio de Informação"), em que cada letra digitada no computador é convertida em um código que a representa.

O código ASCII pode diferir conforme o idioma, como na língua inglesa que não existe acento e nem cê-cedilha. Por isso, a tabela ASCII original não comporta esses tipos de caracteres especiais. Porém, há tabelas que integram esses caracteres especiais, então, ao digitar uma letra com acento será buscado na tabela o código correspondente.

Por esse motivo, em `character set` vamos informar para o banco de dados o conjunto de caracteres permitidos, a depender do idioma. Por exemplo, se a construção do banco de dados são com informações em português, é necessário, portanto, que seja incluído caracteres da língua portuguesa.

Apenas por questão de conhecimento, o _collate_ também específica o padrão desses conjuntos de caracteres a serem usados e o _encryption_ informa se o banco de dados será criptografado ou não.

Como no momento estamos aprendendo SQL, essa informação não é tão relevante e, em razão disso, vamos somente rodar o comando `create`.

Voltando para o _Workbench_, digitando na área do código `CREATE DATABASE SUCOS;` estamos criando um database chamado **sucos**. Quando selecionamos o botão para rodar, no resultado é exibido a mensagem `1 row(s) affected` (uma linha disponibilizada) informando que foi executado com sucesso.

Perceba que o banco de dados **sucos** ainda não consta em _`Schemas`_ do lado esquerdo do MySQL, para que aparaceça, basta apertar o botão direito do mouse na aba e clicar na última opção em _refresh all_ (atualize tudo) que aparece no espaço em que é armazenado os bancos de dados.

> > Nesse vídeo, o instrutor demonstra o caminho onde fica armazenado os bancos de dados, mas pode ser que esse **caminho seja diferente** na sua máquina. Você pode identificar este caminho executando o comando `SELECT @@datadir;` no próprio Workbench, caso tenha mais dúvidas acompanhe [esse tópico no fórum](https://cursos.alura.com.br/forum/topico-onde-visualizo-o-database-que-foi-criado-em-outro-so-245438).

Vamos agora visualizar o local que esse banco de dados está criado fisicamente no disco. Selecione a sua pasta de arquivos do próprio computador e procure o repositório do MySQL. No caso, o caminho é o `C:\ProgramData\MySQL\MySQLServer 8.0` do MySQL e note haver um arquivo nomeado `my.ini`, este é lido pelo MySQL toda vez que ele é iniciado, ou seja, é o **arquivo de inicialização**.

No arquivo `my.ini.` há uma série de variáveis de ambiente. Abrindo esse arquivo, clicando com o botão direito do mouse, em um editor de texto, no caso vou usar o `Edit with Notepad++`, conseguimos encontrar a variável `datadir = C:/ProgramData/MySQL/MySQLServer 8.0/Data`, que mostra o ambiente onde o banco de dados está localizado.

Voltando para os diretórios no computador, na pasta "Data" note que temos um diretório chamado **sucos** agora, porém dentro não temos nenhum arquivo ainda. Mas, caso selecionarmos o repositório _world_ é possível visualizar uma série de arquivos separados, as tabelas com a extensão `.ibd`, isto é, cada tabela possui um registro separado.

Criamos o banco de dados e a partir de agora podemos prosseguir com o nosso treinamento, criando outros componentes no banco de dados **sucos**.

-----------------------------------------------------------------------
Criando um banco de dados usando assistente
https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54328

## Transcrição

Outra maneira de criar o banco de dados é usando um assistente, mas apenas se estiver utilizando o _Workbench_. Visto que, possui funcionalidades que nos auxiliam a realizar tarefas sem a necessidade de digitar o comando SQL.

No MySQL Workbench, em qualquer área do lado esquerdo em _`Schemas`_, selecione o botão direito e clique na opção "_create schema_". Será exibida uma caixa de diálogo com o campo "_name_", que vamos alterar para **SUCOS2** e o "_Charset/Collation_", que na primeira caixa clicável escolheremos a opção `utf8` e na seguinte `uft8_general_ci`. Essas informações estão relacionadas aos caracteres especiais, caso precise conter eles no seu banco de dados. Em seguida, selecione o botão _"Aply"_ do lado inferior esquerdo do Workbench.

Será mostrado uma tela com o título _Apply Changes to Object_, informando que será criado o **objeto** e na próxima página é exibido o comando `CREATE SCHEMA`sucos2`DEFAULT CHARACTER SET utf8;`. Para fins de curiosidade, se pegarmos esse comando e colar na área do MySQL, será executado normalmente. Então, o que a caixa de diálogo exibida pelo _Workbench_ faz é agilizar a escrita do comando SQL.

Perceba que o nome do nosso banco de dados **sucos** está entre crases, essa nomenclatura é mais usada em situações para limitar o nome que há espaços entre as palavras, por exemplo, `sucos 2`, no caso não vamos precisar já que não temos espaços no nome do nosso database, mas podemos manter.

Selecionando _Apply_ novamente, executaremos o comando. Clique em _"Finish"_ para fechar a janela de execução e visualizarmos apenas a área MySQL, observe que no MySQL do lado esquerdo em _`Schemas`_, já consta o banco de dados.

```sql
CREATE SCHEMA `sucos2` DEFAULT CHARACTER SET utf8;
```

Note também, que o comando exibido para criar o banco de dados em uma das telas anteriores não aparece mais, é apenas no momento de execução mesmo. Na parte superior da área de digitação do código, o programa vai abrindo abas conforme executamos os comandos, sendo a primeira aba a `Query 1` que foi o comando manual e direto de criação e a segunda `sucos2 - Schema` é a caixa de diálogo para criar o banco de dados **sucos2**.

À medida que formos executando alguns comandos SQL, irei mostrar uns comandos visuais que auxiliam na memorização da sintaxe. Nessa parte mais visual é possível enxergar o comando que o _Workbench_ está gerando, copiar, colar e adaptar, se necessário.

-----------------------------------------------------------------------
Apagando banco de dados
https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54329


## Transcrição

> [Você pode acessar a documentação MySQL usada para a explicação dessa aula neste link](https://dev.mysql.com/doc/refman/8.0/en/drop-database.html)

Agora que já criamos, vamos aprender a apagar o banco de dados. Para tal, vamos usar o comando `DROP DATABASE`, basta digitar esse comando e o nome específico do banco a ser apagado. Na parte `[IF EXISTS] db_name` serve para evitar um erro de execução caso a database não exista.

Sintaxe completa:

```graphql
DROP {DATABASE | SCHEMA} [IF EXISTS] db_name
```

Voltando para o MySQL _Workbench_, na área de consulta vamos digitar o comando `DROP DATABASE SUCOS;` para apagar o banco de dados **sucos** e rodamos. No espaço de `"Output"`, temos a mensagem `0 rows(s) affected` e em `"Action Output"` nos informa através de uma seta em verde que o comando foi executado com sucesso. Note que o banco de dados não consta mais na lista no lado esquerdo, onde é localizado os demais bancos. Agora, se formos nos arquivos do sistema operacional, no diretório `Data` do MySQL, perceba que também não há mais nenhum diretório com o nome **sucos**.

```sql
DROP DATABASE SUCOS;
```

Por ser um comando que excluí banco de dados e, consequentemente todos os dados contidos nele, é preciso tomar bastante cuidado para quem damos permissão de acesso para executar tal comando. Há até desenvolvedores e desenvolvedoras que não possuem essa permissão, conseguem apenas criar tabelas e inserir dados. O único que possui o privilégio de criar e apagar bancos de dados é o **administrador**, conhecido como DBA (sigla em inglês de _Database administrator_, Administrador de banco de dados).

É possível também excluir a database sem digitar o comando, apenas indo no lado esquerdo no _Workbench_, selecionar com o botão direito do mouse no nome que deseja apagar e escolher a opção "_Drop Schema_". Será exibido uma tela perguntando se realmente queremos excluir o banco de dados com duas opções _"Review SQL_", que irá nos mostrar o comando SQL que será executado e "_Drop Now"_, que é a confirmação para a exclusão. Clicando em "_Review SQL_" perceba que será apresentado o comando ``DROP DATABASE `sucos2`;``, selecionando "_Execute_" a database **sucos2** foi excluído do _Workbench_ e fisicamente no disco.


-----------------------------------------------------------------------
MYSQL por linha de comando
https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54330

## Transcrição

Vamos usar o Workbench ao longo do nosso treinamento por ser mais fácil de inserir comandos, criar e apagar tabelas e até visualizar o resultado na própria interface. Mas, tem os que não gostam e preferem usar o SQL como linha de comando. Com a finalidade de exemplificar, vamos acessar o MySQL sem precisar usar a IDE, isto é, por linha de comando.

> A IDE do MySQL Workbench é apenas uma interface gráfica para nos auxiliar na manipulação do banco de dados.

Quando instalamos as ferramentas do MySQL, o cliente e o servido, não necessariamente precisamos de uma IDE para trabalhar, basta ir direto em linha de comando. Para isso, vamos em "Windows" e no campo de busca digitamos "cmd" para encontrar o **prompt de comando**, selecionando essa opção será exibido uma tela preta.

Para conseguirmos usar a linha de comando, é preciso ir até o diretório onde está localizado o MySQL ou, como qualquer programa do Windows, ir ao painel de controle usando o atalho "Ctrl + P" na variável _path_ e inserir o caminho da localização do executável do MySQL para poder acessar por linha de comando.

No **cmd**, vamos digitar o comando `cd\`, para voltarmos para a pasta **C:** e, em seguida, `cd "Program Files"`, para entrar na pasta e depois “cd MySQL”. Para visualizar os diretórios na pasta MySQL digite `dir`, será exibido diversos diretórios, vamos optar pelo `cd "MySQL Server 8.0"` e, novamente, escrevemos o comando `dir` e, logo após, `cd bin`. Temos nesse diretório **bin** o programa `dir mysql.exe`, é com ele que vamos entrar no MySQL como linha de comando.

Caminho:

```bash
C: \program files>cd “mysql server 8.0>cd bin>dir mysql.exe
```

Prosseguindo, vamos inserir `mysql -h localhost`, sendo o **"-h"** servidor (_host_) e o **"_localhost_"** o meu próprio servidor. Antes de continuarmos, voltando para o _Workbench_ e selecionando o ícone com a imagem de casa na parte superior esquerda da tela, vamos para a área de conexão. Na conexão local, perceba que ela é _localhost_, isto é, podemos acessar a nossa própria máquina apenas indo na máquina chamada _localhost_.

> Localhost é o nome da nossa própria máquina.

Voltando para o prompt de comando, acrescentamos `-u` ao nosso comando,`root` que é o nosso usuário e `root -p`, sendo `-p` a senha, mas não vamos digitar ainda. Esse comando informa que vamos nos conectar no servidor localhost, que vou usar o usuário _root_ e que a senha será digitada a seguir.

```css
mysql -h localhost -u root -p
```

Selecionando "Enter" aparece uma mensagem escrita "_Enter password_" para inserir a senha do usuário root, vamos digitar a senha e clicar em "Enter". Repare que estamos agora no MySQL, visto que o nosso caminho é substituído por `mysql>`.

Vamos realizar o comando `create database sucos;` e apertar o "Enter", será exibido a mensagem `Query OK, 1 row affected (0.00 sec)`. Sem fechar o **cmd**, voltando para o _Workbench_ e clicando na pasta no canto superior esquerdo ao lado do ícone da casa, "_Local instance MySQL80_" saímos da conexão local e retornamos para o ambiente do MySQL. Selecione com o botão direito na aba da árvore que constam os bancos de dados, escolhendo a opção "_Refresh All_", o banco de dados **sucos** aparece, visto que o criamos pela linha de comando.

No prompt, podemos digitar o comando `select * from city;`, nossa tabela de cidades. Mas, ao clicarmos no "Enter", teremos um erro como retorno,`ERRO 1046 (3D000) No database selected`, informando que nenhuma database foi selecionado. Isso acontece porque não selecionamos o banco de dados **world**, e para executar o comando é preciso escolher o banco de dados que quero usar. Para isso, vamos usar o comando `use world`, que corresponde ao duplo clique do Workbench.

> Os comando `CREATE` e `DROP` são comandos de sistema e, em razão disso, não preciso estar associado a um banco de dados.

Apertamos novamente "Enter" para rodar o nosso comando, será exibido uma mensagem dizendo que a database foi alterado (_Database Changed_) e, agora sim, podemos digitar o `select * from city;`. O programa vai listar todos o conteúdo da tabela **_city_**, que são 4.079 linhas em zero segundos, este tempo são os segundos que o banco de dados levou para efetuar a consulta. Para exibir as informações na tela é necessário um determinado tempo, mas por já estar em memória o resultado da consulta é mais rápido.

No Workbench, o nosso banco de dados **world** está selecionado e podemos digitar o comando `select * from city;` e executar, o resultado fica, visualmente, mais agradável que no MySQL por linha de comando.

Novamente no cmd, para sair da database basta digitar "_EXIT_" para fechar o programa, que voltamos para o prompt do Windowns. Veja que podemos escrever o comando com letras maiúsculas ou minúsculas, isto é, o MySQL não é **_case sensitive_**, ao contrário de alguns programas ligados, por exemplo, o Java.

Mas, à medida que formos aprendendo a construir comandos SQL, é uma boa prática indentar de forma correta os comandos, colocando-os em letras maiúsculas para dar destaque.

-----------------------------------------------------------------------
Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Acesse o Workbench.

2) No canto esquerdo temos uma estrutura em forma de árvore onde vemos o banco de dados, ou esquemas.

![1.png](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/02/1.png)

1) Abrindo um dos banco de dados podemos ver alguns dos seus componentes.

![2.png](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/02/2.png)

2) No menu do Workbench, temos o botão "+ SQL" onde uma área de edição será criada para que possamos incluir os comandos de SQL para gerenciar nossos bancos de dados.

3) Efetue um duplo clique no banco de dados World. Depois, execute o seguinte comando na área de edição:

```sql
SELECT * FROM CITY;
```

1) Clique em:

![3.png](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/02/3.png)

E a consulta é executada.

![4.png](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/02/4.png)

1) Digite, abaixo, um novo comando:

```sql
SELECT * FROM COUNTRY;
```

1) Clique em:

![5.png](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/02/5.png)

E as duas consultas serão executadas.

2) Se você selecionar uma área com alguns comandos e clicar em:

![6.png](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/02/6.png)

Somente aquele comando selecionado é que será executado.

3) Caso o comando esteja errado, abaixo você verá o resultado de cada execução.

4) Vamos criar um banco de dados. Para isso, crie um novo script no Workbench e digite:

```sql
CREATE DATABASE SUCOS;
```

5) Execute o comando. Note que o banco de dados é criado.

![7.png](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/02/7.png)

6) Podemos criar o banco de dados através de um assistente. Para isso, clique com o botão da direita do mouse sobre uma área qualquer onde fica a lista dos bancos de dados.

![8.png](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/02/8.png)

E selecione Create Schema.

7) Inclua o nome do banco de dados (ex: Sucos2).

8) Clique em Apply.

9) O comando SQL é exibido. Clique novamente em Apply e o novo banco é criado.

10) Podemos apagar o banco de dados. Execute o comando:

```sql
DROP DATABASE SUCOS;
```

11) Note que o banco não mais aparece na lista de bancos de dados.

![9.png](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/02/9.png)

12) Se escolhermos a base sucos2, com o botão da direita do mouse, podemos também apagar o banco clicando em Drop Schema.

![10.png](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/02/10.png)

13) É possível acessar o MySQL por linha de comando. Vá para o subdiretório c:\Program Files\MySQL\MySQL Server 8.0\bin

14) Digite o comando:

```css
mysql -h localhost -u root -p
```

Tecle enter e depois inclua a senha.

15) Digite o comando:

```sql
CREATE DATABASE sucos;
```

Se você for conferir no Workbench veja que o banco de dados sucos foi acrescido à lista de bancos disponíveis.

16) Para executar uma consulta no banco exemplo world digite:

```xml
USE world; <ENTER>
SELECT * FROM city; <ENTER>
```

Onde `<ENTER>` significa teclar a tecla Enter.

17) Verá que a lista de cidades são listadas.

18) Para sair digite:

```bash
exit
```
-----------------------------------------------------------------------
Tipos de dados

https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54331

## Transcrição

Sabemos que a entidade principal do banco de dados é a tabela, que possui colunas (campos) de diferentes categorias (tipos) e que, ao longo do mesmo campo, todos os valores devem ser do tipo estabelecido na criação da tabela.

Vamos entender agora quais são os principais tipos no caso do MySQL.

|**Tipo**|**Valor em Bytes**|**Menor Valor(Com Sinal) - Signed**|**Menor Valor (Sem Sinal) - Unsigned**|**Maior Valor (Com Sinal) - Signed**|**Maior Valor (Sem Sinal) - Unsigned**|
|---|---|---|---|---|---|
|TINYINT|1|-128|0|127|255|
|SMALLINT|2|-32768|0|32767|65535|
|MEDIUMINT|3|-8388608|0|8388607|16777215|
|INT|4|-2147483648|0|2147483647|4294967295|
|BIGINT|8|-2xE63|0|2xE63-1|2xE64-1|

- Propriedade UNSIGNED: Não permite sinal no número. Por isso, o conjunto de valores válidos aumentam.

Iniciando pelo tipo `NUMÉRICOS`, temos duas categorias: `INTEIROS` e `DECIMAIS`. Nos números inteiros há diversos tipos que podem ser criados no MySQL e estão diretamente relacionados com o espaço que vou precisar para armazenar determinado número no banco de dados. Quanto maior o espaço, maior o conjunto de números possíveis a serem armazenados.

Observando a tabela, na coluna "TIPO" temos cinco categorias de números inteiros que podem ser armazenados no MySQL, o **TINYINT**, **SMALLINT**, **MEDIUMINT**, **INT** E **BIGINT**. No segundo campo, **Valor em Bytes** temos o número de bytes gastos para armazenar um número de determinado tipo, como o TINYINT que para armazenar é necessário 1 byte, o SMALLINT que gasta 2 bytes e assim sucessivamente.

Quanto maior a quantidade de bytes que posso armazenar, maior o espaço de números com os quais posso trabalhar. Então, por exemplo, o TINYINT fica entre -128 e 127, se for criado um número dessa categoria e enviado para armazenar o número 300, será retornado um erro, visto que esse tipo não suporta.

Temos também uma propriedade chamada `UNSIGNED`. É um atributo para números inteiros no MySQL utilizado para a definição de números positivos (sem sinal), visto que o sinal de menos (`-`) ocupa espaço de armazenamento. Então, se informar para o MySQL que uma coluna específica é do tipo inteiro e sem sinal, o conjunto de números para armazenar nesse tipo de campo é maior, visto que não é preciso armazenar no computador os sinais e até mesmo de números positivos, já que não é reservado um espaço para arquivar o sinal.

Exemplificando, se o TINYINT for do tipo UNSIGNED, consigo guardar de 0 a 255 e se for com sinal do -128 a 127, perceba haver uma diferença de espaços com o ganho do sinal.

Falando um pouco sobre os números `DECIMAIS`, temos dois tipos: de **PRECISÃO FIXA** e **PONTO FLUTUANTE**. Este significa que será realizado um arredondamento quando o número de casas decimais for superior ao número permitido pelo banco de dados. No ponto flutuante também temos dois tipos de valores decimais, o **FLOAT**, que trabalha com uma precisão simples de 4 bytes e o **DOUBLE**, com precisão dupla de 8 bytes. A diferença entre ambos é o tamanho de espaço de armazenamento.

O DOUBLE é mais usado para quando queremos ter números mais exatos nos cálculos, uma vez que ele faz arredondamentos mais precisos com números com mais casas decimais. Quando declaramos um número FLOAT ou DOUBLE, é possível especificar o número de dÍgitos e casas decimais.

Como exemplo, quando declaramos esse tipo, podemos especificar da seguinte forma `FLOAT (7,4)` isso significa que esse número do tipo FLOAT vai ter sete dígitos, sendo quatro casas decimais. Podemos inserir um número de casas decimais para além de quatro, como no caso do número `999,00009` com cinco casas decimais. O MySQL, atendendo a especificação, vai arredondar esse número para quatro casas decimais, armazenando o `999,0001`.

Nos `DECIMAIS FIXOS`, temos o **DECIMAL** ou **NUMERIC**, são análogos e sua definição é a quantidade máxima de dígitos que o número pode ter, no caso é 65 dígitos. Isso para números INTEIROS e DECIMAIS, ou seja, posso ter um número com um número inteiro e 64 casas decimais, ou posso ter um número com 64 números inteiros e apenas uma casa decimal.

Quando especificamos o número de casas decimais e a quantidade de dígitos, já estamos indicando o conjunto máximo e mínimo de dados. Vamos supor que temos `DECIMAL(5,2)`, isto é, o número é decimal com 5 dígitos e 2 casas decimais, só poderá armazenar entre -999,99 e 999,99, tal como especificamos no tamanho. Não será feita nenhuma aproximação, apenas vai ser gravado o número exato digitado para ser guardado no banco de dados.

Outro tipo numérico é o `BIT`, que armazena valores de até 64 bytes. Explicando um pouco sobre o BIT, se o campo for do tipo **BIT(1)**, é possível armazenar `1` ou `0`. Se for **BIT(2)** é viável armazenar `01`,`10`,`00` e `11`. Agora, se tiver um número de até 64 BITS, tenho o tamanho de 64 caracteres que podem ser gravado de 1 ou 0 que representa um número binário. Em campos do tipo `LÓGICO`, também é usado o BIT, sendo 1 (um) verdadeiro e 0 (zero) falso.

Os campos numéricos possuem alguns atributos. Já foi mencionado o `SIGNED` e `UNSIGNED`, que representam se haverá número negativo ou não, mas, agora vamos entender um pouco sobre o `ZEROFILL`, que preenche com zeros o que estiver faltando do número. Por exemplo, se tiver um campo do tipo `INT(4)` e pedir para solicitar o valor `5`, será gravado `0005`.

Outro atributo é o `AUTO_INCREMENT`. Esta propriedade é o próprio banco de dados que gera uma sequência numérica automaticamente. Se tiver uma tabela vazia com um campo desse tipo e for inserido um valor nessa coluna será atribuído o **valor 1**, se incluirmos mais um valor será gerado o **valor 2** e assim por diante. Essa sequência se inicia no 1 ou no 0, definido no próprio AUTO_INCREMENT, bem como, o valor do incremento que quero aplicar, podendo ser 0, 5, 10, 15, 20 ao invés de 1, 2, 3, 4.

O `OUT OF RANGE` é um erro que acontece quando tentamos gravar na base de dados um valor que está fora do espaço permitido.

Vamos compreender um pouco agora sobre os campos de `DATA` e `HORA`, temos cinco principais:

O campo `DATE` armazena um dia, no formato ano, mês e dia com traços entre eles, vai dia **1000-01-01** até **9999-12-31**. Já o `DATETIME`, guarda data e hora. A hora é importante principalmente quando tempos campos do tipo `LOG`, que possui o horário em que alguém fez alguma ação específica no sistema.

Seguindo, o `TIMESTAMP` é bem semelhante ao o **DATETIME**, contudo possui duas características principais: tem um _range_ menor, que vai de **1970-01-01** a **2038-01-19** e possui fuso horário. Por isso o range fica menor, para armazenar mais informações.

Por mais que esse range de datas pareça pequeno, vale lembrar que utilizamos fuso horário para sistemas, por exemplo, de agendas para marcar reuniões em empresas que tiver funcionários(as) em diversos países. Por isso, o range até 2038 não é tão pequeno quanto parece, visto que ninguém irá marcar uma reunião de hoje até o ano de 2038.

O `TIME` armazena somente o horário e tem um range, de -838:59:59 a 839:59:59. Normalmente, usamos só para gravar uma hora no relógio que vai de meia-noite às onze e cinquenta e nove da noite do dia seguinte. Por isso, não é preciso ter 838 horas gravadas.

No campo `YEAR` é guardado somente o ano de 1901 a 2155. Podendo ser de duas ou quatro casas decimais, mas, normalmente utilizamos o DATE com uma data de primeiro de janeiro do ano que quero armazenar. Nesse treinamento ainda aprenderemos que existem funções do tipo data que conseguem extrair de um campo DATE, DATETIME ou TIMESTAMP o ano específico.

Falando um pouco do tipo `STRING`, são as cadeias de caracteres, os textos. Temos algumas categorias, começando pelo **CHAR** e o **VARCHAR**, ambos possuem o tamanho limite de 255 caracteres, a principal diferença são os espaços.

Caso tivermos um campo CHAR(4) e o utilizamos para armazenar as letras `"aa"`, no banco de dados será guardado dois espaços vazios, já que no campo foi estabelecido o caractere de tamanho quatro, ficaria `" aa"`. Isto é, esse campo ocupa maior espaço em disco, visto que grava os espaços vazios que, em algumas situações, pode ser desnecessário. Já quando nos referimos ao VARCHAR(4), se quisermos armazenar "aa", será guardado somente dois caracteres sem gastar espaço a mais no disco.

Temos também as STRINGS do tipo binário, o `BINARY` e o `VARBINARY`. Ambos possuem o mesmo conceito do CHAR e VARCHAR, um armazena os espaços e o outro não. O que os difere é que o armazenamento não é em caractere e sim em bytes, ou seja, o tamanho máximo é expresso em binário.

Outros campos do tipo `STRING` são o **BLOB** e o **TEXT**. No primeiro temos as variações de tamanho máximos **TINYBLOB**, **BLOB**, **MEDIUMBLOB** e **LONGBLOB** e no TEXT também, temos o **TINYTEXT**, **TEXT**, **MEDIUMTEXT** e **LONGTEXT**.

O BLOB é binário, então, em um LONGBLOB é possível guardar um grande binário no banco. Exemplo, posso gravar bytes de um arquivo no Word, ou os bytes de uma foto no banco de dados. Já o TEXT vai ser usado para armazenar textos.

Outro campo é o `ENUM`, é como se definíssemos opções. Por exemplo, se tivermos um campo chamado "SIZE" do tipo ENUM, na declaração é necessário inserir as opções que serão armazenadas nesse campo, no caso `Size ENUM ('x-small', 'small', 'médium', 'large', 'x-large')`, só conseguimos guardar no campo "SIZE" os textos nos parênteses.

Dois atributos importantes dos campos do tipo STRING são os `SET` e o `COLLATE`, estão relacionados com as cadeias de caracteres que serão usados para armazenar o texto. Caso queira guardar texto em alguma língua diferente é preciso selecionar na definição de campo o SET e o COLLATE especificando a língua utilizada, assim, será inserido no campo uma **tabela ASCII** maior ou menor dependendo do tipo que você está usando.

Finalmente, há alguns campos que aparecem mais nas versões atuais do MySQL, como o `SPACIAL`, para visualizar mapas. O tipo `POINT` grava o ponto usando a latitude e longitude no banco MYSQL que fornece algum determinado local, como, restaurante, supermercado ou ponto turístico. Outro tipo é o `LINESTRING`, que representa uma linha. O `GEOMETRY` e `POLYGON`, que representam áreas no mapa.

Temos outros tipos, mas mencionei esses para dar um apanhado geral das possibilidades que temos para criar tabelas e quais as opções para definir o tipo de coluna.

-----------------------------------------------------------------------
Criando a primeira tabela

https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54332

## Transcrição

> Você pode fazer o [download](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/03/SQL_02.sql) completo do código realizado neste vídeo e continuar seus estudos.

Agora que já sabemos os tipos, vamos criar a primeira tabela no banco de dados. Lembrando que estamos fazendo um projeto de banco de dados para uma empresa de suco de frutas.

Conversando com a empresa, nos foi passado que gostariam de armazenar no MySQL os cadastros dos clientes com as seguintes informações: o CPF do cliente, o nome completo, o endereço completo (rua, bairro, cidade, estado e CEP), a data de nascimento, a idade, o sexo, o limite de crédito para efetuar a compra dos produtos, o volume mínimo de sucos que o cliente pode comprar e se já foi realizado a primeira compra.

Analisando essas informações, percebemos que cada uma é uma coluna e será necessário definir o tipo de cada campo. Vamos, então, para o Workbench que já temos o banco de dados **sucos**, mas sem nenhuma tabela ainda.

Vamos criar a primeira tabela, então. Na parte superior esquerda da tela, clique no ícone de um papel escrito SQL com um sinal de `(+)` embaixo. Significa que estamos criando um script SQL e irá abrir uma nova área que digitaremos os comandos.

Para criarmos uma tabela, basta escrever `CREATE TABLE`, note que o Workbench nos dá algumas opções do que pode ser o comando que estamos inserindo. Seguindo o comando, é preciso inserir um nome para a tabela, que vai ser "tbcliente". Neste treinamento não vamos nos preocupar tanto com nomenclatura, mas há boas práticas de como criar nomenclatura para tabelas, campos, índices, chave primária e estrangeira, e assim por diante.

```sql
CREATE TABLE tbcliente;
```

Seguindo com a nossa tabela, além do nome é preciso estabelecer as colunas e seus respectivos tipos. Clicando em "Enter" e abrindo um parêntese para especificar os campos, vamos iniciar pelo CPF, o número que identifica o cliente, pode ser que tenha pontos, traços e às vezes inicia com zero. Por essa razão, por mais que o CPF sejam números, é melhor armazenar como texto. Visto que se gravar como número no momento de gravar, os zeros no início serão **truncados**. Exemplificando, se tivermos um CPF com o número `00388323102`, o banco de dados guarda `3888323102`. Por isso, vamos considerar o CPF com o tipo VARCHAR.

```sql
CREATE TABLE tbcliente
(CPF VARCHAR(11),
```

Após a vírgula vamos inserir os próximos campos. O "NOME" também será VARCHAR e, por ter nomes compridos, vamos estabelecer 100 caracteres para reservar o nome. Continuando, temos "ENDERECO" que também devemos considerar haver nomes de ruas grandes, inclusive, às vezes é viável criar dois campos para gravar o endereço. Vamos inserir da seguinte maneira `ENDERECO1 VARCHAR(150),`, `ENDERECO2 VARCHAR(150),`, e depois o bairro `BAIRRO VARCHAR(50),`, a cidade `CIDADE VARCHAR(50),`, lembrando sempre de inserir uma vírgula em cada linha.

O próximo campo pedido pela empresa é o "ESTADO", que também será do tipo VARCHAR `ESTADO VARCHAR(50),` em seguida o `CEP VARCHAR(8),`. Na idade, como dificilmente as pessoas vão ter mais de 150 anos, não é preciso colocar um INT, um SMALLINT já atende o que precisamos `IDADE SMALLINT,`, o sexo, que vai ser uma letra M (masculino) e F (feminino), ficando `SEXO VARCHAR(1),`.

No nosso campo de limite de crédito estamos nos referindo a valores em dinheiro, valores decimais, como, limite de crédito de R$ 1.627.438,32. Então, vamos colocar `LIMITE_CREDITO FLOAT,`, caso queira deixar com espaço entre a palavra limite e crédito, basta inserir crase no início e fim, assim `limite credito`.

Perceba que não especificamos o número de caracteres no FLOAT, mas poderíamos colocar `FLOAT(10, 2),`. Contudo, mesmo sabendo que dinheiro tem duas casas decimais, vamos representar o número sem fixar o número de casas decimais.

> **Opinião do instrutor:** quando estamos falando de banco de dados, estamos falando sobre armazenar informação. Quando exibo a informação é que posso mostrá-la do jeito como ela deve ser representada. Ou seja, na minha opinião, você não precisa se preocupar com o formato do valor, do número, ou do texto no momento de armazená-lo no banco de dados, mas sim no momento de exibir em um relatório, em um programa. E aí você tem, não somente no SQL, mas também nas linguagens de programação com as quais vai trabalhar em conjunto com o banco de dados, de exibir a informação do jeito como ela tem que aparecer. Isto é, posso gravar um número com dez casas decimais, mas no momento em que eu for exibir, forço a exibir só com duas casas.

Já o volume de compras é expresso em litros, então, também não vamos nos preocupar se tem ou não casas decimais: `VOLUME_COMPRA FLOAT,`. Finalmente, o último campo, se o cliente já realizou uma primeira compra ou não. Neste caso vamos usar o campo BIT de um espaço apenas, para eu poder ter o 1 (realizou a primeira compra) ou o 0 (ainda não realizou a primeira compra): `PRIMEIRA_COMPRA BIT(1))`, esse último parêntese fecha o que inseri no início da inclusão de todas as colunas.

Código completo:

```scss
CREATE TABLE tbcliente
( CPF VARCHAR (11) ,
NOME VARCHAR (100) ,
ENDERECO1 VARCHAR (150) ,
ENDERECO2 VARCHAR (150) ,
BAIRRO VARCHAR (50) ,
CIDADE VARCHAR (50) ,
ESTADO VARCHAR (2) ,
CEP VARCHAR (8) ,
IDADE SMALLINT,
SEXO VARCHAR (1) ,
LIMITE_CREDITO FLOAT ,
VOLUME_COMPRA FLOAT ,
PRIMEIRA_COMPRA BIT (1) )
```

Ficou assim, `CREATE TABLE,` logo depois o nome da tabela, abro parênteses, coloco todos os campos separados por vírgula, o nome do campo e o tipo, e fecho o parêntese. Vamos rodar agora, selecionando na parte superior à área que digitamos o comando, o ícone de raio. Na parte de "Action Output" é exibida uma mensagem informando que o comando foi executado com sucesso.

Na região de "Schemas", clicando em **sucos** com o botão direito do mouse e escolhendo a opção "Refresh All", note que a tabela "tbcliente" foi criada.

Fizemos o primeiro comando de SQL para criar uma tabela. Espero que tenham entendido e gostado, até a próxima aula!

-----------------------------------------------------------------------
Criando a tabela pelo assistente
https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54333


## Transcrição

Se a empresa **suco de frutas** possui uma tabela de clientes, consequentemente, precisa de uma tabela de **produtos**, afinal, os clientes devem comprar itens da empresa.

Nessa tabela teremos as informações dos sucos de frutas, tais como: "código do produto", é um código interno para identificar o produto; "nome do produto", descritor do produto; "embalagem", pode ser lata, litro ou em caixa; "tamanho" é o volume do suco, "sabor", visto que há várias marcas com o mesmo sabor e "preço de lista", é o preço tabelado do produto. Todos esses cinco campos serão VARCHAR, visto que o código pode ter letras e o preço de lista, será do tipo FLOAT.

Vamos criar essa tabela de produtos usando uma maneira mais visual, uma caixa de diálogo que o MySQL Workbench possui. Então, voltando para o Workbench, do lado esquerdo em **sucos**, clique em "Tables" com o botão direito do mouse e escolha a opção "create table". Será exibida uma nova aba `"new_table - Table"` com uma série de propriedades que é possível usar na criação da tabela.

Preenchendo essas propriedades, vamos em "Table name" e inserir o nome "tbProduto", não vamos incluir os parâmetros mais detalhados, como charset/collation ou onde tem as letras "PK", "NN", entre outras, isso vamos ver mais adiante, talvez em um curso mais avançado.

Para criar as colunas da tabela, selecione sob "Column name" e digite o nome e ao lado o "Datatype" (tipo do dado) do campo. Começando por código do produto, que vamos chamar somente de "PRODUTO" e o tipo VARCHAR(20), observe que "PK" e "NN" foram selecionados automaticamente, vamos desmarcar no momento por ser propriedades que não são necessarias ainda para configurar na tabela.

Passando para o próximo campo, selecione a seta para baixo do lado direito na caixa de diálogo e digite "NOME" que também será VARCHAR(150), para o campo seguinte, "EMBALAGEM" do tipo VARCHAR(150), "TAMANHO" que será VARCHAR(50), "SABOR" que é VARCHAR (50) e, por último, "PRECO_LISTA" que será FLOAT.

Inserido todos os campos, clicamos agora em "Apply" do lado inferior direito e será exibida uma mensagem informando sobre uma configuração padrão que o programa vai usar, selecione o botão "OK" para continuar.

Será mostrada uma nova tela com o comando com algumas alterações como o nome do banco, ponto e nome da tabela ``CREATE TABLE `sucos`.`tbproduto``, o que não tem problema visto que quando rodamos o script para criar a tabela de clientes já haviamos selecionado a base **sucos**, por isso, ao inserir um campo ele estará se referindo a base sucos. Mas, podemos criar esse script sem a necessidade de entrar no banco de dados que é inserindo o nome do banco, ponto final e nome da tabela. Já as crases no nome da tabela e banco de dados é que, por ser um nome genérico o programa acaba inserindo para garantir caso haja espaço entre os nomes.

Percebe que ao final de cada campo está escrito "NULL", isso significa que esse campo aceita valores nulos ou vazios, como não especificamos na caixa de diálogo o programa acaba inserindo automaticamente.

Mas no momento vamos nos atentar somente aos comandos já vistos nesse curso. Então, criamos uma tabela (`CREATE TABLE`), inserimos o nome da tabela (`sucos.tbproduto`), os campos e suas respectivas categorias separados por vírgula. Clique no botão "Apply" do lado inferior direito e, logo após, "Finish".

Observando, no Workbench, do lado esquerdo a tabela "tbproduto" já foi incluída em **sucos**. Agora, temos no banco de dados duas tabelas, a de clientes e produtos.



-----------------------------------------------------------------------
Para saber mais: opções indisponíveis

A opção de criar coluna pode não aparecer devido à **resolução da tela**, dependendo da disposição algumas opções ficam sobrepostas pelas abas abertas.

Tente ajustar o tamanho da tela do Workbench. Para isso siga a instrução abaixo.

- No canto superior direito, há três opções de ajuste da tela, clique na opção do **meio**, onde ajusta a tela para baixo.

![Configurando a tela do Workbench. No canto superior direito, há três opções de ajuste da tela, onde está destacado em vermelho. A aba column name também está destacado.](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/03/image1.png)

Feito isso, verifique se a opção criar coluna está disponível.

-----------------------------------------------------------------------
Apagando tabelas

https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54334

## Transcrição

Podemos apagar as tabelas, mas antes, é necessário verificar alguns requisitos antes de excluir. No caso, temos duas tabelas que não se relacionam no banco de dados, mas se tivessem alguma relação entre elas, pode ter situações em que não é possível apagar.

Vamos apagar a tabela de duas formas, através do comando e de um assistente. Como iremos utilizar a tabela de clientes e produtos nas próximas aulas, não vamos excluir ela, iremos no _script_ que criamos a tabela de clientes e inserir um sufixo "2" no final do nome da tabela e rodar o comando, realize o mesmo procedimento para o sufixo "3".

Código:

```scss
CREATE TABLE tbcliente2
( CPF VARCHAR (11) ,
NOME VARCHAR (100) ,
ENDERECO1 VARCHAR (150) ,
ENDERECO2 VARCHAR (150) ,
BAIRRO VARCHAR (50) ,
CIDADE VARCHAR (50) ,
ESTADO VARCHAR (2) ,
CEP VARCHAR (8) ,
IDADE SMALLINT,
SEXO VARCHAR (1) ,
LIMITE_CREDITO FLOAT ,
VOLUME_COMPRA FLOAT ,
PRIMEIRA_COMPRA BIT (1));
```

Clique com o botão direito do mouse em "TABLES" e escolha a opção "Refresh All" para aparecer as tabelas 2 e 3 de clientes.

Na primeira forma que temos para excluir uma tabela, no Workbench, selecione a "tbcliente2" com o botão direito do mouse e escolha a opção "Drop Table", será exibida uma mensagem perguntando se queremos revisar o comando "Review SQL" ou executar "Drop Now", selecione essa última opção e pronto, a tabela foi apagada.

A outra forma é por comando, selecione do lado superior esquerdo o ícone SQL com o `+` abaixo para criarmos uma pasta de comando e certifique-se que está no banco de dados **sucos** observando se está em negrito o nome ou usando o comando `use Sucos;`. Agora podemos apagar a tabela "tbcliente3" usando `DROP TABLE tbCliente3;` e rode o comando.

```sql
DROP TABLE tbcliente3;
```

Note que a tabela "tbcliente3" não consta mais em "TABLES" no banco de dados **sucos**. Recapitulando, é possível apagar uma tabela pelo Workbench usando o botão direito do mouse ou por comando "Drop Table" e o nome da tabela.

-----------------------------------------------------------------------
Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Acesse MySQL Workbench.

2) Crie a tabela de cliente digitando o comando abaixo:

```sql
CREATE TABLE tbcliente
( CPF VARCHAR (11) ,
NOME VARCHAR (100) ,
ENDERECO1 VARCHAR (150) ,
ENDERECO2 VARCHAR (150) ,
BAIRRO VARCHAR (50) ,
CIDADE VARCHAR (50) ,
ESTADO VARCHAR (2) ,
CEP VARCHAR (8) ,
IDADE SMALLINT,
SEXO VARCHAR (1) ,
LIMITE_CREDITO FLOAT ,
VOLUME_COMPRA FLOAT ,
PRIMEIRA_COMPRA BIT )
```

1) Execute o comando e depois atualize a árvore do Workbench para observar a nova tabela criada.

2) Podemos criar tabela pelo assistente. Botão da direita do mouse sobre Tables, abaixo do banco de dados Sucos, e escolha Create Table.

![1.png](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/03/1.png)

3) Digite o nome da tabela como tbProduto.

4) Inclua os campos conforme mostrado abaixo:

```scss
PRODUTO VARCHAR(20)
NOME VARCHAR(150)
EMBALAGEM VARCHAR(50)
TAMANHO VARCHAR(50)
SABOR VARCHAR(50)
PRECO_LISTA FLOAT
```

5) Clique no botão Apply.

6) Verifique o comando a ser executado. Clique em Apply novamente e a tabela é criada.

7) A tabela pode ser apagada. Para isso digite o comando para criar novas tabelas:

```sql
CREATE TABLE tbcliente2
( CPF VARCHAR (11) ,
NOME VARCHAR (100) ,
ENDERECO1 VARCHAR (150) ,
ENDERECO2 VARCHAR (150) ,
BAIRRO VARCHAR (50) ,
CIDADE VARCHAR (50) ,
ESTADO VARCHAR (2) ,
CEP VARCHAR (8) ,
IDADE SMALLINT,
SEXO VARCHAR (1) ,
LIMITE_CREDITO FLOAT ,
VOLUME_COMPRA FLOAT ,
PRIMEIRA_COMPRA BIT );
```

```sql
CREATE TABLE tbcliente3
( CPF VARCHAR (11) ,
NOME VARCHAR (100) ,
ENDERECO1 VARCHAR (150) ,
ENDERECO2 VARCHAR (150) ,
BAIRRO VARCHAR (50) ,
CIDADE VARCHAR (50) ,
ESTADO VARCHAR (2) ,
CEP VARCHAR (8) ,
IDADE SMALLINT,
SEXO VARCHAR (1) ,
LIMITE_CREDITO FLOAT ,
VOLUME_COMPRA FLOAT ,
PRIMEIRA_COMPRA BIT );
```

8) Foram criadas duas tabelas. Agora vamos apaga-las. A primeira por comando:

```sql
DROP TABLE TB_CLIENTES3;
```

9) Pelo assistente basta com o botão da direita do mouse sobre o nome da tabela TB_CLIENTES2:

![2.png](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/03/2.png)


-----------------------------------------------------------------------
Inserindo registros na tabela
https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54335

## Transcrição

> ERRATA

> A partir do momento [00:25] o instrutor passa a apresentar a planilha de **PRODUTOS**. Nesta planilha uma das palavras é apresentada com um erro ortográfico, a palavra está escrita como **Melância**, mas na verdade a escrita correta é **Melancia**.

> Você pode fazer o [download](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/04/Aula4.1SQL.zip) completo dos códigos realizados neste vídeo e continuar seus estudos.

Já temos a tabela de **cliente** e **produto** criadas, agora precisamos inserir informações nelas. Neste momento, faremos da seguinte forma: baixe o link disponibilizado para este vídeo, terá uma planilha de Excel chamada "PRODUTOS.xlsx", selecione ela e observe que temos os campos "SKU" que é o código do produto, "DESCRITOR" é o nome do produto que dentro também temos as informações de tamanho e sabor, "EMBALAGEM" e "PREÇO", são as informações específicas do produto.

Vamos usar essa planilha PRODUTOS como base para inserir dados dentro da tabela. Voltando para o Workbench, selecione o ícone para criar um script, vamos pegar a primeira linha que é o "SKU 1040107".

> Certifique-se que está no banco de dados sucos, utilizando o comando `USE sucos;`

O comando utilizado para inserir as informações em uma tabela é o `INSERT INTO tbproduto(`, abrindo parêntese para incluir os campos da tabela. Observe que em "tbproduto" em "columns" há o nome das colunas ("PRODUTO", "NOME", "EMBALAGEM", "TAMANHO", "SABOR" e "PRECO_LISTA") sendo a que vamos incluir no comando _INSERT_.

Código completo até o momento:

```sql
USE sucos;

INSERT INTO tbproduto (
PRODUTO,
NOME, 
EMBALAGEM, 
TAMANHO,
SABOR,
PRECO_LISTA)
```

Após a inclusão dos campos, digite a cláusula **_VALUES_** que significa que vamos especificar os valores da instrução `INSERT INTO`. No caso, a primeira coluna é "PRODUTO", que olhando na planilha do Excel é o "SKU", sabemos que o código do produto foi criado como VARCHAR. Então, voltando para o comando abra um parêntese após VALUES e insira `'1040107`' e uma vígula, que indica que vamos acrescentar a informação sobre o próximo campo "Nome". Repita o procedimento para os demais campos, com exceção do "PRECO_LISTA" que por ser **FLOAT** não é necessário utilizar aspas simples.

> Para inserir uma informação que é considerada STRING, é preciso utilizar aspas simples (`''`) para que o programa identifique.

Código:

```sql
INSERT INTO tbproduto (
PRODUTO, 
NOME, 
EMBALAGEM, 
TAMANHO, 
SABOR, 
PRECO_LISTA) VALUES (
'1040107', 'Light - 350 ml - Melancia', 'Lata', '350 ml', 'Melancia', 4.56);
```

Executando o comando, será exibido uma mensagem informando que o programa rodou com sucesso. Mas, para visualizar as informações nessa tabela, para verificar se foram incluídas, usaremos o comando `SELECT * FROM tbproduto;`, selecione somente essa linha para rodar. Será exibida a tabela produto com as informações inseridas.

|**PRODUTO**|**NOME**|**EMBALAGEM**|**TAMANHO**|**SABOR**|**PRECO_LISTA**|
|---|---|---|---|---|---|
|1040107|Light - 350 ml - Melancia|Lata|350 ml|Melancia|4.56|

Aprendemos, então, a incluir o primeiro registo na tabela. Até a próxima aula!

Incluindo o primeiro vendedor

Vamos criar um vendedor na tabela de vendedores. A informação é a seguinte:

```makefile
Matrícula: 00233
Nome: João Geraldo da Fonseca
Comissão: 10%
```

Digite o comando de inclusão.

-----------------------------------------------------------------------
Inserindo vários registros na tabela

https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54336

## Transcrição

> Você pode fazer o [download](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/04/SQL_04.sql) completo do código realizado neste vídeo e continuar seus estudos.

Continuando com as inclusões das informações na tabela, é possível inserir mais dados em um mesmo script. Olhando agora para a segunda linha da planilha do Excel, vamos inserir esses elementos.

```sql
INSERT INTO tbproduto (
PRODUTO, 
NOME, 
EMBALAGEM, 
TAMANHO, 
SABOR, 
PRECO_LISTA) VALUES (
'1037797', 'Clean - 2 Litros - Laranja', 'PET', '2 Litros', 'Laranja', 16.01);
```

Repita o código para os outros registros da tabela produto.

```sql
INSERT INTO tbproduto (
PRODUTO, 
NOME, 
EMBALAGEM, 
TAMANHO, 
SABOR, 
PRECO_LISTA) VALUES (
'1000889', 'Sabor da Montanha - 700 ml - Uva', 'Garrafa', '700 ml', 'Uva', 6.31);

INSERT INTO tbproduto (
PRODUTO, 
NOME, 
EMBALAGEM, 
TAMANHO, 
SABOR, 
PRECO_LISTA) VALUES (
'1004327', 'Videira do Campo - 1,5 Litros - Melancia', 'PET', '1,5 Litros', 'Melancia', 19.51);

SELECT * FROM tbproduto;
```

Vamos inserir apenas esses registros no momento, temos três comandos _INSERT INTO_ e um _SELECT_, este para visualizar os elementos incluídos na tabela. Rodando o script, uma mensagem comunicando que os comandos foram executados com sucesso será exibida em "_Action Output_" e a tabela com as informações será mostrada em "_Result grid_".

|**PRODUTO**|**NOME**|**EMBALAGEM**|**TAMANHO**|**SABOR**|**PRECO_LISTA**|
|---|---|---|---|---|---|
|1040107|Light - 350 ml - Melancia|Lata|350 ml|Melancia|4.56|
|1037797|Clean - 2 Litros - Laranja|PET|2 Litros|Laranja|16.01|
|1000889|Sabor da Montanha - 700 ml - Uva|Garrafa|700 ml|Uva|6.31|
|1004327|Videira do Campo - 1,5 Litros - Melancia|PET|1,5 Litros|Melancia|19.51|

Essa é a tabela de produtos com os elementos incluídos nos comandos _INSERT INTO_. Nessa aula, então, aprendemos como inserir mais de um registro no mesmo _script_.

# Incluindo mais dois vendedores

 [Próxima Atividade](https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/56446/next)

- [](https://cursos.alura.com.br/suggestions/new/mysql-manipule-dados-com-sql/56446/question)

Vamos criar mais dois vendedores, no mesmo comando SQL.

```makefile
Matrícula: 00235
Nome: Márcio Almeida Silva
Comissão: 8%
```

E

```makefile
Matrícula: 00236
Nome: Cláudia Morais 
Comissão: 8%
```

Digite o comando de inclusão.

-----------------------------------------------------------------------
Alterando registros

https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54337

## Transcrição

> Você pode fazer o [download](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/04/4.3.zip) completo do código realizado neste vídeo e continuar seus estudos.

Nessa aula vamos aprender a como alterar uma informação que já está incluída na tabela. No link associado a este vídeo, baixe o arquivo `SQL_05.sql` e clique com o botão direito do mouse para abrir como editor de texto.

Será exibido os seguintes comandos:

```sql
USE sucos;

INSERT INTO tbproduto (
PRODUTO,  NOME, EMBALAGEM, TAMANHO, SABOR,
PRECO_LISTA) VALUES
('544931', 'Frescor do Verão - 350 ml - Limão', 'PET', '350 ml','Limão',3.20);

INSERT INTO tbproduto (
PRODUTO,  NOME, EMBALAGEM, TAMANHO, SABOR,
PRECO_LISTA) VALUES
('1078680', 'Frescor do Verão - 470 ml - Manga', 'Lata', '470 ml','Manga',5.18);
```

Copiando o script do arquivo, crie no ambiente do _Workbench_ um novo espaço para os comandos, cole e rode o programa para ser incluído mais dois produtos na tabela.

Vamos verificar na planilha o produto com o seguinte código `544931`, se encontra na linha 7 da planilha, perceba que o campo "EMBALAGEM" consta como **lata** e no comando está **PET**, o preço também está diferente sendo na planilha `2,46` e no script `3.20`. Analisando o próximo código `1078680`, a embalagem também está divergente, era para ser **garrafa** e incluímos **lata**, os outros campos estão com as informações corretas.

Gerando novamente um ambiente para um novo script, digite o comando `USE sucos;`, para entrar na base de sucos e, em seguida, o comando para realizar a alteração das informações que estão diferentes com `UPDATE tbproduto SET`, em _set_ especificamos um conjunto de alterações que queremos realizar, utilizando a sintaxe `SET column1 = value1, column2 = value2,...`.

Mas, precisamos especificar em qual produto queremos fazer essa mudança. Para isso, incluímos uma condição WHERE com o código do produto e realizamos o mesmo comando para alterar as informações o produto seguinte.

Código:

```sql
USE sucos;

UPDATE tbproduto SET EMBALAGEM = 'Lata', PRECO_LISTA = 2.46
WHERE PRODUTO = '544931';

UPDATE tbproduto SET EMBALAGEM = 'Garrafa'
WHERE PRODUTO = '1078680';
```

Rodando o programa é retornado um erro na parte de "_Output_" informando que está sendo usado um UPDATE sem uma condição que utilize o campo com chave primária. Esse erro aparece porque o MySQL está me obrigando a usar na condição um campo que seja chave primária, isto é, que não se repete nos registros.

Mas não incluímos uma chave primária nessa tabela, não aprendemos isso ainda. Colocando o mouse por cima do erro, ele me dá uma dica de ir em _preferences -< SQL editor_. Vamos, então, na parte superior em "Edit > Preferences > SQL Editor" para desmarcar o campo `Safe Updates (rejects UPDATES and DELETEs with no restrictions)` e selecione "OK".

Para funcionar, será necessário reconectar o Workbench, para sair vá em "File > Exit" e para abrir novamente clique no Windows, digite "MySQL" e selecione essa opção. Perceba que os comandos estão salvos no ambiente para escrevermos o código, vamos rodar novamente o script, será exibida uma mensagem comunicando que foi efetuado com sucesso.

Para verificar se a alteração foi executada, vamos incluir `SELECT * FROM tbproduto;` e selecionar apenas essa linha para rodar.

|**PRODUTO**|**NOME**|**EMBALAGEM**|**TAMANHO**|**SABOR**|**PRECO_LISTA**|
|---|---|---|---|---|---|
|1040107|Light - 350 ml - Melancia|Lata|350 ml|Melancia|4.56|
|1037797|Clean - 2 Litros - Laranja|PET|2 Litros|Laranja|16.01|
|1000889|Sabor da Montanha - 700 ml - Uva|Garrafa|700 ml|Uva|6.31|
|1004327|Videira do Campo - 1,5 Litros - Melancia|PET|1,5 Litros|Melancia|19.51|
|544931|Frescor do Verão - 350 ml - Limão|Lata|350 ml|Limão|2.46|
|1078680|Frescor do Verão - 470 ml - Manga|Garrafa|470 ml|Manga|5.18|

Note que os campos solicitados foram alterados para os produtos com os códigos `544931` e `1078680`. Nessa aula alteramos os registros na tabela utilizando o comando _UPDATE_, filtrando com _WHERE_ quais linhas gostaríamos de modificar e, nesse caso, tiramos a condição de chave primária para executar esse filtro.

# Alterando informações sobre os vendedores

 [Próxima Atividade](https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/56447/next)

- [](https://cursos.alura.com.br/suggestions/new/mysql-manipule-dados-com-sql/56447/question)

Recebemos a seguinte informação:

Cláudia Morais (00236) recebeu aumento e sua comissão passou a ser de 11%. José Geraldo da Fonseca (00233) reclamou que seu nome real é José Geraldo da Fonseca Junior.

Efetue estas correções na base de dados.

-----------------------------------------------------------------------
#   
Excluindo registros
https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54338

## Transcrição

> Você pode fazer o [download](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/04/SQL_07.sql) completo do código realizado neste vídeo e continuar seus estudos.

Já sabemos incluir e alterar registros na tabela, agora vamos aprender como apagar. Para analisar os elementos da tabela, vamos selecionar somente o comando `SELECT * FROM tbproduto;`, será exibida a seguinte tabela:

|**PRODUTO**|**NOME**|**EMBALAGEM**|**TAMANHO**|**SABOR**|**PRECO_LISTA**|
|---|---|---|---|---|---|
|1040107|Light - 350 ml - Melancia|Lata|350 ml|Melancia|4.56|
|1037797|Clean - 2 Litros - Laranja|PET|2 Litros|Laranja|16.01|
|1000889|Sabor da Montanha - 700 ml - Uva|Garrafa|700 ml|Uva|6.31|
|1004327|Videira do Campo - 1,5 Litros - Melancia|PET|1,5 Litros|Melancia|19.51|
|544931|Frescor do Verão - 350 ml - Limão|Lata|350 ml|Limão|2.46|
|1078680|Frescor do Verão - 470 ml - Manga|Garrafa|470 ml|Manga|5.18|

Vamos escolher o produto `1078680` para excluir. Abrindo um novo arquivo de edição para escrever o comando, insira `USE sucos;` e na próxima linha `DELETE FROM tbproduto`, mas, note que não há uma condição do que apagar, se rodarmos assim o comando vai excluir todos os registros da tabela. Por isso, é necessário incluir uma condição, igual fizemos no _UPDATE_ utilizando a cláusula _WHERE_.

> Cuidado para não confundir **DROP** e **DELETE**. O **DROP** é utilizado para apagar objetos do MySQL, como, banco de dados, tabelas, índices e chave primária. Já o **DELETE** é para excluir registros armazenados em uma tabela do banco de dados.

```sql
DELETE FROM tbproduto WHERE PRODUTO = '1078680';
```

Rodando esse comando, será exibida uma mensagem avisando que foi efetuado com sucesso em "_Action Out_". Para visualizarmos a exclusão do registro, vamos utilizar o `SELECT * FROM tbprodutos;`, selecionando somente esse comando e rodando.

Resultado da tabela após o comando _DELETE_:

|**PRODUTO**|**NOME**|**EMBALAGEM**|**TAMANHO**|**SABOR**|**PRECO_LISTA**|
|---|---|---|---|---|---|
|1040107|Light - 350 ml - Melancia|Lata|350 ml|Melancia|4.56|
|1037797|Clean - 2 Litros - Laranja|PET|2 Litros|Laranja|16.01|
|1000889|Sabor da Montanha - 700 ml - Uva|Garrafa|700 ml|Uva|6.31|
|1004327|Videira do Campo - 1,5 Litros - Melancia|PET|1,5 Litros|Melancia|19.51|
|544931|Frescor do Verão - 350 ml - Limão|Lata|350 ml|Limão|2.46|

**Código completo:**

```sql
USE sucos;

DELETE FROM tbproduto WHERE PRODUTO = '1078680';

SELECT * FROM tbproduto;
```

O comando _DELETE_ é considerado perigoso sem uma cláusula _WHERE_, visto que sem essa condição apaga todos os registros da tabela. Por esse motivo, é importante sempre inserir uma condição para apagar os elementos desejados da tabela.

No que se refere a garantia de apagar algum elemento que não quisesse fazer existem mecanismos dentro do banco de dados. Mas veremos esse tipo de situação em outros treinamentos.

Vamos analisar o que ocorre se rodarmos novamente o comando DELETE com o código `1078680`, selecionando somente esse comando. Em "_Action Output_" note que não será retornado um erro, mas a mensagem exibida informa que zero linhas foram afetadas, isso significa que o programa procurou o registro para realizar a exclusão, mas não o encontrou.

-----------------------------------------------------------------------
Incluindo a chave primária

https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54339

## Transcrição

> Você pode fazer o [download](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/04/SQL_08.sql) completo do código realizado neste vídeo e continuar seus estudos.

> ERRATA

> O instrutor usa `USE tbproduto`; para especificar o banco de dados. Porém, o correto é `USE sucos;`.

Quando tentamos executar o comando _UPDATE_, o MySQL retornou um erro informando ser preciso incluir na condição de filtro um campo que fosse chave primária. Tivemos que ir em "Preferences > SQL Editor" e desmarcar a opção "_Safe Updates_".

Porém, é importante que tenha chave primária na tabela, se não, arriscamos inserir registros iguais na mesma tabela. No caso da "tbproduto" é o código interno do produto, visto que esse não se repete. É possível que os produtos possuam as mesmas descrições, mas o código interno não.

Vamos, então, alterar a tabela e incluir a chave primária associada a tabela de produtos ("tbproduto"). Criando mais uma área de código, insira `USE sucos;` e, na próxima linha, o comando que indica que podemos alterar uma propriedade de uma tabela existente, o `ALTER TABLE tbproduto ADD PRIMARY KEY (PRODUTO);`.

> Quando criamos a tabela de produtos já poderíamos ter especificado a chave primária, porém, vamos aprender como incluir em tabelas já existentes no banco de dados.

**Código**:

```sql
USE sucos;

ALTER TABLE tbproduto ADD PRIMARY KEY (PRODUTO);
```

Será exibida a mensagem que o comando foi executado com sucesso. Para compreender a consequencia dessa ação, vamos inserir um novo produto. Lembrando que em aulas anteriores, excluímos o produto `1078680`, então, vamos copiar o _INSERT INTO_ dele e incluir novamente o produto no nosso _script_ atual e também, o comando _UPDATE_, visto que a embalagem estava incorreta.

Comandos para inserir no código para incluir novamente o produto `1078680` com as alterações:

```sql
INSERT INTO tbproduto (
PRODUTO,  NOME, EMBALAGEM, TAMANHO, SABOR,
PRECO_LISTA) VALUES
('1078680', 'Frescor do Verão - 470 ml - Manga', 'Lata', '470 ml','Manga',5.18);

UPDATE tbproduto SET EMBALAGEM = 'Garrafa'
WHERE PRODUTO = '1078680';
```

Rodando ambos os comandos e, em seguida, o _SELECT FROM tbproduto;_ note que na tabela em "_Result Grid_" estará inserido o produto '1078680'.

**Tabela:**

|**PRODUTO**|**NOME**|**EMBALAGEM**|**TAMANHO**|**SABOR**|**PRECO_LISTA**|
|---|---|---|---|---|---|
|1040107|Light - 350 ml - Melancia|Lata|350 ml|Melancia|4.56|
|1037797|Clean - 2 Litros - Laranja|PET|2 Litros|Laranja|16.01|
|1000889|Sabor da Montanha - 700 ml - Uva|Garrafa|700 ml|Uva|6.31|
|1004327|Videira do Campo - 1,5 Litros - Melancia|PET|1,5 Litros|Melancia|19.51|
|544931|Frescor do Verão - 350 ml - Limão|Lata|350 ml|Limão|2.46|
|1078680|Frescor do Verão - 470 ml - Manga|Garrafa|470 ml|Manga|5.18|

**Código completo:**

```sql
USE sucos;

ALTER TABLE tbproduto ADD PRIMARY KEY (PRODUTO);

SELECT * FROM tbproduto;

INSERT INTO tbproduto (
PRODUTO,  NOME, EMBALAGEM, TAMANHO, SABOR,
PRECO_LISTA) VALUES
('1078680', 'Frescor do Verão - 470 ml - Manga', 'Lata', '470 ml','Manga',5.18);

UPDATE tbproduto SET EMBALAGEM = 'Garrafa'
WHERE PRODUTO = '1078680';
```

Agora que temos o produto incluído e o campo produto sendo a chave primária, vamos rodar o _INSERT INTO_ novamente para verificar o que acontece se tentarmos incluir um produto com o mesmo código na tabela. O MySQL retorna a mensagem de erro "_Error Code: 1062. Duplicate entry '1078680' for key 'PRIMARY'_", isto é, já existe um código com esse número na tabela e não é possível inserir esse registro duplicado.

A chave primária nos permite um maior controle sobre a tabela, não permitindo que seja incluído dois produtos com o mesmo código. Nas boas práticas de MySQL, o ideal é sempre especificar a chave primária de uma tabela, podendo usar o comando _CREATE TABLE_ e, depois, o _ALTER TABLE_ para criar a chave primária.

-----------------------------------------------------------------------
#   
Manipulando datas e campos lógicos

https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54340

## Transcrição

> Você pode fazer o [download](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/04/SQL_09.sql) completo do código realizado neste vídeo e continuar seus estudos.

Vamos manipular duas categorias de campos que não estudamos até o momento, o **_LÓGICO_** e a **_DATA_**, utilizando a tabela de cliente.

Do lado esquerdo do Workbench, em "sucos > tables > tbcliente > columns", temos todas as colunas da tabela, perceba que o campo "PRIMEIRA_COMPRA" é do tipo BIT (**lógico**), mas que não há campo do tipo _DATA_ nessa tabela, apenas "IDADE" que é _INT_.

Conversando com o gerente da empresa "Suco de Frutas", ele menciona que gostaria de incluir a data de nascimento dos clientes. Para tanto, iremos primeiro inserir uma chave primária em "tbcliente", que será o número do "CPF" e em seguida, adicionar a coluna "DATA_NASCIMENTO". Depois, vamos inserir um registro para analisar como incluir _data_ e informação _lógica_ , representada por 1 ou 0, na tabela.

Criando um ambiente para o _script_, insira o comando `USE sucos;` e na linha seguinte `ALTER TABLE tbcliente ADD PRIMARY KEY (CPF);`, para gerar a chave primária. Já para incluir a nova coluna "DATA_NASCIMENTO" utilizaremos também o _ALTER TABLE_ com algumas modificações `ALTER TABLE tbcliente ADD COLUMN (DATA_NASCIMENTO DATE);`.

```sql
USE sucos;

ALTER TABLE tbcliente ADD PRIMARY KEY (CPF);

ALTER TABLE tbcliente ADD COLUMN (DATA_NASCIMENTO DATE);
```

Então, _ALTER TABLE_ (nome da tabela), _ADD COLUMN_ (adicionando um campo novo), e _DATA_NASCIMENTO DATE_, específico o novo campo que quero adicionar e o seu tipo. Vamos rodar esse _script_ com os três comandos. Em "Columns", selecionando o botão direito do mouse e escolhendo a opção "_Refresh All_", aparece o campo que incluímos "DATA_NASCIMENTO".

Vamos inserir os campos usando o _INSERT INTO_, como fizemos em algumas aulas passadas.

```sql
INSERT INTO tbcliente (
CPF, 
NOME, 
ENDERECO1, 
ENDERECO2, 
BAIRRO, 
CIDADE, 
ESTADO, 
CEP, 
IDADE, 
SEXO, 
LIMITE_CREDITO, 
VOLUME_COMPRA, 
PRIMEIRA_COMPRA, 
DATA_NASCIMENTO) VALUES (
'00388934505', 
'João da Silva', 
'Rua projetada A número 10', 
'', 
'Vila Roman', 
'CARATINGA', 
'AM', 
'2222222', 
30, 
'M', 
10000.00, 
2000, 
0, 
'1989-10-05');
```

Perceba que da coluna "CPF" até "CEP" será do tipo _VARCHAR_ por isso, utilizamos aspas simples (`''`) entre os valores. Já referente ao campo "ENDERECO2" inserimos apenas (`‘’`), que significa que essa coluna está vazia - indicar o campo é obrigatório mesmo que seja vazio - visto que o apenas a coluna "ENDERECO1" já foi suficiente para guardar o endereço completo do cliente.

Na coluna "PRIMEIRA_COMPRA" é do tipo _BIT_ (0 ou1), sendo `1` caso o cliente já tenha realizado uma compra e `0` se ainda não. Vamos inserir o zero, sem as aspas já que é representado como um número, para informar que esse cliente ainda não realizou a primeira compra ainda.

Finalmente, o campo "DATA_NASCIMENTO", possível ser reproduzido de diversas maneiras e ordens conforme o país. Mas, há uma forma universal de representar DATA no MySQL e com ela não é preciso se preocupar se é no formato americano, brasileiro, se utiliza barra, aspas ou traços.

Primeiro, essa data será tratada como _STRING_ por isso, ficará entre aspas simples (`''`). Vamos digitar o ano com quatro dígitos, traço, o mês com dois dígitos, traço e o dia com dois dígitos.

Selecionando somente a instrução _INSERT INTO_ e rodando, será exibida a mensagem informando que o comando foi executado. Para verificar, vamos incluir o `SELECT * FROM tbcliente;` na área do código, selecionar somente ele e executar.

**Tabela exibida após o _select_:**

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|**DATA_NASCIMENTO**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|00388934505|João da Silva|Rua projetada A número 10||Vila Roman|CARATINGA|Amazonas|2222222|30|M|10000.00|2000|0|1989-10-05|

Note que o campo "ENDERECO2" está vazio, como indicado no comando _VALUES_ por `('')`, a coluna "PRIMEIRA_COMPRA" está com o número `0` e a "DATA_NASCIMENTO" representada com ano, mês e dia. Nessa aula aprendemos sobre manipulação e inclusão dos campos dos tipos **lógico** e **data**.



-----------------------------------------------------------------------
Modificando a tabela de Vendedores

Vamos incluir novos campos na tabela de vendedores. Eles serão a data de admissão

```bash
(Nome do campo DATA_ADMISSÃO)
```

e se o vendedor está ou não de férias

```bash
(Nome do campo DE_FERIAS). 
```

Não esqueça de _recriar a chave primária_ e depois inclua as informações abaixo:

```makefile
Matrícula - 00235
Nome: Márcio Almeida Silva
Comissão: 8%
Data de admissão: 15/08/2014
Está de férias? Não

Matrícula - 00236
Nome: Cláudia Morais 
Comissão: 8%
Data de admissão: 17/09/2013
Está de férias? Sim

Matrícula - 00237
Nome: Roberta Martins
Comissão: 11%
Data de admissão: 18/03/2017
Está de férias? Sim

Matrícula - 00238
Nome: Péricles Alves
Comissão: 11%
Data de admissão: 21/08/2016
Está de férias? Não
```

> Dicas:
> 
> - Apague a tabela
> - Crie-a novamente com os novos campos
> - Crie a chave primária
> - Inclua os comandos de INSERT

-----------------------------------------------------------------------
Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Acesse o Workbench.

2) Crie uma nova consulta e digite o comando abaixo:

```sql
USE sucos;

INSERT INTO tbproduto (
PRODUTO,  NOME, EMBALAGEM, TAMANHO, SABOR,
PRECO_LISTA) VALUES (
'1040107', 'Light - 350 ml - Melância',
'Lata', '350 ml', 'Melância', 4.56);
```

O comando acima irá inserir um registro na tabela.

1) Execute o comando:

```sql
SELECT * FROM tbproduto;
```

Você verá que o registro foi inserido na tabela.

2) Crie um novo Script no Workbench.

3) Digite:

```sql
USE sucos;

INSERT INTO tbproduto (
PRODUTO,  NOME, EMBALAGEM, TAMANHO, SABOR,
PRECO_LISTA) VALUES (
'1037797', 'Clean - 2 Litros - Laranja',
'PET', '2 Litros', 'Laranja', 16.01);

INSERT INTO tbproduto (
PRODUTO,  NOME, EMBALAGEM, TAMANHO, SABOR,
PRECO_LISTA) VALUES (
'1000889', 'Sabor da Montanha - 700 ml - Uva',
'Garrafa', '700 ml', 'Uva', 6.31);

INSERT INTO tbproduto (
PRODUTO,  NOME, EMBALAGEM, TAMANHO, SABOR,
PRECO_LISTA) VALUES (
'1004327', 'Videira do Campo - 1,5 Litros - Melância',
'PET', '1,5 Litros', 'Melância', 19.51);
```

Agora o comando acima irá inserir diversos produtos na tabela.

4) Execute o comando:

```sql
SELECT * FROM tbproduto;
```

Você verá que vários registros foi inseridos na tabela.

5) Crie um novo Script no Workbench.

6) Digite o comando abaixo para inserir outros registros na tabela:

```sql
USE sucos;

INSERT INTO tbproduto (
PRODUTO,  NOME, EMBALAGEM, TAMANHO, SABOR,
PRECO_LISTA) VALUES
('544931', 'Frescor do Verão - 350 ml - Limão', 'PET', '350 ml','Limão',3.20);

INSERT INTO tbproduto (
PRODUTO,  NOME, EMBALAGEM, TAMANHO, SABOR,
PRECO_LISTA) VALUES
('1078680', 'Frescor do Verão - 470 ml - Manga', 'Lata', '470 ml','Manga',5.18);
```

7) Agora vamos alterar algumas informações dos registros acima incluídos. Digite:

```sql
USE sucos;

UPDATE tbproduto SET EMBALAGEM = 'Lata', PRECO_LISTA = 2.46
WHERE PRODUTO = '544931';

UPDATE tbproduto SET EMBALAGEM = 'Garrafa'
WHERE PRODUTO = '1078680';
```

8) Você verá que os registros foram alterados executando:

```sql
SELECT * FROM tbproduto;
```

9) Podemos excluir registros já existentes na tabela. Para isso digite, em um outro script do Workbench, os comandos abaixo:

```sql
USE sucos;

DELETE FROM tbproduto WHERE PRODUTO = '1078680';
```

10) Você verá que o registro foi apagado executando:

```sql
SELECT * FROM tbproduto;
```

11) Vimos, nas definições de banco de dados, que uma tabela pode ter uma chave primária. Vamos, abaixo, criar uma chave primária para a tabela de produtos. Faça em um novo script do Workbench:

```sql
USE sucos;

ALTER TABLE tbproduto ADD PRIMARY KEY (PRODUTO);
```

12) Execute o comando abaixo duas vezes:

```sql
INSERT INTO tbproduto (
PRODUTO,  NOME, EMBALAGEM, TAMANHO, SABOR,
PRECO_LISTA) VALUES
('1078680', 'Frescor do Verão - 470 ml - Manga', 'Lata', '470 ml','Manga',5.18);

INSERT INTO tbproduto (
PRODUTO,  NOME, EMBALAGEM, TAMANHO, SABOR,
PRECO_LISTA) VALUES
('1078680', 'Frescor do Verão - 470 ml - Manga', 'Lata', '470 ml','Manga',5.18);
```

Note que, da segunda vez, o comando não pode ser executado apresentando erro porque viola a chave primária.

13) Caso você deseje mudar algo neste registro deve altera-lo:

```sql
UPDATE tbproduto SET EMBALAGEM = 'Garrafa'
WHERE PRODUTO = '1078680';
```

14) Crie um novo script e inclua uma chave primária na tabela de clientes:

```sql
USE sucos;

ALTER TABLE tbcliente ADD PRIMARY KEY (CPF);
```

15) mesmo com a tabela já criada podemos incluir novas colunas com o comando:

```sql
ALTER TABLE tbcliente ADD COLUMN (DATA_NASCIMENTO DATE);
```

16) Abaixo temos o comando para incluir um novo cliente. Note como tratamos a inclusão de um campo do tipo data (DATA_NASCIMENTO) e do tipo lógico (PRIMEIRA_COMPRA).

```sql
INSERT INTO tbcliente (
CPF, NOME, ENDERECO1, ENDERECO2, BAIRRO, CIDADE, ESTADO, CEP, IDADE, SEXO, 
LIMITE_CREDITO, VOLUME_COMPRA, PRIMEIRA_COMPRA, DATA_NASCIMENTO)
VALUES ('00388934505','João da Silva','Rua projetada A número 10','',
'VILA ROMAN', 'CARATINGA', 'AMAZONAS','2222222',30,'M', 10000.00, 2000,
0, '1989-10-05');
```


-----------------------------------------------------------------------
Incluindo dados na tabela

https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54341

## Transcrição

> Você pode fazer o [download](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/05/5.1SQL.zip) completo do código realizado neste vídeo e continuar seus estudos.

Nessa aula vamos aprender a realizar consultas nas bases. Já vimos como incluir, alterar e apagar registros e agora, como consultá-los. Para isso, iremos inserir um volume maior de dados na tabela e esses dados estão no link associado a esse vídeo.

Baixe o arquivo `SQL_10.sql` e no Workbench vá em "File > Open SQL script", escolha o arquivo dessa aula, irá carregar o script completo na área do código.

Analisando os comandos, o `USE sucos;` nos conecta a base sucos; `DROP TABLE tbcliente;`, apaga a tabela de clientes e o mesmo caso para a de protudo; `CREATE TABLE tbcliente ()` para criar a tabela de cliente; `ALTER TABLE tbcliente ADD PRIMARY KEY (CPF);`, que adiciona uma chave primária, em seguida, com o `CREATE TABLE tbproduto;` cria a tabela de produto e adiciona uma chave primária com `ALTER TABLE tbproduto ADD PRIMARY KEY (PRODUTO);`. Logo após, há vários `INSERT INTO` seguidos para incluir uma quantidade grande de registros na tabela de cliente e de produto.

Rodando o código e, logo após, clicando com o botão direito do mouse selecionando a opção "Refresh All", as tabelas de cliente e produto estarão em "SUCOS > TABLES". Vamos criar um _script_ novamente para fazermos alguns testes referentes a visualização da tabela de cliente, poderia ser a de produto também. Rodando a tabela de cliente com `SELECT * FROM tbcliente;`, temos:

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|1471156710|Érica Carvalho|R. Iriquitia||Jardins|São Paulo|SP|80012212|1990-09-01|27|F|170000|245000|0|
|19290992743|Fernando Cavalcante|R. Dois de Fevereiro||Água Santa|Rio de Janeiro|RJ|22000000|2000-02-12|18|M|100000|200000|1|

Podemos usar, ao invés do asterisco `(*)`, o nome dos campos, como em `SELECT CPF, ENDERECO1, ENDERECO2, BAIRRO, CIDADE, ESTADO, CEP, DATA_NASCIMENTO, IDADE, SEXO, LIMITE_CREDITO, VOLUME_COMPRA, PRIMEIRA_COMPRA FROM tbcliente;`. Rodando ambos dos comandos _select_, será aberta duas abas com o mesmo resultado em "_Result Grid_". A primeira é a "tbcliente2" que é o primeiro _select_ e a "tbcliente3" que é esse segundo que inserimos os campos ao invés do asterisco.

```sql
SELECT * FROM tbcliente;

SELECT CPF, ENDERECO1, ENDERECO2, BAIRRO, CIDADE, ESTADO, CEP, DATA_NASCIMENTO, IDADE, SEXO, LIMITE_CREDITO, VOLUME_COMPRA, PRIMEIRA_COMPRA FROM tbcliente;
```

Usamos o asterisco para facilitar e agilizar nosso comando se quisermos buscar todos os campos. Agora, caso a intenção seja filtrar a visualização, como, `SELECT CPF, NOME FROM tbcliente;`, nesse caso estamos selecionando somente o campo "CPF" e "NOME", temos como resultado no Workbench:

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**CPF**|**NOME**|
|---|---|
|1471156710|Érica Carvalho|
|19290992743|Fernando Cavalcante|
|2600586709|César Teixeira|
|3623344710|Marcos Nogueira|
|492472718|Eduardo Jorge|
|50534475787|Abel Silva|
|5576228758|Petra Oliveira|

Nos comandos anteriores os resultados exibem todos os registros da tabela, agora, se quisermos visualizar apenas os 5 primeiros registros, precisamos especificar no final do comando `SELECT CPF, NOME FROM tbcliente LIMIT 5;`. Como consequência, temos:

|**CPF**|**NOME**|
|---|---|
|1471156710|Érica Carvalho|
|19290992743|Fernando Cavalcante|
|2600586709|César Teixeira|
|3623344710|Marcos Nogueira|
|492472718|Eduardo Jorge|

Conseguimos também nomear os campos no momento da consulta aplicando o **_`ALIASES`_** , por exemplo, `SELECT CPF AS CPF_CLIENTE, NOME AS NOME_CLIENTE FROM tbcliente;`, rodando esse comando, temos a tabela com os seguintes nomes na coluna:

|**CPF_CLIENTE**|**NOME_CLIENTE**|
|---|---|
|1471156710|Érica Carvalho|
|19290992743|Fernando Cavalcante|
|2600586709|César Teixeira|
|3623344710|Marcos Nogueira|
|492472718|Eduardo Jorge|
|50534475787|Abel Silva|
|5576228758|Petra Oliveira|

> Um _`alias`_ (ALIASES) só existe durante a consulta e serve para substituir nomes de colunas ou tabelas temporariamente.

Essa consulta pode ser realizada não necessariamente na ordem dos campos que estão na tabela, como, `SELECT NOME, CPF, SEXO, IDADE, DATA_NASCIMENTO FROM tbcliente;`, note que as colunas estão em disposições diferentes no comando e na tabela no Workbench. Porém, isso não interfere no resultado, visto que o retorno das colunas será na ordem que especifiquei no `SELECT`.

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**NOME**|**CPF**|**SEXO**|**IDADE**|**DATA_NASCIMENTO**|
|---|---|---|---|---|
|Érica Carvalho|1471156710|F|27|1990-09-01|
|Fernando Cavalcante|19290992743|M|18|2000-02-12|

Nessa aula tivemos o primeiro contato com o comando de seleção de dados na tabela. Aprendemos a selecionar as colunas, informar quais campos queremos visualizar, limitar sua saída e alterar temporariamente o seu nome usando o comando `alias`.


-----------------------------------------------------------------------
Filtrando registros
## Transcrição

> Você pode fazer o [download](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/05/SQL_12.sql) completo do código realizado neste vídeo e continuar seus estudos.

Nessa aula vamos aprender a filtrar registros para casos em que não queremos visualizar todas as informações, visto que referente a filtros o máximo que sabemos usar até o momento é o comando _LIMIT_, que limita o número de linhas exibidas.

Vamos inserir `SELECT * FROM tbproduto;` e `SELECT * FROM tbcliente;` para verificar as informações das tabelas de produto e cliente. Assim como usamos a cláusula `WHERE` para filtrar um produto específico no comando `UPDATE`, podemos usar no `SELECT`: `SELECT * FROM tbproduto WHERE PRODUTO = ‘544931’;`

**Tabela:**

|**PRODUTO**|**NOME**|**EMBALAGEM**|**TAMANHO**|**SABOR**|**PRECO_LISTA**|
|---|---|---|---|---|---|
|544931|Frescor do Verão - 350 ml - Limão|Lata|350 ml|Limão|2.4595|

O retorno dessa consulta terá apenas um registro, o produto com o código 544931.

Nessa condição não é preciso selecionar somente um campo que seja chave primária, pode usar, por exemplo: `SELECT * FROM tbcliente WHERE CIDADE = ‘Rio de Janeiro’;`. Estamos colocando a coluna "CIDADE" na condição, que não é chave primária.

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|19290992743|Fernando Cavalcante|R. Dois de fevereiro||Água Santa|Rio de Janeiro|RJ|22000000|2000-02-12|18|M|10000|200000|1|
|2600586709|César Teixeira|Rua Conde de Bonfim||Tijuca|Rio de Janeiro|RJ|22020001|2000-03-12|18|M|120000|220000|0|
|3623344710|Marcos Nogueira|Av. Pastor Martin Luther King Junior||Inhauma|Rio de Janeiro|RJ|22002012|1995-01-13|23|M|110000|220000|1|

O retorno dessa consulta será somente clientes em que a cidade é Rio de Janeiro.

A cláusula `WHERE` pode ter uma condição que retorne mais de um registro, que também vale para outros comandos, como, `SELECT`, `UPDATE` e `DELETE`. Exemplificando, usando o comando `SELECT * FROM tbproduto WHERE SABOR = ‘Limão’;` o resultado são todos os produtos com o sabor limão, com 4 registros:

|**PRODUTO**|**NOME**|**EMBALAGEM**|**TAMANHO**|**SABOR**|**PRECO_LISTA**|
|---|---|---|---|---|---|
|1042712|Linha Citros - 700 ml - Limão|Garrafa|700 ml|Limão|4.904|
|1051518|Frescor do Verão - 470 ml - Limão|Garrafa|470 ml|Limão|3.2995|
|1088126|Linha Citros - 1 Litro - Limão|PET|1 Litro|Limão|7.004|
|544931|Frescor do Verão - 350 ml - Limão|Lata|350 ml|Limão|2.4595|

Contudo, vamos supor que esse sabor limão será, a partir de agora, chamado **"cítricos"**, para essa alteração podemos usar o comando `UPDATE`: `UPDATE tbproduto SET SABOR = ‘Cítricos’ WHERE SABOR = ‘Limão’`, selecionando apenas esse comando e rodando, é retornado a mensagem comunicando que 4 linhas foram afetadas e 4 linhas alteradas.

Se caso rodarmos novamente o comando `SELECT * FROM tbproduto WHERE SABOR = ‘Limão’;` não teremos nenhum registro como resultado, visto que alteramos o sabor limão para cítricos. Por esse motivo, ao invés de 'limão' vamos inserir o sabor 'cítricos' nesse comando `SELECT`.

Comando `SELECT`:

```sql
SELECT * FROM tbproduto WHERE SABOR = ‘Cítricos’;
```

Executando esse comando, temos como resultado a coluna "SABOR" alterada de 'limão' para 'cítricos':

|**PRODUTO**|**NOME**|**EMBALAGEM**|**TAMANHO**|**SABOR**|**PRECO_LISTA**|
|---|---|---|---|---|---|
|1042712|Linha Citros - 700 ml - Limão|Garrafa|700 ml|Cítricos|4.904|
|1051518|Frescor do Verão - 470 ml - Limão|Garrafa|470 ml|Cítricos|3.2995|
|1088126|Linha Citros - 1 Litro - Limão|PET|1 Litro|Cítricos|7.004|
|544931|Frescor do Verão - 350 ml - Limão|Lata|350 ml|Cítricos|2.4595|

**Código completo dessa aula:**

```sql
SELECT * FROM tbproduto WHERE PRODUTO = '544931';

SELECT * FROM tbcliente WHERE CIDADE = 'Rio de Janeiro';

SELECT * FROM tbproduto WHERE SABOR = 'Cítricos';

UPDATE tbproduto SET SABOR = 'Cítricos' WHERE SABOR = 'Limão';
```

Resumindo, podemos ter na cláusula `WHERE` uma condição que vai me retornar mais de um registro e, não necessariamente, precisa ser chave primária, é permitido todos os campos que constam na tabela.

É possível também executar filtros compostos, mas não veremos isso nesse vídeo, o objetivo dessa aula foi realizar filtros simples para selecionar elementos na tabela que tragam somente alguns registros.


-----------------------------------------------------------------------
Filtrando usando maior, menor e diferente

https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54343

## Transcrição

> Você pode fazer o [download](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/05/SQL_13.sql) completo do código realizado neste vídeo e continuar seus estudos.

Nessa aula vamos aprender a elaborar melhor os filtros, para buscar registros maiores ou menores sobre algum dado.

Vamos criar mais um script e inserir o comando `SELECT * FROM tbcliente WHERE IDADE = 22;`, que teremos como resultado dessa consulta 4 registros somente de clientes com 22 anos:

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|50534475787|Abel Silva|Rua Humaitá||Humaitá|Rio de Janeiro|RJ|22000212|1995-09-11|22|M|170000|260000|0|
|5576228758|Petra Oliveira|R. Benício de Abreu||Lapa|São Paulo|SP|88192029|1995-11-14|22|F|70000|160000|1|
|8502682733|Valdecir da Silva|R. Srg. Édison de Oliveira||Jardins|São Paulo|SP|82122020|1995-10-07|22|M|110000|190000|0|
|9283760794|Edson Meilelles|R. Pinto de Azevedo||Cidade Nova|Rio de Janeiro|RJ|22002002|1995-10-07|22|M|150000|250000|1|

Podemos também selecionar clientes que tem **mais** de 22 anos, substituindo o igual `(=)`" por maior `(>)` no comando: `SELECT * FROM tbcliente WHERE IDADE > 22;`:

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|1471156710|Érica Carvalho|R. Iriquitia||Jardins|São Paulo|SP|80012212|1990-09-01|27|F|170000|245000|0|
|3623344710|Marcos Nogueira|Av. Pastor Martin Luther King Junior||Inhauma|Rio de Janeiro|RJ|22002012|1995-01-13|23|M|110000|220000|1|
|492472718|Eduardo Jorge|R. Volta Grande||Tijuca|Rio de Janeiro|RJ|22012002|1994-07-19|23|M|75000|95000|1|
|5648641702|Paulo César Mattos|Rua Hélio Beltrão||Tijuca|Rio de Janeiro|RJ|21002020|1991-08-30|26|M|120000|220000|0|

Para selecionar clientes com **menos** de 22 anos, basta substituir o maior `(>)` por menor `(<)` no comando: `SELECT * FROM tbCliente WHERE IDADE < 22;`:

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|19290992743|Fernando Cavalcante|R. Dois de Fevereiro||Água Santa|Rio de Janeiro|RJ|22000000|2000-02-12|18|M|100000|200000|1|
|2600586709|César Teixeira|Rua Conde de Bonfim||Tijuca|Rio de Janeiro|RJ|22020001|2000-03-12|18|M|120000|220000|0|
|95939180787|Fábio Carvalho|R. dos Jacarandás da Península||Barra da Tijuca|Rio de Janeiro|RJ|22002020|1992-01-05|16|M|90000|180000|1|

O retorno dessa consulta será 3 registros com os clientes com menos de 22 anos.

Vamos consultar agora clientes que têm **menos** de 22 anos, **incluindo** os que têm. Basta substituir o menor `(<)` por menor ou igual `(<=)` no comando: `SELECT * FROM tbcliente WHERE IDADE <= 22;`, o igual inclui os que têm 22 anos no critério do filtro.

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|19290992743|Fernando Cavalcante|R. Dois de Fevereiro||Água Santa|Rio de Janeiro|RJ|22000000|2000-02-12|18|M|100000|200000|1|
|2600586709|César Teixeira|Rua Conde de Bonfim||Tijuca|Rio de Janeiro|RJ|22020001|2000-03-12|18|M|120000|220000|0|
|95939180787|Fábio Carvalho|R. dos Jacarandás da Península||Barra da Tijuca|Rio de Janeiro|RJ|22002020|1992-01-05|16|M|90000|180000|1|
|50534475787|Abel Silva|Rua Humaitá||Humaitá|Rio de Janeiro|RJ|22000212|1995-09-11|22|M|170000|260000|0|

Supondo que agora precisamos consultar todos os clientes, exceto os que têm 22 anos. Basta substituir pelo símbolo de diferença no comando `(<>)`: `SELECT * FROM tbcliente WHERE IDADE <> 22;`.

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|1471156710|Érica Carvalho|R. Iriquitia||Jardins|São Paulo|SP|80012212|1990-09-01|27|F|170000|245000|0|
|19290992743|Fernando Cavalcante|R. Dois de Fevereiro||Água Santa|Rio de Janeiro|RJ|22000000|2000-02-12|18|M|100000|200000|1|
|2600586709|César Teixeira|Rua Conde de Bonfim||Tijuca|Rio de Janeiro|RJ|22020001|2000-03-12|18|M|120000|220000|0|

Podemos aplicar esses símbolos de menor, maior, menor ou igual, ou maior ou igual em textos também. No MySQL existe uma ordem alfabética para as letras, então, o **"B"** é maior que o **"A"** (B > A), o **"C"** é maior que o **"B"** (C > B), o **"X"** é maior que **"R"** e assim sucessivamente.

Por isso, quando realizamos a consulta `SELECT * FROM tbcliente WHERE NOME > ‘Fernando Cavalcante’;`, o MySQL analisa a primeira letra, no caso **"F"**, a partir desse critério e se tiver outro nome que inicie com **"F"**, como "Fátima" seria um candidato, já ao comparar a segunda letra de cada nome, perceberia que **"E"** é maior que **"A"**, descartando "Fátima" da condição.

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|3623344710|Marcos Nogueira|Av. Pastor Martin Luther King Junior||Inhauma|Rio de Janeiro|RJ|22002012|1995-01-13|23|M|110000|220000|1|
|5576228758|Petra Oliveira|R. Benício de Abreu||Lapa|São Paulo|SP|88192029|1995-11-14|22|F|70000|160000|1|
|5648641702|Paulo César Mattos|Rua Hélio Beltrão||Tijuca|Rio de Janeiro|RJ|21002020|1991-08-30|26|M|120000|220000|0|

O resultado dessa consulta são clientes com nomes "acima" da letra **"F"**, como **M*_arcos, *_P**etra e **P**aulo.

Se quisermos incluir o Fernando na consulta, teríamos que colocar o símbolo maior ou igual `(>=)` no comando: `SELECT * FROM tbcliente WHERE NOME >= ‘Fernando Cavalcante’;`:

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|19290992743|Fernando Cavalcante|R. Dois de Fevereiro||Água Santa|Rio de Janeiro|RJ|22000000|2000-02-12|18|M|100000|200000|1|
|3623344710|Marcos Nogueira|Av. Pastor Martin Luther King Junior||Inhauma|Rio de Janeiro|RJ|22002012|1995-01-13|23|M|110000|220000|1|
|5576228758|Petra Oliveira|R. Benício de Abreu||Lapa|São Paulo|SP|88192029|1995-11-14|22|F|70000|160000|1|
|5648641702|Paulo César Mattos|Rua Hélio Beltrão||Tijuca|Rio de Janeiro|RJ|21002020|1991-08-30|26|M|120000|220000|0|

Para excluir o nome "Fernando" do filtro, usamos o símbolo de diferente `(<>)`: `SELECT * FROM tbcliente WHERE NOME <> ‘Fernando Cavalcante’;`:

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|1471156710|Érica Carvalho|R. Iriquitia||Jardins|São Paulo|SP|8001221|1990-09-01|27|F|170000|245000|0|
|2600586709|César Teixeira|Rua Conde de Bonfim||Tijuca|Rio de Janeiro|RJ|22020001|2000-03-12|18|M|120000|220000|0|
|3623344710|Marcos Nogueira|Av. Pastor Martin Luther King Junior||Inhauma|Rio de Janeiro|RJ|22002012|1995-01-13|23|M|110000|220000|1|
|5576228758|Petra Oliveira|R. Benício de Abreu||Lapa|São Paulo|SP|88192029|1995-11-14|22|F|70000|160000|1|
|5648641702|Paulo César Mattos|Rua Hélio Beltrão||Tijuca|Rio de Janeiro|RJ|21002020|1991-08-30|26|M|120000|220000|0|

Tem um detalhe que vamos ver agora que pode gerar algumas dúvidas. Ao executar o comando `SELECT * FROM tbproduto WHERE PRECO_LISTA = 16.008` o resultado é vazio, isso acontece pelo fato do campo "PRECO_LISTA" ser do tipo FLOAT, um ponto flutuante e, em razão disso, não é possível encontrar exatamente o resultado inserido na condição.

|**PRODUTO**|**NOME**|**EMBALAGEM**|**TAMANHO**|**SABOR**|**PRECO_LISTA**|
|---|---|---|---|---|---|
|NULL|NULL|NULL|NULL|NULL|NULL|

O recomendado para trabalhar com condições de igual `(=)`, menor ou igual `(<=)` ou, maior ou igual `(>=)` e diferente `(<>)` seria o tipo DECIMAL, visto que o MySQL consegue encontrar o número exato na busca.

Para números do tipo FLOAT, é possível usar apenas os símbolos de maior e menor, podemos usar o diferente `(<>)`, porém o produto com o preço `16.008` também irá constar justamente pelo fato do MySQL não encontrar o valor exato.

Temos o comando **_BETWEEN_**, que é mais elaborado que o WHERE. Com ele conseguimos buscar exatamente o valor especificado na condição usando o comando: `SELECT * FROM tbproduto WHERE PRECO_LISTA BETWEEN 16.007 AND 16.009;`, que lista todos os produtos em que o preço está entre `16.007` e `16.009`.

|**PRODUTO**|**NOME**|**EMBALAGEM**|**TAMANHO**|**SABOR**|**PRECO_LISTA**|
|---|---|---|---|---|---|
|1037797|Clean - 2 Litros - Laranja|PET|2 Litros|Laranja|16.008|

Essa é uma característica do MySQL, por ser do tipo FLOAT não é possível buscar o valor exato. Porém, podemos usar os limites inferiores e superiores próximos para conseguir encontrar o valor que queremos.

**Código com todos os comandos dessa aula:**

```sql
SELECT * FROM tbcliente;

SELECT * FROM tbcliente WHERE IDADE = 22;

SELECT * FROM tbcliente WHERE IDADE > 22;

SELECT * FROM tbcliente WHERE IDADE < 22;

SELECT * FROM tbcliente WHERE IDADE <= 22;

SELECT * FROM tbcliente WHERE IDADE <> 22;

SELECT * FROM tbcliente WHERE NOME >= 'Fernando Cavalcante';

SELECT * FROM tbcliente WHERE NOME <> 'Fernando Cavalcante';

SELECT * FROM tbproduto;

SELECT * FROM tbproduto WHERE PRECO_LISTA > 16.008;

SELECT * FROM tbproduto WHERE PRECO_LISTA < 16.008;

SELECT * FROM tbproduto WHERE PRECO_LISTA <> 16.008;

SELECT * FROM tbproduto WHERE PRECO_LISTA BETWEEN 16.007 AND 16.009;
```

-----------------------------------------------------------------------
#   
Filtrando datas

https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54344

## Transcrição

> Você pode fazer o [download](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/05/SQL_14.sql) completo do código realizado neste vídeo e continuar seus estudos.

Nessa aula vamos analisar o comportamento do MySQL quando queremos filtrar campos que são datas.

Abrindo um _script_ no Workbench e selecionando a tabela de clientes com `SELECT * FROM tbcliente;`, temos a coluna "DATA_NASCIMENTO", sendo a que vamos usar para realizar os testes de filtro.

Podemos especificar uma data, para saber quem nasceu nesse dia usando o comando `SELECT` e uma condição com o símbolo de igual `(=)`:`SELECT * FROM tbcliente WHERE DATA_NASCIMENTO = ‘1995-01-13’;`.

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|3623344710|Marcos Nogueira|Av. Pastor Martin Luther King Junior||Inhauma|Rio de Janeiro|RJ|22002012|1995-01-13|23|M|110000|220000|1|

O resultado dessa consulta é somente os clientes que nasceram no dia `13-01-1995`, que no caso é o Marcos Nogueira.

Com datas também é possível usar o símbolo maior `(>)` e o menor `(<)`, sendo quem nasceu depois e antes do dia indicado, respectivamente.

Resultado do `SELECT * FROM tbcliente WHERE DATA_NASCIMENTO > ‘1995-01-13’;`:

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|19290992743|Fernando Cavalcante|R. Dois de Fevereiro||Água Santa|Rio de Janeiro|RJ|22000000|2000-02-12|18|M|100000|200000|1|
|2600586709|César Teixeira|Rua Conde de Bonfim||Tijuca|Rio de Janeiro|RJ|22020001|2000-03-12|18|M|120000|220000|0|
|50534475787|Abel Silva|Rua Humaitá||Humaitá|Rio de Janeiro|RJ|22000212|1995-09-11|22|M|170000|260000|0|

Resultado do `SELECT * FROM tbcliente WHERE DATA_NASCIMENTO <= ‘1995-01-13’;`, perceba que nesse comando há o sinal de **menor ou igual**, isto é, a data indicada está incluída no filtro e será exibida no resultado da consulta.

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|1471156710|Érica Carvalho|R. Iriquitia||Jardins|São Paulo|SP|80012212|1990-09-01|27|F|170000|245000|0|
|3623344710|Marcos Nogueira|Av. Pastor Martin Luther King Junior||Inhauma|Rio de Janeiro|RJ|22002012|1995-01-13|23|M|110000|220000|1|
|492472718|Eduardo Jorge|R. Volta Grande||Tijuca|Rio de Janeiro|RJ|22012002|1994-07-19|23|M|75000|95000|1|

As datas se comportam de forma semelhante aos números na aplicação de filtros, contudo é utilizado o calendário ocidental para ordenar as datas. Pode também manusear partes das datas, como apenas o ano ou o mês, visto que há funções de data que nos auxiliam nisso. Por exemplo: SELECT * FROM tbcliente WHERE YEAR(DATA_NASCIMENTO) = 1995;, sendo `YEAR()` uma função que filtra o ano de uma data especificada no parêntese, o resultado dessa função é um número inteiro e, em razão disso, o ano **1995** não está entre aspas simples `('')`.

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|3623344710|Marcos Nogueira|Av. Pastor Martin Luther King Junior||Inhauma|Rio de Janeiro|RJ|22002012|1995-01-13|23|M|110000|220000|1|
|50534475787|Abel Silva|Rua Humaitá||Humaitá|Rio de Janeiro|RJ|22000212|1995-09-11|22|M|170000|260000|0|
|5576228758|Petra Oliveira|R. Benício de Abreu||Lapa|São Paulo|SP|88192029|1995-11-14|22|F|70000|160000|1|

Em situações que queremos filtrar apenas o mês, como em alguma campanha de marketing em que será enviado um cartão de celebração para quem faz aniversário em um determinado mês de outubro (`10`), por exemplo: `SELECT * FROM tbcliente WHERE MONTH(DATA_NASCIMENTO) = 10;`:

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|8502682733|Valdecir da Silva|R. Srg. Édison de Oliveira||Jardins|São Paulo|SP|82122020|1995-10-07|22|M|110000|190000|0|
|9283760794|Edson Meilelles|R. Pinto de Azevedo||Cidade Nova|Rio de Janeiro|RJ|22002002|1995-10-07|22|M|150000|250000|1|

O resultado dessa consulta são 2 registros com os clientes que fazem aniversário no mês de outubro.

**Código com todos os comandos usados nessa aula:**

```sql
SELECT * FROM tbcliente;

SELECT * FROM tbcliente WHERE DATA_NASCIMENTO = '1995-01-13';

SELECT * FROM tbcliente WHERE DATA_NASCIMENTO > '1995-01-13';

SELECT * FROM tbcliente WHERE DATA_NASCIMENTO <= '1995-01-13';

SELECT * FROM tbcliente WHERE YEAR(DATA_NASCIMENTO) = 1995;

SELECT * FROM tbcliente WHERE MONTH(DATA_NASCIMENTO) = 10;
```

Resumindo, podemos usar a função YEAR e MONTH para inserir anos e meses no filtro e as datas se comportam como números para essas condições. O MySQL considera o calendário interno, sabendo, por exemplo, que o **1-01-1995** vem antes de **31-12-1998**, isto é, ele já possui esse controle interno das datas.

-----------------------------------------------------------------------
Filtros compostos

https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54345

## Transcrição

> Você pode fazer o [download](https://cdn3.gnarususercontent.com.br/1220-mysqlintroducaoaosql/05/SQL_15.sql) completo do código realizado neste vídeo e continuar seus estudos.

Até o momento vimos sobre filtros simples, quando queremos analisar os registros iguais, maior ou menor a algum dado indicado. Nessa aula vamos aprender a realizar filtros compostos, quando queremos juntar duas condições em uma só.

Criando um script e selecionando a tabela de produtos com o comando `SELECT * FROM tbproduto;`, observe a coluna "PRECO_LISTA", que aplicamos a condição `BETWEEN` em aulas passadas.

Quando usamos o comando `BETWEEN` (entre) já estávamos aprendendo mais ou menos sobre como funciona o filtro composto, visto que quando inserimos essa cláusula estamos impondo a seguinte condição: me retorne todos os registros que são maiores ou iguais ao valor indicado primeiro e menores ou iguais a outro valor especificado.

No caso anterior, usamos `SELECT * FROM tbproduto WHERE PRECO_LISTA BETWEEN 16.007 AND 16.009;`, esse comando significa que será executado primeiro a condição `SELECT * FROM tbproduto WHERE PRECO_LISTA >= 16.007;` e sobre o resultado desse comando, aplicar a segunda condição `SELECT * FROM tbproduto WHERE PRECO_LISTA <= 16.009;`. Esta última, quando a executamos é aplicada sobre tudo, de forma separada.

**Código:**

```sql
SELECT * FROM tbproduto;

SELECT * FROM tbproduto WHERE PRECO_LISTA BETWEEN 16.007 AND 16.009;
SELECT * FROM tbproduto WHERE PRECO_LISTA >= 16.007;
SELECT * FROM tbproduto WHERE PRECO_LISTA <= 16.009;
```

Para juntar as condições vamos usar o filtro `AND` ("E"): `SELECT * FROM tbproduto WHERE PRECO_LISTA >= 16.007 AND PRECO_LISTA <= 16.009;`, com esse comando ambas condições serão realizadas simultaneamente, no mesmo `WHERE`. Rodando essa linha de código teremos o mesmo resultado de quando aplicamos o `BETWEEN`:

|**PRODUTO**|**NOME**|**EMBALAGEM**|**TAMANHO**|**SABOR**|**PRECO_LISTA**|
|---|---|---|---|---|---|
|1037797|Clean - 2 Litros - Laranja|PET|2 Litros|Laranja|16.008|

Podemos usar essa condição em diversas situações, como, por exemplo, se quisermos buscar somente clientes que tenham entre 18 e 22 anos. Vamos selecionar a tabela de cliente e inserir a condição: `SELECT * FROM tbcliente WHERE IDADE >= 18 AND IDADE <= 22;`:

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|19290992743|Fernando Cavalcante|R. Dois de Fevereiro||Água Santa|Rio de Janeiro|RJ|22000000|2000-02-12|18|M|100000|200000|1|
|2600586709|César Teixeira|Rua Conde de Bonfim||Tijuca|Rio de JaneirO|RJ|22020001|2000-03-12|18|M|120000|220000|0|
|50534475787|Abel Silva|Rua Humaitá||Humaitá|Rio de Janeiro|RJ|22000212|1995-09-11|22|M|170000|260000|0|
|5576228758|Petra Oliveira|R. Benício de Abreu||Lapa|São Paulo|SP|88192029|1995-11-14|22|F|70000|160000|1|
|8502682733|Valdecir da Silva|R. Srg. Édison de Oliveira||Jardins|São Paulo|SP|82122020|1995-10-07|22|M|110000|190000|0|
|9283760794|Edson Meilelles|R. Pinto de Azevedo||Cidade Nova|Rio de Janeiro|RJ|22002002|1995-10-07|22|M|150000|250000|1|

O resultado dessa consulta são 6 registros com cliente entre 18 e 22 anos.

É possível também incluir mais condições no comando, vamos selecionar quem tem entre 18 e 22 anos **e** são do sexo masculino: `SELECT * FROM tbcliente WHERE IDADE >= 18 AND IDADE <= 22 AND SEXO = 'M';`, perceba que no `AND` é viável aplicarmos condições sobre campos diferentes conjuntamente.

Outra condição é o `OR` ("OU"), que pode ser usado em situações em que quero buscar clientes que moram no Rio de Janeiro **ou** no bairro Jardins em São Paulo simultaneamente, por exemplo: `SELECT * FROM tbcliente WHERE cidade = 'Rio de Janeiro' OR BAIRRO = 'Jardins';`.

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|1471156710|Érica Carvalho|R. Iriquitia||Jardins|São Paulo|SP|80012212|1990-09-01|27|F|170000|245000|0|
|19290992743|Fernando Cavalcante|R. Dois de Fevereiro||Água Santa|Rio de Janeiro|RJ|22000000|2000-02-12|18|M|100000|200000|1|
|2600586709|César Teixeira|Rua Conde de Bonfim||Tijuca|Rio de JaneirO|RJ|22020001|2000-03-12|18|M|120000|220000|0|
|3623344710|Marcos Nogueira|Av. Pastor Martin Luther King Junior||Inhauma|Rio de Janeiro|RJ|22002012|1995-01-13|23|M|110000|220000|1|
|492472718|Eduardo Jorge|R. Volta Grande||Tijuca|Rio de Janeiro|RJ|22012002|1994-07-19|23|M|75000|95000|1|
|50534475787|Abel Silva|Rua Humaitá||Humaitá|Rio de Janeiro|RJ|22000212|1995-09-11|22|M|170000|260000|0|

Conseguimos também juntar às duas condições em um só comando, vamos supor que queremos buscar os clientes entre 18 e 22 anos que são do sexo masculino **ou** da cidade do Rio de Janeiro, **ou** do bairro Jardins em São Paulo.

> Uma boa prática ao escrever o código é usar os parênteses para isolar as condições.

```sql
SELECT * FROM tbcliente WHERE (IDADE >= 18 AND IDADE <= 22 AND SEXO = 'M')
 OR (cidade = 'Rio de Janeiro' OR BAIRRO = 'Jardins');
```

Quando juntamos várias condições em um único comando, chamamos **_lógica_**, não vamos entrar muito a fundo nesse treinamento sobre isso. Mas caso já trabalhe com TI ou com programação, já possui um contato com lógica de programação.

Então, o programa vai realizar a seleção do comando `WHERE` concatenando (encadeando em uma sequência lógica) várias condições usando `AND` e `OR`.

> Para melhor visualização, alguns registros dessa tabela foram omitidos.

|**CPF**|**NOME**|**ENDERECO1**|**ENDERECO2**|**BAIRRO**|**CIDADE**|**ESTADO**|**CEP**|**DATA_NASCIMENTO**|**IDADE**|**SEXO**|**LIMITE_CREDITO**|**VOLUME_COMPRA**|**PRIMEIRA_COMPRA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|1471156710|Érica Carvalho|R. Iriquitia||Jardins|São Paulo|SP|80012212|1990-09-01|27|F|170000|245000|0|
|19290992743|Fernando Cavalcante|R. Dois de Fevereiro||Água Santa|Rio de Janeiro|RJ|22000000|2000-02-12|18|M|100000|200000|1|
|2600586709|César Teixeira|Rua Conde de Bonfim||Tijuca|Rio de JaneirO|RJ|22020001|2000-03-12|18|M|120000|220000|0|
|3623344710|Marcos Nogueira|Av. Pastor Martin Luther King Junior||Inhauma|Rio de Janeiro|RJ|22002012|1995-01-13|23|M|110000|220000|1|
|492472718|Eduardo Jorge|R. Volta Grande||Tijuca|Rio de Janeiro|RJ|22012002|1994-07-19|23|M|75000|95000|1|
|50534475787|Abel Silva|Rua Humaitá||Humaitá|Rio de Janeiro|RJ|22000212|1995-09-11|22|M|170000|260000|0|
|95939180787|Fábio Carvalho|R. dos Jacarandás da Península||Barra da Tijuca|Rio de Janeiro|RJ|22002020|1992-01-05|16|M|90000|180000|1|

Note que o resultado dessa consulta serão clientes entre 18 e 22 anos, do sexo masculino (primeira condição) e os que têm menos ou mais satisfazem a segunda condição, são do Rio de Janeiro **ou** do Bairro Jardins em São Paulo.

Um ponto relevante para comentar é que todas as condições que estamos aplicando na cláusula `WHERE` podemos usar também nos comandos `DELETE` e `UPDATE`, isto é, os filtros compostos podem ser usados em outros comandos que já vimos também.

-----------------------------------------------------------------------
Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com os próximos cursos que tenham este como pré-requisito.

1) Acesse o Workbench e crie um novo script SQL.

2) Abra o arquivo SQL_10.sql e execute o script. As tabelas serão apagadas, recriadas e novos registros serão incluídos. O conteúdo do script é reproduzido abaixo.

```java
USE sucos;

DROP TABLE tbcliente;

DROP TABLE tbproduto;

CREATE TABLE tbcliente
( CPF VARCHAR (11) ,
NOME VARCHAR (100) ,
ENDERECO1 VARCHAR (150) ,
ENDERECO2 VARCHAR (150) ,
BAIRRO VARCHAR (50) ,
CIDADE VARCHAR (50) ,
ESTADO VARCHAR (2) ,
CEP VARCHAR (8) ,
DATA_NASCIMENTO DATE,
IDADE SMALLINT,
SEXO VARCHAR (1) ,
LIMITE_CREDITO FLOAT ,
VOLUME_COMPRA FLOAT ,
PRIMEIRA_COMPRA BIT );

ALTER TABLE tbcliente ADD PRIMARY KEY (CPF);

CREATE TABLE tbproduto
(PRODUTO VARCHAR (20) ,
NOME VARCHAR (150) ,
EMBALAGEM VARCHAR (50) ,
TAMANHO VARCHAR (50) ,
SABOR VARCHAR (50) ,
PRECO_LISTA FLOAT);

ALTER TABLE tbproduto ADD PRIMARY KEY (PRODUTO);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('19290992743','Fernando Cavalcante','R. Dois de Fevereiro','','Água Santa','Rio de Janeiro','RJ','22000000','2000-02-12',18,'M',100000,200000,1);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('2600586709','César Teixeira','Rua Conde de Bonfim','','Tijuca','Rio de Janeiro','RJ','22020001','2000-03-12',18,'M',120000,220000,0);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('95939180787','Fábio Carvalho','R. dos Jacarandás da Península','','Barra da Tijuca','Rio de Janeiro','RJ','22002020','1992-01-05',16,'M',90000,180000,1);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('9283760794','Edson Meilelles','R. Pinto de Azevedo','','Cidade Nova','Rio de Janeiro','RJ','22002002','1995-10-07',22,'M',150000,250000,1);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('7771579779','Marcelo Mattos','R. Eduardo Luís Lopes','','Brás','São Paulo','SP','88202912','1992-03-25',25,'M',120000,200000,1);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('5576228758','Petra Oliveira','R. Benício de Abreu','','Lapa','São Paulo','SP','88192029','1995-11-14',22,'F',70000,160000,1);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('8502682733','Valdeci da Silva','R. Srg. Édison de Oliveira','','Jardins','São Paulo','SP','82122020','1995-10-07',22,'M',110000,190000,0);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('1471156710','Érica Carvalho','R. Iriquitia','','Jardins','São Paulo','SP','80012212','1990-09-01',27,'F',170000,245000,0);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('3623344710','Marcos Nougeuira','Av. Pastor Martin Luther King Junior','','Inhauma','Rio de Janeiro','RJ','22002012','1995-01-13',23,'M',110000,220000,1);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('50534475787','Abel Silva ','Rua Humaitá','','Humaitá','Rio de Janeiro','RJ','22000212','1995-09-11',22,'M',170000,260000,0);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('5840119709','Gabriel Araujo','R. Manuel de Oliveira','','Santo Amaro','São Paulo','SP','80010221','1985-03-16',32,'M',140000,210000,1);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('94387575700','Walber Lontra','R. Cel. Almeida','','Piedade','Rio de Janeiro','RJ','22000201','1989-06-20',28,'M',60000,120000,1);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('8719655770','Carlos Eduardo','Av. Gen. Guedes da Fontoura','','Jardins','São Paulo','SP','81192002','1983-12-20',34,'M',200000,240000,0);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('5648641702','Paulo César Mattos','Rua Hélio Beltrão','','Tijuca','Rio de Janeiro','RJ','21002020','1991-08-30',26,'M',120000,220000,0);

INSERT INTO tbcliente (CPF,NOME,ENDERECO1,ENDERECO2,BAIRRO,CIDADE,ESTADO,CEP,DATA_NASCIMENTO,IDADE,SEXO,LIMITE_CREDITO,VOLUME_COMPRA,PRIMEIRA_COMPRA) VALUES ('492472718','Eduardo Jorge','R. Volta Grande','','Tijuca','Rio de Janeiro','RJ','22012002','1994-07-19',23,'M',75000,95000,1);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1040107','Light - 350 ml - Melância','Lata','350 ml','Melância',4.555);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1037797','Clean - 2 Litros - Laranja','PET','2 Litros','Laranja',16.008);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1000889','Sabor da Montanha - 700 ml - Uva','Garrafa','700 ml','Uva',6.309);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1004327','Videira do Campo - 1,5 Litros - Melância','PET','1,5 Litros','Melância',19.51);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1088126','Linha Citros - 1 Litro - Limão','PET','1 Litro','Limão',7.004);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('544931','Frescor do Verão - 350 ml - Limão','Lata','350 ml','Limão',2.4595);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1078680','Frescor do Verão - 470 ml - Manga','Garrafa','470 ml','Manga',5.1795);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1042712','Linha Citros - 700 ml - Limão','Garrafa','700 ml','Limão',4.904);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('788975','Pedaços de Frutas - 1,5 Litros - Maça','PET','1,5 Litros','Maça',18.011);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1002767','Videira do Campo - 700 ml - Cereja/Maça','Garrafa','700 ml','Cereja/Maça',8.41);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('231776','Festival de Sabores - 700 ml - Açai','Garrafa','700 ml','Açai',13.312);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('479745','Clean - 470 ml - Laranja','Garrafa','470 ml','Laranja',3.768);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1051518','Frescor do Verão - 470 ml - Limão','Garrafa','470 ml','Limão',3.2995);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1101035','Linha Refrescante - 1 Litro - Morango/Limão','PET','1 Litro','Morango/Limão',9.0105);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('229900','Pedaços de Frutas - 350 ml - Maça','Lata','350 ml','Maça',4.211);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1086543','Linha Refrescante - 1 Litro - Manga','PET','1 Litro','Manga',11.0105);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('695594','Festival de Sabores - 1,5 Litros - Açai','PET','1,5 Litros','Açai',28.512);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('838819','Clean - 1,5 Litros - Laranja','PET','1,5 Litros','Laranja',12.008);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('326779','Linha Refrescante - 1,5 Litros - Manga','PET','1,5 Litros','Manga',16.5105);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('520380','Pedaços de Frutas - 1 Litro - Maça','PET','1 Litro','Maça',12.011);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1041119','Linha Citros - 700 ml - Lima/Limão','Garrafa','700 ml','Lima/Limão',4.904);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('243083','Festival de Sabores - 1,5 Litros - Maracujá','PET','1,5 Litros','Maracujá',10.512);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('394479','Sabor da Montanha - 700 ml - Cereja','Garrafa','700 ml','Cereja',8.409);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('746596','Light - 1,5 Litros - Melância','PET','1,5 Litros','Melância',19.505);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('773912','Clean - 1 Litro - Laranja','PET','1 Litro','Laranja',8.008);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('826490','Linha Refrescante - 700 ml - Morango/Limão','Garrafa','700 ml','Morango/Limão',6.3105);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('723457','Festival de Sabores - 700 ml - Maracujá','Garrafa','700 ml','Maracujá',4.912);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('812829','Clean - 350 ml - Laranja','Lata','350 ml','Laranja',2.808);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('290478','Videira do Campo - 350 ml - Melância','Lata','350 ml','Melância',4.56);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('783663','Sabor da Montanha - 700 ml - Morango','Garrafa','700 ml','Morango',7.709);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('235653','Frescor do Verão - 350 ml - Manga','Lata','350 ml','Manga',3.8595);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1002334','Linha Citros - 1 Litro - Lima/Limão','PET','1 Litro','Lima/Limão',7.004);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1013793','Videira do Campo - 2 Litros - Cereja/Maça','PET','2 Litros','Cereja/Maça',24.01);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1096818','Linha Refrescante - 700 ml - Manga','Garrafa','700 ml','Manga',7.7105);

INSERT INTO tbproduto (PRODUTO, NOME, EMBALAGEM, TAMANHO, SABOR, PRECO_LISTA) VALUES ('1022450','Festival de Sabores - 2 Litros - Açai','PET','2 Litros','Açai',38.012);
```

1) Verifique o conteúdo das tabelas de produtos e clientes digitando:

```sql
SELECT * FROM tbproduto;

SELECT * FROM tbcliente;
```

2) Crie um novo script. Vamos fazer algumas consultas a base.

3) Digite:

```sql
SELECT * FROM tbcliente;

SELECT CPF, NOME, ENDERECO1, ENDERECO2, BAIRRO, CIDADE, ESTADO, CEP,
DATA_NASCIMENTO, IDADE, SEXO, LIMITE_CREDITO, VOLUME_COMPRA, PRIMEIRA_COMPRA
FROM tbcliente;
```

Note que os dois comandos retornam a mesma coisa. Podemos usar o * para selecionar todos os campos ou discriminar um por um.

4) Podemos selecionar alguns campos apenas:

```sql
SELECT CPF, NOME FROM tbcliente;
```

5) Também é possível limitar a saída de registros:

```sql
SELECT CPF, NOME FROM tbcliente LIMIT 5;
```

6) Ou também criar um Label (Chamamos de Alias) para cada campo:

```vbnet
SELECT CPF AS CPF_CLIENTE, NOME AS NOME_CLIENTE FROM tbcliente;
```

7) Os registros podem ser filtrados usando o mesmo tipo de cláusula WHERE usada no UPDATE e DELETE.

```sql
SELECT * FROM tbproduto WHERE PRODUTO = '544931';
```

8) Mas não é somente pela chave primária que podemos filtrar as consultas.

```sql
SELECT * FROM tbcliente WHERE CIDADE = 'Rio de Janeiro';

SELECT * FROM tbproduto WHERE SABOR = 'Cítricos';
```

9) Inclusive este tipo de filtro WHERE pode ser usado no UPDATE e DELETE. Digite o comando abaixo de UPDATE para fazer uma alteração em diversos registros ao mesmo tempo.

```sql
UPDATE tbproduto SET SABOR = 'Cítricos' WHERE SABOR = 'Limão';
```

10) Podemos fazer consultas usando condições baseadas em números (Decimais ou inteiros). Crie um novo script e vamos a alguns exemplos:

```sql
SELECT * FROM tbcliente WHERE IDADE = 22;
```

Aqui vemos uma igualdade.

11) Mas podemos usar sinal de maior, menor, maior ou igual, menor ou igual. Olhe alguns exemplos:

```sql
SELECT * FROM tbcliente WHERE IDADE > 22;

SELECT * FROM tbcliente WHERE IDADE < 22;

SELECT * FROM tbcliente WHERE IDADE <= 22;
```

12) Temos o sinal de diferente que é expresso como <>. Veja abaixo:

```sql
SELECT * FROM tbcliente WHERE IDADE <> 22;
```

13) As condições de maior, menor, maior ou igual, menor ou igual, diferente podem ser aplicado a textos. O critério será a ordem alfabética.

```sql
SELECT * FROM tbcliente WHERE NOME >= 'Fernando Cavalcante';

SELECT * FROM tbcliente WHERE NOME <> 'Fernando Cavalcante';
```

14) As condições de maior, menor, maior ou igual, menor ou igual, igual e diferente não se aplica muito bem a campos FLOAT.

```sql
SELECT * FROM tbproduto WHERE PRECO_LISTA > 16.008;

SELECT * FROM tbproduto WHERE PRECO_LISTA < 16.008;

SELECT * FROM tbproduto WHERE PRECO_LISTA <> 16.008;
```

15) O comando BETWEEN pode ser aplicado.

```sql
SELECT * FROM tbproduto WHERE PRECO_LISTA BETWEEN 16.007 AND 16.009;
```

16) Podemos usar como filtro datas. veja alguns exemplos:

```sql
SELECT * FROM tbcliente WHERE DATA_NASCIMENTO = '1995-01-13';

SELECT * FROM tbcliente WHERE DATA_NASCIMENTO > '1995-01-13';

SELECT * FROM tbcliente WHERE DATA_NASCIMENTO <= '1995-01-13';
```

17) Existem algumas funções de data que podem ser usadas como filtros.

```sql
SELECT * FROM tbcliente WHERE YEAR(DATA_NASCIMENTO) = 1995;

SELECT * FROM tbcliente WHERE MONTH(DATA_NASCIMENTO) = 10;
```

18) Podemos usar filtros compostos usando, entre cada teste, os comandos AND ou OR. Veja abaixo alguns exemplos que podem ser testados no Workbench.

```sql
SELECT * FROM tbproduto WHERE PRECO_LISTA BETWEEN 16.007 AND 16.009;

SELECT * FROM tbproduto WHERE PRECO_LISTA >= 16.007;

SELECT * FROM tbproduto WHERE PRECO_LISTA <= 16.009;

SELECT * FROM tbproduto WHERE PRECO_LISTA >= 16.007 AND PRECO_LISTA <= 16.009;

SELECT * FROM tbcliente WHERE IDADE >= 18 AND IDADE <= 22;

SELECT * FROM tbcliente WHERE IDADE >= 18 AND IDADE <= 22 AND SEXO = 'M';

SELECT * FROM tbcliente WHERE CIDADE = 'Rio de Janeiro' OR BAIRRO = 'Jardins';

SELECT * FROM tbcliente WHERE (IDADE >= 18 AND IDADE <= 22 AND SEXO = 'M') OR (cidade = 'Rio de Janeiro' OR BAIRRO = 'Jardins');
```

-----------------------------------------------------------------------
Conclusão

## Transcrição

Parabéns! Você completou o curso de **Introdução ao SQL com MySQL: manipule e consulte dados.**

Como mencionado no início desse treinamento, este curso é voltado para quem nunca viu banco de dados e não conhecia SQL. Agora, você possui uma boa base para dar continuidade aos seus estudos em cursos mais avançados.

Nós iniciamos esse treinamento baixando e instalando o MySQL, vimos alguns detalhes de configurações para fazer a instalação funcionar e, em seguida, conversamos um pouco sobre a história do SQL — como surgiu, suas características atuais e relações quando comparado a outros bancos de dados do mercado.

Conhecemos os componentes que um banco de dados possui, como, as tabelas, os campos, as linhas, as chaves primárias e estrangeiras, os triggers, as procedures e as funções. Após essa breve introdução sobre os elementos de um banco de dados, fomos para a linguagem SQL e aprendemos sobre o seu histórico — como surgiu e sua evolução.

Em seguida, vimos como criar e excluir um banco de dados e as tabelas. Com as tabelas criadas, inserimos dados nelas utilizando o comando `INSERT INTO` e modificamos algumas informações já existentes, visto que podemos ter dados mutáveis, como no cadastro de cliente com algum status que se altera. Vimos também, como excluir dados em uma tabela, já que podemos ter campos que perderam a validade e, consequentemente, não possui mais uma função.

Aprendendo a criar banco de dados, tabelas e manipular, incluir, alterar e excluir dados, vimos como consultá-los utilizando o comando `SELECT`, como selecionar e exibir todos ou alguns campos que compõem a tabela e inserimos nomes temporários para as colunas usando o `ALIAS`.

Estudamos também sobre os filtros simples (igual, maior, menor, maior ou igual, menor ou igual e `BETWEEN`) e compostos (`AND` e `OR`), para desmembrar as informações que queremos exibir. Com essa visão geral sobre o SQL, você conseguirá acompanhar treinamentos mais avançados sobre esse tema.

Espero vocês nos próximos cursos avançados de MYSQL.

Abraços, obrigado pela preferência e até a próxima!


-----------------------------------------------------------------------

