---
type: "9"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
fonte_curso: https://www.alura.com.br/artigos/conectando-workbench-mysql-linux
Url_video_curso: https://cursos.alura.com.br/extra/alura-mais/como-instalar-o-mysql-no-linux-c1158
---

Tópico:: #MySQL #DataBase

![[Pasted image 20250206224613.png]]

-----------------------------------------------------------------------
No dia a dia de um(a) **DBA**, **pessoas desenvolvedoras** e até mesmo **engenheiros(as) de dados** é necessário ter acesso aos dados guardados, modelar um banco de dados ou fazer uma consulta. O **MySQL Workbench** é uma ferramenta gráfica que permite trabalhar de forma fácil e descomplicada com servidores de banco de dados. Neste artigo, iremos aprender a instalar e a conectar o Workbench ao MySQL no Linux. Vamos lá!?

![Quadrado na cor azul escuro e com transparência mostrando a interface do Workbench. No centro deste quadrado é apresentado o desenho de uma chave de boca. Do lado direito da chave é apresentada a forma de um golfinho e de um banco de dados, ambas com traços de cor branca. Embaixo das formas, está a palavra “MySQL Workbench”.](https://www.alura.com.br/artigos/assets/conectando-workbench-mysql-linux/imagem1.png)

## Baixando o MySQL Workbench

Ao acessar a página de [download](https://dev.mysql.com/downloads/workbench/) do MySQL Workbench, iremos selecionar o **sistema operacional (Ubuntu Linux)** e a **versão (20.04)** que está sendo utilizada neste tutorial. Depois de realizar essa ação, a página mostrará dois arquivos com essa versão, faremos o download do primeiro. Esse arquivo tem extensão **.deb**, que é um tipo de arquivo executável do Linux.

![Site da página de download dos arquivos MySQL. No canto superior da imagem é apresentada a URL: https://dev.mysql.com/downloads/workbench/. Logo abaixo, na cor azul, é apresentada a frase: MySQL Community Downloads. No centro da imagem temos duas opções para realização de download. No lado direito, a primeira palavra download é apresentada destacada por um retângulo vermelho.](https://www.alura.com.br/artigos/assets/conectando-workbench-mysql-linux/imagem2.jpg)

Em seguida, o site pedirá para fazer o login na Oracle ou para criar um login, mas não é necessário. Para continuar, clique em “apenas fazer o download”.

![Página do site de downloads do MySQL. No canto inferior esquerdo está escrito “No thanks, just start my donwload”, destacado com um retângulo vermelho.](https://www.alura.com.br/artigos/assets/conectando-workbench-mysql-linux/imagem3.jpg)

Depois de feito o download, vamos abrir o terminal do Linux e começar a instalação.

[![Banner promocional da Alura, com chamada para um evento ao vivo no dia 12 de fevereiro às 18h30, com os dizeres](https://www.alura.com.br/artigos/assets/cursos-imersivos-soft-launch/cursos-imersivos-soft-launch-banner-corpo-mobile.png)](https://conteudo.alura.com.br/vem-ai-o-proximo-nivel-da-alura?utm_source=blog&utm_medium=banner&utm_campaign=cursos-imersivos_captacao-lista-espera)

## Preparando o ambiente para instalação

Antes de tudo, não podemos esquecer de fazer o login como **root** no terminal. Para isso, use o seguinte comando no terminal:

```
sudo su
```

A sua senha será solicitada, digite e aperte enter.

Feito isso, estamos prontos para começar a instalação.

## Instalando o MySQL Workbench

Antes de darmos o comando para a instalação, precisamos **navegar** até a pasta onde se encontra o **arquivo baixado**. Geralmente, os arquivos baixados ficam dentro da pasta **Downloads**. Para isso, use o seguinte comando no terminal:

```
cd Downloads
```

Aperte enter e você estará dentro da pasta de Downloads.

Agora, precisamos descompactar o arquivo para que a instalação possa ser feita. Para isso, use o seguinte comando no terminal:

```
dpkg -i mysql-workbench-community_8.0.27-1ubuntu21.04_amd64.deb
```

![Gif mostrando o terminal do Linux executando o comando “dpkg -i mysql-workbench-community_8.0.27-1ubuntu21.04_amd64.deb”](https://www.alura.com.br/artigos/assets/conectando-workbench-mysql-linux/imagem4.gif)

**Atenção nesse comando:** o nome do arquivo no **comando** precisa estar **igual** ao nome do arquivo dentro da **pasta**. Caso contrário, será retornado um erro informando que o arquivo não foi encontrado.

**Mais um ponto de atenção**: durante a execução do comando será mostrado alguns erros, mas esses erros não implicam em nenhum problema na instalação.

Agora estamos prontos para, de fato, instalar o MySQL Workbench. Para isso, use o seguinte comando no terminal:

```
apt-get -f install
```

![Gif mostrando o terminal do Linux executando o comando “apt-get -f install”.](https://www.alura.com.br/artigos/assets/conectando-workbench-mysql-linux/imagem5.gif)

Depois da execução do comando terminar, vamos verificar se o MySQL Workbench foi instalado, pesquisando pelos aplicativos.

![Tela de pesquisa dos aplicativos no Linux, com fundo de cor roxa. A palavra “workbench” é apresentada dentro da caixa de pesquisa e  logo abaixo é demonstrado o logotipo do MySQL. O logo tem o fundo na cor azul escuro e a forma de um golfinho e uma chave de boca destacada em branco.](https://www.alura.com.br/artigos/assets/conectando-workbench-mysql-linux/imagem6.jpg)

## Conectando ao MySQL Workbench

Vamos abrir o MySQL Workbench clicando no ícone e começar a configurar a conexão. Se você tiver o MySQL Server instalado, por padrão, no Workbench a conexão **localhost** vem pré-configurada.

![Tela inicial do MySQL Workbench com a mensagem “Welcome to MySQL Workbench” e abaixo da mensagem, um texto descritivo sobre o Workbench e a conexão local pré-configurada.](https://www.alura.com.br/artigos/assets/conectando-workbench-mysql-linux/imagem7.jpg)

Ao clicar duas vezes sobre a conexão, abrirá uma janela que solicita a senha. Então, é só digitar a senha e clicar em **ok**.

Prontinho, conexão feita! Agora você pode começar a praticar e criar banco de dados, tabelas e querys.

![Gif apresentado a tela inicial do MySQL Workbench e a aba de login com a conexão local pré-configurada.](https://www.alura.com.br/artigos/assets/conectando-workbench-mysql-linux/imagem8.gif)

Gostou deste artigo e quer conhecer ainda mais sobre banco de dados e o MySQL?

A [Formação SQL com MySQL Server da Oracle](https://alura.com.br/formacao-oracle-mysql) foi feita para você! Aqui, te ajudaremos em todos os passos do processo, desde a instalação até a criação de um banco de dados.