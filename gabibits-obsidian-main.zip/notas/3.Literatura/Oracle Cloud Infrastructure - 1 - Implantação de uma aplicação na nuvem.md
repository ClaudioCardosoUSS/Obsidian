---
type: "10"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
  - "#oracle"
  - "#OCI"
  - "#cloud"
fonte_curso: https://cursos.alura.com.br/formacao-oracle-cloud-infraestructure-one
Url_video_curso: 
OCI: https://cdn3.gnarususercontent.com.br/oracle-one-alumni/OCI%20-%20Cartilha.pdf
w3schools:
---

Tópico:: #oracle #infrastructure #database #oci #cloud

- Aprenda conceitos básicos de computação em nuvem
- Compreenda a arquitetura da Oracle Cloud
- Crie uma conta na Oracle Cloud
- Aprenda a criar redes virtuais e um load balancer na Oracle Cloud
- Aprenda a criar e configurar computes na VCN
- Implante uma aplicação básica na Oracle Cloud
-----------------------------------------------------------------------
## Aulas

- [](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/section/13786/tasks)
    
    [Computação em nuvem](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/section/13786/tasks) [Ver primeiro vídeo](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105655)
    
    - Apresentação
    - Doguito Petshop
    - Computação em nuvem
    - Por que usamos Clouds
    - Faça como eu fiz: iniciando na Cloud
    - Para saber mais: conceitos de Cloud
    - O que aprendemos?
- [
    
    Conta Free Tier na OCI
    
    ](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/section/13787/tasks)
    
    - Criação de conta na OCI
    - Para saber mais: modo gratuito (Free Tier)
    - Modo gratuito (Free Tier)
    - Faça como eu fiz: criando uma conta na OCI
    - Conhecendo o Console da OCI
    - Faça como eu fiz: navegando no Console da OCI
    - Características da Free Tier
    - O que aprendemos?
- [
    
    Arquitetura da OCI
    
    
    ](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/section/13788/tasks)
    
    - Visão geral da OCI
    - Para saber mais: infraestrutura da OCI
    - Compartments
    - Para saber mais: compartments à fundo
    - Faça como eu fiz: criando compartimentos
    - Usuários
    - Para saber mais: IAM na OCI
    - Faça como eu fiz: criando um usuário
    - Cloud Shell
    - Faça como eu fiz: configurando o Cloud Shell
    - Compartments
    - O que aprendemos?
- [
    
    Redes
    
     ](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/section/13789/tasks)
    
    - Introdução à Virtual Cloud Network - VCN
    - Criando a VCN
    - Faça como eu fiz: uma VCN para instâncias
    - Roteamento e segurança
    - Para saber mais: redes na OCI
    - A VCN
    - O que aprendemos?
- [
    
    Compute
     
    ](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/section/13790/tasks)
    
    - Criando um Compute
    - Faça como eu fiz: nosso primeiro compute
    - Para saber mais: tudo sobre computes
    - Configurando um servidor
    - Faça como eu fiz: instalando softwares na instância
    - Múltipla escolha Computes
    - Balanceador de carga
    - Mais um servidor
    - Faça como eu fiz: mais um Doguito Server
    - Nosso balanceador de cargas
    - Para saber mais: introdução aos load balancers
    - Balanceador de cargas
    - O que aprendemos?
    - Conclusão

-----------------------------------------------------------------------
[00:13] Oracle Cloud é um conjunto de serviços em nuvem que se complementam e permitem criar e executar vários tipos de aplicação em um ambiente de alta disponibilidade. Oracle Cloud, conhecida como OCI, oferece recurso de computação de alto desempenho e combina a elasticidade e a utilidade de uma nuvem pública com controle e segurança de uma infraestrutura local, como se fosse um _data center_ privado.

[00:38] Isso tudo para oferecer serviços de infraestrutura de alto desempenho bastante econômicas. Vamos ver as características da OCI, suas tecnologias e fundamentos. E, para fixar nossos conhecimentos, vamos criar um projeto prático que será implantado na nuvem da Oracle.

[00:55] Sou o professor Tiago e quero dar-lhes as boas-vindas ao nosso curso.

-----------------------------------------------------------------------
# 02Doguito Petshop

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105656

## Transcrição

[00:00] Antes de começarmos a trabalhar diretamente com a Oracle Cloud, vamos entender um pouco o contexto da aplicação com que vamos trabalhar, que vamos implantar na Oracle Cloud.

[00:14] A aplicação que vamos implantar é o Doguito Pet shop. Ela é bem simples (bem simples mesmo), no momento ela basicamente permite incluir um cliente novo. Por exemplo, vou colocar o nome "Tiago" e o e-mail "tiagolpadua@yahoo.com". Clicando em "Cadastrar", o cadastro é realizado com sucesso e voltamos para a lista de clientes. A aplicação também permite que façamos a exclusão desse cliente.

[00:50] Então, essa é a aplicação que vamos migrar para a Oracle Cloud. Vamos entender um pouco mais a parte técnica dessa aplicação. Ela é escrita em JavaScript, tem uma parte do site (do _front-end_, do HTML) e tem também uma parte de _back-end_. A aplicação é dividida entre o _front-end_ e a API, que permite fazer a inclusão e a exclusão das entidades.

[01:24] Essa aplicação é baseada em Node, no entanto, não é necessário um conhecimento profundo em Node para conseguirmos seguir o nosso treinamento. Caso você queira fazer o _download_ dessa aplicação e instalar em sua máquina, executar localmente em sua máquina, você pode fazer. Existem instruções no arquivo `README.md`, no entanto, não é um passo obrigatório.

[01:49] Na sequência, vamos dar continuidade ao nosso entendimento da Oracle Cloud.

-----------------------------------------------------------------------
# 03Computação em nuvem

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105657
## Transcrição

[00:00] Para entendermos qual é a vantagem de implantarmos o Doguito Pet Shop na Cloud, é necessário entendermos um pouco melhor o que é a computação em nuvem.

[00:13] A computação em nuvem é a oferta de serviços de computação como servidores, armazenamento, banco de dados, rede e outros _softwares_, através da internet que chamamos de Cloud.

[00:29] O Doguito Pet Shop poderia ser implantado, por exemplo, em uma infraestrutura de _data center_ privado, principalmente quando tratamos de uma empresa média ou grande. Por que essa empresa, em vez de implantar e utilizar um _data center_ privado, optaria por utilizar uma computação em nuvem, uma computação na Cloud? Vamos ver quais são algumas dessas vantagens.

[01:01] A primeira vantagem é relativa ao **custo**. A computação em nuvem reduzirá o custo com a compra de _hardwares_ e _softwares_, quando comparamos com a configuração e execução de um _data center_ físico, local da empresa.

[01:19] Porque, nesse _data center_ físico, você terá que fazer a instalação física de servidores, mexer mesmo com o _hardware_, colocar os computadores para funcionar, instalação elétrica, refrigeração, _back-up_ de energia e todas as outras questões necessárias para manter um _data center_. Não só os custos físicos, há também os custos dos especialistas que você contratará para gerenciar essa infraestrutura.

[01:50] Outra vantagem da utilização da Cloud é relativa à **velocidade**. A maior parte dos serviços em nuvem de computação é fornecida sobre a forma de um autosserviço e sob demanda, isso permite que até as grandes quantidades de recursos de computação possam ser provisionados em minutos.

[02:13] Normalmente, com apenas alguns cliques, você vai à interface do serviço e consegue provisionar, disponibilizar esses recursos, fornecendo às empresas bastante flexibilidade e aliviando a necessidade de planejamento, de capacidade (porque serão necessárias reuniões, compras de _software_ etc).

[02:32] Se você imaginar que, em um _data center_ físico, local, a empresa precisaria fazer todo um processo para comprar mais máquinas, o _data center_ via Cloud parece uma boa estratégia. Em uma oferta via Cloud, isso poderia ser feito em poucos minutos, com alguns cliques e logo já teria um novo _hardware_ disponível.

[02:51] Temos também a vantagem de **escala**. Um dos benefícios da computação em nuvem inclui essa capacidade de dimensionamento elástico. Tanto como falamos anteriormente com relação ao crescimento, se eu preciso em certo momento aumentar a minha capacidade computacional, vou em uma oferta de serviço em Cloud, dou um clique e eu consigo aumentar essa oferta.

[03:15] O mesmo vale quando quisermos reduzir, por exemplo, se eu não precisar mais de tanto _hardware_. No _data center_ físico, tradicional, isso é muito complicado — como é que você vai desfazer as vendas das máquinas que você já comprou? Uma vez que você comprou e instalou, é muito inelástica a sua oferta de _hardware_.

[03:36] A Cloud fornecerá uma quantidade de recursos adequada de TI, assim como a potência de computação maior ou menor, largura de banda, armazenamento, sempre que for necessário e até mesmo para uma localização geográfica correta. As empresas que fornecem serviços de Cloud têm, em geral, serviços espalhados geograficamente para que a empresa consiga solicitar um serviço de Cloud na região geográfica mais próxima.

[04:06] Isso traz bastante ganho em termos de produtividade, os _data centers_ locais normalmente vão exigir uma pilha de equipamentos e implementação como, por exemplo, configuração de _hardware_, _softwares_ e outras tarefas que são demoradas do gerenciamento de TI e necessitam de um profissional, vai gastar recurso para isso, vai dar trabalho para manter isso.

[04:30] A computação em nuvem vai remover a maior parte da necessidade dessas tarefas para que essas equipes de TI possam investir seu tempo na obtenção de metas comerciais ligadas ao negócio da empresa e não a configuração de _hardware_ físico.

[04:47] Há a questão também de **desempenho**. Os maiores serviços de computação em nuvem são executados em uma rede mundial de _data centers_ e esses eles são muito seguros, são autorizados regularmente com relação à geração de_hardware_, _software_ também, e permite uma computação rápida e eficiente. Na empresa tradicional, nos _data centers_ tradicionais, a empresa teria que estar constantemente comprando dispositivos de _hardware_ mais novos e mais potentes, o que também seria um grande trabalho para a empresa.

[05:21] Isso vem também trazer a questão da **confiabilidade**. A computação em nuvem vai facilitar e reduzir os custos de _back-up_ de dados, recuperação de desastres e continuidade do negócio, já que os dados podem ser espelhados em diversos sites redundantes de um mesmo provedor de nuvem. Um provedor possui diversos sites diferentes e você pode fazer esse espelhamento entre esses sites distintos.

[05:47] Com isso também vem a questão da **segurança**, os provedores de nuvem eles vão fornecer um amplo conjunto de políticas, tecnologias e controles que vão fortalecer bastante a postura geral de segurança da empresa para proteger os dados ainda mais nesses tempos que vemos tantos ataques e ameaças ocorrendo.

[06:08] Outro ponto que também temos que entender é quais são os **tipos de nuvem**. Existem vários tipos de nuvens e nem todas são iguais e não há um tipo de computação em nuvem que seja ideal para todas as empresas. Existem vários modelos de serviços e eles foram evoluindo para oferecer a solução certa para a necessidade da empresa.

[06:31] Primeiro, precisamos determinar o tipo de implantação de _software_ e a arquitetura de computação em nuvem no qual os serviços são necessários para serem implementados.

[06:42] Há basicamente três maneiras diferentes de implantar esses serviços em nuvem. Existem as **nuvens públicas** que têm o serviço de provedor terceirizado e são administradas por ele, em geral pela internet. É um serviço que você tem que você vai acessar pela internet, por exemplo, temos Azure, Google, AWS que são muito conhecidos por terem nuvens públicas.

[07:12] Todo o _hardware_, os _softwares_, a infraestrutura e o suporte são de propriedade e gerenciados pelo provedor de nuvem. Você vai acessar esse serviço, gerenciar uma conta utilizando o navegador da _web_.

[07:25] Outro tipo de nuvem que temos é a chamada **nuvem privada**, que se refere ao recurso de computação em nuvem utilizados exclusivamente por uma única empresa ou organização. A nuvem privada pode estar localizada fisicamente no _data center_ local da empresa, a empresa pode pegar o próprio _data center_ que ela já tem e evoluir para fornecer uma oferta mais dinâmica de serviços para a própria empresa.

[07:53] Muitas vezes, a empresa também quer experimentar esse serviço em nuvem, saber como vai funcionar e ela pode partir para esse modelo inicialmente de uma nuvem privada para se adaptar aos processos internos que ela já tem e já trabalha.

[08:08] Depois disso, ela pode ter também uma nuvem que chamamos de **nuvem hibrida**, que vai combinar a nuvem pública e a privada ligadas por algum tipo de tecnologia que vai permitir que os dados sejam compartilhados entre elas.

[08:24] Temos que entender também quais são os **tipos de serviços** que são disponibilizados em nuvem. A maioria dos serviços de computação em nuvem vai enquadrar-se em uma dessas quatro categorias que vamos ver agora. **IaaS** (infraestrutura como serviço), **PaaS** (plataforma como serviço), **SaaS** (_software_ como serviço) e **Serverless** (que seria algo como "sem servidor"). Vamos falar um pouco sobre cada uma delas.

[08:52] O IaaS, infraestrutura como serviço, é uma das categorias mais básicas do serviço de computação em nuvem. Com IaaS, é como se você estivesse alugando uma infraestrutura de TI, isso inclui servidores, máquinas virtuais, armazenamento, redes, sistema operacional, isso você vai alugar de um provedor de serviço e o pagamento em geral vai ser relativo ao uso que você faz desse serviço.

[09:17] Depois disso temos o PaaS que é "plataforma como serviço". A plataforma como serviço refere-se ao serviço de computação em nuvem que vai fornecer o ambiente sob demandas de desenvolvimento, teste e fornecimento, gerenciamento de aplicação de _software_.

[09:32] O PaaS, em geral, é criado para facilitar os desenvolvedores a criar aplicativos móveis ou aplicativos _web_ de uma maneira bastante rápida, sem se preocupar muito com a configuração ou gerenciamento da infraestrutura de servidores. Armazenamento, rede ou banco de dados tudo isso você não precisa configurar nessa modalidade.

[09:52] Depois temos o _software_ como serviço que é um nível de abstração ainda mais alto. O _software_ como serviço é um método que você tem a distribuição de aplicativo de _software_ pela internet sob demanda e normalmente baseado no modelo de assinatura, você vai lá e assina aquele _software_ e você utiliza-o pelo tempo que você quiser e não se preocupa em nada com relação à implantação, a configuração daquele _software_, pois ele já vem pronto.

[10:20] O SaaS os provedores de nuvem hospedam e gerenciam aplicativo de _software_ e a infraestrutura subjacente que vão fazer as manutenções, atualizações e testes de segurança. Os usuários vão comunicar-se nesse aplicativo pela internet, normalmente é um aplicativo _web_ ou através do PC.

[10:38] A última categoria que o Serverless, que é a computação sem servidor, ela vai concentrar-se na criação de funcionalidades de aplicativos sem perder tempo, sem que o desenvolvedor perca tempo com o gerenciamento desses servidores e da infraestrutura. O provedor em nuvem vai cuidar da configuração, planejamento, capacidade e do gerenciamento de servidores para que você desenvolva o mais rápido possível.

[11:05] Essas arquiteturas sem servidor em geral são altamente escaláveis e controladas por eventos. A cada evento, cada vez que você for criar uma função você ao invés de hospedar um aplicativo você vai hospedar uma função e essa função vai ser chamada através de um evento, por exemplo, uma requisição de rede. Cada vez que um evento desses ocorrer isso vai ter uma pequena tarifa e você em geral vai ser tarifado só quando ocorrer um daqueles eventos.

[11:32] O Oracle Cloud Infrastructure é um conjunto de serviços que inicialmente vai atender pelo lado do IaaS ou a infraestrutura como serviço, mas ele também vai fornecer uma série de outros recursos que também vão estar ligados tanto ao Paas, ao SaaS e ao Serveless também. Ele vai ser bastante amplo e englobar todas essas categorias de serviço, ele começa com a infraestrutura como serviço, IaaS.

[12:03] Agora que já entendemos como o nosso aplicativo Doguito vai entrar na Cloud, quais são as vantagens de colocarmos o Doguito Pet Shop na Cloud, é hora de começarmos a utilizar o Oracle Cloud Infrastructure.

-----------------------------------------------------------------------
# 06Para saber mais: conceitos de Cloud

https://app.dataannotation.tech/me


Quando começamos a estudar sobre cloud nos deparamos com uma série de conceitos e siglas que num primeiro momento podem soar estranhos aos nossos ouvidos, no entanto, é importante compreendê-los para podermos ter uma visão ampla de como a Cloud é estruturada e quais são seus princípios. Para te ajudar nesse caminho, temos este [artigo](https://www.alura.com.br/artigos/o-que-e-cloud-e-seus-principais-servicos) que resume muito bem estes conceitos relacionados à Cloud.


-----------------------------------------------------------------------
# 07O que aprendemos?

## Nessa aula, você aprendeu:

- Que as vantagens da computação em nuvem são a redução de custos, maior velocidade, escala, produtividade, desempenho e ganho de desempenho quando comparada a utilização de datacenters tradicionais;
- Os tipos de clouds mais comumente disponibilizados no mercado são a pública, privada e a híbrida;
- Os serviços normalmente oferecidos neste tipo de computação são, por exemplo, IaaS, Paas, Saas e Serverless;
- A Oracle Cloud é inicialmente mais focada em infraestrutura, porém possui várias categorias de serviços que irão atender às mais diversas demandas.


-----------------------------------------------------------------------
# 01Criação de conta na OCI

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105658

## Transcrição

[00:00] O primeiro passo para cadastrarmos, para implantarmos a nossa aplicação do Doguito Pet Shop na Oracle Cloud é fazer o registro lá no site da Oracle. Para isso acessamos: [www.oracle.com/cloud](http://www.oracle.com/cloud) e clicamos na opção: "Try Oracle Cloud for free".

[00:18] Clicando nessa opção, vamos para essa segunda tela onde temos a opção do "Start for free", que podemos iniciar aqui a nossa avaliação do serviço da Oracle. Clicando no "Start for free" temos acesso a dois serviços, uma gama de serviços é chamada de _always-free_ que como o próprio nome diz, são os serviços que vão ser para sempre gratuitos que são: Banco de Dados Autônomo, Máquinas virtuais, Armazenamento de objetos.

[00:48] Além disso, temos acesso a 300 dólares em créditos que são válidos por 30 dias. Vamos conseguir acessar alguns serviços que seriam também pagos e utilizamos esse crédito, se os créditos acabarem não temos mais acesso ao serviço ou se passar também os 30 dias.

[01:08] No entanto, para a nossa aplicação do Doguito Pet Shop, os serviços que são essenciais que são os serviços que estão na categoria de cima, vão ser suficientes para fazermos o cadastramento da nossa aplicação, implantar a nossa aplicação na Cloud e fazer o nosso estudo.

[01:26] Agora vamos cadastrar. A primeira coisa que vamos colocar é o país que estamos, no caso o Brasil, vamos colocar o primeiro e o segundo nome. Sempre recomendo colocar os dados corretos para alguma verificação, vamos colocar aqui o nosso e-mail também e nesse e-mail vamos receber o link de verificação. Com esse link de verificação vamos poder dar continuidade ao processo de cadastramento. O link é enviado e podemos prosseguir com o processo de cadastramento.

[01:59] Após receber o e-mail de confirmação, preencha com seus dados pessoais. A primeira coisa é colocar aqui uma senha, cadastrar uma senha válida para o serviço da Oracle Cloud, você confirma essa mesma senha. Não coloca o nome da empresa senão ele vai pedir dados de CNPJ e o nome da conta da Cloud vamos trocar para "doguitopetshop".

[02:27] Pode ser que quando você vá fazer, peça para colocar um nome diferente aí é só colocar um número na frente só para diferenciar. Aí você vai escolher a sua região local, a região do Data Center que você preferir que seja mais próxima dos seus clientes para ser mais rápida a conexão deles. Neste caso temos o Data Center da Oracle em São Paulo, escolheremos esse, e clicamos em "Continuar".

[02:53] Após isso vai pedir para colocarmos os nossos dados de faturamento, onde vamos colocar o dado do endereço, coloque o seu endereço pessoal. Sempre recomendo colocar os dados verídicos porque eventualmente eles utilizarão esses dados para fazer algum tipo de confirmação, de validação, por isso coloque os dados corretos. Em seguida o nome da cidade, a UF, o código postal da sua residência, o seu CPF também que colocar e na próxima sequência colocamos o nosso telefone de contato.

[03:33] Antes de fazermos o contrato vamos clicar em "Continuar" e adicionar uma forma de pagamento. Essa forma de pagamento vai servir para validar a sua conta, ele vai fazer uma pequena cobrança no cartão de crédito e depois ele vai estornar esse valor, não vai cobrar nada de você, mas é obrigatório colocar um cartão de crédito que seja válido. Clicamos em "Adicionar método de verificação de pagamento" e vai pedir para você digitar clicando em cartão de crédito, pedir para você digitar os dados do seu cartão de crédito.

[04:11] Já vai aparecer aqui pré preenchido os dados dos faturamentos anteriores, escolha a bandeira do seu cartão de crédito, coloque o número do seu cartão de crédito, tem que ser o número correto para ele poder validar, coloque o mês e o ano do vencimento do cartão de crédito e o código verificador do cartão. Confirmando após alguns segundos ele vai mostrar a mensagem de agradecimento, volta para a tela anterior onde podemos clicar que estamos de acordo com os termos do contrato e iniciar o nosso prazo de avaliação gratuita.

[04:55] Lembrando que essa avaliação é gratuita e temos aqueles 300 dólares de crédito, mas existe uma série de serviços que são os serviços sempre gratuitos. Enquanto isso tem que aguardar o processo de finalização de configuração da conta.

[05:11] Após isso vai aparecer essa tela de confirmação da Oracle Cloud e já vai pedir para você logar com o seu nome de conta da Oracle Cloud. Vamos continuar o nosso processo aqui, vamos fazer o login com a conta que criamos anteriormente, no caso "doguitopetshop", clicamos em "Next" e aí esperamos aqui ele criar o nosso domínio.

[05:42] Vamos criar também um usuário local, um usuário para fazer o _login_ aqui. Vou colocar "tiagolpadua@outlook.com" e colocar aqui uma senha para acesso.

[05:58] Pronto, agora ele já está logando aqui a nossa conta da Oracle. Vai aparecer aqui alguma mensagem no caso de navegador, eu estou usando aqui o Edge, mas tudo bem, era uma pergunta aqui bem básica sobre qual o seu interesse no momento com a Oracle Cloud, podemos responder qualquer coisa, o interesse por _Hobbyist_ mesmo e clicamos aqui no "Salvar", vai concluir e vamos ter acesso ao painel inicial, a nossa primeira visão do console de administração web da Oracle.


-----------------------------------------------------------------------
# 02Para saber mais: modo gratuito (Free Tier)

Se você quiser conhecer todos os detalhes dos limites de uso da conta Free Tier, recomendo que veja este [link para informações sobre o modo gratuito](https://www.oracle.com/br/cloud/free/) da Oracle Cloud, nele você terá uma visão minuciosa de tudo que pode ser feito com a conta Free Tier assim como o Free Trial.


-----------------------------------------------------------------------
# 05Conhecendo o Console da OCI

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105659

## Transcrição

[00:00] Agora que já criamos uma conta na Oracle Cloud e já temos acesso aos serviços, já temos usuários, já conseguimos fazer o _login_ é hora de darmos continuidade à implantação do Doguito Pet Shop aqui no ambiente da Oracle Cloud.

[00:14] Para isso temos que compreender bem como funciona, pelo menos, os recursos básicos da interface web da Oracle Cloud. Para isso vamos voltar à tela inicial da "[www.oraclecloud/cloud"](http://www.oraclecloud/cloud%22), clicar em "Try Oracle Cloud for free" e eu posso fazer aqui agora o _sign in_ ao invés de fazer o iniciar para criar um usuário que já fizemos, vamos na opção do "Sign in" que seria para fazer o _login_.

[00:41] Vamos colocar aqui o nosso nome de usuário, no caso "doguitopetshop", vamos clicar em "Next" acessar com o usuário e senha que já tínhamos cadastrado anteriormente no passo de cadastro de usuário. Fazendo isso vamos entrar aqui e vamos cair direto na interface do Oracle Cloud web, o console de administração do Oracle Cloud.

[01:06] Esse console de administração é dividido em várias áreas, a primeira dessas áreas é a área de menu que fica aqui no canto superior esquerdo. Nessa área de menu temos acesso a _Home_, Computação, Armazenamento, Rede, ou seja, praticamente todos os recursos da Oracle Cloud estão disponíveis aqui no menu.

[01:26] Cada vez que clicamos em um menu desse aparece aqui um subgrupo de opções à direita, por exemplo, eu posso vir aqui em "Computação" e ver as instâncias de computação que tem disponíveis, por exemplo. Nesse caso ainda não tem nenhuma, ainda não criamos nenhuma instância de computação. Além disso, eu sempre posso voltar para a tela inicial clicando aqui no Oracle Cloud.

[01:51] Na sequência temos essa área de busca onde eu posso buscar por diversos serviços, por exemplo, eu posso buscar aqui a parte de log. Cliquei aqui em "Log" e apareceu "Loading..." está em destaque. Log são os registros de tudo o que aconteceu na utilização da Oracle Cloud, tem aqui todas as operações com data, hora, tudo o que aconteceu aqui durante a utilização da Oracle Cloud.

[02:19] Na sequência, ao lado direito no canto superior, temos a região que nos encontramos. Neste caso vamos utilizar somente uma região geográfica, só um Data Center aqui da Oracle. No entanto, para casos maiores, para empresas maiores ela pode ter acesso a mais regiões e aí pode fazer replicações e assim por diante. Para o nosso exemplo que é bem básico conseguimos ficar aqui direto só em uma região mesmo.

[02:49] Na sequência temos Cloud Shell que é uma ferramenta muito interessante, ele é o ambiente de linha de comando que quando clicamos a Oracle vai instanciar uma máquina virtual com o ambiente Linux e com todas as ferramentas de linha de comando que podemos utilizar para ter acesso ao Oracle Cloud. Basicamente todas as operações que conseguimos realizar pela interface de menus conseguimos fazer aqui também pela linha de comando.

[03:25] Essa instância que é aberta aqui não é uma máquina virtual que vai cobrar você utilização, não estamos instanciando uma máquina virtual para utilizarmos aqui no Doguito Petshop, é uma máquina que existe simplesmente para que consigamos emitir comandos e não precisa instalar nada localmente na nossa estação local.

[03:45] Por exemplo, aqui eu posso emitir alguns comandos, aqui é um ambiente Linux convencional, eu posso colocar aqui um `uname -a`, vou ver que é um ambiente Linux e eu posso fazer alguns comandos que são os comandos do OCI. Se eu colocar aqui `ocI --version` vai aparecer a versão do OCI atualmente instalada e eu consigo fazer algumas operações aqui do OCI como, por exemplo, `oci iam user list` para listar os usuários que estão cadastrados aqui na ferramenta.

[04:19] Posso expandir aqui também a área e ele vai me mostrar, no caso os usuários da minha conta é só o `tiagolpadua@outlook.com`. Isso vai variar de usuário para usuário. A ferramenta é muito interessante e muito útil para evitar que tenhamos que instalar ferramentas complicadas na nossa máquina local. Terminando o uso podemos clicar aqui no "Encerrar".

[04:45] Na sequência podemos clicar aqui, ver aqui os anúncios, tem alguns alertas, alguns avisos que a Oracle pode emitir que vão estar presentes aqui. Temos também aqui uma área de ajuda onde podemos fazer algum tipo de solicitação, como o nosso caso é a conta _free_ não temos acesso ao suporte imediato, temos mais acesso ao fórum, a documentação textual.

[05:12] Outra opção que temos aqui é para selecionar o idioma da interface web, neste caso está Brasil e aí você pode escolher português ou inglês, fica a seu critério. E aqui mais a direita temos o acesso ao menu do perfil, onde eu tenho acesso aos meus dados de perfil, entre outras opções que vamos ter aqui e eu consigo também fazer o _log off_.

[05:34] Neste caso vou fazer o _log off_ para sair do sistema e eu posso fazer aqui o _Signed out_. E aí se quisermos acessar novamente é só clicar em "Acessar". Isso resume bem as características que temos no console web do OCI.


-----------------------------------------------------------------------
# 07Características da Free Tier

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105660

## Transcrição

[00:00] Agora que já criamos a nossa conta, já entendemos um pouco como que é o console da Oracle Cloud, é importante entendermos quais são as características dessa conta que criamos para trabalharmos. Essa conta que criamos na Oracle Cloud é uma conta chamada Oracle _Free Tier_.

[00:23] Essa conta vai fornecer vários serviços que serão sempre gratuitos, ou seja, esses serviços que estão associados a essa conta _Free Tier_ são sempre gratuitos, eles não vão vencer. Porém, junto com essa criação da nossa conta _Free Tier_ criamos também uma conta chamada _Free Trial_.

[00:49] Para cadastrarmos o Doguito Petshop, para implantarmos o Doguito Petshop temos que entender a diferença entre esse _free tier_ e o _free trial_ para não termos problemas.

[01:01] O _free trial_ que veio junto vai nos permitir utilizarmos 300 dólares de crédito em qualquer serviço da Oracle Cloud pelo período de até 30 dias, isso é chamado de _free trial_. Os serviços do _free tier_ vão estar sempre disponíveis por tempo indeterminado. Já os serviços do _free trial_ que é essa avaliação gratuita, podem ser utilizados até que os seus 300 dólares de créditos gratuitos sejam consumidos ou tenha passado 30 dias, o que acontecer primeiro.

[01:38] A nossa conta, o nosso projeto do Doguito Petshop vai se enquadrar nessa conta do _free tier_. O _free tier_ vamos conseguir cadastrar sem problemas o nosso projeto do Doguito Petshop.

[01:53] Os serviços do Oracle _free tier_ são destinados praticamente a todos os usuários, seja você um desenvolvedor que está criando ou testando um aplicativo, um aplicativo novo ou se você está iniciando um _startup_, uma empresa procurando testar algum projeto para ser colocado na Cloud e no nosso cas também somos estudantes, estamos aprendendo sobre Cloud, aprendendo sobre Oracle Cloud o _free tier_ vai atender muito o nosso caso de uso.

[02:21] Um ponto que é importante destacarmos é que o Oracle Cloud _free tier_ não inclui SLA. O SLA é sigla de _Service Level Agreement_, ou seja, acordo de nível de serviço. Caso a sua aplicação já esteja em uma fase de fornecimento para o usuário final, o usuário que chamamos de produção, é importante que você migre para uma das modalidades pagas da Oracle Cloud para que haja um SLA adequado.

[02:49] Apesar do _free tier_ permitir acessarmos vários serviços e com conseguirmos desenvolver o nosso Doguito Petshop até o final, se fôssemos implantá-lo em produção de verdade para usuários finais, seria importante evoluirmos para uma modalidade paga para que tenhamos um acordo de nível de serviço mínimo da Oracle.

[03:10] Todos esses serviços estão disponíveis, não vou ler um por um porque seria muito maçante, mas temos tanto serviços de _compute_ que são instâncias de computação com armazenamento, com _object storage_ também, com armazenamento de objetos, com armazenamento de arquivos, redes, bases não relacionais, entre outros serviços. Tem vários serviços disponíveis que conseguimos utilizar.

[03:39] Com o serviço da Oracle Cloud Infrastructure você também tem o essencial para criar e testar aplicativos em nuvem, isso vai incluir também até mesmo armazenamento de SSD, que é aquele armazenamento bem rápido dos computadores. E a tráfico de objetos com largura de banda alta, armazenamento de arquivos, entre outras tecnologias.

[04:01] Agora que já entendemos o que é a conta _free tier_ podemos dar continuidade a implantação do nosso projeto.


-----------------------------------------------------------------------
# 08O que aprendemos?

## Nessa aula, você aprendeu como:

- Podemos utilizar a versão gratuita ou free tier das contas na OCI;
- Existem opções no console da OCI para realizarmos a criação de computes, armazenamento, rede e até bancos de dados que nos permitirão a implantação do Doguito Petshop;
- Navegamos pelo console da OCI através do menu principal, pesquisa e cloud shell para nos familiarizarmos com o ambiente;
- Com a conta free tier podemos usar diversos recursos por tempo ilimitado e assim conhecê-los e testá-los sem custos;
- A conta free tier é diferente do período free trial. Durante este período, podemos utilizar diversos recursos que não estão incluídos na conta free tier por 30 dias ou atingir o limite de $ 300,00.

-----------------------------------------------------------------------
# 01Visão geral da OCI

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105661

## Transcrição

[00:00] A arquitetura do OCI vai se dividir entre uma gama muito grande de serviços, serviço de infraestrutura, entre outros.

[00:08] Dentre esses serviços podemos destacar aqui o serviço de computação que vai permitir que criemos diversas instâncias. Essas instâncias vão nos permitir criar máquinas virtuais dedicadas, configurar essas instâncias, criar _pools_ de instâncias, redes de _cluster_, entre outras.

[00:27] Aqui na área de armazenamento vamos tratar da parte de, como se fosse HD, temos aqui o nosso armazenamento em blocos, volumes do disco rígido, temos aqui propriedade para armazenamento de arquivos, entre outros.

[00:42] Na área de redes podemos criar redes virtuais que são redes gerenciadas via software, determinar faixa de IPs por essas redes, entre outras características.

[00:54] Aqui na parte de banco de dados temos o Oracle Database, temos uma série de tipos de banco de dados. Até entre os bancos de dados autônomos, como Autonomous Data Warehouse, banco de dados do JSON, JSON Database, entre outros.

[01:10] Na parte de banco de dados vamos ter os banco de dados mais tradicionais como, por exemplo, o MySQL. Aqui eu posso levantar diretamente um MySQL ou um Oracle NoSQL Database também. Além disso, temos serviços, digamos, de mais alto nível, entre eles funções analíticas e de inteligência artificial para fazer análise de dados, aprendizado de máquinas, entre outros.

[01:36] Depois temos aqui a parte de Serviços ao Desenvolvedor que vai adicionar uma camada de abstração e permitir gerenciarmos _clusters_ de Kubernetes, por exemplo, registrar contêineres, registrar artefatos, entre outras funcionalidades.

[01:52] A parte de Identidade e Segurança nos permite criarmos usuários, zonas de segurança e definirmos grupos e políticas de acesso aos recursos da Cloud. Depois temos a parte de observabilidade e gerenciamento, onde principalmente temos aqui a parte de monitoração e a parte de _logs_ também.

[02:13] Aqui esse menu de Híbrido nos permite algumas soluções um pouco mais avançadas que são Data Centers híbridos. A parte de migração é voltada para a parte de migração de dados. A parte de gerenciamento de faturamento e custo a parte de custos de operacionais. E aqui temos também a parte de Governança e Administração que vai ter aqui algumas políticas, limites, rotas que podemos definir aqui para a nossa governança.

[02:41] Por último temos a parte de _Marketplace_, que define aqui alguns aplicativos que podem ser criados e compartilhados no _Marketplace_ da própria Oracle Cloud.


-----------------------------------------------------------------------
# 02Para saber mais: infraestrutura da OCI

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105683

A Oracle Cloud é um sistema com diversos conceitos comuns à outras clouds mas também possui alguns conceitos próprios. Para entender como a infraestrutura da Oracle Cloud é dividida e seus conceitos mais fundamentais veja o video (video está em inglês mas possui legendas automáticas em português):

O conteúdo em video pode apresentar alguns tópicos desatualizados, por isso, todos os detalhes sobre os conceitos básicos e arquitetura da OCI podem ser também encontrados na documentação oficial através dos links [https://docs.oracle.com/pt-br/iaas/Content/GSG/Concepts/baremetalintro.htm](https://docs.oracle.com/pt-br/iaas/Content/GSG/Concepts/baremetalintro.htm) e [https://docs.oracle.com/es-ww/iaas/Content/GSG/Concepts/baremetalintro.htm](https://docs.oracle.com/es-ww/iaas/Content/GSG/Concepts/baremetalintro.htm).


-----------------------------------------------------------------------
# 03Compartments

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105662

## Transcrição

[00:00] Agora que já entendemos os serviços que são fornecidos pela Oracle Cloud, vamos começar de fato a configurar a nossa própria Cloud.

[00:10] Uma das primeiras coisas que temos que fazer aqui para colocar o nosso projeto do Doguito Petshop no ar é criar o que chamamos de compartimento. Se viermos aqui em "Identidade e Segurança" vamos ver que tem uma opção de menu chamada "Compartimentos", nessa opção vamos identificar de cara o nosso "doguitopetshop" como compartimento raiz.

[00:37] Esse compartimento podemos subdividi-lo, para ficar mais claro vamos criar. Vamos criar aqui um compartimento, uma divisão, por exemplo, que vamos chamar de "Desenvolvimento", eu vou colocar que esse aqui vai ser o "Ambiente de desenvolvimento do Doguito Petshop".

[01:03] No mínimo aqui eu posso criar o meu ambiente de desenvolvimento onde vamos ter nossos bancos de dados, nossas instâncias para testar, para desenvolver o software. E eu posso também criar aqui mais um compartimento que vai ser o ambiente de produção, vou chamá-lo de "Producao" e aqui vou chamar de "Ambiente de producao do Doguito Petshop" e vou criar um compartimento. Ele não permite colocar caracteres acentuados, eu vou colocar "Producao".

[01:40] Criou o compartimento. Se esperarmos alguns segundos e atualizar a tela vamos ver que foram criados dois compartimentos, compartimento de Desenvolvimento e compartimento de Produção.


-----------------------------------------------------------------------
# 04Para saber mais: compartments à fundo

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105684

Em nossa aula vimos os conceitos mais básicos de compartments, mas existem muitos outros detalhes técnicos que são úteis para casos de uso mais complexos. Este video reúne estas informações detalhadas com uma explicação dos por menores dos compartments (video está em inglês mas possui legendas automáticas em português):

O conteúdo em video pode apresentar alguns tópicos desatualizados, por isso, todos os detalhes sobre a utilização de Compartimentos na OCI podem ser também encontrados na documentação oficial, através dos links [https://docs.oracle.com/pt-br/iaas/Content/Identity/compartments/managingcompartments.htm](https://docs.oracle.com/pt-br/iaas/Content/Identity/compartments/managingcompartments.htm) e [https://docs.oracle.com/es-ww/iaas/Content/Identity/compartments/managingcompartments.htm](https://docs.oracle.com/es-ww/iaas/Content/Identity/compartments/managingcompartments.htm).


-----------------------------------------------------------------------
# 06Usuários

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105663

## Transcrição

[00:00] Agora que já criamos os compartimentos para subdividir a Cloud do Doguito Petshop, é importante criarmos alguns usuários adicionais. Esse usuário adicional vai ter um papel e um conjunto de restrições maiores com relação ao que se pode fazer na nossa Cloud.

[00:22] Quando logamos aqui pela Cloud com o nosso usuário comum, no caso o "tiagolpadua" que está logado aqui, é usuário administrador. Se entrarmos aqui dentro de "Identidade e Segurança" e entrar aqui em "'Visão Geral" e clicar em "Usuários" vamos conseguir ver que esse usuário "tiagolpadua" é o único usuário que temos no nosso compartimento e ele está no grupo "Administradores".

[00:47] Ele é um usuário com poderes ilimitados e isso não é bom, nem mesmo para o nosso computador local. Em geral, não utilizamos um usuário com super poderes, no caso da Cloud segue também o mesmo princípio.

[01:04] Nosso próximo passo é criar um usuário, vamos fazer a criação desse usuário que ele vai ter um limite maior do que ele pode fazer. Clicando em "Criar usuário" podemos entrar aqui e colocar o nome do usuário, vou colocar aqui que é o "Doguito" e o sobrenome "Admin", vou desmarcar a caixa "Usar o endereço de e-mail como o nome do usuário" porque eu vou reutilizar o meu próprio endereço de e-mail para criar esse usuário.

[01:34] Vou criar aqui e o nome do usuário é "doguito-admin" e o e-mail vou colocar o meu e-mail atual "tiagolpadua@outlook.com" e aí vou clicar aqui em "Criar" usuário. Criei aqui o usuário Doguito Admin.

[01:57] O próximo passo é criar um grupo para colocar esse usuário. Vamos criar um grupo e com esse grupo depois vamos criar uma política especial, mas o primeiro passo é criar o grupo. Clicando em "Criar Grupo" vamos dar um nome para esse grupo, vou colocar aqui "Administradores Doguito", vou colocar aqui em "Descrição" vou colocar "Grupo de Administradores do Doguito". Inclusive, já vou aqui até incluir o usuário, no caso aqui o usuário "Doguito Admin". Criei o grupo e coloquei aqui o usuário "Doguito Admin", cliquei em "Criar".

[02:48] Agora estamos com o usuário e estamos com esse grupo, se eu entrar aqui no grupo vamos ver quais são os usuários que pertencem a esse grupo, se eu entrar em "Usuários" eu consigo ver quais são os grupos que esse usuário pertence, agora falta eu criar uma determinada política para esse usuário.

[03:06] Vamos criar uma nova política, entrando em "Identidade e Segurança" e eu seleciono a opção "Políticas". Clico em "Criar Política" e eu vou colocar a política: "politica-doguito-admin". Nessa política eu vou colocar uma descrição: "Politica para os administradores do Doguito", vou selecionar onde eu quero salvar a política, eu vou salvar no compartimento raiz e vou escolher uma política padrão, podemos escolher: "Permitir que usuários gerenciem configurações da instância do serviço Compute".

[03:51] Vamos alterá-la daqui a pouco. Em "Domínio" vamos deixar _Default_ mesmo, em "Grupos" vamos colocar o grupo "Administradores Doguito" e o "Local" vamos selecionar o compartimento de "Desenvolvimento". E aqui ele criou a política, mas vamos selecionar aqui e vamos editar essa política um pouco.

[04:12] Mudando para o editor manual conseguimos alterar essa política, vou colocar "Allow group 'Default/Administradores Doguito' to manage all resource in compartement Desenvolvimento" que é uma política bem mais ampla do que a política original, no nosso caso de exercício vai funcionar. Clico em "Criar" e a política foi criada.

[04:38] Para que possamos testar a política agora temos que entrar como o usuário e para isso vamos ter que acessar o nosso e-mail e ativar o usuário que criamos agora a pouco.

[04:51] Na sua caixa de e-mail você deve ter recebido um e-mail com um _link_ e clicando nesse _link_ você pode abrir em uma aba privada para não misturar com outro usuário seu que já está logado. Ele vai pedir para você ativar a conta do Doguito Admin. A primeira coisa que vamos ter que fazer é definir uma nova senha, vamos definir uma senha. Ele pede uma senha com 12 caracteres, é uma senha bem comprida, não perca essa senha.

[05:27] Redefinindo essa senha ele vai permitir que você continue e navegue aqui para acessar. Vamos acessar com o nosso Doguito Admin e a senha que criamos. Você vai ver aqui no canto superior direito que agora ele está logado com Doguito admin. Vamos dar uma olhada aqui e navegar nos recursos.

[05:56] Por exemplo, se eu quiser criar uma instância de "Compute" que é uma instância de computação e clicar aqui no botão, vamos ver que ele vai estar mais limitado. Vamos ver aqui as instâncias e vamos ter que escolher aqui um compartimento. Note que eu vou ter que escolher aqui "Desenvolvimento", está vendo que não está aparecendo aqui "Produção", está aparecendo só "Desenvolvimento" porque é onde eu tenho acesso. Agora aqui liberou para eu poder criar uma instância.

[06:23] Não vou concluir a criação é só para ver aqui que realmente ele limitou o meu acesso. Se eu voltar para a raiz ele já vai falar que eu não tenho permissão e eu teria que vir aqui só na parte de desenvolvimento.

[06:38] Para a segurança da nossa Cloud é muito importante criar usuários e criar compartimentos e definir as permissões corretas para aqueles usuários naqueles compartimentos.


-----------------------------------------------------------------------
# 07Para saber mais: IAM na OCI

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105701

Quando estamos falando de aplicações corporativas, o controle fino de acesso aos recursos é essencial para que não ocorram incidentes como falhas de segurança em nossa aplicação. Para isso, a OCI desenvolveu um modelo avançado de identidade e controle de acesso, que você pode se aprofundar em mais detalhes assistindo a este video (video está em inglês mas possui legendas automáticas em português):

O conteúdo em video pode apresentar alguns tópicos desatualizados, por isso, todos os detalhes sobre IAM na OCI podem ser também encontrados na documentação oficial, na seção “Segurança, Identidade e Conformidade”, através dos links [https://docs.oracle.com/pt-br/iaas/Content/home.htm](https://docs.oracle.com/pt-br/iaas/Content/home.htm) e [https://docs.oracle.com/es-ww/iaas/Content/home.htm](https://docs.oracle.com/es-ww/iaas/Content/home.htm).

-----------------------------------------------------------------------
# 09Cloud Shell

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105664

## Transcrição

[00:00] Veremos agora como podemos configurar o Cloud Shell para ele ser utilizado por outros usuários além do usuário administrador. A primeira coisa que vamos fazer é tentar acessar o Cloud Shell utilizando o nosso novo usuário, o Doguito Admin.

[00:16] Voltando para a nossa tela inicial da Oracle Cloud, nesse momento eu estou logado com o usuário Tiago Pádua e eu vou fazer o _logout_ e vou tentar fazer o _login_ com o usuário "doguito-admin" e tentar acessar aqui a funcionalidade, neste caso vou tentar acessar o Cloud Shell.

[00:41] Como apareceu aqui essa mensagem _Policy Missing_, "Você não está autorizado a acessar o Cloud Shell, o seu administrador de tenancy deve adicionar uma política para te conceder o acesso". Não adianta ficarmos clicando aqui no _retry_ porque nesse caso o usuário está sem acesso necessário, temos que conceder o acesso.

[01:08] Para fazer isso vamos alterar aquela política que já criamos do Doguito Admin. Novamente vamos voltar para o nosso Oracle Cloud fazer aqui o _logout_ do Doguito Admin, confirmo aqui a saída e vou fazer o _login_ novamente, só que eu vou voltar a logar como usuário administrador, no meu caso "tiagolpadua@outlook.com".

[01:37] Fiz aqui o acesso como usuário administrador e agora eu vou acessar a opção aqui de "Políticas", entro aqui no menu, entro em "Identidade e Segurança" e depois eu entro aqui em "Políticas". Vai listar as políticas atuais e aparece aqui a política do Doguito Admin, posso clicar aqui nessa política, posso editar as declarações de política e vou adicionar uma outra instrução para essa opção.

[02:04] Já deixei salvo aqui a minha política, a política é: "Allow group Default/Administradores Doguito/ to use cloud-shell in tenancy", ou seja, permitir que os usuários do grupo Administradores Doguito usem o Cloud Shell dentro do _tenancy_. Vou salvar as alterações e após isso eu vou fazer o _logout_ como usuário administrador e tentar novamente fazer o _login_ com o usuário doguito-admin.

[02:37] Já deixei o usuário salvo aqui para facilitar e acesso como doguito-admin. Novamente vou tentar acessar o Cloud Shell, vocês perceberão que dessa vez o acesso ao Cloud Shell funciona. O OCI console ou esse Cloud Shell é pré-configurado com uma versão mais atualizada do OCI CLI, que é a linha de comandos de OCI.

[03:03] Uma coisa que podemos fazer com o OCI, com esse Cloud Shell é entrar nas máquinas que vamos criar. Daqui a pouco vamos começar as criar as instâncias para colocar o servidor do Doguito e vamos fazer o _login_. Para fazer esse _login_ utilizamos a ferramenta do SSH e o SSH funciona de uma forma muito segura para fazermos o _login_ de uma máquina na outra, neste caso vamos fazer o _login_ do Cloud Shell aqui com a nossa máquina, com o nosso servidor que vamos criar.

[03:35] Para fazer isso de uma forma segura é necessário criarmos um par de chaves público e privado e é isso que vamos fazer aqui agora. Vamos aqui ao Cloud Shell e eu consigo ver aqui qual é o diretório atual que eu estou, aqui estou no Doguito AD, eu estou aqui em um ambiente Linux, os comandos Linux aqui comuns e o primeiro passo que eu vou fazer é criar uma pasta aqui, eu vou criar uma pasta "mkdir .ssh". Nessa pasta é onde vai ficar armazenada as minhas chaves SSH.

[04:09] Agora eu vou acessar essa pasta "cd .ssh" e aí eu vou executar o comando de geração de chave, esse comando `ssh -keygen -b 2048 -t rsa cloudshellkey` eu vou informar a quantidade de _bytes_ que vai ter essa chave, neste caso o recomendado é 2048, depois eu vou informar qual é o algoritmo criptografo que vou utilizar com a opção "-t", neste caso vou usar o algoritmo "rsa" e aí eu vou colocar aqui qual que é o arquivo que eu quero salvar a minha chave, neste caso vou salvar no arquivo "cloudshellkey".

[04:46] Gerando aqui a chave ele pede uma senha de segurança, no meu caso por simplicidade eu vou deixar vazio e aí gerou a minha chave. Se eu fizer o comando aqui `ls -a` para listar todos os arquivos ele vai listar os arquivos "cloudshellkey pub" e o "cloudshellkey".

[05:06] Esse arquivo "cloudshell pub" é um arquivo público que tem a parte pública da minha chave criptográfica e vamos pegar o conteúdo dele, quando criarmos uma instância do servidor Doguito vamos colar essa chave pública lá para que consigamos acessar essa instância a partir do Cloud Shell com segurança.

[05:30] Dessa forma tivemos uma visão geral do Cloud Shell e estamos vendo que não precisa instalar ferramentas locais na sua máquina para trabalhar com Oracle Cloud. Só com o Cloud Shell e a interface Web ele já vai nos fornecer todas as ferramentas necessárias para operarmos com segurança aqui a Cloud da Oracle. Muito obrigado e até a nossa próxima aula.

-----------------------------------------------------------------------
# 12O que aprendemos?

## Nessa aula, você aprendeu:

- A arquitetura da OCI é composta por uma série de elementos, como as instâncias de Computação, Armazenamento, Rede, Bancos de Dados, Políticas de Identidade e Segurança, entre outros. Eles contribuem para construir um ambiente coeso de cloud;
- Criamos usuários, grupos e políticas na OCI para controlar o acesso às funcionalidades;
- Como usar alguns comandos básicos do Cloud Shell e gerar uma chave RSA que nos permite efetuar uma conexão segura com as instâncias de compute que serão criadas na sequência.


-----------------------------------------------------------------------
# 01Introdução à Virtual Cloud Network - VCN

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105665

## Transcrição

[00:00] A partir de agora, entenderemos como funcionam as redes dentro da Oracle Cloud. É importe sabermos como elas funcionam porque são necessárias para instanciarmos o nosso servidor.

[00:15] As redes dentro da Oracle Cloud são chamadas de VCNs, _Virtual Cloud Network_. O primeiro item que temos que fazer é entender o que é a _Virtual Cloud Network_. Essa rede é uma rede privada criada por software e é utilizada para fazer uma comunicação segura, por isso é uma rede definida por software não é uma rede física com placas de rede, é uma rede, digamos, virtual, como o próprio nome diz.

[00:45] Essa rede é utilizada para que as instâncias se comuniquem entre si, entre os ambientes e entre as regiões e também para que as instâncias consigam comunicar-se até mesmo com a internet. Essa rede virtual vai residir em uma região, em uma _region_, ela é definida como um serviço regional. Essa VCN é via software, mas ela possui alta disponibilidade, é altamente escalável e altamente segura também.

![Diagrama de Virtual Cloud Network (VCN). À esquerda, há uma área quadrada grande denominada VCN, que possui um IP X.X.X.X/X. Dentro dela, há duas *subnets*, uma pública e outra privada, cada uma com um IP X.X.X.X/X. À direita, há dois elementos: internet e Oracle Services Network. Ligando a área VCN à internet, há duas setas — uma bidirecional denominada IG (internet gateway) e outra da esquerda para direita denominada NAT (NAT gateway). Ligando a área VCN à Oracle Services Network há uma seta, da esquerda para direita, denominada SG (Service Gateway).](https://cdn3.gnarususercontent.com.br/2486-oci-1/Transcri%C3%A7%C3%A3o/Aula+04/Imagens/OCI.png)

[01:17] Antes de nos aprofundarmos em alguns detalhes da VCN, vamos entender alguns básicos que estão envolvidos. O primeiro conceito que VCN possui é um espaço de endereçamento que é definido utilizando uma anotação, essa é uma anotação CIDR. A rede é definida aqui com essa faixa aqui de endereço, vamos definir uma faixa de endereço para ela.

[01:46] Para esse nosso caso que é básico não vamos precisar mexer em nenhuma configuração adicional, mas é interessante sabermos que temos essa faixa de endereço da VCN e dentro dessa VCN vão sendo criadas algumas sub-redes, como essas sub-redes aqui dentro da VCN, e essas sub-redes vão estar dentro de um espaço de endereçamento definido aqui por esse endereço principal.

[02:12] É justamente nessas sub-redes, nessas _Public Subnet_ que vamos instanciar as nossas máquinas, isso vai definir o próprio IP da máquina e vai definir também que tipo de serviço que essa máquina vai conseguir acessar. Dependendo da sub-rede que utilizarmos para instanciar a máquina ela vai assumir um IP dessa faixa dessa sub-rede.

[02:36] Agora falando sobre comunicação, existem diversos mecanismos dentro de uma VCN para realizar comunicação. A primeira noção que temos que entender é a noção do chamado _internet gateway_, esse IG aqui, esse IG que é o _internet gateway_. Ele é utilizado para a comunicação de qualquer coisa, qualquer elemento que temos dentro dessa sub-rede para ele se comunicar com a internet é necessário que ele passe por esse _internet gateway_.

[03:06] Por exemplo, se tivemos uma servidor web e queremos que ele se comunique com outros servidores, com outros web sites vamos utilizar, vamos atravessar a comunicação por esse _internet gateway_. Ou seja, estamos definindo isso para a comunicação que chamamos de bidirecional. Se você olhar aqui a seta é uma seta que tem a ponta saindo e tem a ponta entrando aqui do _internet gateway_. Esse é o primeiro elemento de roteamento que temos.

[03:35] Outro componente que temos é o chamado de _NAT gateway_, que é esse elemento aqui, esse _NAT gateway_ aqui. Ele é utilizado para prover NAT como serviço e significa que ele permite tráfego somente unidirecional. Olha como é a seta dele, o tráfego dele é unidirecional, ele só sai aqui e vai para a internet. Ele permite que haja tráfego, mas entre a sua instância e a internet, porém a internet não consegue acessar essa instância, ele é tráfego para um lado só.

[04:13] O último dos roteadores que temos aqui é o chamado _service gateway_, esse SG aqui. O objetivo dele é permitir que recursos de uma VCN acessassem os serviços da OCI como, por exemplo, armazenamento de objetos, mas sem usar a internet ou _nat gateway_. A própria OCI fornece vários serviços de rede, _Oracle Services Network_, mas não vamos fazer essa comunicação com os serviços da _Oracle Services Network_ nem através de NAT e nem do _internet gateway_, vamos fazer através do _services gateway_.

[04:49] Esses são os três principais cenários de acesso externo que temos, acesso: o _internet gateway_ para tráfego direcional por internet, o _nat gatway_ para tráfego unidirecional, somente na direção da sua instância para a internet,e o _service gateway_ para comunicação com os serviços da própria OCI.


-----------------------------------------------------------------------
# 02Criando a VCN

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105666

## Transcrição

[00:00] Nosso próximo passo é a criação da VCN para que possamos levantar as nossas instâncias do Doguito Petshop. Para isso vamos entrar novamente no console do OCI e devemos está logado como "doguito-admin". Para conferir você pode clicar no "Profile" e você vai verificar que está logado como o "doguito-admin".

[00:23] Esse usuário já configuramos antes e demos todos os acessos necessários para ele naquele compartimento do desenvolvimento, é nesse compartimento que vamos criar a nossa VCN. O próximo passo que vamos realizar é entrar no menu, vamos clicar na opção de "Networking" de rede e vamos notar que existem diversas opções distintas, gerenciamento de IP, de DNS, conectividade de clientes, entre outras.

[00:51] Vamos acessar o "Virtual Cloud Networks". Acessando essa opção você vai ver que permite que possamos criar aqui manualmente o _Create VCN_ ou utilizar aqui um _Wizard_ que vai facilitar para nós. Vamos clicar aqui "Start VCN Wizard" para utilizar o _Wizard_.

[01:13] Clicando aqui para utilizar o _Wizard_ ele vai nos mostrar essa tela com essa imagem que define todas as características dessa conectividade que vamos criar, dessa VCN que vamos criar. Essa VCN tem acesso à internet, tem um _internet gateway_ que vai permitir acesso bidirecional entre a internet e os meus _hosts_ que estiverem nessa _subnet_ pública, ele tem acesso também NAT, tem acesso via _service gatway_ para os serviços da Oracle também.

[01:47] Essa segunda opção que temos aqui continua tendo acesso à internet, mas ela inclui também outro serviço que é o chamado "Site-to-Site" VPN. Em geral, é para casos de usos mais avançados onde o usuário, a empresa ela vai ter o ambiente _on-promise_ e quer fazer a conectividade com esse ambiente.

[02:07] No nosso caso do Doguito Petshop é um caso bastante simples e podemos utilizar a primeira opção mesmo. Selecionamos aqui a primeira opção e clica em "Start VCN Wizard" e vamos ser direcionados aqui para essa tela. Nessa tela vamos dar um nome aqui para a nossa VCN, vamos chamá-la de "VCN1", de forma bem simples.

[02:31] Ele pergunta qual é o compartimento que queremos salvar, queremos o compartimento do Desenvolvimento, onde o nosso usuário tem acesso. Depois ele vem aqui e fala sobre uma configuração da VCN e das sub-redes, aqui ele nos indica um bloco CIDR. Esse bloco aqui vamos deixar dessa mesma forma que está, a forma padrão, e ele já indica aqui duas sub-redes, uma chamada de sub-rede pública e outra como a sub-rede privada.

[03:04] Ele tem também aqui uma formatação de um bloco CIDR também. O importante é que não haja sobreposição entre esse bloco e esse bloco aqui, essa definição da sub-rede dessa definição aqui. Nesse caso vamos deixar do jeito _default_ que já está configurado corretamente.

[03:25] É importante saber também que quando criarmos uma instância e a instância for colocada em uma _subnet_ pública essa instância vai poder se comunicar com a internet de forma bidirecional. Quando colocarmos uma instância na _subnet_ privada essa instância não vai receber um IP público, o único meio de essa instância comunicar-se com a internet vai ser utilizando o que chamamos de _NAT gateway_ ou ela também pode se comunicar com serviços da Oracle pelo _service gatway_.

[03:55] Agora podemos clicar aqui na opção "Next" e ele vai permitir uma tela que possamos rever todo o conteúdo. Ele vai falar aqui o nome da VCN que está sendo criada, em qual compartimento, qual que é o bloco CIDR dela, o _label_ que ela vai ter, quais são as _subnets_ que estão sendo criadas. Está sendo criada aqui uma _subnet_ pública, está sendo criada aqui também uma _subnet_ privada, ele vai falar qual é o bloco CIDR dessas duas sub-redes.

[04:26] Além disso, ele vai falar para nós quais são _gateways_ que estão sendo criados. Eu tenho três _gateways_, eu tenho o _internet gateway_, eu tenho o NAT _gateway_ e eu tenho _service gateway_. Estão aqui e ele aponta aqui para qual das _subnets_ que está utilizando cada um desses _gateways_.

[04:44] Por fim, ele vai trazer aqui informações de segurança, _Security Lists_, para as regras da minha primeira sub-rede e aqui as regras para a sub-rede privada também serão exibidas aqui. E por fim, ele fala aqui também as tabelas de roteamento que tem aqui, nesse caso ele vai direcionar esse bloco aqui, dá esse IP, vai para o _internet gateway_. Nesse outro aqui vai para o NAT _gateway_ também para fazer a comunicação com o ambiente externo.

[05:14] Estando satisfeitos com essas opções, podemos clicar aqui no botão "Create" e a nossa sub-rede, a nossa VCN vai ser criada depois de alguns segundos. Esperamos um pouco, ele vai atualizando a tela com as informações e podemos clicar aqui em "View Virtual Cloud Network" e temos aqui as informações dessa nossa rede virtual.

[05:40] Novamente, aquelas mesmas informações que utilizamos para fazer a criação vão estar aqui disponíveis para que possamos detalhar, caso seja nosso desejo.


-----------------------------------------------------------------------
# 04Roteamento e seguranç

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105667

## Transcrição

[00:00] Agora que criamos a nossa VCN, precisamos entender o básico de dois assuntos muito importantes, que é a questão de roteamento e a questão de segurança.

[00:09] Existe um conceito chamado Tabela de Roteamento, que conseguimos acessar através do console da OCI. Na nossa lista de VCNs, podemos clicar em VCN1 e, depois, nessa opção "Route Tables", para ver as tabelas de roteamento.

[00:27] Vemos que foram criadas duas tabelas de roteamento. A VCN vai utilizar essas tabelas de roteamento para enviar um tráfego para internet, alguma rede _on premise_, entre outras opções. Clicando nessa primeira tabela "Route Table for Private Subnet VCN1", vamos ver os detalhes criados.

[00:51] Temos o "Destination" e o "Target". O _destination_ é definido através dessa máscara de IP que tem esse código CDIR, se for para 0.0.0.0/0, ele vai para o _NAT Gateway_. Se você lembrar, o _NAT Gateway_ é aquele _gateway_ que permite o tráfego de saída para a internet, mas não permite o tráfego de entrada.

[01:17] Outro ponto também importante sabermos é que o tráfego entre duas sub-redes da VCN vai ser automaticamente gerenciado pelo próprio roteador local da VCN. Estamos vendo que essa tabela tem esse primeiro destino o 0.0.0.0/0 e o segundo destino com _All GRU Services in Oracle Services Network_, esse destino aqui.

[01:38] Quando um novo tráfego é gerado a VCN vai olhar para essa tabela de rotas e a rota que for mais específica vai ter prioridade, porque essa rota 0.0.0.0/0 é uma rota extremamente genérica, ou seja, qualquer endereço vai dar _match_ com essa rota aqui.

[01:57] O que vai acontecer é, se tentarmos acessar algum tipo de serviço da Oracle _services network_, que vamos tentar acessá-lo por um determinado IP, ele vai dar _match_ com esse destino aqui e ele vai para esse _gateway_ específico aqui que é o _gateway_ de serviços.

[02:14] Qualquer outro endereço vai bater aqui no _NAT Gateway_ e ele vai para internet, para algum endereço externo. Se voltarmos na nossa lista de tabelas, podemos dar uma olhada nessa segunda tabela, que é "Default Route Table for VCN1", e veremos que ela é um pouco diferente — ela tem 0.0.0.0/0, dando um _match_ com tudo 0, e ele vai mandar para _Internet Gateway_. Ou seja, esse tráfego vai para a internet.

[02:41] Quando olhamos aqui, percebemos que esse aqui não tem o roteamento para os serviços da Oracle. Ou seja, somente aquela primeira _Route Table for Private Subnet VCN1_ tem acesso aos serviços da Oracle Network.

[02:56] Voltando para a lista de VCNs, nessa lista anterior que vai mostrar a lista das VCNs, posso clicar na "Public Subnet VCN1" e eu vejo aqui qual que é a tabela de roteamento que está associada para ela. A "Public Subnet-VC1" que é aquela que consegue ter acesso à internet e a internet consegue acessar essa rede, ela está aqui com essa tabela de roteamento "Default Route Table for VCN1" que é justamente aquela que tem acesso ao _internet gateway_.

[03:27] Se olharmos aqui para a nossa segunda _subnet_, "Private Subnet", vamos ver que ela tem a tabela associada a "Route Table for Private Subnet-VCN1". Essa _subnet_ vai ter acesso aos serviços da Oracle e vai ter acesso à internet somente através do _NAT Gateway_ que não vai permitir a comunicação de tráfego oriundo da internet para atingi-la aqui.

[03:51] Outro ponto também que temos que é muito importante é com relação a parte de segurança, esse _Security Lists_ aqui. Ele vai funcionar de uma forma uma pouco parecida, em uma VCN temos esse conceito de _Security Lists_ e elas vão funcionar como regras de _firewall_, que vão estar associada a uma sub-rede e aplicadas a todas as instâncias dentro dessa sub-rede.

[04:23] O _firewall_ é um mecanismo que temos para barrar a comunicação em geral para impedirmos comunicação que seja indevida ou comunicação errada. Se lembrarmos, a tabela de roteamento também faz isso, bloqueia algumas comunicações e determina algumas comunicações, mas ela não tem um foco em segurança e ela também não determina as portas que podem comunicar-se. A lista de segurança tem o objetivo um pouco diferente.

[04:53] Se entrarmos aqui e detalhar essa primeira lista de segurança, vamos ver que ela também consiste em uma lista de regras que determinam o que pode entrar e o que pode sair da sub rede. Isso se aplica a qualquer instância que estiver conversando uma com a outra dentro da VCN ou outra máquina fora da VCN.

[05:14] Essas regras podem ser como _Stateful_ e _Stateless_, aqui, como estamos vendo, ela é NO por isso ela não é _stateless_ vai ser _stateful_ e ela dividida também entre regras de _Ingress_ e regras de _Egress_. O _ingress_ são as regras para entrada e o _egress_ são as regras de saída. Quando uma regra é de _stateful_ que dizer que se um tráfego é permitido entrar por uma determinar porta, ele também vai poder sair por essa determinada porta.

[05:46] Aqui conseguimos ver que tem as regras de entrada e saída, nas regras de entrada eu tenho que todos aqui vão ser _Stateless No_. Por exemplo, vamos dar uma olhada nessa primeira regra "Security List for Private Subnet-VCN1", perceba que ele está permitindo a entrada da comunicação a partir dos IPs na faixa 10.0.0.0/16, que é da própria rede interna. E a regra de saída dele é para o destino 0.0.0.0.0, ele está permitindo tráfego para todas as portas.

[06:23] Se voltarmos ao "Security List Details" e eu vir aqui na VCN1, eu venho no "Security Lists" e eu vou olhar "Default Security List for VCN1" que é a regra para VCN1 e aqui podemos ver que ela é um pouco diferente, veja que o tráfego de origem vai permitir dar 0.0.0.0/0, ou seja, de qualquer endereço ele está permitindo que atinja a porta 22. Essa aqui como regra de entrada e essa aqui como regra de saída.

[06:57] Voltando ao "Security Lists" eu volto aqui para a minha VCN1 e eu consigo ver nas minhas sub-redes, se eu clicar na sub-rede que é a pública, conseguimos ver qualquer que é até a _security lists_ que está associada a ela aqui também. Aqui eu consigo ver qual é a tabela de roteamento e aqui eu vejo qual é a _security list_. Sabe-se que _security lists_ eu posso utilizar múltiplas listas de segurança para esse caso aqui. Vou voltar só para vermos a dois e também tem aqui a lista de segurança associada e a tabela de roteamento.

[07:37] Essas duas caracterísiticas vão ser muito importantes na hora que levantarmos o nosso servidor do Doguito para conseguir justamente liberar a comunicação via porta HTTP da internet, via o nosso servidor web com a internet e para que o Doguito Petshop possa ser acessado.


-----------------------------------------------------------------------
# 05Para saber mais: redes na OCI

Quando falamos de infraestrutura em Cloud, uma de nossas primeiras tarefas é estruturar uma rede. Em geral estas redes são conhecidas como redes virtuais pois são definidas via software ao invés de dispositivos físicos de hardware. Estas redes virtuais possuem diversos conceitos elaborados que você pode se aprofundar assistindo aos videos [desta playlist](https://www.youtube.com/playlist?list=PLvlciYga5j3z7biGjV7-fywS-xEJ3W6Pp) (video está em inglês mas possui legendas automáticas em português).

O conteúdo em video pode apresentar alguns tópicos desatualizados, por isso, todos os detalhes sobre a utilização de Redes na OCI podem ser também encontrados na documentação oficial, através dos links [https://docs.oracle.com/pt-br/iaas/Content/Network/Concepts/landing.htm#top](https://docs.oracle.com/pt-br/iaas/Content/Network/Concepts/landing.htm#top) e [https://docs.oracle.com/es-ww/iaas/Content/Network/Concepts/landing.htm#top](https://docs.oracle.com/es-ww/iaas/Content/Network/Concepts/landing.htm#top).


-----------------------------------------------------------------------
# 07O que aprendemos?

- s VCNs - Redes Virtuais em Nuvem - controlam a comunicação dos componentes da Cloud com a internet e com os serviços da Oracle através de sub-redes virtuais que possuem suas próprias tabelas de roteamento, listas de segurança e gateways;
- Criamos uma VCN com uma sub-rede pública e outra privada na OCI utilizando o Wizard em poucos passos;
- Como é definido o roteamento e a segurança nas VCNs e como estes atributos irão restringir e tornar segura a comunicação das instâncias que criaremos para nossa aplicação.


-----------------------------------------------------------------------
# 01Criando um Compute

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105668

## Transcrição

[00:00] Chegou a hora de criarmos de fato o nosso servidor do Doguito Petshop. Para isso precisamos criar aqui uma entidade dentro da OCI chamada _Compute_, esse serviço de _Compute_ pode nos prover das máquinas virtuais ou servidores que chamamos de _bare metal_ para atender os requisitos da nossa aplicação.

[00:21] Os _computes_ da OCI são muito escaláveis, tem alta performance e um custo bem baixo. A forma ou o _shape_, que eles chamam, do _compute_ é bastante flexível e significa que podemos escolher quantos núcleos de CPU desejamos e quanto de memória que queremos disponibilizar para a máquina.

[00:40] Além disso, a OCI permite que você escolha até mesmo o tipo de processador que o seu _compute_ vai utilizar. Por exemplo, pode ser AMD, Intel, ARM, tem vários tipos de processadores disponíveis. Uma vez definida a forma do _compute_ podemos criar a instância dele.

[00:57] Vamos começar. A partir da tela inicial da Oracle Cloud, podemos clicar aqui no menu e ir na opção de "Compute", segunda opção do menu. Em _compute_ podemos clicar em "Instances" para ver as nossas instâncias, vamos clicar em "Create instance", lembrando que você deve estar logado com o usuário "doguito-admin".

[01:26] A primeira coisa que vamos ver aqui na instância é o nome dela, vamos dar um nome para ela. Eu vou dar o nome de "dps-vm1", a máquina virtual 1, Doguito Petshop VM1. O segundo ponto que temos que escolher aqui é em qual compartimento que desejamos criar, no caso o nosso usuário tem acesso ao compartimento de "Desenvolvimento", ele até apareceu por _default_ e já vamos deixá-lo preenchido aqui.

[01:59] Uma instância vai residir em uma região, essa região é composta de diversas _availlabillity domain_ ou domínios de disponibilidade. Aqui nessa opção do _Placement_ ele já deixa por _default_ a _availlabillity domain_ que tem aqui que no caso é AD1, o _Fault domain_ que vamos colocar vai ser por _default_, tem a opção de editar, mas vamos manter os valores _default_.

[02:30] Cada instância que vamos executar tem um sistema operacional e outros softwares que vão ficar armazenados nesse disco de _boot_, tem um disco de _boot_ que vai ser definido. Esse sistema operacional que é definido pela imagem vamos escolhê-lo para fazer o _boot_ da nossa instância.

[02:47] Esse disco de _boot_ é um disco virtual de rede, ele não fica diretamente no _host_ da instância. Além disso, você tem um disco de dados que vai armazenar os arquivos e o _firewall system_ ele também vai ficar em _driver_ de rede. Esse disco de sistema operacional e o disco de dados formam em conjunto o que chamamos de volume de bloco. A imagem e a forma já foram escolhidas por padrão, mas podemos clicar aqui em "Editar".

[03:16] Vindo aqui na opção do "Image and shape" eu posso clicar aqui na opção de editar e poderíamos escolher para ver as outras opções. Temos aqui o sistema operacional desse _image_, é o sistema operacional que eu falei e é o sistema operacional que ele vai dá o _boot_ na instância.

[03:37] Se clicarmos em "Change image" vamos ver que tem algumas opções aqui eu posso escolher, inclusive, as imagens da plataforma, imagens da Oracle, imagens de associados ou até mesmo criar, no caso da empresa, criar a sua própria imagem.

[03:58] Em nosso caso vamos com a opção padrão que é "Oracle Linux", veja que ele também já está com _Always Free-elegible_, ou seja, é uma opção que sempre vai está no pacote de sempre livre. Aqui ele fala qual vai ser o sistema operacional, vamos deixar tudo como _default_ mesmo. Vou clicar em "Cancelar" porque não fez nenhuma alteração.

[04:21] Agora a nossa opção que temos aqui do _shape_, se clicarmos em "Change shape" veja que temos aqui várias opções onde eu poderia escolher, no caso, _Bare metal machine_ que é um servidor físico dedicado, mas no nosso caso vamos utilizar a máquina virtual, _virtual machine_ mesmo, veja que ela também está no pacote _Always Free_. Como o nosso caso é muito simples vamos manter no _virtual machine_.

[04:52] Podemos ver agora as opções de processador que temos, como eu tinha comentado, AMD, Intel, ARM, entre outras opções. Vamos deixar também aqui no padrão e esse padrão vai permitir que o cliente utilizasse essa instância mesmo após ao final do período de teste.

[05:14] Aqui deixamos no valor padrão, vamos deixar aqui nessa máquina _Standard_ e podemos deixar aqui no _Select shape_ mesmo que vai ficar a mesma opção anterior. Mais abaixo um pouco vamos ver a opção que temos de rede, eu tenho aqui _Networking_. Veja que por padrão ele já selecionou aqui a nossa VCN1, a VCN1 que tínhamos criado na aula anterior.

[05:40] Temos que prestar atenção aqui também em qual sub-rede que queremos colocar, no caso vou deixar uma sub-rede já existente e vamos escolher aqui a sub-rede pública. É importante colocar que a sub-rede é pública, pois a nossa máquina vai ser acessível a partir da internet. Essa sub-rede pública vai permitir também que tenhamos aqui um IP público, ou seja, é um endereço de IP que vai estar visível para fora também da instância.

[06:09] Além disso, nós também vamos receber um IP privado. Dependendo do caso poderíamos manter só IP privado sem definir o IP público, se fosse um servidor de banco de dados, alguma coisa assim vai depender do caso de uso ali. Para definir a instância, para levantarmos a instância sempre é necessário escolhermos a opção da sub-rede.

[06:31] Mais abaixo um pouco vamos ver que tem a opção para adicionar a chave SSH, ele fala aqui que você pode gerar um par de chave pública e privada, fazer _upload_ ou colar aqui uma chave pública. Se você lembrar de uma aula anterior que já fizemos nós realmente já criamos uma chave pública. Vamos acessar aqui o nosso console novamente, o nosso Cloud Shell, esperar ele instanciar a nossa instância pelo Cloud Shell, vai instanciar no usuário _home_.

[07:15] Após conectar no Clud Shell podemos acessar novamente aquela pasta `cd .ssh` que já tínhamos criado anteriormente, listar os arquivos e agora podemos dar aqui um `cat` para ver o conteúdo do arquivo `cat cloudshellkey.pub`. Podemos pegar o conteúdo dessa chave pública e colocar no campo adequado. Eu vou selecionar aqui o valor da chave pública, posso vir aqui com o botão direito, copiar e vou voltar na opção e vou colar a chave pública aqui.

[07:58] Temos aqui mais algumas opções abaixo como volume de _boot_ e algumas opções avançadas que nesse momento não precisamos nos preocupar porque o nosso caso de uso é muito simples. Podemos deixar tudo com o valor padrão. Agora podemos clicar aqui no botão "Create" e ele vai fazer a criação dessa instância.

[08:19] Note que durante a criação ele vai deixar essa letra I aqui na cor alaranjada indicando que ele está no processo de criação, ele está provisionando a máquina para nós, isso vai demorar alguns segundos. Nesse meio tempo podemos dar uma olhada em algumas informações interessantes como, por exemplo, o IP público que já foi criado. Está aqui o endereço de IP público que foi criado, aqui temos o endereço do IP privado e algumas outras informações sobre a nossa placa de rede virtual.

[08:52] Outra informação aqui também muito importante é o nome do usuário, aqui usuário OPC, que é o usuário que vamos utilizar para fazer o _login_. Note também que já foi escolhido aqui um _fault domain_ que neste caso foi escolhido aleatoriamente o _fault domain_ número 3 que é uma subdivisão que tem dentro do domínio de disponibilidade.

[09:14] Com isso agora podemos logar nessa máquina, lembre-se: a instância do Cloud Shell é uma instância só para você utilizá-la como ferramenta para acessar as outras instâncias reais. Agora já criamos uma instância real, note que está a letra I com a cor verde e a máquina está rodando, _running_. Vamos tentar acessar essa máquina.

[09:38] Vamos acessar essa máquina através do comando SSH, posso clicar aqui no comando _copy_ do _Public IP address_ para copiar o endereço de IP e vou tentar acessar via SSH. `ssh` aí eu vou colocar aqui o usuário, no caso o usuário `opc@`, vou colar aqui o endereço de IP público (você deve colocar o IP público da sua instância) e vou colocar aqui o arquivo, vou indicar qual é o arquivo de chave privado e vou colocar aqui o arquivo `cloudshellkey`. No meu caso, ficará assim: `ssh opc@132.226.245.137 -i cloudshellkey`.

[10:12] Agora vou dar um "Enter", ele vai pedir aqui uma confirmação, aceitei a confirmação e de fato, estou logado na máquina virtual, agora estou logado nessa máquina aqui. Essa linha de comando refere-se a essa instância.

[10:28] Uma vez que já estamos logado na máquina, para testarmos realmente se ela está funcionando, se ela está acessando internet podemos tentar pingar um site público, por exemplo, eu posso dar aqui um comando de `ping` e colocar aqui `ping www.google.com`, fez aqui o `ping`, conseguiu atingir a máquina da Google.

[10:54] Podemos aqui cancelar e com isso conseguimos criar essa instância, instanciamos um serviço de _compute_ dentro da OCI.


-----------------------------------------------------------------------
# 03Para saber mais: tudo sobre computes

Como já aprendemos, computes representam as instâncias que de fato vão servir nossas aplicações na cloud. Existem muitas opções para se escolher, que equilibram questões de custo e performance.

Se você se interessou pelo assunto e quer saber todos os detalhes da configuração de computes na OCI, não deixe de ver [esta playlist](https://www.youtube.com/playlist?list=PLKCk3OyNwIzsAjIaUaVsKdXcfBOy6LASv) que fala tudo sobre computes na OCI.

O conteúdo em video pode apresentar alguns tópicos desatualizados, por isso, todos os detalhes sobre Computes na OCI podem ser também encontrados na documentação oficial, na seção “Computes”, através dos links [https://docs.oracle.com/pt-br/iaas/Content/home.htm](https://docs.oracle.com/pt-br/iaas/Content/home.htm) e [https://docs.oracle.com/es-ww/iaas/Content/home.htm](https://docs.oracle.com/es-ww/iaas/Content/home.htm).


-----------------------------------------------------------------------
# 04Configurando um servidor

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105669

## Transcrição

[00:00] Agora que temos a nossa instância criada, nossa _compute_, ainda temos alguns preparativos para serem feitos antes de executar de fato o Doguito Petshop. A primeira coisa que precisamos fazer nessa instância que criamos é realizar a instalação de um servidor HTTP.

[00:19] Como, por exemplo, temos o Apache, esse servidor HTTP é o que vai servir as páginas web do Doguito. Para isso, podemos utilizar o próprio Cloud Shell, fazendo a conexão via SSH com a nossa instância. Podemos executar aqui alguns comandos de instalação.

[00:39] Depois de fazer o _login_ via SSH podemos fazer aqui o comando `sudo yum -y install httpd`. No caso o comando `sudo` é para executar com _root_, vamos executar a porta do comando como _root_, o `yum` é um instalador que temos aqui no Oracle Linux disponível, é instalador de pacotes aqui do Oracle Linux, `-y` é para realizar as confirmações automaticamente, se for pedir alguma confirmação, principalmente de uma dependência adicional. `install` é o comando de instalação e `httpd` é o programa que queremos instalar, no caso `httpd` é o Apache Web Server.

[01:27] Teclando aqui "Enter" ele vai fazer o processo de instalação desse pacote. Concluída a instalação do pacote `httpd` que é o servidor da Apache, o nosso próximo passo é abrir uma porta do _firewall_. O _firewall_ já vem instalado no próprio sistema operacional, no caso do Oracle Linux, não confundir com o próprio _firewall_ que estamos definindo na VCN. O nosso próximo passo é fazer a liberação dessa porta de _firewall_ do Oracle Linux.

[02:00] Para isso podemos executar aqui um comando de `sudo firewall -cmd --permanent --add -port-80/tcp`. Ou seja, estamos executando aqui o comando `sudo firewall`, vamos operar aqui sobre o _firewall_, essa alteração é classificada como permanente e eu vou adicionar a porta 80 no tcp, ele vai permitir comunicação com a porta 80. Damos aqui o comando "Enter", ele vai proceder a essa alteração e agora precisamos recarregar o sistema do _firewall_ para que isso funcione.

[02:56] `sudo firewall -cmd --reload`, fazendo aqui o comando do _reload_ ele vai recarregar, vai liberar o _firewall_. O próximo passo temos que "startar" ou iniciar o servidor do Apache e para isso fazemos aqui o comando `sudo systemctl start httpd`. Esses comandos podem variar de acordo com a versão do Linux que você estiver utilizando ou do sistema operacional que você estiver utilizando podem alterar um pouco, depende da configuração do sistema operacional.

[03:38] A próxima coisa que precisamos fazer é o seguinte: colocar algum conteúdo em uma página HTML padrão para que consigamos acessar pelo navegador. Isso vai fazer pelo comando `sudo su`, aqui estou trocando de usuário para usuário _root_, perceba aqui que no console alterou de opc para _root_, aqui o nome do usuário e agora eu vou fazer aqui um comando `echo`. O comando `echo` basicamente vai ecoar esse texto que vamos colocar.

[04:10] Vamos colocar aqui: `echo "Doguito Petshop Server 1" >> /var/www/html/index.html`. Os dois símbolos de maior significam que é para concatenar, se já houver o arquivo, para adicionar o final do arquivo. E esse arquivo é o arquivo raiz do servidor, `/var/www/html/index.html`. Aqui estamos complementando esse arquivo `index.html` com esse conteúdo `Doguito Petshop Server 1`.

[04:54] Entro aqui, à priori, pelo que já imaginamos, já deveria estar funcionando. Vamos tentar acessar pelo navegador essa máquina, pelo aqui esse IP público, vou abrir outra aba do navegador e vou colocar aqui o endereço. Note que não está acontecendo nada, ele está rodando, rodando aqui e não vai para lugar nenhum.

[05:21] Aqui podemos fazer uma alteração, vamos ter que lembrar um ponto importante que é a nossa VNC. A nossa VCN precisa estar configurada para permitir esse acesso da máquina. Vamos abrir novamente a nossa VCN, podemos clicar aqui diretamente na rede para detalhá-la e temos uma característica aqui importante da VCN que é a parte de segurança da nossa _Security Lists_.

[06:00] Clicou aqui no "Security Lists" e clicamos aqui nessa lista de segurança e vamos ver que ele está liberando aqui a porta 22. No tráfego de entrada, _ingress_, existem três regras: uma regra para ICMP, no caso aqui o ICMP aqui é para o próprio protocolo a TCP e temos aqui a porta 22, estamos liberando aqui só a porta 22.

[06:32] O que eu preciso fazer aqui é adicionar uma nova regra de _ingress_, vamos colocar aqui a nossa nova regra para permitir a comunicação TCP na por 80. Vou colocar aqui _Add Ingress Port Rules_ e vou definir aqui qual é o tipo de origem, o tipo de origem aqui no caso eu vou defini-lo com CIDR e vou colocar aqui a faixa de IP de origem. Nesse caso vamos colocar a faixa de IP de origem mais ampla que é 0.0.0.0/0.

[07:07] O tipo de protocolo que eu vou trabalhar é TCP, a porta de origem podemos deixar _All_, a porta de destino vai ser a porta 80. Eu poderia colocar uma descrição, mas por simplicidade vou deixar só dessa forma aqui, clico em "Add Ingress Rules". Coloquei aqui essa forma, vou voltar na minha máquina, voltar no meu "Compute > Instances", vou pegar aqui a minha instância, vou copiar aqui novamente o IP público dela, vou abrir uma nova aba no navegador e colocar aqui o IP.

[07:55] Perceba que agora conseguimos acessar aquele conteúdo que tínhamos feito o `echo`, uma página HTML muito básica, realmente só com um texto corrido, mas aqui já estamos conseguindo. Ou seja, a partir da internet, posso colocar aqui o IP público que conseguimos aqui no OCI e consigo acessar aqui um conteúdo lá do meu servidor, o conteúdo que colocamos para servir.

[08:23] Com isso temos um servidor HTTP plenamente configurado e ele pode receber de fato as páginas do Doguito.


-----------------------------------------------------------------------
# 07Balanceador de carga

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105670

## Transcrição

[00:00] Já conseguimos subir uma instância de um servidor que vai hospedar o nosso Doguito Petshot. A nossa esperança é que a aplicação seja um sucesso absoluto e suspeitamos que durante o lançamento dessa aplicação vai ter um grande número de acessos e esse número de acessos pode não ser suportado para uma única instância de nosso servidor.

[00:24] Para evitar esse problema, podemos utilizar um componente da OCI chamado de _load balancer_. O _load balancer_ nos permite ter uma alta disponibilidade e também escalabilidade na nossa aplicação. Ou seja, ela não vai cair e ela pode suportar um grande número de acessos simultâneos.

[00:44] Um _load balancer_, às vezes, também é chamado de um _proxy reverse_ e a forma como ele funciona é que ele fica entre o internet _gateway_ e as múltiplas instâncias da nossa aplicação.

[00:56] Vamos ver aqui no menu da OCI que ele vai nos trazer um exemplo dele. Venho aqui em "Load Balancers" e se eu clicar aqui em "Create Load Balancer" ele já nos apresenta esta figura aqui.

[01:08] Vamos entender como ele funciona. O _load balancer_ que este componente aqui ele vai distribuir a carga de requisições entre as instâncias, quando eu tenho aqui múltiplas instâncias, digamos aqui, do nosso servidor esse _load balancer_ que fica aqui no meio vai distribuir a carga.

[01:34] Mesmo que um servidor fique fora do ar, por exemplo, vamos dizer que algum desses servidores aqui fique fora do ar, vamos dizer que eles sejam clones um do outro e um fica do ar, o _load balancer_ vai desviar o tráfego para as outras máquinas que estejam disponíveis. E o usuário final vai continuar conseguindo acessar, pois ele vai ser direcionado para uma instância que estiver operacional.

[01:59] O _load balancer_ também permite uma melhor escalabilidade, pois a medida que o nosso tráfego aumenta, o nosso número de usuários aumenta é possível incluir mais instâncias do seu servidor atrás do _load balancer_. Aqui temos, digamos três instâncias e se começar a ter muito tráfego, o sistema começou a ficar lento, eu vou adicionando mais instâncias aqui de forma transparente e o _load balancer_ vai sendo reconfigurado para distribuir o tráfego entre essas novas instâncias.

[02:33] Além disso, você também pode utilizar o _load balancer_ para algum recurso mais avançado como, por exemplo, terminação de SSL, podemos configurar o SSL, o HTTPS para encerrar o _load balancer_, entre outras características.

[02:48] A OCI nos disponibiliza dois tipos de _load balancer_ já pré-configurados, o primeiro é esse que estamos vendo aqui, ele é chamado de um _load balancer_ de nível 7 ou _layer_ 7, o que significa que esse _load balancer_ consegue entender o tráfego HTTP e HTTPS. Esse _layer_ 7 vem da nomenclatura do modelo OSI, se alguém já estudou o modelo OSI vai lembrar sobre as camadas, ele está aqui na camada 7.

[03:21] O segundo modelo aqui de _load balancer_ que é esse aqui é chamado de _Network Load Balancer_, como o nome diz, ele opera em uma camada mais baixa, ele opera na camada 4 do modelo OSI. Ele consegue compreender TCP, UDP, ICMP, ele é um _load balancer_, digamos, de nível mais baixo, ele não consegue compreender HTTP, que é um protocolo de aplicação.

[03:49] Por ele trabalhar em um nível mais baixo ele tem também uma performance melhor, ele não tem que ficar abrindo os pacotes HTTP para inspecionar, ele trabalha mais rápido do que um _load balancer_ de nível 7. Por outro lado, o _load balancer_ de nível 7 tem mais inteligência, ele capaz de processos de mais alto nível porque ele consegue olhar pacotes, inspecionar esses pacotes, ver o conteúdo disso e tomar alguma decisão sobre esse pacote.

[04:18] O tipo de _load balancer_ que você vai utilizar depende dos requisitos do seu negócio, no caso do Doguito Petshop, vamos utilizar mesmo o _load balancer_ de nível 7 porque ele mais simples de trabalhar.


-----------------------------------------------------------------------
# 08Mais um servidor

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105671

## Transcrição

[00:00] Antes de começarmos criar o nosso _load balancer_ a primeira coisa que temos que fazer é criar um outro servidor do Doguito PetShop para que nele possamos ficar fazendo esse balanceamento de carga entre o servidor 1 e o servidor 2.

[00:18] No momento se entrarmos aqui na área de "Compute > Instances" vamos ver que tem somente uma instância. Vamos entrar aqui nessa instância só para confirmar que ela está está funcionando tudo certo, colocando aqui em uma outra aba está aqui "Doguito Petshop Server 1".

[00:38] Temos que criar uma outra instância. Vamos fazer aqui o processo de criação dessa segunda instância, mas vou fazer mais rápido porque vamos fazer exatamente os mesmos passos que já fizemos anteriormente. Aqui tem o "dps-vm1" e vou criar aqui a instância 2.

[00:57] A primeira coisa que eu vou fazer aqui é colocar o nome dela, vou colocar "dps-vm2", ambiente desenvolvimento, aqui vamos deixar no mesmo _domain_. Vou deixar aqui na _shape_ _default_, _network_ _default_ também, vai cair na rede pública. E aí eu vou colocar aqui também a questão de colar a chave pública aqui, eu vou voltar lá no meu Shell e a partir desse Shell eu vou pegar a minha chave pública novamente.

[01:30] Lembrando que, em uma situação real, em geral, colocaríamos essas VMs, essas instâncias em uma rede privada e deixaria acessível somente o _load balancer_, mas para efeito de exemplo aqui vamos fazer de uma forma mais simples, vamos deixar tanto as instâncias do servidor do Doguito PetShop na rede pública quanto o _load balancer_ também.

[01:55] Já entrei aqui no meu Cloud Shell, vou acessar agora aquela mesma pasta `ssh/` e vou dar um `cat cloudshellkey` aqui na parte da chave pública, novamente vou fazer aqui a cópia dessa chave pública, copiei ela aqui e vou colar a chave pública aqui e deixo tudo como _default_ e coloco aqui no _Create_.

[02:24] Novamente temos que aguardar aqui alguns segundos para fazer essa criação. Decorridos alguns segundos a instância vai ser criada, ela vai ser criada e _running_. Com essa instância executada, com ela criada o nosso próximo passo vai ser concluir a instalação dos softwares nela, que é o que vamos fazer aqui em seguida.

[02:50] O primeiro ponto que vamos fazer é fazer um SSH para acessar essa máquina, `ssh opc` e vamos colocar aqui o IP público dela, `-i` e colocamos aqui o arquivo de chave privada. Colocou aqui, ele vai pedir para aceitarmos, aceitamos e confirmamos. Daí para frente vai fazer a instalação dos softwares que já instalamos na outra instância.

[03:23] O primeiro passo é instalar nela o software que é o _daemon_ do Apache com o comando `sudo yun -y install httpd`, executamos aqui esse comando e aguarda também alguns minutos até a conclusão da execução deste comando. Após a conclusão da instalação do HTTPD, que é o _daemon_ do Apache, vamos fazer a abertura da porta do _firewall_ da instância, o comando `sudo firewall -cmd --permanent --add-port=80/tcp`.

[04:03] Com esse comando o _firewall_ vai abrir a porta 80, esse é o _firewall_ da instância. E depois vamos recarregar aqui o _firewall_ para que ele assuma as novas configurações com o comando `sudo firewall -cmd --reload`.

[04:22] Em seguida, vamos iniciar o serviço do Apache com o comando: `sudo systemctl start httpd`. Com isso o Apache vai iniciar e podemos trocar aqui para o usuário _root_ com comando `sudo su`. Troquei aqui para o usuário _root_ com o comando `sudo su`, agora vamos fazer o último passo que é colocar aquela página inicial, aquela página que indica um HTML bem básico com o conteúdo do Doguito PetShop Server.

[04:59] Nesse caso vamos fazer o comando `echo 'Doguito Petshop Server 2' >> /var/wwwhtml/index.html`, fazendo aqui esse comando a página já vai ficar carregada. Agora podemos pegar aqui esse IP público e colar aqui no navegador, vamos colocar aqui o IP público do navegador e vamos conseguir acessar. Está aqui: "Doguito Petshop Server 2".

[05:32] Podemos também voltar ali e olhar as outras instâncias que tínhamos, vamos voltar aqui na minha lista de instâncias. Eu tenho essa outra aqui que foi terminada já que era um teste que eu estava fazendo, mas que está executando: "dps-vm2" e "dps-vm1" também em execução.

[05:54] Se eu pegar aqui o IP do "dpm-vm1" e abrir aqui outra aba do navegador e colar eu tenho aqui: "Doguito Petshop Server 1". E do outro lado eu tenho "Doguito Petshop Server 2", em dois IPs públicos distintos.

[06:11] Obviamente que não desejamos que o usuário tenha que ficar trocando de uma instância para outra manualmente pelo IP, é nesse ponto que vamos entrar com a instalação do _load balancer_, vamos fazer com que o _load balancer_ direcione o tráfego para cada um destes dois servidores.


-----------------------------------------------------------------------
# 10Nosso balanceador de cargas

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105672

## Transcrição

[00:00] Agora que já temos as duas instâncias de servidores do Doguito Petshop criadas, vamos começar, de fato, a criar o nosso _load balancer_.

[00:08] Temos aqui a insstância "dps-vm1" ativada e a "dps-vm2" ativada também, executando também. Se estivéssemos trabalhando com vários domínios de disponibilidade até poderíamos colocar cada um desses servidores do Doguito Petshop em um domínio de disponibilidade diferente, isso reduziria o risco de indisponibilidade da nossa aplicação porque, se estivesse falha em um domínio, o outro estaria funcionando e o _load balancer_ automaticamente direcionaria para um e para outro para outra aplicação.

[00:48] E isso nos lembro dos motivos de colocarmos os servidores através de um _load balancer_, que é permitir primeiro a escala horizontal, assim quanto mais requisições a nossa aplicação tiver mais servidores podemos implantar atrás desse _load balancer_. O segundo motivo é em relação à disponibilidade, porque se um servidor cair o tráfego pode ser direcionado para o outro servidor.

[01:14] Vamos começar a criação. Para criarmos o nosso _load balancer_ clicamos aqui no "Menu" do OCI, clica em "Networking" e clicamos aqui em "Load Balancers". Aqui não tem nenhum _load balancer_ ativo no momento, eu posso clicar aqui em "Create Load Balancer".

[01:34] Com isso podemos escolher também aqui o primeiro tipo de _load balancer_ que é o _layer 7_ e criar aqui em "Create Load Balancer". A primeira coisa que ele vai nos pedir nessa próxima tela é para informar um nome para ele, nesse caso ele já deu um nome _default_, podemos deixar esse nome aqui _default_ mesmo.

[01:58] A próxima questão é se devemos deixar o _load balancer_ como público ou privado. Público significa que ele também vai ter um IP público e o _private_ ele não vai ter um IP público. No caso, um _load balancer_ privado poderia ser utilizado para distribuir o tráfego internamente na minha aplicação.

[02:20] Por exemplo, se eu tiver uma aplicação de _back-end_ e uma camada de persistência e eu quero criar um _load balancer_ entre essas duas camadas, eu poderia criar ali um _load balancer_ privado. No nosso caso, vamos deixar dessa forma, público mesmo, porque esse _load balancer_ vai ter acesso pela internet.

[02:41] O próximo ponto, ele fala para atribuirmos um IP público efêmero ou reservado. No nosso caso aqui, vamos deixá-lo com o efêmero, efêmero quer dizer que ele pode mudar se derrubarmos e levantarmos novamente esse _load balancer_ esse IP pode mudar. No nosso caso não temos um endereço privado. Provavelmente se tivéssemos criando uma aplicação real no mundo internet seria melhor termos um IP reservado para ele.

[03:12] Agora o próximo ponto aqui que ele vai falar é sobre o _shape_ do _load balancer_. Nesse _shape_, ele vai determinar aqui qual que é a banda mínima e determinar o número mínimo de recursos que vamos ter no nosso _load balancer_ e também aqui, mais para baixo, o valor máximo de largura de banda que ele vai utilizar. Também nesse caso aqui é opcional, ele vai até 8000 _megabytes_ por segundo, o que seria aproximadamente 8 _gigabytes_ por segundo.

[03:42] Se deixarmos esses dois valores iguais, que é da forma que está aqui, vamos ter um _load balancer_ que chamamos de _load balancer_ fixo. No nosso caso como a nossa conta é uma conta gratuita, é uma conta do _free tier_, é isso que podemos fazer.

[03:57] O próximo ponto que vamos fazer é escolher uma rede. No nosso caso, criamos a nossa VCN1, vamos atribuir esse _load balancer_ nessa VCN1 e qual que é a sub-rede dentro dessa rede. No caso, vamos escolher aqui a sub-rede pública, essa sub-rede pública vai ser aquela que tem contato com a internet.

[04:23] Nós poderemos ver aqui algumas opções mais avançadas, alguma coisa com relação a _network security groups_ também, mas são opções, como eu falei, um pouco mais avançadas e para o nosso caso já podemos clicar aqui direto no "Next".

[04:35] Clicando aqui no _next_, a próxima escolha que devemos fazer é com relação ao algoritmo de balanceamento que vamos utilizar. Existem vários algoritmos possíveis, aqui já temos três pré-definidos: o primeiro é a _Round Robin_, que talvez seja um dos mais comuns. Esse _round robin_ quer dizer que, a cada requisição que chegarem no _load balancer_, ele vai jogar em uma máquina diferente, ele vai girando por essas máquinas fazendo esse _round_, esse ciclo aí por essas máquinas.

[05:08] O próximo que temos aqui é o chamado de IP _Hash_, ele vai fazer o seguinte: ele vai criar um _hash_ de IPs e de acordo com o IP de origem, ele sempre vai jogar em uma mesma máquina de destino. Isso vai assegurar que todas as requisições vindas de um mesmo IP, de uma mesma origem vão para o mesmo servidor de destino, é o que é chamado de _sticky-session_. Algumas aplicações que mantêm seção do lado do servidor e isso são interessantes e poderia ser utilizada essa opção.

[05:39] A opção mais a direita que é o _Least Connections_, que vai direcionar o novo tráfego que chegar para o servidor com menos conexões ativas de maneira a distribuir o peso de trabalho. No nosso caso, até por simplicidade, podemos ir com o _Round Robin_ mesmo que é o mais comum.

[06:00] A próxima opção que temos que fazer aqui é adicionar os _back-ends_. Clicando em "Adicionar Backends", vão ser mostrados os servidores que já criamos, "dps-vn1" e "dps-vn2", os que estão ativos. São para esses servidores que queremos direcionar o tráfego, vamos vir aqui e vamos selecionar os dois servidores que eu quero jogar o tráfego nestas duas máquinas.

[06:26] Lembrando também que essas máquinas elas não precisariam ter IPs públicos, só fizemos isso para um efeito didático e para ficar mais fácil de vermos que os servidores estavam funcionando colocando o IP público diretamente na internet. No dia a dia, em uma aplicação real, essas máquinas não teriam IPs público, porque o _load balancer_ comunica-se com eles através dos IPs privados, seria esse caso.

[06:52] Agora podemos clicar em adicionar servidores do _backend_ que foram selecionados aqui, vão estar aqui selecionados e podemos definir o próximo passo que é definir como vai ser feito o _health check_. Veja aqui também que ele vai direcionar na porta 80 e aqui vamos definir nessa próxima área aqui o nosso _health check_.

[07:14] Isso é basicamente um teste que é feito para analisar a disponibilidade dos _back-ends_, pode ser uma conexão, pode ser uma requisição HTTP e vamos definir alguns atributos, podemos definir alguns atributos como um intervalo entre essas chamadas para ver de quanto em quanto tempo que a máquina vai estar ativa, entre outras questões.

[07:33] Essa política vai monitorar continuamente os servidores. Por ora, podemos deixar os valores padrão mesmo, poderíamos também definir um certificado SSL, mas para o nosso caso de uso também vamos deixar sem essa marca aqui do SSL e nem as opções mais avançadas.

[07:52] Podemos clicar aqui no "Next", aqui ele já vai chegar na próxima opção que é indicar um _listener_. O _listener_ é a entidade responsável por ouvir o tráfego que chega no IP do balanceador, temos algumas opções aqui, vamos deixar a escolha mais comum que no caso é o HTTP, é a mais básica. E dependendo do caso de uso dessa aplicação você poderia ter outras opções aqui, vamos deixar HTTP a porta 80.

[08:22] Clicamos em "Next", para a última parte, e vamos colocar aqui a parte de _log_. Essa parte de _log_ ele vai criar aqui um grupo de _log_ para nós, uma retenção de _log_ para conseguirmos ver se vai acontecer algum problema, algum tipo de erro, é uma informação para fazermos verificação depois.

[08:45] Nesse caso também vamos deixar todas as opções aqui _default_ e vamos clicar aqui em "Submit". Com isso, ele vai começar o processo de criação do _load balancer_ e, dentro de alguns segundos, o nosso _load balancer_ deve ser criado. Vamos ver aqui também ao lado de dentro, enquanto ele está fazendo essa criação que ele está olhando aqui o _backend sets health_, ele está vendo aqui como é que está a saúde dos nossos _back-ends_.

[09:18] Quando ocorrer a conclusão da criação do _load balancer_, esse _status_ aqui vai ser alterado para vermos que está ativo. Após alguns segundos, foi carregado aqui a tela, ele está aqui com o _status_ dele como ativo e temos todas as informações aqui dele. A rede privada que ele foi criada, a VCN, a sub-rede, todas as informações aqui estão ativas dele.

[09:46] Ele está aqui verde, verde é ok. Para testar, selecionamos aqui o IP público dele, vou selecionar todo o valor do IP dele, podemos copiar esse IP aqui, rolar em outra aba do navegador e vamos perceber aqui que ele vai cair em um servidor. Agora se eu atualizar a página dando o "F5", eventualmente ele cai em uma máquina, às vezes ele cai na outra. Como estamos no algoritmo de _round robin_ ele vai cair em uma máquina e vai para outra, vai para uma máquina e vai outra.

[10:19] Estamos vendo aqui esse "Doguito Petshop Server 1" e "Server 2" aqui se alternando cada vez que atualizamos a página porque o _load balancer_ está enviando o tráfego para uma máquina ou para outra máquina de acordo com as requisições.

[10:34] Com isso conseguimos implantar com sucesso o _load balancer_ que vai nos garantir a disponibilidade e a escalabilidade da nossa aplicação.


-----------------------------------------------------------------------
# 11Para saber mais: introdução aos load balancers

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem/task/105715

Ao pensarmos em aplicações escaláveis horizontalmente, implantadas tanto em clouds quanto em infraestruturas convencionais, o primeiro componente que nos vêm à mente é um balanceador de cargas. Ele servirá para distribuir as cargas de trabalho entre diferentes instâncias de servidores de acordo com um algoritmo pré-determinado.

Você pode encontrar maiores detalhes sobre os load balancers na OCI vendo este video da própria Oracle:

https://youtu.be/tY2UuVbDElc

O conteúdo em video pode apresentar alguns tópicos desatualizados, por isso, todos os detalhes sobre a utilização de Load Balancers na OCI podem ser também encontrados na documentação oficial, através dos links [https://docs.oracle.com/pt-br/iaas/Content/Balance/home.htm#top](https://docs.oracle.com/pt-br/iaas/Content/Balance/home.htm#top) e [https://docs.oracle.com/es-ww/iaas/Content/Balance/home.htm#top](https://docs.oracle.com/es-ww/iaas/Content/Balance/home.htm#top).


-----------------------------------------------------------------------
# 14Conclusão

## Transcrição

[00:00] Parabéns por ter chegado até o final desse curso. Espero que você tenha gostado e esteja bastante motivado para continuarmos o próximo curso, em que vamos concluir a implantação do Doguito Pet Shop no OCI.

[00:14] Não deixe de fazer também todas as atividades indicadas, pois elas são muito importantes para a fixação do seu conhecimento. Em caso de alguma dúvida ou dificuldade, não deixe também de colocar lá no fórum do curso, pois rapidamente nós vamos auxiliá-lo. Você poderá auxiliar outros alunos que estão fazendo o mesmo curso, mantendo assim a nossa comunidade de desenvolvedores cada vez mais forte.

[00:36] Nesse curso, inicialmente criamos a nossa conta do OCI para podermos logar, entendemos a nossa conta _free tier_, o que conseguimos fazer nela, e entendemos também as características e vantagens de trabalhar em uma Cloud, além dos motivos pelos quais muitas empresas estão migrando para esse ambiente.

[00:54] Em seguida, criamos o usuário "doguito-admin" para evitar trabalharmos com o usuário raiz da Cloud e isso poderia ser um pouco perigoso. Feito isso, vimos também um pouco sobre a interface da OCI, as opções que ela tem aqui, todas as opções que a OCI nos fornece e, além disso, também vimos sobre o Cloud Shell, que é essa ferramenta aqui embaixo, o Shell de linha de comando que nos permite trabalhar com o OCI em um ambiente web totalmente sem necessidade de instalação de nenhum software local.

[01:28] O próximo passo foi a criação da nossa VCN, _Virtual Cloud Network_. Fomos na opção de Rede, em _Virtual Cloud Network_ e criamos aqui a nossa VCN1. Entre outras coisas, essa VCN vai definir o nível de visibilidade que os nossos servidores terão.

[01:48] Com isso, partimos para a criação de um servidor de fato e, aqui no OCI, é chamado de _compute_. Fomos à aba "Compute" e criamos as nossas instâncias, criamos no caso duas instâncias para poder fazer aquele balanceamento de carga que é o fato que falamos aqui, como estamos prevendo que vai ter um volume considerável de acesso para a aplicação já criamos o _load balancer_ e vamos distribuir as requisições entre essas duas instâncias.

[02:19] O _load balancer_ criamos na aba "Networking > Load Balancers" e aí criamos e configuramos o nosso _load balancer_.

[02:28] Por fim, eu peço a você que não se esqueça de nos deixar uma avaliação do curso e também um comentário nos contando o que podemos melhorar. Até a próxima.

-----------------------------------------------------------------------




