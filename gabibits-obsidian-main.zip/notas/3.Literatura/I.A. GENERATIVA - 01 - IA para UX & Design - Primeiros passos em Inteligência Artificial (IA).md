---
type: "10"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
  - "#oracle"
  - "#OCI"
  - "#cloud"
fonte_curso: https://cursos.alura.com.br/formacao-ia-generativa-one
Url_video_curso: 
IA: https://www.alura.com.br/artigos/primeiros-passos-em-inteligencia-artificial-ia
w3schools:
---

Tópico:: #Inteligencia_Artifical #IA_generativa 

#### Inteligência artificial

A inteligência artificial (IA) se tornou uma peça chave no campo da programação, revolucionando a maneira como desenvolvemos e otimizamos software. Sua capacidade de aprender e se adaptar permite automatizar tarefas repetitivas, identificar erros rapidamente e propor soluções eficientes. Além disso, a IA potencializa a criatividade dos desenvolvedores ao liberar tempo que pode ser dedicado à inovação. Ferramentas como o ChatGPT facilitam a compreensão de códigos complexos e melhoram a colaboração em projetos, tornando a programação mais acessível e eficaz.

A Inteligência Artificial (IA) está redefinindo os processos criativos e produtivos em diversas áreas, oferecendo ferramentas poderosas para transformar ideias em soluções práticas e inovadoras. Você aprenderá conceitos fundamentais e técnicas aplicadas de IA voltadas para a criação de **landing pages**, com ênfase no uso estratégico de prompts para desenvolver copywriting e planejar estruturas de página eficazes.

Além disso, você conhecerá o papel da IA na **automação de tarefas**, otimização de fluxos de trabalho e melhoria da produtividade. Ferramentas avançadas serão apresentadas para apoiar atividades como pesquisa de mercado, organização de insights, documentação técnica e a construção de portfólios profissionais.

-----------------------------------------------------------------------
https://www.alura.com.br/artigos/primeiros-passos-em-inteligencia-artificial-ia

-----------------------------------------------------------------------
# Primeiros passos em Inteligência Artificial (IA)

![](https://cdn-wcsm.alura.com.br/2025/04/primeiros-passos-em-inteligencia-artificial-ia.jpg)

![](https://www.alura.com.br/assets/img/formacao/step-alura.1730889067.svg)

23/05/2018

Compartilhe

- [](https://twitter.com/share?url=https://alura.com.br/artigos/data-science/primeiros-passos-em-inteligencia-artificial-ia)
- [](https://linkedin.com/shareArticle?url=https://alura.com.br/artigos/data-science/primeiros-passos-em-inteligencia-artificial-ia)
- [](https://facebook.com/share.php?u=https://alura.com.br/artigos/data-science/primeiros-passos-em-inteligencia-artificial-ia)
- [](https://api.whatsapp.com/send?text=https://alura.com.br/artigos/data-science/primeiros-passos-em-inteligencia-artificial-ia)

[

![](https://www.alura.com.br/assets/api/formacoes/categorias/data-science.svg)

Esse artigo faz parte da

Formação Machine Learning na prática: fundamentos e aplicações





](https://www.alura.com.br/formacao-machine-learning)

Confira neste artigo:

1. [Agora vamos lá para as referências mais práticas](https://www.alura.com.br/artigos/primeiros-passos-em-inteligencia-artificial-ia#agora-vamos-la-para-as-referencias-mais-praticas)
2. [E como saber mais sobre IA?](https://www.alura.com.br/artigos/primeiros-passos-em-inteligencia-artificial-ia#e-como-saber-mais-sobre-ia)

Vou iniciar este artigo com um questionamento: você já parou para se perguntar qual é o tipo de **carreira em IA** que você deseja iniciar e o que irá fazer nela? Seria coordenar? Programar? Inovar? Considero que todas essas opções são possíveis.

Na primeira, você gerenciaria um time de IA, na segunda, faria parte desse time e na terceira, trabalharia em um laboratório de inovação ou com pesquisa.

Antes de qualquer coisa, gostaria de dedicar este post ao Flávio Andre Virgilio, meu aluno da Alura e inspirador da resposta, à Mayra Oliveira, minha revisora, que me incentivou a fazer o post, e a todas as pessoas que querem começar na área de IA, mas não enxergam uma direção clara.

Partindo disso e da minha experiência, é uma boa que você:

- **Goste de lógica**. Algoritmos são a base da IA, quanto mais desenvolvido for o seu raciocínio lógico, melhor.
    
- **Tenha interesse em questões filosóficas, de neurociência, matemática, física e até de psicologia**. Na Filosofia, além da área de Lógica, a de Teoria do Conhecimento propõe pensar como definir o que é conhecer algo, e isso é importante para IA.
    
- **Saiba uma linguagem de programação**. Assim pode aplicar os algoritmos, a lógica e as teorias usando um computador. Aconselho **Node (para as APIs de serviços)**, **Python e Java (para os códigos e bibliotecas)**. **C** ou [**C++**](https://www.alura.com.br/artigos/formacao-linguagem-c-plus-plus) são uma boa também. Teste programar em algumas dessas linguagens e veja com a qual sente maior afinidade.
    

Considero esses 3 pontos básicos, até para saber se esse é o caminho. Ainda falando de modo pessoal, caso você seja apaixonado ou apaixonada pelas coisas acima, continue. IA pode ter um mercado em expansão agora, **mas sempre seremos bons naquilo que amamos e somos felizes fazendo.**

## Agora vamos lá para as referências mais práticas

Tendo em mente o que é IA e pensando nos pontos que citamos no início do texto, a respeito dos interesses e conhecimentos prévios necessários para trabalhar com IA, o passo seguinte é praticar. Procure pegar um problema simples e resolva-o até o final. E então, pegue um próximo, depois outro, e assim por diante.

Isso é importante para que você sinta como é desenvolver uma solução.

## E como saber mais sobre IA?

- Com a formação da Alura de [**Machine Learning**](https://www.alura.com.br/formacao-machine-learning), e o de [Estatística](https://www.alura.com.br/curso-online-estatistica-distribuicoes-e-medidas);
    
- Com os exemplos ou competições do [Kaggle](https://www.kaggle.com/) (em inglês);
    
- Executando os exemplos da [Google AI](https://ai.google/education/#?modal_active=none) (em inglês);
    
- Fazendo o curso de [Inteligência Artificial](https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-034-artificial-intelligence-fall-2010/lecture-videos/) do MIT (em inglês);
    
- Também pelos cursos de Machine Learning e IA do [Andrew Ng](http://www.andrewng.org/courses/) (em inglês);
    
- Lendo e seguindo os exemplos do livro de [Inteligência Artificial](https://www.americanas.com.br/produto/234759/livro-inteligencia-artificial?WT.srch=1&epar=bp_pl_00_go_liv_todas_geral_gmv&gclid=EAIaIQobChMI9JL3laLq2gIVggeRCh1ZJgc3EAQYASABEgIfF_D_BwE&opn=YSMESP&sellerId=00776574000660) do Russell e Norvig (em português) ou free em inglês nesse site da [Universidade de Berkeley](http://aima.cs.berkeley.edu/);
    
- Estudando as apostilas do [Silvio do Lago Pereira](https://www.ime.usp.br/~slago/main.materiais.html) do IME-USP;
    
- Explorando esse mapa mental do [Sci-kit learn](http://scikit-learn.org/stable/tutorial/machine_learning_map/index.html) (em inglês);
    
- [CURSO de Inteligência Artificial | #HipstersPontoTube — YouTube](https://www.youtube.com/watch?v=huNvfkS5Dus).
    

Além disso, te incentivamos a não parar por aí. Depois de ter concluído o primeiro projeto, compartilhe. Mostre para pessoas próximas, faça um blog, mande um link no twitter, participe de Meetups de IA na sua cidade.

Independentemente de como você classifique esse conhecimento que adquiriu: seja iniciante, intermediário ou avançado, é sempre bom que ele seja compartilhado e se multiplique.

Eu poderia adicionar referências a esse post eternamente, mas espero que tenha te dado algum norte para colocar as mãos na massa e começar.

Bora começar a trabalhar em uns algoritmos!

[

Artigo Anterior

**SQL SELECT: select count(*), count(1) e count(nome) — a batalha das funções count no SQL**

](https://www.alura.com.br/artigos/select-count-count1-e-countnome-a-batalha-dos-counts-de-sql)[

Próximo Artigo

**Manipulação de strings no pandas: lower, replace, startswith e contains**

](https://www.alura.com.br/artigos/manipulacao-de-strings-no-pandas-lower-replace-startswith-e-contains)

-----------------------------------------------------------------------

-----------------------------------------------------------------------

-----------------------------------------------------------------------

-----------------------------------------------------------------------

-----------------------------------------------------------------------

-----------------------------------------------------------------------

-----------------------------------------------------------------------

-----------------------------------------------------------------------

-----------------------------------------------------------------------

-----------------------------------------------------------------------

-----------------------------------------------------------------------






