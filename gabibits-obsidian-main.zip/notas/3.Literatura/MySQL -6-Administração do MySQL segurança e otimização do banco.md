---
type: "9"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
fonte_curso: https://cursos.alura.com.br/course/mysql-dba-administracao
Url_video_curso: https://dev.mysql.com/doc/
MySql_funcions: https://dev.mysql.com/doc/refman/8.0/en/functions.html
w3schools: https://www.w3schools.com/sql/sql_ref_mysql.asp
---

Tópico:: #MySQL #DataBase

- Conheça qual é o papel do DBA
- Faça um tuning do seu hardware
- Aprenda como executar corretamente o backup
- Use plano de execução e melhore o desempenho com índices
- Administre usuários e privilégios
-----------------------------------------------------------------------
- [](https://cursos.alura.com.br/course/mysql-dba-administracao/section/8465/tasks)
    
    [O papel do DBA](https://cursos.alura.com.br/course/mysql-dba-administracao/section/8465/tasks) [Ver primeiro vídeo](https://cursos.alura.com.br/course/mysql-dba-administracao/task/58114)
    
    0 / 13
    
    51min
    
    - Introdução
    - Instalando o MySQL
    - Preparando o ambiente: Linux e Mac
    - Recuperando a base de dados
    - Para saber mais: erro na importação
    - DBA - Database Administrator
    - Funções do DBA
    - Conexões no MySQL
    - Informações para as conexões
    - Serviço do MySQL
    - Formas de parar e iniciar o serviço
    - Consolidando o seu conhecimento
    - O que aprendemos?
- [
    
    Mecanismos de armazenamento
    
    0 / 13
    
    55min
    
    ](https://cursos.alura.com.br/course/mysql-dba-administracao/section/8466/tasks)
    
    - Arquivos necessários para a aula
    - Tuning de Hardware
    - Pontos importantes do Tuning
    - Variáveis de ambiente
    - Valor da variável
    - Mecanismo de armazenamento MyISAM
    - Aplicação do mecanismo de armazenamento
    - InnoDB e Memory
    - Acesso ao dados
    - Usando os mecanismos de armazenamento
    - Mecanismo de armazenamento padrão
    - Consolidando o seu conhecimento
    - O que aprendemos?
- [
    
    Backup e recuperação de dados
    
    0 / 17
    
    69min
    
    ](https://cursos.alura.com.br/course/mysql-dba-administracao/section/8467/tasks)
    
    - Arquivos necessários para a aula
    - Criando a base de dados
    - Comando para a criação da base de dados
    - Mudando a localização da base
    - Diretório de criação das bases de dados
    - Apagando a base de dados
    - Comando para apagar a base de dados
    - Realizando o backup com o mysqldump
    - Backup de uma base de dados
    - Usando o Workbench para backup
    - Diretório com o backup das tabelas
    - Backup de arquivos
    - Passos para o backup
    - Recuperando os backups
    - Programa para recuperar o arquivo
    - Consolidando o seu conhecimento
    - O que aprendemos?
- [
    
    Plano de execução e índices
    
    0 / 17
    
    84min
    
    ](https://cursos.alura.com.br/course/mysql-dba-administracao/section/8468/tasks)
    
    - Arquivos necessários para a aula
    - Plano de execução
    - Consulta mais lenta
    - Visualizando o plano de execução
    - Custo da consulta
    - Conceito de índices
    - Custo de ter um índice
    - Algoritmos Hash e BTree
    - Algoritmo de busca
    - Usando índices
    - Índices para melhorar uma consulta
    - Usando o Workbench
    - Plano de execução gráfico
    - A ferramenta mysqlslap
    - Criando índices
    - Consolidando o seu conhecimento
    - O que aprendemos?
- [
    
    Gerenciando usuários e privilégios
    
    0 / 18
    
    60min
    
    ](https://cursos.alura.com.br/course/mysql-dba-administracao/section/8469/tasks)
    
    - Arquivos necessários para a aula
    - Criando um usuário administrador
    - Excluir o usuário root?
    - Criando um usuário normal
    - Propriedades do usuário normal
    - Criando um usuário para somente leitura
    - Privilégios READ e EXECUTE
    - Criando um usuário para backup
    - Privilégios para o backup
    - Acessando de qualquer servidor
    - Intervalo de IPs
    - Limitando o acesso aos esquemas
    - Acesso a uma base
    - Revogando privilégios
    - Mudando o acesso
    - Consolidando o seu conhecimento
    - O que aprendemos?
    - Conclusão

-----------------------------------------------------------------------
# 01Introdução

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58114

## Transcrição

[00:00] O meu nome é Victorino Vila e nós vamos iniciar mais um curso, dentro da carreira de MySQL e esse curso vai se dedicar a parte de administração de um ambiente de SQL, a gente vem respeitando a mesma linha didática de um curso parecido que temos aqui na Alura, de Microsoft SQL server.

[00:22] Então aqui no curso de MySQL, a gente viu a introdução ao SQL, vimos a parte de consultas, a parte de manipulação de dados, vimos um curso específico sobre a parte de programação e aí, terminamos agora com esse curso que vamos iniciar, que é da parte de administração de um ambiente MySQL.

[00:46] Falar de administração do MySQL, consiste em falar de muito assunto, muita coisa, claro que esse treinamento não vai percorrer de forma detalhada tudo o que o profissional que administra um ambiente de banco de dados precisa saber, mas a gente vai dar algumas pinceladas das coisas mais importantes.

[01:09] E aí, claro, se você quiser se aprofundar nesse assunto, tem vasta documentação na internet para serem consultada. E aí, a gente vai começar basicamente fazendo de novo uma revisão, de como é que se instala o MySQL e entendendo também qual é a função do DBA, que é o profissional que administra o banco de dados.

[01:34] Cabe ao DBA, entender bem a administração do ambiente e poder ajudar os analistas e os usuários nas necessidades de... que eles possam ter em relação aos bancos de dados. O DBA também, ele vai precisar saber como é que se faz uma conexão entre um cliente e um MySQL, falaremos sobre isso nesse treinamento.

[02:00] E é claro, a gente vai começar o treinamento também, mostrando como a gente recupera uma base de dados, que nós vamos usar como exemplo. Aí, nós vamos começar o nosso treinamento em si e a gente vai falar um pouco sobre (tuning) de hardware.

[02:17] Quais são os fatores básicos que um hardware precisa para poder suportar uma boa instalação do MySQL e aí, a gente vai pular para uma coisa chamada: variáveis de ambiente do MySQL, que são variáveis que ajudam o administrador a fazer o seu tuning dentro do branco de dados.

[02:40] Existem diversas variáveis, algumas delas, por exemplo, tem a ver com limitações que o ambiente vai ter, para tratar os dados dos bancos de dados. Vamos entender também o que é um mecanismo de armazenado do MySQL, falar um pouquinho sobre os principais mecanismos de armazenamento e dar ênfase a dois deles, que é o MyISAM e o InnoDB.

[03:07] E aí, vamos pular para uma assunto que é importante em qualquer base de dados, é o backup, dados estão sujeitos a perdas e perder dados, significa dentro de uma empresa, custo. Logo, nós vamos falar sobre as formas de se efetuar backups dentro do MySQL.

[03:30] Nós vamos dar ênfase a dois tipos, uns backups que nós chamamos de frios e quentes, a gente faz a cópia de todo o ambiente e o outro, através de um aplicativo do MySQL, onde a gente consegue extrair e salvar aquilo que a gente quer salvar.

[03:50] E aí, depois, claro, vamos aprender a recuperar esses ambientes. Aí, nós vamos pular para uma coisa muito importante, uma tarefa muito importante do DBA, que é ajudar os analistas de negócio, os analistas de sistema, que estão projetando o sistema e os bancos de dados a fazer, que é performance nas consultas.

[04:17] A gente vai entender o que é um plano de execução, como ele funciona, que tipo de informação um plano de execução dá e aí, em paralelo, a gente também vai falar sobre índices, como é que são os índices dentro de um ambiente MySQL, como eles se organizam.

[04:33] E aí, depois, nós vamos juntar essas duas coisas e ver como é que índice pode melhorar o plano de execução de uma consulta à base de dados. E aí, depois, finalmente, nós vamos falar de usuários. Uma outra função do administrador do ambiente de MySQL é criar usuários e dar privilégios a esses usuários.

[04:57] Nós vamos criar alguns usuários do tipo leitura, usuários normais, usuários que fazem somente backup, usuários administradores e veremos também como é que a gente dá privilégios aos usuários, para apenas olharem um banco ou até mesmo, apenas olharem uma tabela de dados.

[05:18] E finalmente, terminaremos vendo como é que eu limpo privilégios previamente cadastrados aos usuários, dentro do ambiente MySQL. Como eu falei no início desse vídeo, esse é o assunto que nós vamos pincelar sobre administração do MySQL, mas existem muitos outros que a gente, infelizmente pelo tempo, não vai conseguir entrar em detalhe, a fundo.

[05:44] Mas eu acho que será um excelente pontapé inicia e um ótimo complemento a carreira de MySQL, que a gente vem percorrendo desde o primeiro curso da introdução ao SQL, com o MySQL, até esse. Então, gente obrigado pela preferência, espero que vocês gostem desse treinamento.

[06:05] Vamos seguir frente, um forte abraço. Tchau, tchau.

-----------------------------------------------------------------------
# 02Instalando o MySQL

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58115

## Transcrição

[00:00] A gente agora vai ter que recuperar uma base, que nós vamos usar como exemplo para esse treinamento, se você já vem fazendo os cursos da carreira de MySQL na sequência e está com o ambiente que você usou nos treinamentos anteriores, essa base de dados que nós vamos usar como exemplo, ela já existe.

[00:18] Se você teve que instalar o MySQL agora, então faz o seguinte, continue assistindo esse vídeo e aí, eu vou mostrar agora aqui um outro vídeo, onde a gente faz a recuperação desse ambiente, então não saia daí. Nesse momento todo mundo deve estar com o MySQL e o MySQL Workbench instalados na máquina.

[00:37] Vamos agora recuperar a base. Então, eu vou aqui executar o MySQL Workbench e aí, vou acessar essa base aqui... essa base não, essa conexão que foi configurada, quando a gente instalou o nosso MySQL, vou clicar. E claro, aqui eu não tenho nenhum banco a disposição.

[01:05] Se você está usando o MySQL do curso introdução ao MySQL com o MySQL, você deve estar olhando aqui também a base que nós usamos nesse treinamento anterior, mas não importa, nós vamos criar uma base nova.

[01:21] E para criar essa base nova, eu dou o botão direito do mouse sobre essa área, clico em Create Schema e vou criar aqui uma base chamada sucos_vendas, esse é o nome da base de dados que nós vamos trabalhar nesse treinamento. Vou clicar em apply, finish.

[01:48] Temos então aqui a nossa base suco_vendas criada, porém vazia, sem tabela e sem dado, nós vamos recuperar isso através de um link, que nós temos associado aqui a esse treinamento, clique nele, baixe vamos... Você vai ver um arquivo Zip com esse nome aqui: RecuperacaoAmbiente.zip.

[02:12] Descompacte ele, você deve ver uma lista de arquivos, como mostrado aqui em cima, mas aqui a nossa mais importante é esse subdiretório aqui: DumpSucosVendas. Vou voltar aqui ao Workbench, eu vou clicar nesse link aqui, primeiro na aba administração e depois eu vou clicar em Data Import/Restore.

[02:46] Cliquei, eu tenho aqui a minha caixa de diálogo, onde eu vou restaurar um arquivo que foi anteriormente feito um Backup, no caso é aquele diretório que eu especifiquei para vocês, o diretório DumpSucosVendas, que possui a base de dados que nós vamos recuperar.

[03:08] E aqui, nessa caixa de diálogos, eu vou selecionar aquele subdiretório, então vou clicar aqui, no meu caso, ele está no driver... o treinamento que eu estou dando é esse aqui, está aqui, selecionei o diretório, que foi o diretório que veio... que apareceu na descompactação do arquivo e eu tenho ali aqui, já posso recuperar.

[03:47] Só que tem um probleminha aqui, note que a resolução que eu estou usando aqui na minha máquina, ela é muito baixa, porque justamente para grava os vídeos e ficar umas letras um pouco maiores, para que vocês possam assistir o vídeo de maneira mais clara.

[04:03] Só que eu não consigo aqui, não tem um scroll, eu não consigo clicar no botão de inicializar recuperação. Então, eu vou fazer uma coisa aqui, eu vou mudar o meu computador, a configuração para 1.600 x 1.024, por exemplo, deixa eu mudar aqui, eu vou colocar 1.400 x 900.

[04:41] Ok e aí, eu agora consigo visualizar esse botão aqui , que é o botão Start Import, eu vou clicar nele e aí, a recuperação da base, ela começa a ser executada. Pronto, terminei a recuperação, deixa eu voltar de novo a minha resolução, para resolução original.

[05:17] Ok, então eu volto aqui para o Workbench, então a minha importação funcionou, só para a gente ter a certeza, eu vou clicar nessa pasta Query 1, se vocês não tiverem essa pasta, vocês cliquem aqui nesse botão.

[05:37] E aí, eu vou selecionar aqui uma consultas, select “*” from, vamos pegar aqui, por exemplo, a tabela de itens_notas_fiscais, que é a tabela maior. Claro, eu tenho que selecionar o banco, dando duplo clique sobre o banco sucos_venda, para ficar negrito esse banco.

[06:04] Tudo isso, eu ainda vou explicar melhor quando a gente começar a fazer as consultas, talvez... eu vou precisar também explicar um pouquinho para vocês, como é que a gente trabalhar no Wordbench. Eu aqui, só estou testando para saber se a minha recuperação da base funcionou.

[06:20] Está aqui, eu tenho informações, então essa recuperação funcionou, então nesse momento eu já estou pronto para iniciar o treinamento. Essa parte do vídeo, é apenas, caso você não tenha conseguido recuperar a sua base de dados através do diretório Dump, da recuperação deste diretório aqui.

[06:48] Por algum motivo você não conseguiu, deu erro. Então, faça o seguinte, vou mostrar uma segunda maneira de recuperar a base, ela é um pouquinho mais trabalhosa, mas também tem mais probabilidade de funcionar. Eu vou então aqui apagar a base sucos_vendas.

[07:10] Atenção, só façam isso se o primeiro método não funcionou, se o primeiro método funcionou, vocês podem até parar de assistir o vídeo nesse ponto, então eu vou clicar aqui em Drop Schema.

[07:30] Então não tenho mais a minha base e eu vou cria-la novamente, clico em Create Schema, selecionou a base, o nome sucos_vendas, dou o apply e dou o finish, duplo clique sobre ela, tenho a base de novo aqui criada, mas vazia. Aí, eu vou fazer o seguinte, eu vou clicar em File, Run SQL Script, vou escolher essa opção aqui.

[08:05] E eu tenho todos esses arquivos aqui com extenção “.sql”, que eu vou usar para importar a base de uma outra maneira, eu vou começar com esse aqui, primeiro arquivo, criação_esquema.sql, eu vou clicar nele, vou clicar em abrir e vou ver um script recuperação e aí, eu vou escolher aqui a base sucos_vendas.

[08:36] E vou escolher aqui em Default Character Set, que é essa opção utf8, que está aqui em baixo, do Run e aqui, ele vai terminar. Vou agora de novo e vou fazer agora, para esse arquivo aqui, Carga_Tabelas_Cadastrais.sql. Seleciono a base, seleciono o utf8 e run.

[09:14] Nesse momento, eu consegui recuperar as tabelas e os dados cadastrais, agora eu vou recuperar os dados referentes às notas fiscais. Clico de novo em Run SQL Script e vou escolher agora esse arquivo aqui, Carga_Notas_01. Seleciono e dou run.

[09:50] Esse script vai demorar um pouquinho mais, porque eu agora estou carregando dados com um volume substancial de linhas, então eu vou fazer o seguinte, eu vou parar o vídeo num instante, quando essa barra terminar, eu volto. Ok, se eu tiver essa msg aqui, é porque tudo correu bem.

[10:15] Vou agora recuperar, só que agora é o arquivo 2, Carga_Notas_02, seleciono aqui a base, utf8 e Run. Ele está processando o arquivo 02, vocês vão fazer para o arquivo Carga_Notas_02 e depois para o Carga_Notas_03. E aí, toda a parte do cabeçalho da nota fiscal, vai estar importada no banco.

[10:52] Então eu vou parar aqui o vídeo e eu vou voltar quando eu terminar o Carga_Notas_03, vocês façam esses passos e aí, me encontrem daqui a pouco. Até já. Pronto, nesse momento eu importei os arquivos Carga_Notas_01, 02 e 03. Eu agora, vou importar o Carga_Intens_Notas, de 01 a 07.

[11:24] Então, eu vou começar aqui com o 01, seleciono a suco_vendas, seleciono aqui o utf8, dou o Run, então eu vou começar a importar o Carga_Itens_Notas_01. Então, façam isso com o 01, 02, 03, até o 07 e aí, quando vocês terminarem o último arquivo, a base vai estar recuperada.

[11:59] Pronto, importei aqui o Carga_Itens_Notas_07, então, nesse momento, eu também tenho a minha base recuperada. Então, eu mostrei para vocês nesse vídeo, duas maneiras de recuperar a base, vocês devem tentar a primeira, se não funcionar, tentem a segunda.

[12:22] Agora, estamos preparados para continuar o nosso treinamento. Um abraço, até a próxima.

-----------------------------------------------------------------------
# 03Preparando o ambiente: Linux e Mac

Se você estiver utilizando o sistema operacional Linux ou Mac, temos um excelente artigo que explica de forma detalhada o processo de instalação do MySQL. Recomendamos que você siga os passos descritos neste artigo antes de continuar com o curso:

- [MySQL: da instalação até a configuração](https://www.alura.com.br/artigos/mysql-instalacao-configuracao)

Caso surjam dúvidas durante o processo de instalação, não hesite em procurar assistência no fórum ou no Discord da Alura. Estamos aqui para ajudar você a ter uma experiência de aprendizado tranquila e produtiva.

Desejamos a você ótimos estudos e sucesso em sua jornada de aprendizado!

-----------------------------------------------------------------------
# 04Recuperando a base de dados

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58652

## Transcrição

> _O arquivo **RecuperacaoAmbiente.zip** pode ser baixado [aqui](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/01/RecuperacaoAmbiente.zip)._ Nas versões mais recentes do MySQL, a _collation_ `utf8mb4_0900_ai_ci` foi descontinuada. Então, caso você tenha problemas em utilizar a versão do arquivo disponibilizada acima, [você pode fazer aqui o download desta outra versão](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/RecuperacaoAmbiente.zip).

[00:00] A gente agora vai ter que recuperar uma base, que nós vamos usar como exemplo para esse treinamento, se você já vem fazendo os cursos da carreira de MySQL na sequência e está com o ambiente que você usou nos treinamentos anteriores, essa base de dados que nós vamos usar como exemplo, ela já existe.

[00:18] Se você teve que instalar o MySQL agora, então faz o seguinte, continue assistindo esse vídeo e aí, eu vou mostrar agora aqui um outro vídeo, onde a gente faz a recuperação desse ambiente, então não saia daí. Nesse momento todo mundo deve estar com o MySQL e o MySQL Workbench instalados na máquina.

[00:37] Vamos agora recuperar a base. Então, eu vou aqui executar o MySQL Workbench e aí, vou acessar essa base aqui... essa base não, essa conexão que foi configurada, quando a gente instalou o nosso MySQL, vou clicar. E claro, aqui eu não tenho nenhum banco a disposição.

[01:05] Se você está usando o MySQL do curso introdução ao MySQL com o MySQL, você deve estar olhando aqui também a base que nós usamos nesse treinamento anterior, mas não importa, nós vamos criar uma base nova.

[01:21] E para criar essa base nova, eu dou o botão direito do mouse sobre essa área, clico em Create Schema e vou criar aqui uma base chamada sucos_vendas, esse é o nome da base de dados que nós vamos trabalhar nesse treinamento. Vou clicar em apply, finish.

[01:48] Temos então aqui a nossa base suco_vendas criada, porém vazia, sem tabela e sem dado, nós vamos recuperar isso através de um link, que nós temos associado aqui a esse treinamento, clique nele, baixe vamos... Você vai ver um arquivo Zip com esse nome aqui: RecuperacaoAmbiente.zip.

[02:12] Descompacte ele, você deve ver uma lista de arquivos, como mostrado aqui em cima, mas aqui a nossa mais importante é esse subdiretório aqui: DumpSucosVendas. Vou voltar aqui ao Workbench, eu vou clicar nesse link aqui, primeiro na aba administração e depois eu vou clicar em Data Import/Restore.

[02:46] Cliquei, eu tenho aqui a minha caixa de diálogo, onde eu vou restaurar um arquivo que foi anteriormente feito um Backup, no caso é aquele diretório que eu especifiquei para vocês, o diretório DumpSucosVendas, que possui a base de dados que nós vamos recuperar.

[03:08] E aqui, nessa caixa de diálogos, eu vou selecionar aquele subdiretório, então vou clicar aqui, no meu caso, ele está no driver... o treinamento que eu estou dando é esse aqui, está aqui, selecionei o diretório, que foi o diretório que veio... que apareceu na descompactação do arquivo e eu tenho ali aqui, já posso recuperar.

[03:47] Só que tem um probleminha aqui, note que a resolução que eu estou usando aqui na minha máquina, ela é muito baixa, porque justamente para grava os vídeos e ficar umas letras um pouco maiores, para que vocês possam assistir o vídeo de maneira mais clara.

[04:03] Só que eu não consigo aqui, não tem um scroll, eu não consigo clicar no botão de inicializar recuperação. Então, eu vou fazer uma coisa aqui, eu vou mudar o meu computador, a configuração para 1.600 x 1.024, por exemplo, deixa eu mudar aqui, eu vou colocar 1.400 x 900.

[04:41] Ok e aí, eu agora consigo visualizar esse botão aqui , que é o botão Start Import, eu vou clicar nele e aí, a recuperação da base, ela começa a ser executada. Pronto, terminei a recuperação, deixa eu voltar de novo a minha resolução, para resolução original.

[05:17] Ok, então eu volto aqui para o Workbench, então a minha importação funcionou, só para a gente ter a certeza, eu vou clicar nessa pasta Query 1, se vocês não tiverem essa pasta, vocês cliquem aqui nesse botão.

[05:37] E aí, eu vou selecionar aqui uma consultas, select “*” from, vamos pegar aqui, por exemplo, a tabela de itens_notas_fiscais, que é a tabela maior. Claro, eu tenho que selecionar o banco, dando duplo clique sobre o banco sucos_venda, para ficar negrito esse banco.

[06:04] Tudo isso, eu ainda vou explicar melhor quando a gente começar a fazer as consultas, talvez... eu vou precisar também explicar um pouquinho para vocês, como é que a gente trabalhar no Wordbench. Eu aqui, só estou testando para saber se a minha recuperação da base funcionou.

[06:20] Está aqui, eu tenho informações, então essa recuperação funcionou, então nesse momento eu já estou pronto para iniciar o treinamento. Essa parte do vídeo, é apenas, caso você não tenha conseguido recuperar a sua base de dados através do diretório Dump, da recuperação deste diretório aqui.

[06:48] Por algum motivo você não conseguiu, deu erro. Então, faça o seguinte, vou mostrar uma segunda maneira de recuperar a base, ela é um pouquinho mais trabalhosa, mas também tem mais probabilidade de funcionar. Eu vou então aqui apagar a base sucos_vendas.

[07:10] Atenção, só façam isso se o primeiro método não funcionou, se o primeiro método funcionou, vocês podem até parar de assistir o vídeo nesse ponto, então eu vou clicar aqui em Drop Schema.

[07:30] Então não tenho mais a minha base e eu vou cria-la novamente, clico em Create Schema, selecionou a base, o nome sucos_vendas, dou o apply e dou o finish, duplo clique sobre ela, tenho a base de novo aqui criada, mas vazia. Aí, eu vou fazer o seguinte, eu vou clicar em File, Run SQL Script, vou escolher essa opção aqui.

[08:05] E eu tenho todos esses arquivos aqui com extensão “.sql”, que eu vou usar para importar a base de uma outra maneira, eu vou começar com esse aqui, primeiro arquivo, criação_esquema.sql, eu vou clicar nele, vou clicar em abrir e vou ver um script recuperação e aí, eu vou escolher aqui a base sucos_vendas.

[08:36] E vou escolher aqui em Default Character Set, que é essa opção utf8, que está aqui em baixo, do Run e aqui, ele vai terminar. Vou agora de novo e vou fazer agora, para esse arquivo aqui, Carga_Tabelas_Cadastrais.sql. Seleciono a base, seleciono o utf8 e run.

[09:14] Nesse momento, eu consegui recuperar as tabelas e os dados cadastrais, agora eu vou recuperar os dados referentes às notas fiscais. Clico de novo em Run SQL Script e vou escolher agora esse arquivo aqui, Carga_Notas_01. Seleciono e dou run.

[09:50] Esse script vai demorar um pouquinho mais, porque eu agora estou carregando dados com um volume substancial de linhas, então eu vou fazer o seguinte, eu vou parar o vídeo num instante, quando essa barra terminar, eu volto. Ok, se eu tiver essa msg aqui, é porque tudo correu bem.

[10:15] Vou agora recuperar, só que agora é o arquivo 2, Carga_Notas_02, seleciono aqui a base, utf8 e Run. Ele está processando o arquivo 02, vocês vão fazer para o arquivo Carga_Notas_02 e depois para o Carga_Notas_03. E aí, toda a parte do cabeçalho da nota fiscal, vai estar importada no banco.

[10:52] Então eu vou parar aqui o vídeo e eu vou voltar quando eu terminar o Carga_Notas_03, vocês façam esses passos e aí, me encontrem daqui a pouco. Até já. Pronto, nesse momento eu importei os arquivos Carga_Notas_01, 02 e 03. Eu agora, vou importar o Carga_Intens_Notas, de 01 a 07.

[11:24] Então, eu vou começar aqui com o 01, seleciono a suco_vendas, seleciono aqui o utf8, dou o Run, então eu vou começar a importar o Carga_Itens_Notas_01. Então, façam isso com o 01, 02, 03, até o 07 e aí, quando vocês terminarem o último arquivo, a base vai estar recuperada.

[11:59] Pronto, importei aqui o Carga_Itens_Notas_07, então, nesse momento, eu também tenho a minha base recuperada. Então, eu mostrei para vocês nesse vídeo, duas maneiras de recuperar a base, vocês devem tentar a primeira, se não funcionar, tentem a segunda.

[12:22] Agora, estamos preparados para continuar o nosso treinamento. Um abraço, até a próxima.

-----------------------------------------------------------------------
# 05Para saber mais: erro na importação

O erro que é apresentado é decorrente a importação dos arquivos que contém caracteres codificados em um conjunto de caracteres (charmap) que não é suportado pelo MySQL.

Para solucionar o problema tente realizar uma nova tentativa de importação dos dados. Para isso, siga os passos abaixo:

- Baixe e extraia o arquivo [RecuperacaoAmbiente.zip](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/01/RecuperacaoAmbiente.zip):

![Gif que simula a extração de arquivos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/rgIQcrL.gif)

- Exclua o schema `suco_vendas`, essa etapa evitará possíveis interferências em configurações antigas:

![Gif do workbench. Nela o usuário clica com o botão direito em suco_vendas em seguida, seleciona a opção Drop Schema. Em seguida a opçao Drop Now](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/4QCVyiE.gif)

- Agora iremos criar o Schema suco_vendas. Para isso, na aba Schemas, com o botão direito do mouse, clique em **Create Schema**:

![Na aba Schema, ao clicar com o botão direito do mouse, seleciona a opção create schema.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/Yl64JUg.gif)

- Em seguida, nomeie o schema sucos_vendas. E clique em **Apply** para as seguintes etapas.

![Gif que simula a criação do Schema](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/mFvvlHj.gif)

- Para a importação de cada arquivos. Selecione a opção **Open SQL Script**, selecione o arquivo correspondente e **execute**.

![Gif SQL Workbench. Ao selecionear em file é escolhido o arquivo em seguida é executado o script](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/zsGlj35.gif).

Você fará essa ação para os demais arquivos, Cargas_Itens_Notas e Carga_Tabelas_Cadastrais.


-----------------------------------------------------------------------
# 06DBA - Database Administrator

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58116

## Transcrição

[00:00] Vamos começar falando sobre o DBA, quem é esse profissional? O DBA, ele é o profissional responsável por administrar o banco de dados e aí, eu menciono algumas características das funções de um DBA.

[00:17] A primeira característica é avaliar o ambiente, o DBA, ele é o profissional que avalia os hardwares necessários para a instalação e funcionamento de uma SQP, ele deve avaliar se os equipamentos disponíveis são necessários, para que os bancos de dados possam corresponder às necessidades operacionais da empresa.

[00:43] Outra característica do DBA, é que ele é responsável por configurar o acesso à base de dados, seja através de conexões ou através de interfaces IDE, são aquelas interfaces amigáveis, como por exemplo o MySQL Workbengh ou outra interface qualquer.

[01:07] Cabe a ele também configurar as conexões de forma segura, para que o acesso entre o cliente e o servidor não seja, por exemplo, hackeado. Cabe também ao DBA manter o banco de dados performático, um dos instrumentos a sua disposição, por exemplo, são os índices.

[01:27] Os índices são estruturas que melhoras as consultas e o retorno dos dados, sabe ao DBA buscar os melhores índices, para que ele seja usado nas aplicações que acessão dados, aos bancos de dados, também o DBA, ele é responsável pela armazenagem dos dados.

[01:50] Cabe a ele fazer o backup das informações, para que as mesmas não sejam perdidas e também a sua função, recuperar esses dados, que eventualmente foram perdidos ou então, por uma necessidade qualquer do usuário.

[02:08] Também cabe ao DBA auxiliar a área de desenvolvimento, fazendo cargas em lotes de dados, criar e apagar dados indesejáveis e desfragmentar o banco de dados e fazer a manutenção das tabelas. Também o DBA é responsável por monitorar a instalação do MySQL.

[02:33] Cabe a ele observar os recursos que estão sendo consumidos pelo banco e fazer gerenciamentos pontuais na instalação atual, para que ela se adapte as necessidades dos usuários.

[02:50] Também o DBA, ele é responsável por configurar o ambiente, através de arquivos de inicialização e dentro desses arquivos, ele pode configurar diversas propriedades, como por exemplo, configurar o auto incremento do tamanho das bases, gerenciar o seu crescimento, gerenciar o uso do espaço e administração do esquema de dados, enfim.

[03:13] Diversas propriedades que são configuradas nesse arquivo de inicialização. Finalmente, o DBA também é responsável por administrar os usuários que irão acessar o MySQL. Ele é responsável por criar usuários básicos e avançados, usuários que vão poder fazer backups, usuários que vão, por exemplo, somente ler dados, enfim.

[03:40] Cabe a ele administrar esses usuários e determinar que função cada um vai fazer dentro da base de dados. Enfim, essas são as funções mais o menos básicas de um DBA, dentro do ambiente do MySQL. Algumas pessoas questionam se ainda existe a necessidade de um DBA dentro das empresas.

[04:07] Primeiro, porque já existe algumas ferramentas que otimizam a administração do banco de dados de forma automática e também com o adento das nuvens, ou seja, cada vez mais as empresas estão colocando os seus bancos de dados em nuvens.

[04:28] O DBA perde um pouco o sentido, já que quem vai se preocupar em fazer backup, manutenção dos dados é o administrador da nuvem, mas eu diria que essas novas tecnologias, elas não invalidam a necessidade de um DBA, talvez as funções desse profissional tenham que ser modificadas.

[04:51] Ou seja, cabe a ele ser expert nas ferramentas de produtividade ou então, cabe a ele entender a fundo como criar e administrar recursos de banco de dados em nuvem. Enfim, é um ponto que a gente pode ficar aqui durante muito tempo discutindo, mas não é o nosso foco.

[05:12] Vamos seguindo esse treinamento, vendo algumas dessas funcionalidades na prática, funcionalidades que são de responsabilidade do DBA. Valeu. Obrigado.

-----------------------------------------------------------------------
# 08Conexões no MySQL

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58117

## Transcrição

[00:00] Nesse momento eu tenho o meu MySQL instalado e agora, o que eu preciso fazer é configurar as conexões entre o meu cliente e o meu servidor. Quando eu fiz a instalação do MySQL, eu já fiz uma configuração com o meu cliente servidor locais.

[00:19] Apesar de eu estar usando uma única máquina, aqui está instalado o servidor e o cliente e a comunicação deles está sendo feita também via TCP/IP, só que as duas (distâncias) não estão fisicamente no mesmo hardware, no mesmo PC, vamos entrar no MySQL Workbench e olhar essas propriedades de conexão.

[00:47] Então eu ou entrar aqui no MySQL Workbench e aí, eu já tenho aqui a minha propriedade de conexão, que foi criada durante a instalação do MySQL, se eu quiser modificar ou verificar os parâmetros dessa conexão, basta eu escolher aqui, esse ícone que mostra... é o ícone de uma ferramenta, onde eu consigo ver as propriedades de conexão.

[01:14] Eu vou clicar aqui então na ferramenta e eu consigo ver, escolhendo a minha conexão, as propriedades de conexão. Aqui, eu tenho várias maneiras de se conectar com o meu servidor, eu estou usando o TCP/IP padrão, em alguns lugares a gente usa o... através de SSH, que é uma conexão criptografada, que é uma coisa mais segura.

[01:43] Nós temos aqui o servidor, a porta de comunicação, que normalmente a gente usa a 3306, um padrão, mas isso não significa que eu seja obrigado a usar esse número sempre, dependendo da instalação, eu posso estar trocando esse número e aqui eu tenho o meu usuário.

[02:05] Claro que esse meu PC, é um PC local, eu não estou em uma rede, eu não tenho como me conectar aqui em outro servidor, mas para mostrar a vocês como é que a gente faz uma configuração em um outro servidor no mesmo Workbench, eu vou me conectar num outro MySQL, que está na nuvem.

[02:28] Eu tenho pessoalmente um MySQL que está na nuvem, eu uso ele para fazer várias coisas e eu vou estar acessando nesse MySQL que está na nuvem, usando essa mesma máquina que já está se conectando com o servidor local.

[02:46] Eu vou então aqui fechar essa caixa de diálogo e vou clicar nesse ícone aqui que tem um mais, vou clicar nele, vou colocar um nome para a conexão, então MySQL nuvem. Aqui, eu vou colocar o IP desse servidor, o IP, eu tenho ele aqui, a porta é a 3306 e o usuário também é Root.

[03:19] Vou testar a conexão, note que ele vai me perguntar aqui a senha desse servidor que eu disse que eu tenho na nuvem, então eu vou parar o vídeo um instante, vou colocar a senha e volto já, já. Pronto, coloquei a minha senha, vou clicar ok e vou clicar... tenho a conexão, conectado com sucesso, clico ok.

[03:44] E agora, eu tenho aqui no meu Workbench duas conexões configuradas. Vou clicar na segunda. Novamente, essa segunda conexão, você não vão conseguir fazer, eu estou mostrando só como um exemplo para mostrar para vocês como é que eu me conecto em dois servidores ao mesmo tempo, através do mesmo cliente.

[04:09] Então, eu tenho aqui o meu ambiente da nuvem, tenho aqui uns bancos de dados de trabalho e aí, se eu clicar aqui em cima no ícone home, eu volto para a tela principal, se eu der um duplo clique também na minha instância local.

[04:23] Então eu tenho aqui, tenho aqui as tabelas da minha instância local e se eu clicar aqui, eu estou vendo as tabelas da minha instância de nuvem. Se eu colocar alguma coisa aqui, por exemplo, eu vou estar executando num MySQL que está lá na nuvem.

[04:41] Se eu vier aqui em instância local e fazer algum comando aqui, eu vou estar executando no banco que está localmente na minha máquina. Eu vou fechar aqui a minha instância de nuvem, vou fechar a minha instância local e aí, eu posso também pelo administrador do Workbench apagar conexões, basta eu vir aqui, clicar na manutenção.

[05:10] Clico aqui no meu MySQL nuvem e eu tenho aqui o ícone delete. Clico nele, clico em delete e a conexão é apagada. Eu vou criar de novo uma outra conexão, só que usando as mesmas propriedades locais, então vou clicar aqui, vou colocar aqui: Local Instane MySQL80 v2.

[05:43] Vou colocar aqui local host, mesma porta, usuário Root, vou testar a conexão e dou um ok. Então, note que eu tenho agora aqui duas conexões, só que claro, ela são iguais, mas não deixa de ser duas conexões diferentes. Onde é que isso fica armazenado na minha máquina?

[06:06] Se eu vier aqui, eu já tenho até um diretório aqui salvo, deixa eu copiar aqui ele e aí, eu vou explicar onde é que esse diretório fica. Eu, na verdade, estou indo no profile do meu usuário, AppData, Roaming, MySQL, Workbench, ou seja, são um diretório local do meu usuário.

[06:34] Existe um arquivo aqui chamado connections.xml, eu posso... botão direito do mouse aqui, verificar esse arquivo com um editor de texto e eu tenho aqui, olha só, um xml com as minhas duas conexões. Eu tenho uma conexão aqui e outra aqui. Pois bem.

[07:00] Caso eu queria, por exemplo, replicar essa minha conexão para que outros usuários e outras máquinas que tenham somente o cliente MySQL, acesse esses servidores, eu não preciso ir de máquina em máquina, sair configurando conexão de todo mundo.

[07:20] Imagina, eu tenho uma empresa com 10 conexões e faço a instalação numa outra máquina, eu vou ter que ir no Workbench, colocar manualmente essas conexões, pois bem, eu posso fazer isso numa máquina única e eu posso pegar esse arquivo connections.xml, copiar ele e transportar ele para o diretório AppData, Roaming, MySQL, Workbench.

[07:44] E aí, o outo cliente já vai ter configurado na sua máquina as mesmas conexões, então isso é uma forma de você replicar as conexões dentro de vários clientes da sua organização. Então é isso aí, gente, que eu queria falar com vocês. Valeu.


-----------------------------------------------------------------------
# 10Serviço do MySQL

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58118

## Transcrição

[00:00] Quando eu me conecto com o banco, esse banco está lá no servidor rodando e ele tem que estar ativo, ou seja, ele tem que estar preparado para receber as solicitações dos clientes. Só que esse banco pode, eventualmente, estar parado ou fora do ar.

[00:17] Eu como administrador, tenho o poder de parar esse banco ou não, vamos fazer então o seguinte, eu vou parar aqui a conexão que eu criei extra, vou me conectar de novo localmente. Então entrei, estou aqui na minha conexão, eu vou fechar a conexão.

[00:44] E note que aqui na parte de serviços do Windows, eu tenho esse serviço rodando aqui, MySQL80, ele está em execução e inclusive está configurado como sendo automático, ou seja, quando o sistema operacional der boot, esse serviço automaticamente será inicializado novamente.

[01:10] Esse serviço, ele roda no servidor, como a minha máquina, ele é cliente/servidor ao mesmo tempo, eu agora estou olhando o servidor. Eu posso parar esse serviço, então, se eu vier aqui, selecionar esse serviço e clicar no ícone aqui de parada do serviço, note que o serviço no MySQL não está rodando mais.

[01:32] Se eu vier aqui e tentar me conectar agora localmente, note que eu entro, mas eu não consigo ver nenhuma tabela e ele me mostra aqui uma série de informações, basicamente dizendo que os servidor está parado, ele não está rodando. Eu vou fechar, se eu vier aqui em serviço e inicializar ele novamente.

[02:05] Agora, voltando ao Workbench, se eu escolho a conexão, eu consigo entrar no meu servidor. O serviço pode ser parado e inicializado através do serviços do Windows ou então, eu posso executar também em linha de comando, então eu posso vir aqui em linha de comando.

[02:29] Vou executar como administrador, vamos lá de novo e aí, se eu colocar “net stop mysql80”, o serviço, ele é parado. Então, se eu novamente tentar entrar aqui, eu não vou conseguir ver nada e se eu colocar aqui “net start mysql80”, o serviço é inicializado novamente, se eu entrar agora aqui, eu entro dentro do MySQL.

[03:22] Qual é a importância de eu parar e subir o serviço ou parar e subir o servidor? Depende, pode ser que durante um período de tempo, o DBA queira fazer uma manutenção no ambiente, então eu posso parar o serviço, para que ninguém mais entre no MySQL, enquanto eu vou processar algum tipo de manutenção.

[03:43] Outra coisa que a gente vai ver com mais detalhes mais a frente, é os parâmetros de inicialização do MySQL, uma série de características do nosso banco de dados, ela é configurada através de um arquivo de inicialização, onde eu tenho inúmeras variáveis de ambiente, que podem ser configuradas.

[04:03] Algumas dessas variáveis, elas precisam que o banco pare e retorne novamente, então pode ser que ao modificar uma variável de ambiente, eu precise parar o serviço e subir o banco de novo, para que essas variáveis de ambiente, façam parte do MySQL.

[04:22] Então tá, era isso que eu queria falar para vocês sobre o serviço. Um abraço.


-----------------------------------------------------------------------
# 12Consolidando o seu conhecimento

Chegou a hora de você pôr em prática o que foi visto na aula. Para isso, execute os passos listados abaixo.

---

1) Se você está usando uma máquina limpa, deve instalar o **MySQL**. Para isso, siga as instruções a seguir (caso você já tenha o **MySQL** instalado, pode pular para o **passo 22**).

2) Acesse o link [https://www.mysql.com/downloads/](https://www.mysql.com/downloads/), para baixar o MySQL.

3) Procure por **MySQL Community Edition** e clique em **Community (GPL) Downloads**.

4) Em **MySQL on Windows (Installer & Tools)**, clique em **Download**.

5) Clique em **MySQL Installer**.

6) Clique no botão de download ao lado da opção **Windows (x86, 32-bit), MSI Installer**.

7) Clique em **No thanks, just start my download** e espere o download terminar.

8) Execute o instalador que foi baixado.

9) Aceite os termos e clique em **Next**.

10) Escolha a instalação **Developer Default**, clique em **Next** e em **Next** também na próxima tela.

11) Clique em **Execute**, para fazer o download e instalação do banco e seus componentes. Terminado isso, clique em **Next**.

12) Na próxima tela, clique em **Next**.

13) Mantenha a escolha **Standalone MySQL Server / Classic MySQL Replication** e clique em **Next**.

14) Mantenha as propriedades padrões do serviço e da porta de comunicação. Clique **Next**.

15) Mantenha a opção **Use Strong Password Encryption for Authentication**. Clique em **Next**.

16) Inclua a senha do usuário **root** e repita-a. Clique em **Next**.

17) Em **Windows Service**, mantenha as propriedades padrões e clique em **Next**.

18) Clique **Execute** para iniciar a instalação. Terminada a instalação, clique em **Finish**.

19) Nas próximas telas, clique em **Next**, **Finish** e em **Next**.

20) Na tela **Connect To Server**, digite a senha configurada anteriormente e clique em **Check**. Em seguida, clique em **Next** e em **Execute** em seguida.

21) Finalize a instalação e automaticamente o **Workbench** será aberto. Clique na conexão que está configurada. Ao digitar a senha e clicar em **OK**, você acessará o ambiente com o MySQL no ar.

22) Se você está usando uma máquina limpa, você deve recuperar a base de dados a ser usada neste curso. Para isso, siga as instruções a seguir.

23) Caso ainda não tenha feito, faça o download do arquivo **RecuperacaoAmbiente.zip** [aqui](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/01/RecuperacaoAmbiente.zip) e descompate-o.

24) Abra o **MySQL Workbench**. Utilize a conexão que está configurada.

25) Clique com o botão direito do mouse sobre a área vazia de _Schemas_ e escolha **Create Schema**.

26) Insira o nome **sucos_vendas**. Clique em **Apply** duas vezes e em **Finish** em seguida.

27) Na área **Navigator**, clique na aba **Administration**.

28) Clique em **Data Import/Restore**.

29) Na opção **Import from Dump Project Folder**, escolha o diretório **DumpSucosVendas**, que você baixou e extraiu anteriormente.

30) Em seguida, clique no botão **Start Import**.

31) Verifique se as tabelas foram criadas na base **sucos_vendas**.


-----------------------------------------------------------------------
# 13O que aprendemos?

Nesta aula, aprendemos:

- A instalar o **MySQL** e recuperar o ambiente que será utilizado neste treinamento
- Como criar conexões e distribuí-las pelos clientes
- Como paramos e iniciamos o serviço do MySQL

-----------------------------------------------------------------------
# 01Arquivos necessários para a aula

Ao longo dos vídeos, o instrutor irá utilizar alguns arquivos específicos, que são necessários para o decorrer desta aula e do treinamento. Você pode baixar um ZIP com esse conteúdo [aqui](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/02/arquivos-aula-2.zip).

-----------------------------------------------------------------------
# 02Tuning de Hardware

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58119

## Transcrição

[00:00] Vamos falar um pouquinho de tuning. Eu, quando estava preparando esse curso, eu tentei achar uma palavra que traduzisse tuning, não encontrei, seria “envenenar”, digamos assim, o nosso ambiente de MySQL, quando a gente fala que a gente faz um tuning num carro ou carro tunado, é uma palavra aportuguesada, da palavra tuning.

[00:27] Eu estou envenenando o motor do carro, então fazer um tuning no MySQL, significa, a gente envenenar o MySQL, deixar ele mais rápido e a gente tem quatro maneiras de fazer um tuning dentro do nosso ambiente do MySQL.

[00:42] Primeiro, trabalhando com os banco de dados e índices, são coisas que eu vou falar depois, nós temos tuning através das variáveis internas do MySQL, que a gente chama ali de MySQLD tuning e através do hardware e do sistema operacional que o MySQL está instalado.

[01:10] Vou começar a falar agora um pouquinho para vocês sobre o tuning de hardware e depois o tuning do MySQLD. A primeira coisa que eu posso falar sobre o tuning de hardware, é claro, é considerar sempre sistemas operacionais de 64bits.

[01:33] O MySQL tem uma gama de poder utilizar vários processadores em paralelo e de consumir realmente toda a capacidade de memória de hardware que a máquina possui.

[01:50] Então, a gente dar preferencia a processadores de 64 bits, significa a gente poder ter processos com RAMs muito maiores do que, por exemplo, se eu estivesse usando processadores de 32 bits, onde os meus processos ficariam limitados a 2.4GB de RAM por processo.

[02:18] Hoje em dia isso é muito pouco, então vamos dar ênfase, claro, aos sistemas operacionais de 64 bits. Claro que hoje em dia, a maioria dos computadores já são 64 bits, mas as vezes no ambiente corporativo, ainda temos servidores antigos e as vezes quando a gente vai instalar o MySQL, esses servidores antigos, são os que são disponibilizados para a gente poder trabalhar.

[02:46] Outra coisa importante é ver a configuração de RAM que está sendo utilizada, na verdade, existe um parâmetro interno no MySQL, que a gente diz quanto de RAM os nossos processos vão poder consumir no máximo, é claro que eu não vou disponibilizar toda a RAM disponível dentro da minha máquina.

[03:12] Normalmente a dica é que você disponibilize, pelo menos, no máximo 50% da sua RAM existente. Então, se eu estiver usando, por exemplo, um servidor com 32G de RAM, a gente vai ter então disponível para o MySQL, preferencialmente metade disso ou 16G.

[03:38] Aí, cabe a você definir se esses 16G é muita coisa ou não e há aí uma relação que a experiência mostra... direta, entre o tamanho da base e a quantidade de RAM que o processo vai gastar, um exemplo é o seguinte. Opa, eu passei para frente, vamos lá.

[04:02] Um exemplo é o seguinte, uma base normalmente de 1GB de tamanho, não vai gastar mais do que 8GB de RAM para fazer qualquer coisa nessa sua base. Claro que um ambiente real, a gente não vai ter só uma conexão fazendo coisa na base, eu vou ter várias conexões.

[04:23] Então, dependendo da forma com que o banco é usado, talvez, mesmo tendo um bando de 1GB, 8G de RAM vai ser pouco, porque eu posso ter muitos processos acessando a base ao mesmo tempo. Outro ponto importante que deve ser colocado é o tipo de leitura de disco, o “io”, que esse banco vai ter.

[04:51] E aí, claro, aonde estiver armazenado a base de dados, vai fazer uma enorme diferença. Hoje em dia, a gente tem diversos tipos de HDs de discos rígidos, onde nós podemos armazenar os nossos dados.

[05:08] Claro que se você tiver dinheiro e capacidade de colocar tudo num disco SSD, que é um disco rígido de memória, aí ia ser imbatível, a velocidade de “io” vai ter um ganho enorme, mas hoje os SSDs ainda são caros. Então, a gente sempre vai encontrar discos do tipo: SCSI, SATA e SAS.

[05:36] Desses três, normalmente SCSI são muito velhos, a gente quase não encontra mais hoje em dia e entre disco SAS e SATA, de preferência aos discos SAS, porque eles são mais performáticos. Outra forma também é como é que você usa a sua controladora de disco RAID.

[05:59] Geralmente os discos RAID são usados, para a gente poder trazer segurança aos nossos dados. Existem vários tipos de RAID, os mais usados são RAID 0, RAID 1, RAID 5 e RAID 10, normalmente o seguinte, o RAID 0, ele vai dividir o seu dado e dois discos rígidos diferentes.

[06:22] Então, eu tenho dois discos rígidos físicos, mas logicamente, eu enxergo somente um drive e aí, o sistema operacional vai dividindo esse dado entre os discod. O RAID 1, normalmente é uma cópia, eu tenho dois discos rígidos, eu olho um só, mas a capacidade do que eu olho de discos normalmente é de um deles somente.

[06:51] E internamente, toda a vez que eu gravo, que eu incluo, altero ou excluo informações, essa operação é feita ao mesmo tempo nos dois discos, esse é o tipo RAID 1. Aí, você tem variantes do RAID 5 e RAID 10. RAID 5 seria a divisão dos dados, só que em mais discos.

[07:14] E o RAID 10, seria o espelhamento dos discos, usando mais discos rígidos. Claro que o RAID 10 e o RAID 1, eles gastam metade do espaço físico fazendo redundância, mas com certeza, eles são mais seguros para suportar um bando de dados MySQL, porque se por acaso um dos discos quebrar ou tiver indisponível, eu tenho o meu dado no outro disco preservado.

[07:50] Claro que essas configurações de hardware, elas vem muito com a experiência do profissional e o pessoal de infraestrutura e de suporte, eles podem ajudar muito o DBA a desenhar o melhor ambiente para o banco de dados MySQL, mas aí, novamente falando sobre nuvens, hoje em dia, a gente usa muito a nuvem para criar uma instância do MySQL.

[08:22] E aí, quando a gente fala de nuvem, da mesma maneira que a gente não precisa mais estar se preocupando em configurações de backup de ambiente, também performance, a gente não se preocupa mais, porque a gente tem dentro da configuração do MySQL na nuvem, seja ela na Amazon, na Azure ou na Google, você tem configurações de recursos de hardware que você vai reservar para o seu banco de dados MySQL.

[08:55] E aí, você consegue em maneira lógica, ir aumentando esses recursos, na medida em que seu banco vai sendo usado e aí, internamente, se eu estou usando RAID, quanto te RAM, se é RAID 0, RAID 1, RAID 5, isso tudo é transparente para mim, que na parametrização da nuvem está pedindo para que aquele MySQL utilize mais recursos.

[09:25] Então são esses comentários que eu gostaria de falar sobre a parte de tuning do MySQL, no que diz respeito a hardware. Valeu.


-----------------------------------------------------------------------
# 04Variáveis de ambiente

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58120

## Transcrição

[00:00] Uma outra forma de a gente melhorar a performance do nosso ambiente do MySQL é através das variáveis de ambiente. As variáveis de ambiente são variáveis que são declaradas na inicialização do ambiente MySQL e elas valem para várias coisas.

[00:22] Elas não só definem limites dentro dos bancos de dados, como também alguns parâmetros do tipo, a porta de comunicação, em que diretório a base de dados será criada e assim por diante, existem mais de 250 variáveis de ambiente, a gente não é nem obrigado a saber todas elas.

[00:44] E cada versão nova de MySQL, a lista dessas variáveis de ambiente sofre modificações, algumas variáveis novas são acrescidas, outras deixam de existir.

[00:56] Então é sempre bom, a cada versão nova do MySQL, se as variáveis de ambiente são importantes para você fazer a configuração do ambiente onde você está trabalhando, sempre de uma conferida na documentação para saber se aquela variável de ambiente está valendo ou não para a nova versão do MySQL.

[01:16] O comando Show Status, ele mostra a situação atual das variáveis de ambiente, então é uma forma de a gente verificar o valor dessa variável de ambiente e nós temos dois tipos de variáveis de ambiente, a global e a session.

[01:32] A global, ela vai valer para o MySQL todo, então quando eu modificar essa variável de ambiente, ela vale para todo o ambiente MySQL. Já a session vai valer apenas para a minha conexão, essas variáveis de ambiente, elas ficam armazenadas num arquivo externo chamado my.ini, se for Windows ou my.cnf, se a gente estiver falando de Linux.

[02:01] E dentro desse arquivo, nós temos duas diretivas, a MySQLD e a client, a MySQLD tem a ver com as globais e a client, tem a ver com as sessions e ali eu tenho um link mostrando onde eu consigo entrar a documentação dessas variáveis de ambiente.

[02:24] Então, vamos primeiro dar uma olhada, como é que é o formato desse arquivo my.ini, ele está localizado... deixa eu abrir uma... no explorador do Windows, ele está localizado nesse diretório programdata.

[02:45] Para vocês irem no programdata, vocês precisam digitar, porque normalmente o diretório programdata é um diretório escondido dentro do ambiente operacional, MySQL, MySQL Server 8.0, eu tenho o arquivo aqui my.ini. Eu vou abrir ele com o editor de texto.

[03:04] Então, eu tenho aqui a declaração de todas as variáveis aqui, uma variável aqui “max_connections=151”, pelo próprio nome diz, essa é uma variável que diz quantas conexões concorrentes eu posso ter no MySQL, então eu tenho no máximo 151 conexões concorrentes.

[03:31] Esse, por exemplo, é o que significa esse parâmetro. Aqui, “tmp_table_size=103M”, isso significa o tamanho máximo de tabelas temporárias que vão poder ser criadas em memória, é o que significa esse parâmetro, “tmp_table_size”.

[03:59] Vamos falar um pouquinho mais sobre essas tabelas temporárias, como um exemplo para a gente ilustrar como que as variáveis de ambiente, elas são importantes para a gente configurar a performance do MySQL.

[04:15] Mas antes disso, eu vou voltar aqui para a minha apresentação e eu vou mostrar também para vocês o link que eu coloquei aqui, para olhar a documentação dessas variáveis de ambiente. Então, note, eu entrei aqui na página do MySQL e note, se eu arrastar aqui, eu tenho muitas variáveis de ambiente aqui criadas.

[04:41] Cada uma delas... vou pegar uma aqui aleatoriamente, “disabled-storage-engines”, então diz aqui o que que significa a variável de ambiente, que escopo ela é, se ela é global ou session, o tipo dela, um valor default, ou seja, se ela não for declarada, se ela é inicializada ou não e com que valor ela vai ser inicializada.

[05:10] Então, usar essa documentação aqui é super importante para você saber se aquela variável de ambiente que você trabalha, está valendo ou não. Vamos então voltar para aquele exemplo das tabelas temporárias, para a gente ver como é que a gente pode usar tabelas... como que é a configuração de tabelas temporárias pode mexer com a performance.

[05:33] Eu vou entrar aqui no meu MySQL e aí, eu vou aqui... deixa eu ver aqui nas minhas anotações, ok. Eu vou fazer o seguinte, eu vou colocar aqui “Show Global Status Like – eu vou colocar uma variável que é a – ‘Created_tmp_disk_tables’”.

[06:13] Então eu tenho Created_tmp_disk_tables está com o valor 0. Eu tenho uma outra variável, é a LIKE... Created_tmp_tables, vamos olhar o conteúdo dela, eu tenho aqui 290. Deixa eu rodar as duas, vamos explicar um pouquinho o que que é isso. O que que é uma tabela temporária dentro do MySQL? [06:49] Toda a vez que eu fizer um join, um group by ou seja, quando eu fizer uma consulta um pouco mais rebuscada, o MySQL automaticamente vai criar tabelas temporárias lá dentro, para poder fazer essas contas e essas tabelas temporárias, elas são criadas em memória.

[07:10] Claro, porque se eu estou fazendo uma consulta, é preciso juntar, somar, fazer cálculos em cima (quare) que eu estou executando, eu jogo sem memória porque é muito mais rápido. A variável created tmp tables, mostra para mim o número de tabelas temporárias que foram criadas e que estão em memória.

[07:42] Então eu tenho aqui 292 tabelas temporárias criadas em memória e o primeiro comando vai me mostrar quantas tabelas temporárias eu tenho criada em disco, é a variável Created_tmp_disk_tables, o que acontece?

[08:03] Existe uma variável global que diz o número máximo de memória que eu posso gastar para criar tabelas temporárias, essa variável, eu ainda vou mostrar para vocês qual é.

[08:18] Se eu começar a fazer muita consulta com group by, order by, joins, assim por diante, se esse limite de tamanho de tabelas temporárias que eu posso criar em memória estourar, ele começa a criar essas tabelas temporárias e disco, ele tem que resolver a consulta para mim.

[08:41] Só que quando ele começar a fazer a criação dessas tabelas temporárias em disco, vai ficar mais lento, porque eu tenho que escrever e ler do disco, o que... eu estou vendo aqui, rodando essas duas (quares), é que por enquanto eu tenho 295 em memória e não tenho nenhuma em disco, o que significa?

[09:08] Que o espaço que eu reservei para trabalhar com tabela temporária está legal, está satisfatório, porque se não tiver satisfatório, eu teria tabelas temporárias criadas em disco.

[09:22] É claro, esse meu MySQL eu acabei de instalar, eu abri ele agora, não fiz nenhuma (quare), por isso que o número de tabelas temporárias em disco está 0 e o número de tabelas temporárias em memória está até baixo, mas vamos supor que eu tivesse encontrado na Created_tmp_disk_tables um número grande, o que isso significa?

[09:48] Que eu estou gastando disco para gerar tabela temporária, com certeza as consulta, as (quares) que os sistemas ou os usuários estão fazendo no meu ambiente estão lentas, porque eu estou gastando tempo escrevendo e lendo de disco, então o que que eu posso fazer?

[10:10] Eu posso aumentar a variável que diz: “Eu vou reservar mais memória do meu hardware para a criação de tabelas temporárias, porque o que eu tenho reservado no momento, não é suficiente”, como é que eu sei qual é o valor dessa variável de memória?

[10:35] Eu venho aqui e posso escrever aqui, “Show Global Variables Like”, e aí, a variável que eu estou achando é a tmp underscore, table underscore, size. Essa variável tmp table size, que é justamente aquela que eu mostrei para vocês, quando eu mostrei o arquivo “ini”, cadê ele aqui?

[11:11] É essa variável aqui. Ela é definida quando eu inicializo o MySQL com 103M, 103M, traduzindo para bytes, vai dar esse número aqui, dá 108 milhões de bytes. Ok, com 108 milhões de bytes, eu tenho 0 tabelas criadas no disco, então esses 108 milhões de bytes ou 103... foi isso mesmo?

[11:48] Isso, 103, desculpe, 103M é o suficiente, mas vamos supor que não fosse suficiente, digamos que eu tivesse muita tabela em disco escrita, eu poderia então vir aqui no MySQL e aumentar o parâmetro tmp table size.

[12:07] Então eu posso fazer o seguinte: “Set Global tmp_table_size = ...” e aí eu posso colocar aqui, por exemplo 208003328. Ao fazer isso, se eu olhar agora o tamanho dessa variável, note que eu aumentei, aumentei em 100 milhões de bytes.

[12:42] Então, eu fui para, se eu não me engano, 203M de espaço de RAM, reservado para tabela temporária. Se eu tivesse muita tabela temporária em disco, ao fazer esse parâmetro aumentar, as próximas consultas não vão mais gravar em disco, porque eu reservei um tamanho maior na memória.

[13:08] Então as tabelas temporárias vão voltar a serem criadas na memória, aumentando a performance do meu ambiente. É claro que quando eu faço isso, todas as conexões passam a olhar esse parâmetro maior, porque essa variável, ela é global.

[13:32] Mais uma coisa importante, eu tenho ela definida aqui na inicialização, no my.ini, o que que vai acontecer? Eu aumentei, mas se eu chegar, parar o serviço e subir ele de novo, aí essa variável volta a valer 103M, ou seja, essa modificação que eu fiz aqui, ela está valendo enquanto o meu servidos MySQL estiver no ar, estiver funcionando.

[14:06] A hora que ele parar e subir de novo, vai valer o que está no my.ini, então o que eu teria que fazer talvez, é vir aqui, aumentar também esse parâmetro aqui, para que quando eu parasse o servidor e subisse ele novamente, o parâmetro tabelas temporárias fosse aumentado.

[14:33] Eu quis dar um pequeno exemplo, existem inúmeros outros exemplos, que mexendo com as variáveis de ambiente, eu consigo aumentar a performance, isso tudo vai depender da forma com que eu estou configurando o meu MySQL e a forma com que ele está se relacionando com o hardware que está disponível para ele estar executando.

[15:04] Então é isso aí. Valeu.


-----------------------------------------------------------------------
Qual comando é usado para ver o valor de uma variável global?

SHOW GLOBAL VARIABLES LIKE 'nome_da_variavel';
SHOW GLOBAL STATUS;
SHOW GLOBAL STATUS LIKE 'pattern';

 sua resposta está correta, parabéns! Os comandos `SHOW GLOBAL VARIABLES LIKE 'nome_da_variavel';`, `SHOW GLOBAL STATUS;` e `SHOW GLOBAL STATUS LIKE 'pattern';` são utilizados para visualizar o valor de variáveis globais no MySQL. O comando `SHOW GLOBAL VARIABLES` exibe os valores de variáveis globais, enquanto o comando `SHOW GLOBAL STATUS` exibe informações de status do servidor. Continue se dedicando aos estudos!

-----------------------------------------------------------------------
# 06Mecanismo de armazenamento MyISAM

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58121

## Transcrição

[00:00] Vamos falar um pouquinho sobre mecanismos de armazenamento, esses mecanismos de armazenamento que existem no MySQL, são um dos recursos mais exclusivos do banco de dados, ele tem a ver com a forma com que o dado é guardado dentro das tabelas e o MySQL disponibiliza cerca de 20 diferentes tipos de mecanismos de armazenamento.

[00:31] Então, como eu falei, ele é um mecanismo que gerencia a forma com que o dado é gravado em tabelas e a gente pode ter num mesmo banco de dados, diferentes tipos de mecanismos diferentes, como ele é aplicado a nível de tabela, as vezes a gente confunde muito o mecanismo de armazenamento com um tipo de tabela.

[00:57] A gente pode chamar assim mesmo, quando a gente se refere a um mecanismo de armazenamento, na verdade, nós estamos falando de um tipo de tabela diferente do meu banco de dados.

[01:08] Nas instruções de criação de tabela e de alteração de tabela, respectivamente os create tables e os alter tables, nós temos uma opção chamada engine, onde eu posso definir ou alterar o mecanismo de armazenamento que aquela tabela respectiva vai ter.

[01:33] Uma outra característica interessante é que o mecanismo de armazenamento da tabela, ela está... não está associada com a arquitetura interna do MySQL, separando, justamente a forma com que eu tenho o (core) do banco de dados, com a forma com que eu vou armazenar a informação dentro da tabela.

[02:02] Apesar de a gente ter esses 20 diferentes tipos de mecanismos de armazenamento, normalmente a gente trabalha com três principais, é o MyISAM, o InnoDB e o MEMORY. Vamos falar então um pouquinho do que que é o MyISAM.

[02:23] O MyISAM, ele é, na verdade, o mecanismo padrão do MySQL, inclusive, as tabelas internas do MySQL são armazenadas usando MyISAM. Ele é um mecanismo bem confiável e ele herdou do mecanismo original, que foi implementado nas primeiras versões do MySQL, que era o mecanismo chamado de ISAM.

[02:54] E a partir da versão, crio que 3.2 do MySQL, eles substituíram o padrão original ISAM, para o MyISAM, qual é a característica principal do mecanismo MyISAM? Ele não é um mecanismo puramente transacional, ele não implementa mecanismos de bloqueio dos registros dentro das tabelas.

[03:25] O tipo de bloqueio que o MyISAM faz quando uma tabela está sendo atualizada, é um (lock) na tabela como um todo, isso permite com que a tabela seja muito mais rápida, se eu quiser, por exemplo, usá-la para efetuar somente leituras, mas aí, você tem um problema.

[03:49] Se você tiver muita gravação simultânea, por diferentes usuários, diferentes sessões dentro do banco, como esse controle não é tão específico, a gente pode ter problemas usando tabelas MyISAM, por isso nós temos que tomar cuidado.

[04:11] Então, algumas características específicas do MyISAM, para a gente decidir que tipo de forma de tabela a gente vai utilizar, por exemplo... Então, se eu tiver uma tabela que não vai ter muitas transações, eu posso usar MyISAM.

[04:29] O MyISAM tem uma característica que a chave estrangeira não suporta o tipo FULLTEXT, que é um tipo de dado específico da tabela. Quando a gente cria um cache de dados ou um cache de índice, a gente nunca pode se referenciar a ele através do nome.

[04:49] Nós temos uma vantagem que o MyISAM implementa dois tipos de forma de índice, que é o HASH e o BTREE, a gente vai falar um pouquinho sobre eles mais a frente, como eu já falei, o MyISAM, ele implementa bloqueio a nível de tabela, isso faz com que a atividade de leitura seja muito rápida, quando você usa o MyISAM.

[05:10] Então ela é muito específica para bancos de dados, que nós chamamos de Data Warehouse, ou seja, bancos de dados gerenciais de consulta e internamente, os dados que são armazenados dentro das tabelas do MyISAM, já são automaticamente armazenados de forma compacta, melhorando o tamanho do banco de dados, quando eu tenho muita informação.

[05:38] Lembra que a gente falou sobre variáveis de ambiente? Existe algumas variáveis de ambiente que são diretamente ligadas ao MyISAM. A primeira variável é o key_buffer_size, o key_buffer_size, ele determina, esse parâmetro, o tamanho de cache que a gente vai usar para armazenar os índices do MyISAM.

[06:07] Dependendo do sistema operacional, se eu estiver usando 32 bits ou 64 bits, esse padrão pode ir desde 8MB, até 4GB. Um outro parâmetro importante é o concurrent_insert, é outro parâmetro que a gente pode estar especificando lá no my.cnf ou no my.ini, que é o arquivo de inicialização do MySQL.

[06:36] Esse parâmetro determina o comportamento das inserções concorrentes dentro de uma tabela MyISAM. Existe uma variável chamada: intervalo de dados, que é uma espera que MySQL faz entre a inserção de um dado e de outro dado. Se essa variável concurrent_insert for igual a 1, você consegue fazer inserções simultâneas, sem intervalo de dados.

[07:06] Se a configuração for igual a 0, a gente desativa as inserções simultâneas, ou seja, uma inserção sempre vai esperar a tabela ser liberada para funcionar e quando tiver a configuração número 2, eu permito a inserção simultâneas com um intervalo de dados ativado.

[07:28] Outra variável é a delay_key_write, a gente usa essa variável para criar um atraso entre a atualização dos índices e o momento que a tabela é fechada, por exemplo, quando eu faço uma inserção de dados, se eu usar o delay_key_write, o MySQL vai esperar todas as inserções serem efetuadas, para depois fazer uma atualização dos índices.

[08:02] Isso cria, claro, uma melhor consistência no dado dentro do banco de dados, porém, isso cria uma lentidão um pouco maior no momento da atualização da informação. O padrão do MyISAM é essa variável delay_key_write, com o valor igual a 1.

[08:28] Então, quando eu crio automaticamente uma tabela do tipo MyISAM, automaticamente o delay_key_write vai estar ativado, se eu quiser melhorar um pouco a performance dos inserts, eu devo ir lá na configuração e colocar essa variável delay_key_write como off.

[08:50] Nós temos também a variável max_write_lock_count, essa variável de ambiente, ela determina quantas gravações em uma tabela vão ter precedências às leituras, ou seja, quando tiver gravações e leituras ao mesmo tempo, qual vai ser a prioridade da inclusão de dados na tabela, em relação às leituras.

[09:28] E a gente tem uma outra variável, que é a preload_buffer_size, essa variável, ela determina o tamanho do buffer que vai ser usado no pré carregamento do índice de caches de chaves da tabela. O padrão dessa variável, normalmente, é 32KB.

[09:55] Claro que o uso dessas variáveis de ambiente vai vir com o tempo, na medida em que o administrador do MySQL começa a entender melhor o seu ambiente, entente melhor os mecanismos de MyISAM e pode mexer com essas variáveis.

[10:15] Mas a minha experiência diz o seguinte, use sempre o padrão, quando você cria uma tabela do tipo MyISAM, você deve apenas levar em consideração se o seu caso, ele está dentro dessa opções aqui, específicas, para determinar se você vai usar o MyISAM ou não como tipo de tabela.

[10:44] O que nós estamos vendo aqui, são três utilitários que existem dentro do MySQL, para a gente poder manipular tabelas do tipo MyISAM. A gente tem um primeiro aplicativo que é o myisamchk, ele é usado para a gente poder analisar, otimizar e reparar tabelas MyISAM, pode ser que as tabelas estejam mal construídas, algum problema no seu armazenamento interno.

[11:16] Então o myisamchk, reconstrói essas tabelas. O myisampack, ele é usado para a gente poder criar tabelas MyISAM compactadas, que vão ser só usadas para leitura, nada mais. São tabelas que a gente, durante o uso do aplicativo, a gente cria elas, coloca informação e elas não vão poder sofrer nenhum tipo de insert.

[11:43] Claro que essas tabelas vão ter mecanismos de controle de escrita, praticamente nulos, praticamente inexistentes, fazendo com que a performance da leitura seja muito rápida.

[11:57] E um outro aplicativo é o myisam_ftdump, que é usado para a gente poder exibir informações sobre os campos do tipo texto, que eu tenho dentro do MyISAM, ele fornece uma informação mais completa sobre esses campos.

[12:14] Então, tá, era mais ou menos isso que eu gostaria de falar para vocês, sobre os tipos de tabela MyISAM. Valeu.


-----------------------------------------------------------------------
# 08InnoDB e Memory

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58122

## Transcrição

[00:00] Agora vamos falar do InnoDB. O InnoDB é um mecanismo de armazenamento usando quando eu vou realmente ter um banco de dados transacional.

[00:12] Quando eu falo banco de dados transacional, eu estou imaginando um banco de dados onde eu tenho uma aplicação, onde eu tenho dezenas, centenas ou milhares de usuários fazendo inclusões, alterações, exclusões e consulta de dados naquele banco ao mesmo tempo.

[00:32] É uma forma diferente, quando eu falo de bancos de dados gerenciais, onde durante um período, eu faço uma carga grande desse banco e depois os usuários apenas consultam as informações. Nesse caso, o MyISAM, ele é mais direcionado.

[00:51] Já para bancos de dados com várias transações, a gente aconselha usar o mecanismo de armazenamento InnoDB e foi o InnoDB que trouxe para o MySQL o suporte a transações relacionais, até versões anteriores, quando não utilizavam esse tipo de mecanismo, o MySQL não era full transacional.

[01:17] Então, claro, algumas características do mecanismo de armazenamento InnoDB. Claro, suporte completo ao banco de dados transacional, o bloqueio da tabela durante uma atualização, ele é feito a nível de linha.

[01:38] Ou seja, quando eu atualizo um informação, aquela linha está bloqueada, mas a tabela toda está liberada para sofrer outras alterações e também tem suporte completo à chaves estrangeiras.

[01:56] Em termos de índice, o InnoDB só utiliza índice do tipo BTREE, eu ainda não estou explicando para vocês o que é um índice e quais são os seus tipos, mas a gente já vai adiantando que InnoDB só suporta BTREE.

[02:13] Para a gente configurar um cache de buffer, para poder ele agilizar os seus processos internos, no caso de um banco de dados InnoDB, a configuração do cache, tanto para o banco, quanto para o índice, pode ser feita de formas separas, diferente, por exemplo, do MyISAM.

[02:35] E eu consigo, através de bancos InnoDB, fazer um backup do banco sem bloqueá-lo, sem precisar tirar ele do ar para fazer isso. Nós temos algumas variáveis de ambiente, as três primeiras, elas estão relacionadas com as tabelas.

[02:59] A gente tem o Innodb_data_file_path, que determina o caminho dentro do sistema operacional, onde as informações serão armazenadas e o tamanho desses arquivos máximos. O InnoDB, ele armazena as informações através de um arquivo que vai crescendo e depois quando ele acaba, ele vai criando um outro arquivo com sufixo 1, 2, 3 e assim por diante.

[03:30] O local desse arquivo e o tamanho máximo de cada parte do arquivo é determinado através desse parâmetro. Um outro parâmetro é o innobd_data_home_dir, como o próprio nome diz, ele é feito para dizer qual é o caminho comum de diretório de todos os arquivos InnoDB.

[03:54] Se eu especificar esse cara, ele vai gravar tudo dentro desse diretório, diferente do default, o default, o padrão, ele vai gravar tudo dentro de um diretório chamado MySQL Data, que é o padrão do armazenamento de dados de um banco de dados MySQL.

[04:18] A gente tem o Innodb_file_per_table, a gente pode especificar cada tabela de armazenamento InnoDB, os arquivos que armazenam as informações, eles tem uma extensão “.ibd”. E aí, quando a gente usa esse parâmetro Innodb_file_per_table, a gente consegue separar o armazenamento dos dados, com os índices.

[04:55] O padrão é que a gente armazene essas informações num espaço compartilhado, com essa variável de ambiente, a gente consegue separar o armazenamento do índice e também do dado. Já as três últimas variáveis que estão aqui nesse slide, ele diz respeito a variáveis que estão relacionadas com performance.

[05:20] A primeira variável, que é a Innobd_buffer_pool_size, ela determina o tamanho de buffer que o mecanismo de armazenamento InnoDB, vai estar usando para armazenar dados e índices em cache. Quando a gente utiliza cache, a gente está falando de coisas que ficam em memória que melhoram a performance.

[05:43] Já a variável de ambiente Innodb_flush_log_at_trx_commit, nome grande, ela vai configurar a frequência com que o buffer de log é liberado para o disco. Na medida em que a gente vai usando o banco, esse buffer de log vai crescendo e de tempos em tempos, ele é descarregado para o disco rígido.

[06:11] Então essa variável vai dizer a frequência com que isso vai ser feito. Finalmente, a innodb_log_file_size, ele vai determinar o trabalho em bytes que cada um dos arquivos de log (InnoDB) vão ter. O padrão dessa variável, quando você não menciona nada, é ter um log de no máximo 5MB.

[06:38] Essa variável vai dizer se o tamanho desse log vai ser maior ou menor por arquivo, isso não significa que o log terá 5MB ou mais ou menos, significa que cada arquivo de log, será criado de 5 em 5MB.

[07:01] Vamos agora falar de outro mecanismo de armazenamento, que é o Memory e como o próprio nome diz, o Memory, ele é um mecanismo de armazenamento que cria tabelas apenas na memória, quando eu falo memória, eu estou falando apenas na memória RAM.

[07:24] E aí, claro, se a informação... se a tabela está lá na memória RAM, isso significa que o acesso a ela é super rápido, porém tem uma desvantagem, essa informação, ela não fica armazenada no disco. Os dados, eles precisam ser sempre reinicializados quando o servidor é inicializado.

[07:51] Ou seja, eu inicializei um servidor, as tabelas de Memory estão vazias, se eu for criar tabelas e colocar dados em memory, eles vão ficar lá até o servido ser reinicializado novamente. Se isso acontecer, se houver uma reinicialização, os dados são perdidos.

[08:12] Nós temos algumas características dos bancos em memory, das tabelas em memory. Não tem chave estrangeira. É claro, o ato de ler e escrever dados nas tabelas memory são muito rápidos.

[08:31] Claro, porque a informação está em memória e o bloqueio é muito parecido com o MyISAM, ou seja, quando eu vou bloquear algum registro, porque eu estou atualizando ele, eu bloqueio a tabela toda.

[08:48] Em termos de índices, o Memory, ele também utiliza os mecanismos de HASH e de BTREE, mas o padrão é o HASH, novamente, índices eu vou falar mais a frente o que significa.

[09:06] Mas a gente já viu, tanto nesse vídeo, quanto no anterior, que o padrão MyISAM, InnoDB e Memory, possuem alguns tipos de índices que são suportados e alguns tipos de índices que são padrões. As tabelas de Memory, elas têm uma característica específica para armazenar o dado.

[09:32] Eles usam um formato que no MySQL, nós chamamos de formato de linha de comprimento fixo, então, por causa disso, eu não posso ter tipos de campos muito grandes, como por exemplo, tipos Blob ou tipos Text, ou seja, campos que são muito... são campos que tem tamanho muito grande, que armazenam muitos caracteres.

[09:58] Então era isso que eu queria falar para vocês sobre as tabelas do tipo InnoDB e Memory. Valeu.


-----------------------------------------------------------------------
# 10Usando os mecanismos de armazenamento

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58123

## Transcrição

[00:00] Vamos ver na prática um pouquinho como é que funciona durante a manipulação de tabelas, os mecanismos de armazenamento. Então, eu vou criar aqui um script novo, eu entrei aqui no MySQL Workbench e eu vou usar esse banco aqui, o sakila, que é um banco de dados padrão que vem, quando a gente instala o MySQL.

[00:26] Eu vou criar uma tabela: “Create Table”, é o comando para criar tabela, “Default_Table”, vai ser o nome da tabela, a gente quando viu o curso de manipulação de dados ou curso de consulta avançada e até o curso de introdução, a USQL, usando o MySQL, a gente já viu o comando Create Table.

[00:54] Mas a gente não viu esse mecanismo de armazenamento, ou seja, especificar qual é o mecanismo de armazenamento que uma tabela vai usar. Estou criando a tabela, eu vou criar um campo ID que inteiro, “Integer” e um campo, nome, que eu vou colocar como “Varchar (100)”.

[01:23] Não estou especificando nada, não estou falando qual é o mecanismo de armazenamento que essa tabela vai usar, eu simplesmente vou rodar o comando.

[01:33] Se eu vier aqui no meu banco sakila, botão direito do mouse dou um Refresh e vou ver aqui que eu tenho a minha default_table e aqui do lado, eu tenho um campinho que me dá a informação sobre essa tabela. Eu vejo os campos, os índices, as chaves, tudo mais.

[01:50] Bem, eu vou clicar aqui no “i” e aí note que ele tem esse parâmetro aqui: Engine InnoDB, o que significa? Significa que se eu não falar nada, automaticamente o MySQL vai criar uma tabela do tipo InnoDB.

[02:11] Ou seja, vai preparar a minha tabela para um banco de dados relacional, que vai suportar muitas transações, que vai fazer o controle da transação por linha, banco que está sendo preparado para ser usado numa aplicação que vai ter muitos usuários acessando ao mesmo tempo, incluindo, alterando, excluindo ou consultando informação.

[02:41] Mas eu posso, se quiser, alterar esse mecanismo da tabela, mesmo com a tabela criada a inclusive, mesmo com a tabela com dados. Se eu pegar esse comando aqui, vou colar aqui, só que... Não, não vou fazer isso, desculpe, vou alterar o mecanismo.

[03:04] Então, eu uso o “Alter Table”, coloco aqui o nome da tabela e aí, o parâmetro é engine, se eu botar aqui “EnGINE = MySAM”, vamos olhar aqui, eu coloquei aqui “Engine = MySAM”, essa tabela default table que originalmente é InnoDB, se eu rodar esse comando, vier aqui e olhar a informação da tabela, note que ela agora ficou MySAM.

[03:39] Ou seja, agora é uma tabela que vai estar locando a tabela toda quando eu for alterar uma coisa nela, é uma tabela que fica mais rápido para leitura, mas que pode não se dar bem, quando a gente tiver muitas transações sobre ela, alterando ou incluindo coisas novas.

[04:04] Mas durante a criação da tabela, eu posso estar especificando o mecanismo de armazenamento, então agora sim, eu vou copiar aqui o comando de cima, vou criar uma tabela dois e aqui, depois da criação da tabela, eu posso colocar o engine, por exemplo, memory.

[04:29] Ou seja, eu estou forçando e especificando que durante a criação da tabela, essa tabela vai ser do tipo de memória, memory. Eu vou selecionar a linha, rodei, atualizo aqui o meu banco, as tabelas do meu banco, então eu tenho aqui o meu default table 2, botão direito do mouse.

[04:52] Não, na verdade, não, clicando no table 2, eu vou clicar no “i” de informação e eu tenho aqui o meu padrão memory. A gente viu e eu falei sobre o InnoDB, o MyISAM e o Memory, que são os mais utilizados.

[05:11] Mas por exemplo, se eu clicar aqui em tables, botão direito do mouse e usar a opção create tables, ou seja, eu vou ver a caixa de diálogo, de criação de uma tabela, para eu poder criar tabela, não necessariamente por comando.

[05:28] Note que ao selecionar essa caixa de diálogo, a opção engine aqui em cima, ela já vem InnoDB selecionada, porque é o padrão, é o default do MySQL criar tabelas do tipo InnoDB, mas note, eu tenho uma gama de outras formas de... outros mecanismos de armazenamento que a gente pode estar utilizando.

[05:54] A gente viu o InnoDB, o MyISAM e o Memory, eu dei ênfase a esses três tipos, desse treinamento porque são os mais usados, mas eu tenho aqui uma série de outros tipos de mecanismos, que tem propriedades específicas.

[06:11] Claro que você tem uma vasta documentação no MySQL e você pode depois dar uma lida sobre o que significa cada um e a principal característica desses mecanismos de armazenamento, para ver qual é a situação que eles vão mais se adaptar ao seu caso.

[06:34] Então era isso que eu queria mostrar a vocês sobre o mecanismo de armazenamento. Valeu.

-----------------------------------------------------------------------
# 12Consolidando o seu conhecimento

Chegou a hora de você pôr em prática o que foi visto na aula. Para isso, execute os passos listados abaixo.

1) As variáveis que estão declaradas no **C:\ProgramData\MySQL\MySQL Server 8.0\my.ini** serão inicializadas com os valores declarados no arquivo sempre que o MySQL for inicializado.

2) [Aqui](https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html), você pode ver a documentação de inúmeras variáveis de ambiente.

https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html

3) O valor das variáveis durante a seção pode ser vista pelo Workbench. Entre no Workbench e, na base de dados **sakila**, digite no editor de comandos SQL:

```sql
SHOW GLOBAL STATUS LIKE 'Created_tmp_disk_tables';
```

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/02/image1.png)

4) Ainda na base de dados **sakila**, outra variável pode ser observada:

```sql
SHOW GLOBAL STATUS LIKE 'Created_tmp_tables';
```

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/02/image15.png)

Estas duas variáveis estão relacionadas com o número de tabelas temporárias que podem ser abertas durante uma seção em memória e em disco. Claro que isso influencia na performance do banco, caso seja necessário usar o HD para armazenar tabelas temporárias criadas pelo MySQL durante os comandos SQL.

5) A variável `tmp_table_size`, que foi inicializada pelo **my.ini**, tem o valor de 103 e ele pode ser visto pelo comando do WorkBench:

```sql
SHOW GLOBAL VARIABLES LIKE 'tmp_table_size';
```

6) A variável de ambiente pode ser modificada pelo usuário que tenha privilégios para isso. Para isso, novamente na base de dados **sakila**, digite o seguinte comando:

```sql
SET GLOBAL tmp_table_size = 208003328;
```

7) Assim, é possível modificar o valor desta variável e ignorar o que estava, inicialmente, especificado no **my.ini**.

8) Já sobre mecanismos de armazenamentos, durante a criação da tabela, é possível determinar qual mecanismo a mesma irá utilizar. Crie uma tabela, na base de dados **sakila**, conforme o comando abaixo:

```sql
CREATE TABLE DEFAULT_TABLE (ID INTEGER, NOME VARCHAR(100));
```

9) Se você for na tabela, na árvore de objetos do Workbench e clicar sobre o ícone de informações, verá as características de armazenamento desta tabela que foi criada:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/02/image45.png)

10) Você pode ver que, por padrão, as tabelas são criadas com o mecanismo de armazenamento **InnoDB**:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/02/image5.png)

11) É possível alterar a propriedade do mecanismo de armazenamento da tabela, com o comando:

```sql
ALTER TABLE DEFAULT_TABLE ENGINE = MyISAM;
```

12) Além disso, você pode definir o tipo de mecanismo de armazenamento que será usado na tabela no momento de sua criação. Para isso, digite:

```sql
CREATE TABLE DEFAULT_TABLE2 (ID INTEGER, NOME VARCHAR(100)) ENGINE = MEMORY;
```

13) Quando você cria uma tabela pelo assistente do Workbench, você pode ver a opção de seleção do mecanismos de armazenamento, sempre apresentando o **InnoDB** como padrão:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/02/image20.png)


-----------------------------------------------------------------------
# 13O que aprendemos?

Nesta aula, aprendemos:

- A importância das variáveis de ambiente
- Como modificar a variável de ambiente pelo Workbench
- O que são os mecanismos de armazenamento e os tipos principais, com suas características
- Como determinar o mecanismo de armazenamento no momento da criação das tabelas

-----------------------------------------------------------------------
# 02Criando a base de dados

o longo dos vídeos, o instrutor irá utilizar alguns arquivos específicos, que são necessários para o decorrer desta aula e do treinamento. Você pode baixar um ZIP com esse conteúdo [aqui](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/03/arquivos-aula-3.zip).

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58124

## Transcrição

[00:00] Vamos continuar estudando, vamos falar agora sobre base de dados, o MySQL, ele se organiza numa estrutura que nos chamamos de base de dados. Dentro dessa base de dados, nós vamos ter todos os elementos que compõem um banco, tabelas, índices, history procedures, triggers e assim por diante.

[00:23] Todas aquelas entidades que compõem um banco de dados vai estar dentro da base, se a gente olhar o nosso Workbench, note que do lado esquerdo nós temos a lista das bases, então eu tenho algumas bases aqui, não necessariamente no exemplo de vocês, vocês vão ter todas essas bases aí.

[00:45] E cada ícone desse aqui, significa uma base de dados, quando eu estou olhando um componente de uma base de dados, não significa que eu não consiga ver ele, estando em outra base de dados.

[01:04] Ou seja, eu posso, por exemplo, na base de dados “A”, fazer um select na base de dados... numa tabela que esteja na base de dados “B”, por exemplo, desde que a segurança permita isso. Como é que eu crio uma base de dados? Tem um comando muito simples, eu vou mostrar a vocês.

[01:30] Eu vou criar aqui um novo script e vou digitar, por exemplo, “Create Database Library”, um comando bem simples, ou seja, create database, eu estou criando a base de dados e library é o nome dessa base de dados.

[01:53] Se eu por acaso executar esse comando, o comando foi criado com sucesso e do lado esquerdo, se eu der botão direito do mouse e dar um Refresh, eu tenho a minha library criada.

[02:11] Eu poderia estar criando a base de dados também, usando a caixa de diálogo interna do Workbench, se eu der botão direito mouse sobre essa área vazia, eu tenho aqui uma opção chamada: Create Schema, ou seja, quando eu falar database ou Schema, eu estou falando a mesma coisa.

[02:35] Tanto é que existe o comando Create Schema, mas o comando Create Schema e Create Database faze a mesmíssima coisa. Então vamos lá, Create Schema, eu posso colocar aqui um nome, eu vou botar aqui library 2 e eu tenho dois parâmetros que podem ser escolhidos na criação da base de dados.

[03:01] Esses parâmetros, esses collations estão baseados na tabela (ASCII) interna que eu vou estar usando para armazenar principalmente campos textos, dentro dessa base de dados.

[03:16] Para quem não está muito familiarizado do que que é uma tabela (ASCII), para falar de uma forma bem reduzida, internamente o computador tem uma tabela numeral, que representa cada letra do teclado, ou seja, o “A” maiúsculo tem um número, o “A” minúsculo tem outro número e assim por diante.

[03:37] Quando, no começo da computação essa tabela (ASCII) tinham somente os caracteres que estão compatíveis com a língua inglesa, ou seja, “ç”, acento, “A” com acento, “A” com tio, isso não havia na tabela (ASCII) original.

[04:00] Então, começou-se a criar com o tempo tabelas (ASCII) estendidas, onde caracteres que originalmente não se encontram na língua inglesa, passaram a ser representados por um número e aí, você tem várias tabelas (ASCII) diferentes.

[04:19] Inclusive, umas que atendem outros idiomas, sem ser os latinos, idioma russo, grego, idioma árabe, ideograma chinês, japonês e assim por diante. Quando você está criando um banco de dados no MySQL, você pode definir qual é a tabela (ASCII) que você vai usar, ou seja, a língua que você vai estar representando os dados texto no seu banco de dados.

[04:54] Se você vier aqui, você pode escolher uma série de tabelas (ASCII) previamente definias, cada tabela dessa tem a sua representação de símbolos e aí, você pode... invés... se você não falar nada, você vai estar usando a Collation, ou seja, a tabela (ASCII) default do seu sistema operacional.

[05:26] Continuando, coloquei aqui o nome do banco de dados, eu clico no botão apply e aí, ele me representa aqui o comando que ele vai executar. Note, ele escreveu aqui “Create Schema” e o nome do banco que eu coloquei, mas Create Schema e Create database são as mesmas coisas.

[05:50] Então, se eu clicar aqui em apply, dou um finish e aí, pronto, eu tenho aqui o banco de dados library 2 criado. Então era sobre isso que eu queria falar um pouquinho para vocês, sobre criação de base. Valeu.

-----------------------------------------------------------------------
# 04Mudando a localização da base

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58125

## Transcrição

[00:00] Agora uma pergunta, eu criei base de dados, agora, aonde elas foram criadas dentro da minha máquina? Em que diretório? Vamos fazer o seguinte, deixa eu fechar essa aba aqui e eu vou criar um novo script.

[00:17] E é o seguinte, eu vou colocar, eu vou executar um comando para mostrar algumas variáveis de ambiente, que tenham a palavra “dir” no meio delas, então vou botar aqui “Show Variables Where Variable_Name Like” e eu vou procurar por: %dir.

[00:50] Note, eu tenho aqui vários diretórios, mas o diretório importante que eu gostaria de passar para vocês é esse aqui, datadir, o datadir é o diretório que diz aonde as minhas bases serão criadas fisicamente dentro do meu disco. Se a gente copiar aqui esse caminho e eu abrir aqui o meu explorando do Windows, eu vou colar aqui e vou dar um “Enter”.

[01:24] Então note, eu tenho esse diretório aqui, é um diretório onde eu tenho uma pasta para cada banco de dados criado e dentro de cada pasta, eu tenho os arquivos que compõem o banco de dados. Agora, e se eu quiser mudar o caminho desse banco?

[01:49] Por padrão, ele está colocando no mesmo diretório onde está instalado o MySQL, o diretório chamado programdata, mas pode ser que esse diretório C, ele esteja muito cheio, tenha pouco espaço, eu preciso fazer com que o diretório padrão do MySQL seja um diretório diferente do que está localizado no mesmo disco onde o software está instalado.

[02:18] Então, vamos fazer essa mudança, essa variável aqui, datadir, ela está localizada naquele arquivo my.ini, lembrando-se, o my.ini é o arquivo de inicialização de variáveis. Vamos olhar esse arquivo, o my.ini, ele normalmente fica no programdata, MySQL, MySQL Server 8.0.

[02:57] Então eu tenho lá o arquivo my.ini. Se eu abrir ele com um Notepad, um editor de texto qualquer, vou procurar essa variável aqui, ela deve estar aqui, datadir, note que pelo o padrão, o datadir é aquele diretório onde a base se encontra.

[03:20] Vamos fazer o seguinte, vamos mudar o valor dessa variável e aí, criar os nossos dados em outro diretório diferente do diretório padrão que é esse que está aqui destacado aqui em cima. Então, para eu não perder essa configuração, eu vou botar aqui um jogo da velha na frente do comando, que representa um comentário.

[03:48] E vou colocar aqui datadir = ... eu vou escolher aqui um diretório meu aqui, deixa eu ir aqui em outra pasta, eu vou ver aqui no meu C, Tempo, que eu já tenho até um diretório Data aqui, deixa eu apagar esse diretório. Então, na verdade, dentro do meu C Tempo, eu não tenho nada.

[04:17] Então eu vou criar aqui uma pasta chamada Data, dentro dessa pasta, eu não tenho nada e aí, claro, o meu diretório padrão vai ser esse daqui, então eu estou dizendo que a partir do momento que eu inicializar de novo o MySQL, o diretório de dados será o C, Tempo, Data.

[04:42] Para que essa variável tenha valor, eu tenho que parar o serviço e subir ele de novo, então eu vou fazer o seguinte, vou fechar aqui o Workbench, vou vir aqui em serviços do Windows.

[05:03] Então, eu tenho aqui os meus serviços da máquina e se eu for aqui na letra M, eu tenho aqui o MySQL, botão direito do mouse, vou clicar em parar, vamos esperar um pouquinho, o MySQL foi parado. Eu agora vou subir ele de novo, para que as variáveis de ambientes sejam lidas.

[05:31] As variáveis de ambiente subiram novamente. Eu cometi um erro aqui, deixa eu parar aqui. Eu não salvei o arquivo, o meu Notepad Plus, que é o Plus que eu uso, eu não salvei o arquivo, vou salvar agora o my.ini. Agora, o my.ini está salvo.

[05:59] Antes... eu acabei parando o serviço e subindo, carregando esse valor aqui antigo, mas agora está salvo. Então vamos lá, de novo aqui serviço, que está parado, eu vou inicializar. Agora sim, eu já... claro, eu já treinei esse exercício, eu já sabia que esse tipo que nós fizemos ia dar esse erro.

[06:24] O que que significa esse erro? Significa o seguinte, que o diretório Data está totalmente vazio, não tem nada, ele tem algumas tabelas internas de controle, que precisam estar no diretório Data para que o MySQL suba corretamente.

[06:42] Então eu vou fazer o seguinte, vou cancelar aqui, não vou subir o serviço, eu vou no diretório Data original, que é esse daqui, que é o programdata, MySQL, MySQL 8.0, Data, vou pegar essa pasta, vou copiar ela, copiem para a gente não perder a configuração original e vou colar lá no meu Tempo e substituir sobre a pasta Dara que eu tinha criado.

[07:21] Então agora na C, Tempo, Data, eu tenho aquela estrutura toda do banco MySQL. Agora vamos tentar subir o serviço de novo. Pronto, agora o serviço subiu, sem erros, olhando como diretório de dados o meu C, Tempo, Data e não mais aquele padrão que é especificado quando a gente instala o MySQL.

[07:55] Vamos então voltar, abrir o Workbench, abri, estou olhando tudo direitinho, se eu rodar de novo aquele comando do Show Variable, note que o datadir é C, Tempo, Data e se eu criar aqui uma outra base de dados, “Create Database Library3”, eu vou executar esse comando.

[08:39] O comando foi executando, dou um Refresh, na minha lista eu tenho lá Library3 criada e aí, claro, se eu vier no C, Tempo, no C, Tempo, Data, que é o meu novo diretório, eu tenho aqui o Library3 criado. Então agora o meu MySQL está olhando um outro diretório.

[09:05] Isso foi só um exemplo que eu quis mostrar a vocês, como é que a gente consegue estar manipulando dados num disco diferente do padrão, mas é claro que para a continuidade dos nossos exercícios aqui para frente, eu vou voltar essa configuração para o diretório original.

[09:29] Então, antes disso, eu vou fazer o seguinte, como no meu diretório aqui, eu tenho esse Library3 criado, só que ele não existe no programdata, porque eu criei ele, o Library3, quando o diretório padrão era o meu C, Tempo, Data, para não dar problema, eu vou fazer isso daqui: eu agora estou voltando para o que estava antes.

[09:58] Então, eu vou pegar esse diretório Library3, eu vou copiar ele e vou no C, programdata, MySQL, onde ele está? MySQL, MySQL 8.0, vou entrar aqui no Data e vou colar essa pasta aqui. Eu vou fechar o meu Workbench, vou parar o meu serviço, vou aqui no Notepad e voltar a configuração original, vou salvar, voltei para o serviços e vou iniciar.

[11:04] Iniciou corretamente, volto de novo ao Workbench. Aí, você vai perguntar: “Mas cadê o Lybary3?”, ele não apareceu, apesar de ter copiado o banco de dados fisicamente, era para aparecer aqui. É porque, na verdade, eu só copiei a data, mas o cadastro de dados do MySQL não foi copiado.

[11:45] O certo seria eu ter copiado toda a pasta Data de novo, porque aí, eu garanto que tudo está voltando a configuração original, quer ver? Então eu vou fazer isso, vou parar, vou parar o serviço de novo, vou no meu C, Tempo, Data, aqui, vou copiar e vou para o diretório programdata, MySQL, MySQL Server 8.0 e copiar a pasta Data.

[12:21] Claro que ele vai substituir quase todos os arquivos, eu vou dizer que “Ok”, substituiu, vamos subir o serviços. Subiu o serviços, abrimos o Workbench, eu agora estou vendo a minha Library3 aqui.

[12:49] Então isso é um cuidado que deve-se tomar, sempre transportando tudo o que está no diretório Dara, quando eu quero mudar de um disco para o outro. Isso aí, gente. Valeu.

-----------------------------------------------------------------------
# 06Apagando a base de dados

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58126

## Transcrição

[00:00] Claro que quem consegue criar base, pode também apagar base e atenção, esse processo de apagar base, ele é um processo muito radical, é importante que somente administradores do ambiente possam apagar bases e mesmo assim, depois que elas são apagadas, se você não fez um backup ou uma cópia dessa base antes, você acaba perdendo tudo.

[00:26] Então, eu posso apagar base de duas maneiras ou eu clico sobre a base, então eu cliquei aqui sobre a base Library3, botão direito do mouse, eu tenho a opção “Drop Schema”. Então, cliquei em “Drop Schema”, confirmo que vou apagar essa base e aí, ela é apagada.

[00:55] A outra maneira é através de linha de comando, eu clico aqui em novo script e eu posso escrever: “Drop Database Library2”, seleciono aqui o comando e executo.

[01:13] A base também já foi apagada. Se a gente for lá no diretório Data, no programdata, MySQL, MySQL 8.0, Data, porque agora eu voltei ao normal, não estou mais olhando no diretório Tempo, como eu fiz no vídeo anterior, notem que o diretório Library e Library2 foram excluídos aqui do diretório de bases do MySQL.

[01:41] Era isso que eu queria falar com vocês sobre apagar base.


-----------------------------------------------------------------------
# 08Realizando o backup com o mysqldump

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58127


## Transcrição

[00:00] Vamos falar um pouquinho de uma coisa muito importante, quando a gente fala de administração de um banco de dados que é o backup.

[00:09] O backup nada mais é do que uma cópia do meu banco de dados, que eu faço periodicamente para poder depois recuperar num momento futuro, caso, por exemplo, eu tenha algum problema na minha base de dados ou algum processo que faz... acaba destruindo, por exemplo, a base de dados, algum processo errado que o analista executou.

[00:40] Então eu preciso voltar o estado do banco a um determinado momento, então a gente pega o backup que foi tirado periodicamente, digamos assim, toda a meia noite eu tiro um backup e aí, eu pego e ele recupero. E aí, eu tenho duas maneiras principais de se fazer um backup.

[01:05] Uma é o que nós chamamos do backup lógico, o backup lógico, ele exporta todas as estruturas, tabelas, dados, rotinas que estão armazenadas num banco de dados, para um script de instruções SQL, que depois, esse script pode ser executado para recriar o estado do banco de dados.

[01:36] O backup lógico, ele tem a vantagem que pode ser manipulado externamente, antes de eu recuperar as informações, ou seja, eu posso abrir aquele script.sql e editar os comandos. Já o backup lógico tem uma desvantagem, ele acaba sendo muito lento, já que eu tenho que executar comando a comando para poder recuperar o meu backup.

[02:05] O outro tipo de backup é o backup físico, o backup físico é uma cópia que contém todos os arquivos de sistema, que o banco de dados usa para armazenar as suas entidades, ele representa o backup dos arquivos binários do disco, os arquivos que representam o banco de dados, que estão armazenados no HD do servidor.

[02:32] Para tirar o backup físico é muito rápido, basta fazer uma cópia desses arquivos e a sua recuperação também, ela é mais rápida. Embora os arquivos do backup físico não sejam muito bem compactados, já que os arquivos binários originalmente, eu não consigo compactar muito essa informação.

[02:58] Normalmente, o tamanho do backup físico é menor do que o tamanho do backup lógico, já que no backup lógico, eu tenho todos os comandos dentro de um script, enquanto que o backup físico, eu tenho o arquivo onde a informação está armazenado.

[03:18] Normalmente a gente chama também os backup físicos de backup bruto. O MySQL tem um aplicativo chamado: Mysqldump, ela é a ferramenta que nós usamos para executar os backups lógicos.

[03:41] Ele oferece uma variedade de opções para a gente incluir ou excluir banco de dados, selecionar dados específicos para o backup, fazer backup, por exemplo, somente do esquema, somente da estrutura ou somente dos dados, fazer backup de uma tabela específica, enfim.

[04:05] Eu posso selecionar pelo Mysqldump tudo aquilo que eu quero utilizar para salvar dentro do meu backup. Então isso é um pouquinho da teoria que eu gostaria de falar para vocês sobre backup. Vamos fazer agora alguns exercícios práticos, tirando o backup, através do backup lógico, usando o mysqldump.

[04:33] Então eu vou fazer o seguinte, vou lá no Workbench, tenho o meu Workbench aqui aberto e eu vou olhar esse banco de dados aqui, o sucos_vendas, que é um banco de dados que a gente recuperou no início desse treinamento, que nós vamos usar como banco de exemplo, para a gente fazer os nossos exercícios.

[04:55] Eu vou fazer um backup desse banco, usando o Mysqldump. Eu vou vir aqui e vou abrir aqui uma linha de comando e eu vou para o diretório onde o Mysqldump está instalado, então ele está em Program Files, MySQL Server 8.0, bin.

[05:28] E se eu digitar aqui Mysqldump, eu tenho o arquivo, claro que eu preciso colocar alguns parâmetros. Eu quero tirar o backup do banco de dados completo sucos_vendas.

[05:45] Então eu coloco: Mysqldump -uroot, eu coloco bem junto mesmo do “-u” usuário, “-p” e dou um espaço, eu não coloco a senha, porque a senha vai ser requisitada quando eu rodar o comando, menos, menos, dois menos, databases e eu colocar o nome o database que eu quero tirar o backup, sucos_vendas.

[06:19] E aí, eu coloco o sinal de maior e aonde eu vou salvar o arquivo de backup? Eu previamente, já criei aqui no meu computador um diretório chamado: C:\mysqladmin, esse nome pode ser como qualquer um.

[06:39] Crie um diretório vazio na máquina de vocês, onde dentro desse diretório, a gente vai salvar tudo aquilo que a gente for fazer que exigir arquivos externos. Eu criei aqui no meu “C”, um diretório mysqladmin, mas vocês podem criar aonde vocês quiserem, com o nome que vocês quiserem, desde que utilize esse nome dentro dos comandos.

[07:04] Então, voltando aqui, eu vou salvar o backup no C:\mysqladmin\ e vou colocar o nome de um arquivo, sucos_vendas_full.sql. Então está aqui, mysqldump, -uroot, -p vazio, a cláusula menos, menos databases, o nome da base, o sinal de maior e o arquivo externo.

[07:44] O nome do arquivo pode ser qualquer um, não precisa ser obrigatoriamente extensão “.sql”, só que esse arquivo vai ser um arquivo texto, que depois, eu vou poder rodá-lo com um script e aí, (igual) a todos os scripts de linguagem sql., a gente coloca como “.sql”.

[08:05] Vou executar. Vou dar “Enter”, ele vai me pedir a senha, coloquei aqui Root e aí, pronto, executou. Vamos olhar lá no diretório, então eu tenho aqui no diretório Mysqladmin, eu tenho esse arquivo sucos_vendas_full, sucos, underscore vendas, underscore full, “.sql”, vamos abrir esse arquivo com o editor de texto.

[08:35] Então eu vou abri-lo aqui, então eu tenho aqui uma série de comandos, onde eu tenho o create database, onde eu crio aqui a base de dados sucos_vendas, eu dropo a tabela itens_notas_fiscais, depois eu crio a tabela. Aí, eu loco a tabela, ou seja, deixo a tabela fechada para escrita.

[09:08] E aí, eu faço os comandos de insert, esses comandos de insert estão um do lado do outro, tem vários comandos de insert aqui. Esses comandos aqui, eu estou inserindo os dados que estavam na base de dados quando eu tirei o backup.

[09:25] Então vocês imaginam, se eu tiver uma tabela de milhões, 10 milhões, 20 milhões de registros, ele vai escrever 20 milhões de linhas de insert. Claro que são inserts agrupados, mas isso vai ocupar espaço, esse arquivo “.sql”, vai ser um arquivo muito grande, que as vezes, nem com editor de texto, a gente consegue abrir.

[09:52] Aí, eu tenho alguns comandos internos para setar variáveis internas, depois eu tenho a segunda tabela, notas fiscais, também tenho o comando create, tenho lá os inserts e assim por diante, ou seja, isso aqui foi criado automaticamente pelo meu processo de... por ter executado o Mysqldump.

[10:23] Vamos voltar então aqui para o ambiente de prompt, eu falei para vocês que a gente pode pelo Mysqldump, poder especificar que tipo de entidade a gente quer fazer o backup.

[10:40] Então, por exemplo, no comando que eu acabei de rodar, eu executei o backup, digamos assim, da base de dados toda, mas a gente pode executar um comando para fazer, por exemplo, o backup de apenas uma tabela. Então seria assim, mysqldump -uroot -p --, aí a cláusula é tables.

[11:13] Não, na verdade, desculpa, primeiro eu especifico a base, databases sucos_vendas, aí, agora sim, --tables, coloco o nome da tabela, então eu vou escolher a tabela de notas fiscais.

[11:34] E aí, eu coloco o sinal de menor e a saída, mysqladmin/sucos_vendas_ tab_notas_fiscais.sql, coloco aqui o root. Pronto, executei. Se eu olhar aqui, eu agora tenho um outro arquivo, note que esse arquivo é um pouco menor, porque claro, só tem informações de uma tabela e se eu abrir aqui ele com um editor de texto, eu só tenho aqui as informações de notas fiscais.

[12:21] Eu posso, por exemplo, gerar de todo mundo, menos de uma tabela específica, então aqui, mysqldump -uroot -p –databases sucos_vendas. Aí, eu uso, por exemplo, o comando ingnore table. E aí, eu vou colocar aqui, por exemplo, sucos_vendas.notas_fiscais.

[13:01] Quando eu estou me referenciando a uma tabela que eu vou ignorar, eu tenho que colocar o nome do banco, ponto, o nome da tabela, diferente quando eu quero somente aquela tabela. Quando eu quero só a tabela, eu coloquei aqui só o nome da tabela.

[13:17] Quando eu quero ignorar, eu coloco o nome da base, ponto o nome da tabela. Vamos salvar no diretório mysqladmin\sucos_vendas_ig (ignore)_tab_notas_fiscais.sql, root. Escrevi errado notas fiscais aqui, mas não importa, a gente vai salvar um arquivo externo.

[13:55] Pronto, vamos voltar lá para o diretório, tem lá já um terceiro arquivo, só vou aqui renomear e colocar aqui: fiscais, para ficar certinho. E eu posso, por exemplo, se eu quiser, eu posso salvar apenas as informações de, por exemplo, de dados, quero ignorar, por exemplo, toda a informação a respeito da estrutura da tabela.

[14:37] Então eu posso botar aqui mysqldump -uroot -p –databases sucos_vendas – no-create-db. Aí, ele já vai salvar um backup, lógico, que não criar base, -- no-create-info, não vai colocar as informações da base e por exemplo: --complete-insert, vou inserir todos os inserts das tabelas.

[15:23] E aí, vou salvar isso no c:\mysqladmin\sucos_vendas_somente_inserts .sql, root. Foi. Se eu olhar o arquivo, tenho mais um quarto arquivo que... somente inserts, se eu olhar, note que eu não tenho comando de create, eu simplesmente entro na base e insiro as informações de todas as tabelas.

[16:08] Eu poderia ficar aqui horas mostrando para vocês uma série de comandos que eu tenha para poder usar o Mysqldump numa série de parâmetros, mas a documentação do MySQL que eu tenho na internet, ela é bem detalhada e bem vasta, eu vou até mostrar aqui para vocês.

[16:31] Se eu colocar aqui: [https://dev.mysql.com/doc/refman](https://dev.mysql.com/doc/refman) – que é manual de referência – barra a versão, vou pegar aqui o inglês, mysqldump.html, eu acho que essa que é a URL. Eu tenho aqui todas as informações sobre o comando mysqldump.

[17:19] Se a gente arrastar aqui para baixo, olha só, eu tenho lá um montão de parâmetros, olha, “--add-drop-database”, adiciona o drop database antes de criar o database; “--add-locks”, coloca o comando lock tables. Se eu passar aqui o mouse, tem uma gama de parâmetros para o comando Mysqldump.

[17:50] E é claro, a gente vai consultar a documentação, quando a gente quiser fazer alguma coisa específica, “Poxa, eu quero fazer um backup que somente tenha dados, mas também (lock) tabelas”, então eu vou vir aqui e procurar uma combinação de parâmetros que me aquilo que eu estou interessado.

**Observação IMPORTANTE sobre a inserção de Rotinas e Stored Procedures em Bachups de BDs, a partir em versões mais recentes do MySQL(a partir da 8.0)**:![Insira aqui a descrição dessa imagem para ajudar na acessibilidade](https://cdn1.gnarususercontent.com.br/1/116846/b15ad214-90df-416c-80d1-e2a9919de769.png)

-----------------------------------------------------------------------
# 10Usando o Workbench para backup

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58128

## Transcrição

[00:00] Quando a gente tira o backup, pode ser que durante o processo de cópia, o banco de dados esteja sofrendo alguma atualização, seja por um sistema, por um processo e path ou qualquer outro meio. Tem gente acessando o banco, incluindo, alterando ou excluindo registros.

[00:23] Então é interessante que eu faça alguma coisa para que o banco fique congelado, antes de eu fazer o meu backup e depois liberar ele de novo para uso. Eu tenho um comando para congelar o banco e outro comando para liberar o banco novamente.

[00:45] Eu vou aqui no meu Workbench, eu tenho o banco então sucos_vendas selecionado e aí, eu tenho esse comando aqui, “Lock Intance For BackuP”, ao executar esse comando, o meu banco está fora, eu não consigo mais fazer coisa nele, eu deixei a minha instância trancada, inclusive lock significa trancar.

[01:24] E aí, eu posso fazer o meu backup nesse momento, seja pelo Mysqldump, seja pelo Workbench e para destrancar o banco, eu executo, “Unlock Intance”. Aí, eu destranco o banco. Mas vamos mostrar agora para vocês, como é que eu tiro o backup lógico, agora usando o Workbench.

[02:00] Claro que pelo Workbench, eu consigo executar coisas sem precisar digitar comandos, a vantagem do Mysqldump é que eu posso construir um arquivo (.bet) de comandos, para poder ser executado a noite, eu posso usar o próprio (scadole) para que aquele comando rode, por exemplo, todo o dia a 1h da manhã ou outro horário qualquer.

[02:29] E aí, eu posso criar uma rotina de backup automática. Tirar o backup pelo Workbench é uma coisa mais pontual, é até mais fácil, porque é tudo visual, mas é uma coisa que eu não consigo depois (esquedular) isso para rodar num determinado momento, mas aí, vamos ver como é que eu faço usando o Workbench.

[02:57] Eu vou trancar aqui o banco, então o banco está trancado, está lock e aí, eu vou aqui nessa aba aqui, administração. Clicando nessa aba, eu tenho aqui uma opção que é Data Export, eu vou clicar nela.

[03:19] E aí, eu tenho aqui a caixa de diálogo de exportação de dados, por causa da minha resolução da tela, porque para gravar os vídeos, eu preciso ter uma resolução baixa, para que a qualidade do vídeo fique boa, eu quase que não consigo ver a caixa de diálogos toda, porque esse botão de iniciar a exportação fica praticamente escondido.

[03:48] Mas se eu conseguir minimizar bem essa janela aqui de baixo, que é a janela de output, se eu puxar ela bem para baixo, eu consigo aqui ainda mexer no comando. Talvez no caso de vocês, vocês não precisem fazer isso.

[04:11] Então, eu tenho do lado esquerdo, todos os bancos de dados e eu vou escolher o banco que eu quero gerar o meu backup, então eu vou gerar aqui do sucos_vendas e aqui embaixo, eu vou escolher essa opção aqui, Export do Self-Contained File.

[04:36] E aí, eu posso dizer se eu quero incluir a criação do esquema, se eu quero inserir novos comandos, por enquanto eu vou manter isso aqui desabilitado e aqui eu vou botar o diretório C:\mysqladmin\sucos_vendas_full_ work, para dizer que eu estou gerando pelo Workbench, “.sql”.

[05:10] E vou clicar aqui o botão Start Export e aí, ele me gera a exportação do arquivo, se eu olhar aqui, não é aqui... Não, está aqui no C, mysqladmin, eu tenho o arquivo sucos_vendas_full_work.sql, se eu abrir com o editor de texto, eu vou ver o conteúdo praticamente semelhante ao que é gerado quando eu uso o mysqladmin... Desculpe, o mysqldump, o mysqladmin é o nome do diretório que eu criei, mysqldump.

[06:00] Então, eu tenho um arquivo semelhando ao gerado quando eu uso a linha de comando mysqldump. Só que ele também, o Workbench permite um outro tipo de backup, em que eu crio uma pasta e dentro dessa pasta, eu tenho vários arquivos para cada objeto do banco de dados.

[06:27] Então vamos fazer isso, eu vou de novo clicar em Data Export, vou selecionar o sucos_vendas, mas agora eu vou escolher essa opção: Export to Dump Project Folder e eu vou aqui no C:\mysqladmin\ e aí, aqui eu não vou colocar o nome de um arquivo, eu vou colocar o nome de um folder, eu vou botar aqui bkp_sucos_vendas.

[07:03] Clico em Start Export. Note que ele, na verdade, executou um processo para cada tabela, se a gente olhar aqui no diretório, eu agora tenho um subdiretório chamado bkp_sucos_vendas e aqui dentro, eu tenho como se fosse os scripts para estar criando cada tabela separadamente.

[07:34] Se eu abrir esse daqui, eu tenho aqui o script de criação, drop create da também insert dos dados, se eu abrir aqui o tab_faturamento, tem também ela, ou seja, eu tenho um sql para cada tabela, é como se eu tivesse rodado o Mysqldump, quando a gente coloca aquele parâmetro –tables.

[08:04] E aí, eu crio como se estivesse rodando um para cada tabela, essa opção do Workbench já cria uma pasta com todos os pontos sqls criados lá dentro. Claro que finalmente, depois que a gente termina de gerar o backup, eu destranco a instância.

[08:33] Vou rodar aqui. Rodou com sucesso aqui em baixo. Então, pronto, o meu banco já está pronto para ser consultado novamente, o meu backup está salvo. Então é isso aí, eu quis mostrar para vocês, além do uso do Mysqldump, como eu posso tirar o backup lógico através do Workbench. Isso aí. Valeu.


-----------------------------------------------------------------------
# 12Backup de arquivos

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58129

## Transcrição

[00:00] A maneira mais simples de fazer backup dos dados do banco de dados é simplesmente copiar os arquivos, os quais os dados são armazenados no meu HD ou em outro local. Em muitos casos, essa é uma das maneiras mais eficazes de executar o backup.

[00:25] Eu vou escrever a seguir os passos para a gente estar fazendo essa cópia de dados da base, de um lugar, que é onde o MySQL está olhando, para um lugar a parte, para que no futuro eu possa estar recuperando o meu backup.

[00:46] Esse backup copy all, a gente precisa, claro, desligar a instância usando lock, para garantir que todas as conexões não estão acessando o banco. Nesse caso da cópia da base, meio que o lock instance é um procedimento obrigatório, quando a gente uma o Mysqldump, não necessariamente é obrigatório eu usar o lock.

[01:17] Claro que é desejável a gente usar o lock, para que a gente não permita que pessoas façam modificações na base durante o backup, mas se eu esquecer o lock e rodar o Mysqldump, ele vai executar normalmente, mesmo que pessoas estejam acessando a base.

[01:40] No caso da cópia completa, eu preciso fechar todas as instancias e além disso, eu preciso identificar dentro do MySQL, quais são os arquivos onde estão os meus dados e os arquivos de configuração do MySQL também são importantes de serem copiados junto com a base e os arquivos de espaço das tabelas InnoDB, que é uma área de arquivos temporários que as tabelas tipo InnoDB utilizam.

[02:20] Então, vamos começar a fazer agora um exemplo prático da cópia de dados de um diretório para outro. Então, o primeiro passo é fazer um lock no banco. Eu vou rodar aqui o comando lock, tranquei, ninguém mais está acessando o meu banco.

[02:43] Eu agora vou naquele diretório onde eu estou fazendo os meus backups, o meu mysqladmin e vou criar um novo diretório aqui, chamado Dados, aqui dentro é onde eu vou estar salvando o meu backup. Então, a primeira coisa que eu vou fazer é copiar o arquivo de inicialização do MySQL.

[03:10] Vou abrir aqui uma outra janela e esses dados estão no C:\programdata, MySQL, MySQL Server 8.0 e eu tenho aqui a informação do arquivo de configuração, lembrando que esse diretório padrão é definido lá na inicialização, a gente até mostrou nesse mesmo curso, como é que a gente muda esse diretório.

[03:51] Então, eu vou pegar aqui esse arquivo my.ini, eu vou copiar e vou colar no diretório aqui dentro de dados, coloquei ele aqui, então foi a minha primeira cópia. Agora, eu preciso copiar os arquivos de dados e os arquivos de dados, a gente sabe é o diretório Data.

[04:22] Então aqui dentro, eu tenho uma série de arquivos temporários que ele utiliza e dentro cada subdiretório aqui, eu tenho as minhas bases de dados, então aqui, por exemplo, eu tenho a base suco_vendas e eu tenho aqui, por exemplo, a área das tabelas InnoDB.

[04:45] Para garantir a integridade, eu sempre faço uma cópia do diretório Data todo, então eu vou copiar e aí, a gente volta aqui para o... para onde eu vou salvar o meu backup e vou colar aqui. Então pronto, o meu diretório Data, ele foi copiado todo.

[05:13] Agora, claro, eu desbloqueio a instancia, libero o meu banco para acesso, mas eu já tenho uma cópia aqui salva. Tem a forma com que eu tirei o backup agora, nesse momento, copiando todos os dados.

[05:33] Normalmente, oferece um desempenho muito bom de tempo para tirar o backup e com uma certa previsibilidade de duração, principalmente quando a gente quer restaurar o banco, porque as vezes, quando a gente restaura o banco usando o script, a gente não sabe muito bem quanto tempo vai durar, enquanto que a cópia de arquivo é uma coisa mais previsível.

[06:01] Porém, essa forma de armazenagem do backup torna o backup mais vulnerável, porque existe grande possibilidade de que se você não faz uma manutenção coerente nos discos onde o backup está salvo, a probabilidade de você acabar corrompendo algum determinado arquivo de dados é grande.

[06:32] Não significa que vai acontecer, mas toda a vez que a gente utiliza então, salvar os dados de forma binária dentro do disco, eu posso, por algum motivo, perder esse dado por motivo físico da informação que está gravada.

[06:54] Se um arquivo binários daqueles for corrompido, pode ser que uma das tabelas do meu backup, eu não consiga mais acessa-la e eu, quando recuperar o backup, eu não vou conseguir ver o erro, eu vou simplesmente copiar os arquivos, subir o banco e para mim, aparentemente vai estar tudo legal.

[07:16] Só quando a gente for acessar o objeto onde ele está de forma binária, salvo no arquivo que foi corrompido, é que eu vou descobrir o problema e aí, então, vem a seguinte questão. Então, qual é o melhor backup? É o lógico ou o físico?

[07:37] A minha resposta é a seguinte, façam os dois. Sempre você tenha o backup físico e também o lógico, de tal maneira que se ao recuperar o físico, você tiver algum problema numa tabela, você tem como ir no lógico e rodar o script para trazer os dados, nem que você apague aquela tabela dentro do Workbench e aí, leia o script somente para ela.

[08:09] Você consegue abrir o “.sql” e editar o script que você quer rodar, então assim, por mais que seja... você vai gastar dois espaços em disco, talvez o tempo seja mais longo, mas eu aconselho a gente estar sempre gerando os dois tipos de backup, para poder garantir que a recuperação dos dados vai ser feita de forma correta.

[08:37] Então é isso aí. Valeu.


-----------------------------------------------------------------------
# 14Recuperando os backups

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58130

## Transcrição

[00:00] Então, a gente já aprendeu a fazer backup usando o Mysqldump, usando o Workbench e copiando os arquivos fisicamente. Agora, a gente vai aprender a recuperar o backup, a gente vai primeiro recuperar o backup a partir do arquivo que foi gerado pelo Mysqldump.

[00:22] Então, novamente, se eu abrir aqui aquele meu diretório, onde eu estou salvando todos os backup, eu vou estar utilizando... vamos ordenar aqui por data, esse cara aqui, o sucos_vendas_full.slq, que foi o arquivo que eu criei usando o Mysqldump, quando eu usei aquela propriedade –databases, ou seja, salvei toda a estrutura do banco.

[00:57] Eu vou então aqui no Workbench, aqui em Schemas, vamos criar aqui um script novo e aí, eu vou apagar a minha base: “Drop Databases sucos_vendas, vamos matar ela. Na verdade, é “Database”, Databases é o parâmetro que a gente usa lá no Mysqldump, é –databases, no plural, no Drop é database.

[01:39] Isso é normal, eu... as vezes a gente acaba confundindo os parâmetros, mas vamos lá, “Drop Database sucos_vendas”, então se eu vier aqui, eu não tenho mais um sucos_vendas, eu agora vou criar um novo, vou criar aqui o banco sucos_vendas.

[02:08] Então, pronto, eu tenho o meu sucos_vendas criado, porém vazio, sem nada. Então vamos lá, voltando aqui ao comando prompt, para eu recuperar os dados, eu vou rodar aquele script “.sql”, que tem todos os comandos para recuperar a informação.

[02:30] Então é como se eu tivesse feito um script manual e fosse executar ele através do MySQL, eu poderia, inclusive... é porque ele é muito grande, eu poderia inclusive, se quisesse, copiar, digamos assim, esse script aqui, copiar e não sei... vir aqui no Workbench e colar e rodar ele aqui.

[03:01] Se eu rodar ele aqui, eu vou fazer todo o processo, só que claro, esse arquivo “.sql”, como tem toda a informação da base, ele é muito grande e aí, rodar os scripts de dentro do Workbench, pelo editor de scripts, não é muito legal fazer isso, quando eu tenho milhões de linhas.

[03:22] Então, eu vou apagar aqui, eu não vou fazer por aqui, não. Eu vou fazer por linha de comando, como é que eu faço isso? Através do comando MySQL, se eu clicar aqui MySQL, vou botar -uroot -p e colocar aqui a senha do root, eu estou aqui dentro do MySQL.

[03:49] Se eu der aqui use sakita, é sakita mesmo o nome do banco? É sakila, use sakila, entrei na base sakila, se eu quiser aqui, vamos pegar uma tabela do sakila, actor, eu posso vir aqui e rodar: select * from actor. Está vendo? Eu estou dentro da interface do MySQL, através somente de linha de comando.

[04:23] Muita gente está mais acostumada a administrar o MySQL pelo MySQL linha de comando, do que propriamente dentro do Workbench.

[04:33] Eu prefiro o Workbench porque ele é gráfico, eu consigo ver os comandos, selecionar o comando que eu quero, quando eu gero resultado, eu gero dentro de um grid, eu tenho algumas ferramentas de produtividade que me facilitam o desenvolvimento, o trabalho.

[04:51] Linha de comando é mais para o pessoal das antigas, old school, que o pessoal está acostumado a trabalhar. Por esse MySQL que eu vou executar um script grande, que pode ter muitas linhas.

[05:05] Então, eu vou dar um exit aqui, o exit sai do MySQL e vou chamar o MySQL de novo, mas vou fazer a seguinte coisa, eu vou chamar o MySQL passando o usuário e a senha e executando aquele script que foi salvo. Então é mysql -uroot -p, espaço e aí, agora, eu uso o comando menor.

[05:34] Eu usei o comando maior, o símbolo maior quando eu quero jogar para fora do MySQL os dados para um script, o menor, eu estou jogando para dentro, então é como se... a direção da seta está mostrando, eu estou vindo de fora para dentro e aí, aqui eu vou colocar o nome daquele arquivo mysqladmin, vamos conferir lá o nome do arquivo, é sucos_vendas _full.sql.

[06:16] Então ficou assim. MySQL, o usuário, a senha, a seta indicando o sentido em que os dados vão estar sendo transferidos e aí, o nome do arquivo: extensão MySQL. Cliquei, eu vou colocar a senha root, note que eu estou esperando um tempo e ele está, na verdade, executando todos os comandos. Acabou.

[06:50] Eu agora, se eu vier aqui no Workbench, der aqui um Refresh no sucos_vendas, inicialmente... já até apareceu as tabelas, eu não precisava nem dar o Refresh, mesmo assim, eu vou dar u Refresh de novo e eu agora tenho aqui as informações recuperadas.

[07:12] Então é assim que eu consigo recuperar os dados, através do comando MySQL, quando a minha origem é um arquivo lógico. Agora, vamos recuperar o backup, não de um arquivo “.sql” que foi gerado pelo Mysqldump e sim através daqueles dados que eu salvei naquele subdiretório que eu chamei até de Dados, esse diretório aqui.

[07:38] Desculpe, eu chamei de backup sucos_vendas, onde eu tenho a estrutura completa dos dados, eu vou fazer isso então. A primeira coisa que eu vou fazer é parar, fazer um lock na base de dados, mas quando eu faço essa cópia, eu gosto de fazer uma coisa mais radical, eu gosto de derrubar o serviço do MySQL.

[08:06] Eu vou deixar o MySQL desligado, então eu vou fazer o seguinte, vamos fazer o seguinte exemplo, antes de continuar, eu vou dar o botão direito do mouse e vou dar um drop na base sucos_vendas. Então, note, a minha base sucos_vendas, ela não existe mais.

[08:28] Eu fecha o Workbench e eu vou aqui no serviço do Windows e vou procurar o serviço do MySQL, aqui, MySQL 8.0, vou parar esse serviço. Então aí, realmente ninguém mais vai entrar no MySQL nesse momento.

[08:57] E aí, eu vou fazer o seguinte, aqui, dentro daquele meu diretório Dados, eu vou pegar o my.ini, eu vou copiar, vou lá naquele diretório C, Program Data, MySQL, MySQL Server 8.0, que é o diretório onde o MySQL espera encontrar a base de dados, eu vou colar e vou fazer a mesma coisa com o diretório Data, vou copiar e vou colar.

[09:37] Ele talvez diga que vai substituir alguns arquivos, tudo bem, vamos substituir. Já fiz a cópia dos arquivos fisicamente, então eu volto lá para o meu serviço, vou em inicializar e agora, vamos abrir o Workbench de novo. Vou entrar na minha conexão, vou colocar aqui a senha do usuário root, vou salvar ele, para não precisar mais.

[10:16] Note, eu entrei agora e a base sucos_vendas apareceu novamente, que eu tinha apago antes de copiar o backup, então eu tenho a minha base aqui recuperada. Então, essa é uma forma, é a segunda forma de eu poder recuperar o backup, quando eu quero copiar fisicamente os arquivos que foram salvos também, através de uma cópia física.

[10:42] É esse tipo de cópia que quando eu faço, ela aparentemente vai funcionar, mas pode ser que quando eu acessar alguma tabela dessa aqui, eu vá encontrar algum problema de algum dado corrompido, mas só vou descobrir isso quando ou eu for acessar uma coluna ou quando eu vou, por exemplo, acessar aqui... vamos pegar aqui um Select, quando eu for... Vamos lá de novo.

[11:17] Send to, aqui, quando eu for, por exemplo, executar um Select. Então, só nesse momento é que eu vou descobrir que há um problema de dado corrompido. Aí, eu uso o arquivo script “.sql”, que eu salvei pelo Mysqldump, para complementar a recuperação do backup, através da cópia dos arquivos.

[11:41] Ficou claro para vocês? Então é isso aí. Valeu.


-----------------------------------------------------------------------
# 16Consolidando o seu conhecimento

Chegou a hora de você pôr em prática o que foi visto na aula. Para isso, execute os passos listados abaixo.

---

1) Os componentes de uma base ficam armazenados em um banco de dados. Você pode criar um banco de dados novo com o seguinte comando (no caso, será criado com nome o **library**):

```sql
CREATE DATABASE LIBRARY;
```

2) A base de dados pode ser criada, também, pelo assistente do Workbench. Para isso, clique com o botão direito do mouse sobre a área vazia da lista de componentes, à esquerda do Workbench, e escolha a opção **Create Schema**:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/03/image27.png)

3) Crie uma nova base chamada **library2**, mas utilizando o assistente. Para isso, digite o seu nome na opção **Name**:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/03/image14.png)

4) Quando você criou estas bases, o MySQL escreveu no seu disco rígido os arquivos físicos que as representam. Para saber em que diretório estes arquivos foram criados, você pode ver o valor da variável de ambiente `Variable_Name`:

```sql
SHOW VARIABLES WHERE Variable_Name LIKE '%dir';
```

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/03/image2.png)

Você verá todas as variáveis que possuem `dir` no nome. A variável que com o diretório dos arquivos é a `datadir`.

5) Indo no diretório mencionado acima, você verá:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/03/image37.png)

Há um subdiretório para cada base.

6) A inicialização desta variável `datadir` está no **my.ini**:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/03/image46.png)

7) Para apagar uma base, basta executar o comando:

```sql
DROP DATABASE library2;
```

8) Ou pelo assistente do Workbench. Para isso, clique com o botão direito do mouse sobre a base de dados a ser excluída e escolha a opção **Drop Schema**:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/03/image28.png)

9) Crie um diretório chamado **mysqladmin**, na raiz do drive **C:\**.

10) Na linha de comando do Windows, digite os seguintes comandos:

```bash
cd\
cd "Program Files"
cd "MySQL"
cd "MySQL 8.0"
cd Bin
```

11) Para realizar um _backup_ da base **sucos_vendas**, digite:

```css
mysqldump -uroot -p --databases sucos_vendas > c:\mysqladmin\sucos_vendas_full.sql
```

A senha do usuário **root** será necessária para a execução do comando.

12) Dentro do arquivo **C:\mysqladmin\sucos_vendas_full.sql**, você terá os comandos para recuperar a base **sucos_vendas**.

13) Para realizar um _backup_ somente da tabela **notas_fiscais**, da base **sucos_vendas**, execute o seguinte comando:

```css
mysqldump -uroot -p --databases sucos_vendas --tables notas_fiscais > c:\mysqladmin\sucos_vendas_tab_notas_fiscais.sql
```

14) Para realizar um _backup_ de todas as tabelas da base **sucos_vendas**, exceto a tabela **notas_vendas**, execute o seguinte comando:

```css
mysqldump -uroot -p --databases sucos_vendas --ignore-table sucos_vendas.notas_fiscais > c:\mysqladmin\sucos_vendas_ig_tab_notas_fiscias.sql
```

15) Para realizar um _backup_ somente dos comandos de **`INSERT`** de todas as tabelas da base **sucos_vendas**, execute o seguinte comando:

```css
mysqldump -uroot -p --databases sucos_vendas --no-create-db --no-create-info --complete-insert > c:\mysqladmin\sucos_vendas_somente_inserts.sql
```

16) Na página [https://dev.mysql.com/doc/refman/8.0/en/mysqldump.html](https://dev.mysql.com/doc/refman/8.0/en/mysqldump.html), você pode ver todas as propriedades suportadas pelo **mysqldump**.

17) Você pode realizar um _backup_ através do Workbench. Para isso, abra-o.

18) Antes do processo, você precisa "desligar" o banco, para fazer o processo de criação do _backup_. Para isso, dê um duplo clique sobre o banco **sucos_vendas**, digite e execute:

```undefined
LOCK INSTANCE FOR BACKUP;
```

19) Clique na aba **Administration**:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/03/image31.png)

20) E depois em **Data Export**.

21) Selecione a base **sucos_vendas**.

22) Marque a opção **Export to Self-Contained File**.

23) Ao lado, inclua o nome do arquivo a ser salvo (**C:\mysqladmin\sucos_vendas_full_work.sql**).

24) Clique em **Start Export**.

25) Veja que, no diretório de saída (**C:\mysqladmin\**), um arquivo novo foi criado, com o mesmo conteúdo do arquivo criado pelo **mysqldump**.

26) Você pode exportar cada componente do banco (no caso, as tabelas) em um arquivo, separadamente. Para isso, novamente clique em **Data Export**.

27) Selecione a base **sucos_vendas**.

28) Escolha a opção **Export to Dump Project Folder**.

29) Ao lado, inclua o nome do diretório onde os arquivos serão salvos (**C:\mysqladmin\bkp_sucos_vendas**).

30) Clique em **Start Export**.

31) Veja que, no diretório de saída (**C:\mysqladmin\**), haverá uma pasta e dentro dela haverá diversos arquivos representando as diferentes tabelas.

32) Outra forma de fazer o _backup_ é copiando toda a estrutura do banco. Mas antes, no diretório **C:\mysqladmin\bkp_sucos_vendas\**, crie um diretório chamado **Dados**.

33) Vá em **C:\ProgramData\MySQL\MySQL Server 8.0** e copie o arquivo **my.ini** para o diretório **C:\mysqladmin\bkp_sucos_vendas\Dados\**.

34) Depois, copie o diretório (e também o seu conteúdo) **C:\ProgramData\MySQL\MySQL Server 8.0\Data** para dentro de **C:\mysqladmin\bkp_sucos_vendas\Dados\**.

35) O que você tem salvo em **C:\mysqladmin\bkp_sucos_vendas\Dados** é todo o ambiente de dados, preservado em um outro disco.

36) Após o fim do processo, libere a instância do banco de dados, digitando o seguinte comando:

```undefined
UNLOCK INSTANCE
```

37) Para recuperar o _backup_, primeiramente, no Workbench, apague a base **sucos_vendas**, digitando:

```sql
drop database sucos_vendas;
```

38) O _backup_ desta base está salvo em **C:\mysqladmin\sucos_vendas_full.sql**. Então, abra uma janela de linha de comando do Windows e digite:

```bash
cd\
cd "Program Files"
cd "MySQL"
cd "MySQL 8.0"
cd Bin
```

39) E execute:

```css
mysql -uroot -p < c:\mysqladmin\sucos_vendas_full.sql
```

40) A base será criada e seus dados incluídos novamente.

41) Você também pode recuperar a base através do arquivo físico. Para isso, no Workbench, apague novamente a base:

```sql
drop database sucos_vendas;
```

42) Saia do Workbench e pare o serviço do MySQL.

43) Vá em **C:\mysqladmin\bkp_sucos_vendas\Dados\** e copie o arquivo **my.ini** para dentro de **C:\ProgramData\MySQL\MySQL Server 8.0\**.

44) Copie o diretório (e também o seu conteúdo) **C:\mysqladmin\bkp_sucos_vendas\Dados\Data** para **C:\ProgramData\MySQL\MySQL Server 8.0\Data**.

45) Suba o serviço do MySQL.

46) Entre no Workbench e veja que a base **sucos_vendas** voltou a estar disponível.

-----------------------------------------------------------------------
# 02Plano de execução

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58131

## Transcrição

[00:00] Um dos principais fatores de performance dentro de um banco de dados é o tempo com que eu faço consultas sql à base e dependendo de quanto mais complexas são essas consultas, mais tempo eu perco para poder obter o resultado de uma consulta.

[00:24] E é claro, é função do DBA poder ajudar o analista a melhorar a performance das consultas que estão sendo colocadas no relatórios das aplicações que esse analista está colocando em produção. Vamos entrar aqui no Workbench e vamos fazer aqui três consultas.

[00:45] Primeiro, eu vou fazer uma consulta, Select, eu vou chamar aqui: “A.Nome_Do_Produto From tabela_de_produtos”, simplesmente... e aí, eu vou chamando essa tabela de tabela A. Se eu rodo isso daqui, eu vejo lá todos os nomes dos produtos, mas eu quero ver, além do nome do produto, eu quero ver a quantidade que ele vendeu.

[01:25] Então, eu posso pegar aqui: “C.Quantidade” e aí, eu vou pegar a tabela de produtos A e fazer um “INNER”... vamos botar aqui em baixo, “INNER JOIN”, qual é a tabela que tem a quantidade? É a tabela aqui de itens_notas_fiscais, eu tenho o campo quantidade aqui.

[01:55] Então, eu vou colocar aqui itens... eu tenho aqui a tabela, “C ON”, qual é o campo que une as duas? É o campo código do produto, que tem tanto na tabela de itens_notas_fiscais, quanto na tabela de produtos. Então, eu vou botar: “A.codigo_do_produto = C.codigo_do_produto”.

[02:33] Vamos ver se vai funcionar a consulta. Pronto, está lá, cada produto, eu estou vendo a quantidade, mas eu queria também olhar isso por data, eu quero saber quanto eu vendi em casa cano, por exemplo. Então, eu posso vir aqui, vou pegar essa consulta, só que aí, eu vou adicionar aqui “B.Data_Venda”.

[03:01] Deixa eu ver se o campo chama-se realmente data_venda, o campo data_venda, eu tenho aqui em notas_fiscais, é isso aí, “Data_Venda”, só que eu quero ver isso por ano, então eu vou colocar um “Year” de “Data Venda As Ano”.

[03:19] E aí, claro, eu vou fazer um “Inner Join” com a tabela de “notas_fiscais B ON”. Qual é o campo que eu tenho em comum? É o campo número, então “A.Numero = B.Numero”. Vamos rodar isso daqui. Na verdade, o campo não é número... não, o campo é número. Ah, é com a tabela...

[03:57] Na verdade, eu tenho que juntar a tabela C, com a tabela B, que eu tenho que juntar a tabela de itens_notas_fiscais, com notas_fiscais, então é C com B, aqui que estava o meu erro. Pronto. Só que aí, eu estou linha a linha, eu poderia estar querendo ver isso daqui agrupado.

[04:25] Então, eu vou pegar aqui mais uma consulta, vou botar aqui “Sum” de quantidade e aí, todo esse processo aqui, eu vou botar um “Group By”, o nome do produto e o ano, posso até colocar aqui um “Order By” com os mesmos campos. Se rodar esse Select, mas é complicado.

[05:06] Notem que... já tive um tempo, se a gente olhar aqui no canto, deixa eu ver se eu consigo aqui... chegar aqui para o lado, acho que eu vou fazer assim... Ah, vamos lá.

[05:29] Aqui, note que todas as consultas estavam demorando 0 segundos, bem instantâneo, mas a última já demorou 0.828 segundos, porque essa última consulta já começou a fazer join, group by, order by, então, ou seja, quanto mais agregada é a minha consulta sql, mais tempo eu vou gastar.

[05:58] Claro que esse nosso banquinho aqui, ele é muito pequeno, ele tem poucos registros, mas quando a gente estiver falando de um banco de dados corporativo, a performance dos comandos sql é muito importante. Claro que aqui, foi meio que no olho, que a gente concluiu as nossas consultas.

[06:24] Agora, será que eu tenho um instrumento que eu possa realmente saber qual é o tempo esperado que cada comando Select vai demorar? Nós temos, sim, nós temos o comando explain.

[06:43] O comando explain, ele me dá o plano de execução da consulta, é como se fosse um pré-planejamento do que o MySQL vai fazer para resolver aquela consulta, independente do plano de execução que eu vou estar seguindo, eu posso tomar algumas atitudes em termos de performance do eu banco, para que as minhas consultas fiquem de uma certa maneira, um pouco mais rápidas.

[07:17] Então, a gente vai se dedicar agora, os próximos vídeos dessa aula, a tentar entender como é que funciona o plano de execução, quais são os impactos que esse plano de execução dá dentro da minha base e ver os resultados deles, através desse comando que chama-se explain, que é o comando que nos mostra o plano de execução.

[07:46] Mas aí, isso aí, eu vou continuar nos próximos vídeos. Tchau, tchau.


-----------------------------------------------------------------------
# 04Visualizando o plano de execução

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58132

## Transcrição

[00:00] Vamos entender na prática como é que o plano de execução pode mostrar para a gente, se uma consulta vai ser rápida ou demorada e para isso, a gente vai usar o MySQL como linha de comando.

[00:16] Então, eu vou buscar aqui, vou abrir a minha janela de linha de comando e vou lá para o diretório do MySQL, fica em program files, MySQL, MySQL Server 8.0 e bin. E aí, para entrar no MySQL, é mysql -uroot -p, coloco a minha senha root e aí, pronto, tenho aqui o meu ambiente do MySQL por linha de comando.

[00:58] Vou na minha base sucos_vendas e aí, vou executar uma daquelas consultas, vou começar pela consulta mais simples, que é a primeira, vou colar aqui. Opa, não copiei, copy, pronto. E aí, eu tenho lá o resultado da minha consulta pela linha de comando.

[01:27] Para a gente poder ver o plano de execução, a gente escreve explain e a consulta que eu quero executar, ele me dá esses campos aqui, onde cada campo me dá uma pista de como vai se comportar essa consulta. Eu vou ter uma linha para cada tabela envolvida na query que está sendo analisada pelo explain.

[01:58] Como no caso aqui, esse Select, somente utilizou uma tabela, que eu chamei de tabela A, somente a tabela A está envolvida nessa consulta, mas tem uma outra forma de a gente ver esse resultado, se eu botar aqui no final da linha um “\G”, eu tenho o meu resultado, invés de no formato de tabela, sequencialmente, fica até mais simples de a gente poder estar olhando.

[02:34] Agora, eu tenho um terceiro formato do explain, que é o meu preferido, que é o seguinte, eu coloco aqui, “Format=Json”, ao colocar esse comando, eu vou ter a minha resposta assim. Aparentemente, você pode achar que isso é mais confuso, mas é que eu tenho informações mais interessantes nessa consulta.

[03:10] Uma delas é essa aqui, o query cost, o query cost, ele é basicamente o custo da consulta. Você vai me perguntar: “Que unidade de medida é essa? É segundo? É hora? É minuto?”, na verdade é uma unidade indefinida. Pense no seguinte, quanto menor o query cost, mais rápida vai ser a consulta.

[03:41] Então o seu objetivo é ir arrumando a consulta, de tal maneira que o query cost seja o menor possível. Aqui, por exemplo, tem o número de linhas que vão ser examinadas e basicamente, esses dois valores mostram o custo de leitura e de escrita da consulta.

[04:11] Então, primeira... a nossa primeira consulta custou 3.75, então eu vou até colocar aqui como comentário aqui em cima, 3.75. Vamos ser a segunda consulta, eu vou até fazer uma dica, antes de copiar e colar, vamos tirar os espaços aqui da consulta, deixar ela numa linha única.

[04:38] Então, eu vou copiar e voltando lá para a linha de comando, eu vou colocar aqui: “Explain Format=Json” e vou colar essa segunda consulta, só que eu vou colocar o “\G” no final. Bem, essa consulta, ela tem um Json um pouco maior, note que eu tenho dois loopings.

[05:04] Eu tenho um looping que vai buscar dados da primeira tabela e note que ele aqui tem uma outra informação, que é possível chave de uso “Primary”, por quê? Porque lembra? Eu tenho que fazer um join entre a tabela de produto e a tabela de itens, pelo código do produto e na tabela de produtos, o meu código é um primary key.

[05:34] Então, ele vai usar essa... a primary key para ajudar a fazer com que a performance desse join seja maior. Tem lá os mesmos custos, muito parecidos com a query, quando eu rodei ela sozinha, só que depois, eu tenho uma segunda query que inclusive, os custos são bem altos.

[06:00] E aí, o importante é que esse join trouxe esse custo total, 76mil 517.94, então, note que a query ficou mais pesada ainda. Então, eu vou até colocar esse número aqui, 76517.94, foi o curso da segunda query. Note, muito mais custosa, simplesmente pelo fato de eu ter feito um join.

[06:41] Vamos para a terceira, a terceira, eu já faço dois joins, então copiei aqui a consulta, vou vim aqui na linha de comando, lá em baixo. Opa. Vou dar um “Enter” aqui, até aparecer. Pronto. “Explain Format=Json” e eu vou colar a consulta, colocando o “\G” no final.

[07:19] Então está lá, tem já bastante coisa, vamos lá para o topo, essa minha consulta já custou 260242.51, note que ela foi mais pesada do que a consulta anterior e a de baixo que vai usar group by e order by, será que ela vai custar mais do que a outra?

[08:00] Vamos ver. “Explain Format=Json”, “\G”. Opa, cometi algum erro? Vamos repetir aqui o comando. Ah, sim, porque “;” aqui em baixo, tinha um “;” perdido aqui no canto, eu vou tirar ele. Pronto, vou executar. Ok, foi. Tenho lá as minhas buscas e o custo aqui foi 260.242.51, foi praticamente o mesmo custo que a query... Praticamente não, igual, o mesmo custo que a query anterior.

[09:14] Ou seja, inserir o group by e o order by, não influenciou no resultado da consulta. Então, a gente já conseguiu ver que explain dá mais ou menos esse indicador, para dizer se a query é pesada ou ela é leve. O que a gente precisa é tentar redesenhar ou colocar artifícios dentro do MySQL, para fazer com que essa consulta fique mais rápida, que o custo dela caia.

[09:52] Esse é um desafio que o DBA tem para ajudar o analista de negócio, na verdade não é o analista de negócio, mas o analista que está projetando o banco, criando sistema, para que ele, ao construir consultas que vão gerar relatórios para os usuários, que ele faça consultas, de tal maneira que o custo da query acabe sempre sendo um pouco menor.

[10:23] Então é isso aí, gente, é isso que eu queria falar para vocês sobre o comando explain e como que ele nos dá esse resultado do custo da query. Valeu.

-----------------------------------------------------------------------
# 06Conceito de índices

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58133

## Transcrição

[00:00] Vamos falar um pouquinho sobre índices. O conceito de índice baseia-se assim, que... se eu for pesquisar um conjunto de dados, buscar um dado dentro de uma lista de informações, onde esse dado que eu estou buscando, se ele está previamente classificado, ordenado, é muito mais fácil achar esse dado, do que se eu tivesse procurando essa informação numa lista totalmente espalhada.

[00:34] Porque assim, se eu tenho uma coisa ordenada de forma alfabética, por exemplo e eu vou procurar por um nome, por exemplo, Pedro, eu já buscar direto na letra “p”, porque eu sei... se ela está ordenada, eu tenho essa busca de uma maneira mais inteligente, mais rápida, do que se eu for buscar esse nome dentro de uma listra totalmente bagunçada.

[01:02] Então, o índice, ele serve para ajudar a gente na busca dessas informações, então é uma estrutura que auxilia a tabela a achar dados. Quando o MySQL, ele cria um índice, seja esse índice uma ou mais colunas, ele vai e cria para a gente uma copia dessa coluna, numa outra estrutura, mas de forma ordenada.

[01:40] O que nós estamos vendo aqui em cima, seria a representação de como funciona o índice. Atenção, numa tabela do tipo MyISAM, a informação que é colocada na tabela, ela está apresentada de forma, como eu posso dizer, assim... de forma... na ordem com que os registros forem incluídos.

[02:06] Então, eu tenho aqui no canto uma tabela de livros, onde o primeiro livro que foi inserido foi o livro 7-234-5, deixa eu só colocar aqui o apontador. Pronto. Foi o livro 7-234-5, Moby Dick e esse é o autor.

[02:22] Depois, eu inclui esse outro ID, com esse no título e esse autor e o de baixo, depois, foi o terceiro livro a ser colocado nessa base de dados. Se eu quiser procurar pelo livro 2-345, se eu não tiver a estrutura de índice, eu tenho que percorrer essa tabela e ir procurando, até acha-la.

[02:51] Mas aí, em tabelas MyISAM, que é o exemplo que eu estou mostrando aqui em cima, quando eu crio um índice, ele cria uma estrutura a parte, onde ele coloca a coluna, onde o índice está sendo representado, já de forma ordenada e eu tenho do lado uma estrutura que diz a posição daquela coluna dentro da tabela.

[03:20] Então, por exemplo, o 2-2315 é o segundo registro, está aqui, é o segundo registro. O 7234-5, é o primeiro registro, está aqui em cima. Então, esse aqui seria a tabela de índices, quando a gente utiliza o ID como índice.

[03:41] Agora, se tu quiser criar índices para a coluna título ou para a coluna autor, eu vou ter outras estruturas, onde o campo está ordenado de forma alfabética e eu tenho como referência o registro que está aqui em cima. Então, nesse caso aqui, eu tenho uma tabela e três índices.

[04:04] Não importa se o índice é de uma coluna que é chave primária ou não, relembrando, chave primária é aquela chave que a tabela tem, onde nenhum registro pode se repetir com aquela mesma chave. Aqui no caso, a chave primária é ID, mas a representação do índice dentro de uma tabela MyISAM, funciona da mesma maneira que os outros índices.

[04:36] Agora, essa estrutura, ele tem um certo custo. Apesar de o índice facilitar o processo de busca, se eu, por acaso, for incluir um novo registro na minha tabela, eu vou ter que estar colocando, atualizando esses índices, toda a vez que eu modificar a minha tabela.

[05:09] E isso de uma certa maneira, é custoso. Imagine, eu tenho aqui três índices, toda a vez que eu modificar ou incluir alguém, quando essa operação for feita nessa tabela, eu tenho que também estar atualizando as tabelas de índice.

[05:31] Então, claro, se eu tiver uma tabela muito grande dentro do MySQL e se eu tiver muitos índices associados a essa tabela, toda a vez que eu for incluir, alterar ou excluir ou... um registro daquela tabela, eu vou ter um problema de performance, porque essa operação vai ficar muito mais lenta, porque a cada modificação da tabela, eu vou ter que alterar os índices.

[06:02] Então, isso é um peso de benefício e custo, que você deve estar meio que prestando atenção, sempre que você for projetar os índices e tudo mais, dentro da tabela que você vai usar na base de dados.

[06:26] Agora, nas tabelas do tipo InnoDB, apesar de o índice também ser de uma certa maneira custoso ao atualizar a tabela, a estrutura de índices na InnoDB, ela é um pouquinho diferente da apresentada aqui.

[06:45] Então, vamos passar para o próximo slide, aqui está a representação dos índices numa InnoDB. Na InnoDB, há uma distinção entre o índice que está associado à chave primária e ao que não é chave primária. Quando eu tenho um índice associado à chave primária, ele faz parte da tabela de dados.

[07:09] Então, aqui no caso, note, apesar de a minha tabela ter uma ordem natural de inclusão dos dados, ao fazer isso, uma tabela InnoDB já organiza a própria tabela usando o índice da chave primária. Então, é como se o índice e a tabela de dados, para a chave primária, fossem uma coisa só.

[07:37] Então, note que aqui os dados na minha tabela já estão orneados pelo ID, porque o ID é a chave primária, por isso que quando a gente faz uma leitura, uma inclusão de dados numa tabela InnoDB, alteração em massa, por exemplo, “Ah, estou carregando um Data Werehouse, então tem que ler 1 milhão de registro de um canto para o outro canto”.

[08:10] Se os dados que eu estou usando para fazer essa leitura de massa já vierem ordenados lá da fonte, usando o mesmo critério que a chave primária da tabela, eu vou ter uma melhora substancial na performance de leitura desses dados. Agora, como é que são os índices?

[08:33] No caso dos índices dos outros campos, que não são chaves primárias, ele também cria aqui uma estrutura a parte, só que aqui, no caso, eu vou ter só uma estrutura para o índice do título e do autor, porque o índice de ID, que é chave primária está na própria tabela.

[05:55] E aí, a referência que eu vou ter, não é a posição do registro na tabela e sim, o código da chave primária. Então, por exemplo, vamos subir aqui antes. Antes os dados estão desordenados na tabela e a referência é a posição do registro.

[09:18] Já na InnoDB, a tabela já vem ordenada automaticamente e a referência é pelo campo da própria chave primária. A vantagem dessa ordenação de índices, através da chave primária, é que, por exemplo, se a gente precisar fazer uma busca por ID, a gente não precisa estar trabalhando com duas estruturas ao mesmo tempo.

[09:50] Na MyISAM, por exemplo, se eu quero buscar um ID, eu tenho que vir aqui no índice, achar o ID, ver a posição e aí, depois ir para a tabela e buscar a informação. Se eu quero buscar por ID, dentro da InnoDB, ele vai buscar na própria tabela, então não utilizo uma outra estrutura.

[10:15] É claro que o custo para achar alguém, que não é chave primária, é praticamente o mesmo, tanto na MyISAM, quanto na InnoDB, porque eu vou ter que realmente usar a estrutura de índices para achar quem eu estou procurando, ver a referência, não importa se aqui no caso a referência é uma chave primária, no caso de InnoDB ou uma posição dentro da tabela, como é no caso do MyISAM.

[10:43] Eu vou buscar essa posição e aí, eu tenho a ligação com a informação na tabela. Então, essas são duas diferenças substâncias internas de como é que funciona um índice dentro de tabelas MyISAM e InnoDB. Valeu.


-----------------------------------------------------------------------
# 08Algoritmos Hash e BTree

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58134

## Transcrição

**Nota:** No tempo 16:16 do vídeo, o instrutor fala que apenas o HASH vai funcionar direito no InnoDB sendo que na verdade é o BTree, assim como ele explicou no início do vídeo.

[00:00] A gente já viu em vídeos anteriores, principalmente no vídeo passado, mais precisamente, que o MyISAM e o InnoDB têm estruturas diferentes quando constroem os seus índices.

[00:14] No caso do MyISAM, independente se o índice é chave primária ou não, a gente constrói sempre uma estrutura de dados ordenados pelo critério do índice e a referência na tabela é pelo posicionamento do registro na ordem com que eles forem inseridos, independente se é PK ou não.

[00:41] Já o InnoDB, ele tem uma distinção de o índice é PK ou não PK, se ele é PK, a própria tabela é ordenada pelo índice, pelo critério da chave primária e os outros índices possuem uma estrutura muito parecida com o MyISAM, só que a referência entre o dado que está no índice e na tabela, não é pela posição do dado que foi inserido e sim pela localização da própria PK.

[01:18] Agora, para a gente procurar o valor dentro do índice, a gente tem dois tipos de algoritmos que nós podemos fazer isso e em outro vídeo, bem no início dessa aula, eu até mencionei isso e falei que iria explicar sobre isso um pouco mais na frente.

[01:38] Esses dois algoritmos são os BTREE e HASH, são dois algoritmos diferentes que nós usamos para buscar alguém dentro de uma lista ordenada. Então, independente de como é a minha estrutura de índice, eu vou ter que fazer buscas nessas listas que já foram previamente ordenadas.

[02:05] E aí, eu posso fazer essas buscas através o BTREE ou através do HASH, porém o MyISAM, ele suporta índices que usam o algoritmo de cada BTREE ou HASH. Já o InnoDB não, o InnoDB, ele só utiliza algoritmos de busca, do tipo BTREE. Agora, como é que funcionam esses algoritmos?

[02:37] Para entender bem como é que funciona esses algoritmos, a gente precisa primeiro entender um conceito, um pouco diferente, que é o conceito de uma árvore binária. Então, o que eu estou vendo aqui em cima é uma árvore binária.

[02:56] Quando a gente monta essa árvore binária, a gente garante sempre que todos os valores que estão a esquerda do nó, são valores menores do que o valor do nó e todos os valores que estão a direita do nó, são valores maiores do que o nó.

[03:20] Então, se a gente olhar aqui esse exemplo, essa figura, note o seguinte, todos os valores que estão a esquerda do 27, são nós menores que 27 e todos que estão a direita do 27 são nós maiores que 27. Então, se eu estiver olhando o 27 e quiser buscar um número menor que 27, eu vou para o lado esquerdo.

[03:49] Se eu quiser achar um número maior do que o 27, eu vou para o lado direito, se eu quiser achar o próprio 27, eu não preciso ir para lugar nenhum, já o encontrei. Agora, se a gente olha o foco do outro nó, por exemplo o 14, todos os nós que estão à esquerda 14, são menores do que 14 e todos que estão a direita do 14, são maiores do que o 14.

[04:16] Então, por exemplo, então eu estou vendo... vamos fazer um exemplo aqui hipotético, digamos que eu queria buscar o número 19, como é que o algoritmo funciona? Ele vai no 27, 19 é maior que 27? Não, é menor, então eu sei que está tudo do lado esquerdo.

[04:42] Eu esqueço os nós do lado direito. Aí, eu passo para o nó de baixo que é o 14, o 14, ele é menor ou maior que 19? “Ah, ele é maior que 19”, então eu sei que o 19 está a direita do 14, eu não... tudo o que estiver a esquerda do 14, eu não vou mais, aí eu desço mais um nível.

[05:06] Aí, eu acho o próprio número 19. Agora, o que que é uma BTREE, uma BTREE é uma árvore binária balanceada, por isso a letra B, de balance, qual é a diferença então de uma árvore binária normal e uma árvore binária balanceada?

[05:34] Na árvore binária normal, quando eu monto esse algoritmo de esquerda e direita, eu não garanto para vocês que a árvore tem os mesmos nós, tanto para um lado, quanto para o outro. Já numa árvore balanceada, a gente meio que garante que os nós estão bem distribuídos, ou seja, normalmente o topo da árvore binária é a mediana dos números, das opções que eu estou procurando.

[06:14] E aí, eu garanto que se eu for buscar para o lado direito ou buscar para o lado esquerdo, tanto faz, eu vou ter mesmos custos para achar um determinado número. Agora, como é que a gente usa esse algoritmo de BTREE para achar um dado dentro do índice, quer dizer, como é que o índice faz isso?

[06:47] Então, o que acontece é o seguinte, a gente arruma, o índice, ele arruma os dados dentro de um topo, usando um algoritmo que chama D e dois D. Então, é como se eu pegasse o menor e o maior valor e criasse intervalor constantes que a gente chamaria de D e eu vou colocar esse números nesse topo.

[07:15] E aí, eu sei, por exemplo, que o que está a esquerda do 7, está nesse grupo aqui, o que está entre o 7 e o 16, está nesse grupo aqui e o que está para lá do 16, está nesse grupo aqui. Então, ela é uma árvore binária um pouquinho, então se eu quiser buscar o número 7, eu já acho de cara.

[07:41] Se eu quiser buscar o número 9, por exemplo, eu vou ver aonde que o 9 está, então o 9 não está aqui, porque o 9 não é menor que sete, o 9 não está aqui nessa região, porque ele não é maior que 16, eu sei que o 9 está entre o 7 e o 16. Então, ele sabe que ele vai estar num grupo de número ali do meio.

[08:12] Então, essa busca... a gente faz esse exemplo aqui com números, mas esses valores a serem buscados podem ser textos, claro... qual é o texto que é menor do que outro? Respeitando a ordem alfabética, o A sempre vai ser menor do que B, menor que C e assim por diante.

[08:36] O algoritmo de BTREE, ele é matematicamente eficiente, se eu tiver, por exemplo, 4 bilhões de nós, por exemplo. Se você olhar matematicamente, no máximo eu vou precisar fazer 32 buscas para achar qualquer número num algoritmo de BTREE, por quê?

[09:06] Porque assim, tem 4 bilhões, então o nó do meio da árvore balanceada, vai ser o número 2 bilhões. Então, se eu quero achar um número, a primeira coisa, digamos que eu queira achar o número 1450, eu vou no 2 milhões, eu vejo esse número está à direita ou a esquerda?

[09:33] Está a esquerda. Aí, no segundo nível a esquerda do 2 milhões, eu tenho um nó central que é um bilhão. Aí, eu vou testar, estou no segundo nível. O número está à esquerda do um bilhão ou a direita de um bilhão? “Ah, está a esquerda”.

[09:52] Aí, o nó de baixo do grupo da esquerda, vai estar em 500 milhões e assim por diante e aí, até eu descer, depois de descer 32 níveis, eu vou conseguir chegar ao grupo de nós, que o número que eu estou buscando o existe, por isso que é uma consulta que requer... é um algoritmo que requer um esforço computacional para achar qualquer valor bem pequeno.

[10:24] Do que, por exemplo, eu percorrer os 4 bilhões e saber quem é número, esse número é o que eu quero? Não. É o que eu quero? Não. Lembrando que essa busca da árvore binária, seria a busca para eu achar o valor que e usado como critério do índice.

[10:45] Se eu tenho um índice por estado, então eu estou usando o método BTREE para achar o estado dentro da lista ordenada. Quando eu achar o estado, aí eu vejo a referência, se for MyISAM, a referência é pela linha da tabela, se for InnoDB, essa referência é a PK e aí, vou na tabela e consigo capturar todos os dados que eu estou procurando.

[11:16] Então, esse aqui é o conceito do algoritmo BTREE. O algoritmo HASH, ele é um pouquinho mais difícil de entender, até eu mesmo tenho um pouco de dificuldade, porque ele tem algumas coisas meio misteriosas embutidas nele.

[11:37] Algoritmo de HASH, ele é usado, não somente para índices, mas o HASH é usado muito para criptografia, para armazenagem de senhas e o algoritmo de HASH é um algoritmo matemático que permite que a gente pegue um valor de texto, um string, independente do seu tamanho, se é uma string de um caractere ou de 100 caracteres.

[12:05] A gente reduz isso a uma palavra de tamanho fixo, então é como se a gente, por exemplo, essa tabela, eu tenho lá o seguinte, eu tenho uma string, aqui tem um montão de letras e aplicando o algoritmo de HASH nele, eu transformo essa string em outros caracteres de string com tamanho fixo.

[12:29] Mas, se eu por acaso pegar uma outra string, um pouco menor, eu consigo reduzir ele para uma string do mesmo tamanho que o anterior, isso vai depender dos parâmetros que eu estou colocando no HASH. E aí, o algoritmo de HASH tenta tanto transformar o string em HASH, como pegar o HASH e transformar de volta para string.

[12:57] Os valores que foram transformados pelo HASH, são valores completamente embaralhados, que eu não consigo entender, por isso que esse algoritmo é muito usado em criptomoedas, criptografia, armazenar senha, essas coisas. Agora, como é que isso então ajuda a gente a achar alguém em uma tabela dentro do banco de dados?

[13:25] Você imagina um livro, um livro que você compra na banca, na livraria, numa banca de jornal. A primeira coisa que o livro tem, na primeira página dele tem um negócio chamado índice, que tem os capítulos e cada capitulo tem subtópicos e dentro de cada subtópico do capitulo, tem a página.

[13:49] Então, eu só quero pegar aquele livro e eu quero entender um assunto, eu quero ler sobre tal coisa. Eu vou olhar o índice, eu vejo em que página o índice está, o assunto, desculpe, vou pegar o índice, acho o meu assunto, vejo a página que o assunto está.

[14:09] E aí, eu vou naquela página e aí, eu começo a ler o texto, até encontrar o tópico que eu estou procurando. O HASH funciona da mesma maneira, como é que funciona isso? Então eu tenho o meu índice, lá com os meus dados num estrutura separada.

[14:32] E aí, eu guardo dentro de palavras HASHs o endereço de memória de alguns conjuntos de dados, então é como se, por exemplo aqui, eu tenho tanto o ID5, quanto o ID3 armazenados nesse conjunto de endereço de memórias HASH e aí, é como se esse “id=3” e “id=5”, fizessem parte do mesmo capítulo de um livro, que é esse grupo aqui.

[15:15] Então, quando eu quero pegar o dado de 5, eu aplico o algoritmo de HASH, ele vai me dar uma palavra constante, que é o endereço de memória onde o dado está e aí, eu vou buscar aqui dentro o registro que eu quero achar. E aí, pode ser que seja esse ou seja esse ou seja esse, porque esse endereço de memória está ligando a posição da tabela onde o resto do dado está.

[15:53] A gente tem que entender um pouquinho o seguinte, que tanto o HASH, quanto o BTREE, eles são algoritmos de buscas, cada um tem o seu conceito deferente de trabalhar e que o MySQL suporta esses dois algoritmos internamente, porém apenas se for MyISAM.

[16:12] Se a gente tiver um banco InnoDB, apenas o HASH vai funcionar direito. Então é isso aí. Valeu.


-----------------------------------------------------------------------
# 10Usando índices

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58135

## Transcrição

[00:00] Agora, você vê que essa aula eu comecei falando de explain, para a gente entender o plano de execução e como é que a gente consegue ver o custo de uma query, depois eu pulei de assunto e falei de índice, como é que funciona o índice, quais são os algoritmos de busca.

[00:22] Agora, eu vou juntar as duas coisas, porque acontece muito o seguinte, o índice é um dos principais instrumentos para a gente melhorar o custo das queries, quer ver? Vamos fazer um exemplo prático para ilustrar isso. Então, voltei aqui para o meu ambiente do meu MySQL em linha de comando e eu vou fazer o seguinte.

[00:46] Eu vou pegar a seguinte consulta: “Select * From Notas_Fiscais Where Data_Venda = 20170101”, deixa eu até selecionar essa linha, vou dar um “Ctrl + C”, porque eu vou usar esse comando várias vezes, então vamos lá, eu vou rodar.

[01:19] Eu trouxe lá uma série de linhas, todas elas são botas fiscais para o dia 27/01. Claro que internamente, o MySQL fez um plano de execução e executou a query, vamos ver como é que foi o custo dessa query? Se eu der um “Explain Format = Json”, colocar o “\G”, note que o custo da query foi 8849.05.

[02:06] Eu vou até aqui abrir um editor de texto e vou guardar isso daqui, essa query, ela custou para mim: 8849.05, eu vou até manter esse editor aberto e tudo que é comando que eu for executar, eu vou salvar aqui, para depois salvar esse arquivo e vocês terem como material para usar como complemento do curso.

[02:44] Então eu rodei o explain, “Format = Json” e query. Aí, nós vamos fazer o seguinte, nós vamos criar um índice, como é que eu crio um índice? Eu coloco o comando: “Alter Table” o nome da tabela, “Notas_Fiscais Add Index” e o campo que vai ser o índice e no caso aqui, eu vou colocar “Data_Venda”. [03:23] Por que que eu estou criando um índice para data_venda? Porque era o seguinte, aqui na minha consulta, note que a minha condição de filtro, que é where, eu tenho que buscar na tabela, registros cuja a data da venda é 01 de janeiro de 2017.

[03:47] Se eu tiver um índice pela data da venda, pelo campo data da venda, esse where vai ser muito mais eficiente, porque invés de eu percorrer a tabela toda, eu vou lá no índice, acho aquela posição através do BTREE ou do HASH e pegando esse cara, se for MyISAM, eu vou pegar a posição dos registros que aquele cara pertence ou se for InnoDB, a posição da primary key da tabela_notas_fiscais.

[04:24] E aí, eu consigo buscar as linhas da tabela que respeitam essa condição, por isso que, teoricamente, criar o índice vai funcionar, vai deixara query mais rápida, é o que vamos tentar ver se o plano de execução me mostra isso. Então, eu rodei esse comando aqui, o Alter Table, vou executá-lo aqui.

[05:04] Então, pronto, o índice foi criado, vamos rodar agora o explain novamente? Vou rodar de novo o explain. Vamos ver o custo da query? Olha só o custo da query, caiu para 60.28, ou seja, depois que eu rodo a criação do índice, o custo da query caiu para 60.28, olha com o que o custo melhorou.

[05:48] Para a gente ter certeza que realmente isso ajudou, note que... No Jason da consulta, onde o índice não havia sido criado, a gente tem aqui uma informação que é a seguinte: eu não tenho aqui... Eu tenho esse acess_type = all, significa que ele vai acessar a tabela toda.

[06:29] E eu não tenho uma informação aqui chamada key, porque ele não achou pelo critério que eu coloquei, que é where, nenhuma chave que me ajude a achar aquela informação. Agora, já no Json que a gente rodou com o índice, o access_type, mudou a ser ref e ele achou aqui uma chave possível data da venda e achou o índice aqui.

[07:07] Esse aqui data_venda, é o índice que eu criei, então ele achou esse índice e falou: “Opa, eu vou usar esse índice porque é melhor do que eu não usar nada”, enquanto que aqui em cima, ele não usou nenhuma chave, porque ele não encontrou.

[07:27] Para a gente ver que realmente o índice está fazendo diferença, a gente pode, depois que criar o índice, a gente pode apagar esse índice, é: “Alter Table Notas_Fiscais Drop Index Data_Venda”. Eu agora, apaguei o índice, o índice não mais existe, o que acontece então se a gente rodar o explain de novo?

[08:17] Vou tirar aqui o espaço e aqui, vou no final, colocar o “\G”. Pronto, agora melhorou. Note que o custo voltou ao valor 8994.33, “Poxa, mas o número, está diferente daqui”, na verdade esse custo da query é variável. Talvez vocês executando aí na máquina de vocês, vocês vão encontrar números diferentes.

[09:08] Isso, como eu falei, também depende muito da memória, do hardware que você está usando e assim por diante, mas o importante é que os dois são muito maiores do que 60.28, isso mostra o quanto que um índice, ele ajuda na resolução desse... de melhorar a consulta.

[09:32] Então, imagina que eu tenho um relatório, um relatório num sistema e o usuário fica reclamando: “Olha, eu rodo esse relatório aqui, demora séculos”, as vezes você criando um índice, vai fazer com que o relatório fique rápido. É o caso aqui em cima.

[09:52] Então tá, é isso que eu queria falar com vocês. Misturando um pouco agora a análise do plano de execução da query, com o índice para ver como é que ela melhora, quando você consegue adicionar os índices corretos. Valeu.


-----------------------------------------------------------------------
# 12Usando o Workbench

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58136

## Transcrição

[00:00] Vocês se lembram em alguns vídeos passados, a gente executou essas quatro consultas e teve esse plano de execução aqui, crescente. A gente consegue também fazer o plano de execução pelo Workbench.

[00:16] Eu vou criar aqui um script novo e vou pegar essa primeira consulta aqui e se eu rodar, claro, o comando aqui: “Explain” e eu rodar ela aqui, eu tenho um plano de execução em forma de tabela, aqui e eu posso também, se quiser, botar aqui: “Format Json” e executar essa consulta.

[00:57] Só que o Json fica meio... eu não consigo ver ele de uma forma mais “identada”, como eu consigo ver lá no... na linha de comando do MySQL, mas a informação mais importante, que é o custo da query, eu consigo ver, que está aqui. Agora, no Workbench, tem uma maneira mais fácil de ver o plano de execução.

[01:22] Se eu executar a consulta normalmente, eu aqui no canto direito, tenho formas de visualizar o resultado, a gente viu até esse tópico, quando viu o curso de consultas avançadas, não, foi o curso de... Eu não sei se foi o curo de consultas avançadas ou de manipulação de dados com o MySQL.

[01:46] A gente viu algumas opções diferentes que estão do lado direito do resultado da consulta, mas a última opção dessa lista é o plano de execução da query. Então, se a gente olhar aqui para baixo, clicar aqui no último, eu tenho aqui o plano de execução da minha consulta.

[02:15] Então, ele mostra, em mostra em vermelho o que ele teve que fazer... ele chama de um Full Table Scan, ou seja, percorrer a tabela nem nenhum índice por isso que ele está com a cor vermelha, ele fez isso com a tabela A e fez isso em 3.75, o custo, capturou 35 linhas a aí, exibiu o resultado.

[02:40] Agora, se eu pegar o segundo, vamos colocar aqui o segundo, eu vou criar um outro script, vou colar aqui e aí, eu vou rodar agora esse segundo... esse segunda consulta.

[02:55] Está lá o meu resultado e se eu for lá no plano de execução, eu já tenho um plano de execução um pouco mais complexo, onde ele aqui, nesse canto, ele fez o Full Table Scan, se eu deixo o mouse em cima, eu consigo ver informações mais detalhadas sobre essa tarefa.

[03:15] Depois, ele fez o Non-Unique Key Look, note que essa segunda busca ficou verde, porque ele achou um índice para estar fazendo essa busca. Depois eu falo um pouquinho mais a frente quem é esse índice, porque a gente não criou nenhum índice específico para o campo código produto lá da tabela de quantidades.

[03:48] Mas aí, depois, ele faz aqui o Join, junta as duas tabelas e mostra o nosso custo. Já, se eu pegar a terceira consulta, vou criar aqui um outro script, tenho aqui o meu resultado e aí, claro, essa terceira consulta já vai ter um plano de execução um pouco mais rebuscado, porque ele ai estar fazendo o Join de três tabelas.

[04:21] Então, pega a A, B, com a C, faz o Join, depois volta com a A, então, note que aqui eu tenho um custo crescente, o custo foi 133 mil, só para fazer esses dois Join, depois cresceu para 207 e aí, exibiu resultado... Esse tempo aqui, daqui para cima é o tempo de saída, o dado já está pronto, ele cospe de uma vez só, não perde muito tempo.

[04:47] E aí, o custo final fica praticamente igual ao custo desse segundo looping. E se a gente executar a nossa consulta usando o order by e o group by? A gente viu lá na linha de comando que o custo praticamente não se alterou e é claro que o resultado aqui também que ser o mesmo.

[05:14] Se a gente olhar o plano de execução, ele já é um pouquinho mais rebuscado, mas note que grupar e ordenar foi uma tarefa fácil, porque o dado já estava de uma certa maneira pronto aqui e o resultado final dessa tabela é muito pequeno, mas ele mostra aqui o plano de execução com crescimento do tempo, na medida em que os Joins vão sendo feitos.

[05:44] E depois, o group e order até o resultado final, que está aqui em cima. Então, esse plano de execução gráfico, ele dá uma noção até bem mais organizada, digamos assim, que o plano de execução, através da linha de comando, a gente vê o Json pronto.

[06:08] Então o Workbench é uma boa ferramenta para a gente estar fazendo esses plano de execução. Aí, eu queria aproveita então esse assunto e linkar com um outro tópico, que faz parte desse vídeo, que é o seguinte. Quando a gente executou essa consulta, note que ele tem aqui duas consultas em verde, porque ele usou, ele achou um índice para usar isso.

[06:37] Note, Index: Primary e ele usou a chave primária como índice, o que isso significa? Vocês se recordam que quando a gente viu os nossos cursos de MySQL, eu falei para vocês que existe duas entidades importantes dentro do banco de dados, que é a chave primária e a chave estrangeira.

[07:03] A crave primária, é aquela chave que faz com que nenhuma linha da tabela possa se repetir, se aquela chave se repetir também. Por exemplo, cadastro de cliente, eu tenho como chave primária o CPF, eu não posso ter dois clientes com o mesmo CPF.

[07:29] Por exemplo, uma tabela com automóveis, onde eu tenho como chave primaria a placa do veículo, eu não posso ter dois veículos com a mesma placa e a placa estrangeira é aquela que liga as tabelas, que faz o relacionamento entre as tabelas dentro do banco de dados.

[07:47] O que acontece é que quando eu crio chaves primárias ou estrangeiras, seja num momento de criação da tabela ou dá alteração da mesa, automaticamente o MySQL cria índices internos, usando como critério as chaves primárias e as chaves estrangeiras.

[08:08] Então, automaticamente uma chave primária e uma chave estrangeira em índices e é claro, porque internamente, o banco de dados vai fazer buscas ali. Quando eu vou incluir um novo registro, ele sempre vai testar se aquele registro já existe.

[08:27] Se ele vai testar, ele precisa procurar ele dentro da chave primária e essa busca, o índice é mais eficiente, da mesma maneira, quando a gente faz um relacionamento, se eu tenho uma tabela de notas fiscais que faz uma relação com a tabela de clientes, eu só posso colocar cliente na tabela de notas fiscais, que estejam no cadastro de clientes.

[08:50] Estão essa busca, esse cheque, antes de eu aceitar o insert, ele faz usando índice, por isso que as chaves primárias e estrangeiras possuem índice.

[09:03] Eu vou fazer um exercício agora para vocês aqui, que é o seguinte, eu vou criar aqui três novas tabelas sem índices e colocar todo o conteúdo do banco de sucos_vendas para essas tabelas e ver que quando a gente faz uma consulta que internamente não tem chave primária, nem estrangeira, o custo dela vai aumentar bastante.

[09:36] Então, olha o que eu vou fazer. Eu vou vir aqui, vou pegar a tabela de itens de notas fiscais, botão direito do mouse e vou vir “Send to”, “Create Statement”, eu tenho aqui o comando para criar a tabela itens_notas_fiscais.

[09:58] Eu vou colocar aqui um número 2, porque eu vou criar uma nova tabela e vou tirar todas essas linhas, porque essas linhas, são as linhas que criam a chave primária e as chaves estrangeiras para essa tabela. Opa, não foi. Selecionei, apaguei, agora foi.

[10:25] Vou fazer a mesma coisa, vou dar um “Enter” aqui, dois “Enter”, vou fazer a mesma coisa para a tabela de notas fiscais, vou apagar a criação das chaves primárias e estrangeiras e vou fazer também a mesma coisa com a tabela de produtos.

[10:53] Aqui, no caso, não tem chave estrangeira, a tabela de produtos, só tem chave primária e vou colocar aqui também o número 2 e o número 2. Então, vou criar três tabelas novas, sem chaves primárias e sem chaves estrangeiras. Executei.

[11:15] Vou agora pegar um novo script e vou fazer o seguinte, eu vou escrever esse comando aqui: “Insert Into”, a tabela: “itens_notas_fiscais2” e vou escrever isso daqui: “Select * From itens_notas_fiscais”.

[11:42] Ou seja, eu estou incluindo na tabela de notas fiscais 2, que é a sem índice, sem chave primária e estrangeira, ou seja, sem índices, o conteúdo da tabela original itens_notas_fiscais, essa sim com chave primária e com chave estrangeira. Estou executando. Pronto.

[12:05] Transferi 213.803 registros, vou fazer a mesma coisa com a tabela de notas fiscais. Rodando. Colocou 87.960 registros e vou fazer também com a tabela de produto. Opa, tabela de produtos, é no plural, é isso? É isso aí. Pronto.

[13:19] Então agora, eu tenho três tabelas que não possuem chaves primárias, nem estrangeiras, que são iguais as mesmas três tabelas que possuem chaves primárias e estrangeiras, vamos fazer um comparativo de consultas. Eu vou pegar essa consulta aqui, essa do meio, que faz o Join entre duas tabelas.

[13:43] Vou copiar ela aqui, vou criar um novo script e aí, esse custo aqui, 76.519 foi o custo original, com chave primária e estrangeira, com PK e FK. E eu agora, vou executar essa outra, essa mesma consulta, só que invés de usar a `tabela_de_produtos`, eu vou usar a `tabela_de_produtos2` e itens notas fiscais, itens notas fiscais 2.

[14:29] Vamos executar e ver se vai ter diferença no plano de execução. Rodei. Vamos olhar aqui o plano de execução. Note que o plano de execução fez isso em 769.497, ou seja, 10 vezes mais, 769.497.31, é o sem PK e FK, ou seja, como não tem chave primária, nem estrangeira, não tem índice, como não tem índice a query custa mais.

[15:12] E se a gente olhar aqui a resolução, note que aqui, ele teve que fazer um Full Table Scan nas duas tabelas, porque ele não achou índice, teve que percorrer a tabela toda para achar as coincidências, para ele poder fazer o join. Então, olha só, a diferença foi essa daqui.

[15:34] Então, isso mostra como que ter chave primária e ter chave estrangeira ajudam também na performance do banco, quando eu faço uma consulta. Então é isso aí. Valeu.


-----------------------------------------------------------------------
# 14A ferramenta mysqlslap

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58137

## Transcrição

[00:00] Antes de terminar a performance, eu gostaria de falar de uma ferramenta que já vem no MySQL chamado: MySQL Slap, o que que essa ferramenta faz?

[00:12] Ela simula acessos concorrentes a uma determinada consulta, assim, a gente aqui está vendo o custo da consulta, mas a gente consegue simular no MySQL... criar uma simulação, onde eu estou dizendo: “Vamos ver o que acontece se 100 usuários ao mesmo tempo, fazem 10 consultas nesta base, usando a consulta tal”.

[00:45] E aí, a gente pode usar ela com índice e ela sem índice e ver o resultado. Vamos começar, vamos pegar... vou criar aqui um script novo no Workbench, vamos pegar aquela consulta, “`Select * From Notas_Fiscais Where Data_Venda = 20170101`”.

[01:25] A gente executou, se a gente olhar o plano de execução dela, a gente tem lá um Full Scan, porque não estou usando índice, lembra? Se a gente criar aqui “`Alter Table Notas_Fiscais Add Index(Data_Venda)`”, então eu estou aqui criando um índice.

[01:59] E aí, agora, com o índice, se eu executo de novo a consulta no Execution Plan, note que ele fiou aqui verde, porque ele conseguiu usar o índice para poder fazer aquela busca da data específica, então a consulta ficou muito mais rápida, mas vamos simulas o acesso de várias usuários concorrentes a essa consulta.

[02:29] A gente vai comparar ela com essa daqui, com aquele 2, lembra? A tabela 1, 2, é uma tabela sem backup, sem FK e é claro, sem esse índice, porque o índice, eu criei na tabela normal, então vamos executar ela aqui. O custo original aqui deu 63.10, se eu executar consulta na tabela 2.

[03:02] Vamos olhar aqui o Execution Plan, deu um valor de 8.831.73, quer dizer, ficou bem mais pesada a consulta, mas vamos ver o resultado disso num sql slap. Então, para isso, eu vou voltar lá para o prompt do comando do Windows, no diretório Program Files, MySQL Server 8.0 bin e vou digitar `MySQLSLAP -uroot -p`.

[03:49] E aí, é o seguinte, eu vou entrar com dois parâmetros, um parâmetro é número de inteirações e o outro parâmetro é número de acesso concorrentes. Então, eu vou colocar aqui: `concurrency`, eu vou colocar 100, 100 acessos concorrentes, fazendo, `iterations 10`.

[04:39] Então aqui, eu estou dizendo: 100 acessos concorrentes, 10 interações, aonde? No create... espera aí, que eu estou... `iterations`, vamos lá para o final... `create_schema`, aí é o meu schema que eu estou usando, sucos_vendas e “query =” e entre aspas duplas, eu vou colocar aquela nossa consulta.

[05:24] Eu vou pegar primeiro a consulta com PK, com FK e com índice. Então, vamos ver se o comando ficou certo, ficou assim: “`Mysqlslap -uroot -p --concurrency = 100 --iterations=10 --create-schema, o nome do esquema, -equery select From Notas_Fiscais Where Data_Venda`”, tem a minha data da venda.

[06:06] Vamos rodar. Vou entrar com a senha. Vamos esperar. Está lá, ele fez a minha simulação e note, em média, essa query vai retornar em 0.54 segundos o seu resultado, nas simulações, o maior tempo foi 1.28 e o menor tempo 0.23 segundos.

[06:40] Agora, vou repetir o comando, só que agora, eu vou botar o 2, coloquei aqui o 2, para eu simular a outra tabela que não tem PK, não tem FK e não tem índice o data venda. Lembrando que o conteúdo das duas tabelas é o mesmo, porque uma foi fonte da outra.

[07:05] Então, eu vou rodar. Entrei com a senha. Eu não sei se deu para sentir, mas inclusive, visualmente o tempo está maior, está demorando mais tempo para fazer a simulação. Terminou.

[07:24] Note que o tempo médio foi de 0.54, para 2.6, o maior tempo que era 1.28, foi 3.44 e o menor tempo aqui foi 2.31, ou seja, o menor tempo na tabela que não tem chave primária, nem estrangeira, nem índice, o menor tempo ainda foi maior do que o maior tempo com os índices.

[08:02] Então, esse comando também é um comando muito legal para você testar, então, vale a pena você estar sempre usando o explain para ver o custo da query e o MySQL Slap para calcular o tempo. E aí, depois que a gente falou disso tudo, vem aquela pergunta: “Se eu acho uma query lenta, o que eu preciso fazer para que essa query fique rápida?”.

[08:34] Existem dezenas de procedimentos que podem ser feitos para a query melhorar, eu vou falar só de depois específicos. Primeiro, vamos pegar aquela query mais rebuscada, ela está aqui... A primeira coisa interessante, quando você tiver `Join`, que você garanta que haja índices nessas igualdades aqui.

[09:25] Claro que normalmente os Joins são feitos pelas PKs, então se a tabela não tem PK, cria PK, mesmo assim, se você fizer um `Join` com alguém que não tem índice, você cria o índice. Então, por exemplo, o código do produto, ele é índice na tabela de produtor e ele é índice na tabela de itens notas fiscais também, porque faz parte da PK.

[09:50] O número a mesma coisa, mas digamos que tivesse fazendo um Join com data ou tivesse fazendo `Join` com um atributo da tabela que não é chave. Então é interessante você criar um índice para ela.

[10:09] Outra dica importante é quando a gente fez essa última consulta, de quando eu tiver um `where`, principalmente wheres de igualdades, menor, maior, `between`, `like`, de também ter índice nesse campo que você utiliza para fazer o critério de filtro.

[10:40] Então, assim, existem várias outras coisas que podem ser feitas para a query ficar mais rápidas, mas seguindo esses dois pontos, você já vai ter grandes ganhos. Índices nas igualdades dos Joins e índice nos filtros de consulta, se você conseguir fazer isso, você vai conseguir um ganho enorme, em termos de resultados das suas consultas.

[11:10] É isso aí. Valeu, um abraço.


-----------------------------------------------------------------------
# 16Consolidando o seu conhecimento

Chegou a hora de você pôr em prática o que foi visto na aula. Para isso, execute os passos listados abaixo.


1) Na base **sucos_vendas**, abra um novo script MySQL.

2) Digite as três consultas abaixo:

```sql
SELECT A.NOME_DO_PRODUTO FROM tabela_de_produtos A;

SELECT A.NOME_DO_PRODUTO, C.QUANTIDADE 
FROM tabela_de_produtos A
INNER JOIN itens_notas_fiscais C ON A.codigo_do_produto = C.codigo_do_produto;

SELECT A.NOME_DO_PRODUTO, YEAR(B.DATA_VENDA) AS ANO, C.QUANTIDADE 
FROM tabela_de_produtos A
INNER JOIN itens_notas_fiscais C ON A.codigo_do_produto = C.codigo_do_produto
INNER JOIN notas_fiscais B ON C.NUMERO = B.NUMERO;

SELECT A.NOME_DO_PRODUTO, YEAR(B.DATA_VENDA) AS ANO, SUM(C.QUANTIDADE) AS QUANTIDADE 
FROM tabela_de_produtos A
INNER JOIN itens_notas_fiscais C ON A.codigo_do_produto = C.codigo_do_produto
INNER JOIN notas_fiscais B ON C.NUMERO = B.NUMERO
GROUP BY A.NOME_DO_PRODUTO, YEAR(B.DATA_VENDA)
ORDER BY A.NOME_DO_PRODUTO, YEAR(B.DATA_VENDA);
```

3) Se você executar estas consultas, uma a uma, você verá que, a cada execução, o tempo de retorno das consultar passa a demorar cada vez mais. É que cada consulta vai exigindo mais processamento do banco de dados:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/04/image43.png)

4) Na linha de comando do Windows, acesse o diretório do MySQL:

```bash
cd\
cd "Program Files"
cd "MySQL"
cd "MySQL 8.0"
cd Bin
```

5) Em seguida, acesse a interface de linha de comando do MySQL (a senha do usuário **root** será necessária):

```css
mysql -uroot -p
```

6) Já dentro da interface de linha de comando do MySQL, digite:

```css
explain SELECT A.NOME_DO_PRODUTO FROM tabela_de_produtos A;
```

7) Você verá alguns indicadores que refletem o custo de execução desta consulta.

8) Para visualizar em outro formato, digite:

```sql
explain format=JSON SELECT A.NOME_DO_PRODUTO FROM tabela_de_produtos A \G;
```

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/04/image38.png)

Acima, você terá o plano de execução desta consulta e o parâmetro `cost_info` expressa o custo de resolução desta _query_ (no caso acima, 3.75).

9) Veja o custo de outra consulta. Digite:

```sql
explain format=JSON SELECT A.NOME_DO_PRODUTO, C.QUANTIDADE FROM tabela_de_produtos A INNER JOIN itens_notas_fiscais C ON A.codigo_do_produto = C.codigo_do_produto; \G;
```

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/04/image44.png)

Aqui, o custo da consulta, pelo plano de execução, passou a custar 76.517,94. Dezenas de vezes em relação à medição original.

10) Veja o custo de mais uma consulta. Digite:

```sql
explain format=JSON SELECT SELECT A.NOME_DO_PRODUTO, YEAR(B.DATA_VENDA) AS ANO, C.QUANTIDADE FROM tabela_de_produtos A INNER JOIN itens_notas_fiscais C ON A.codigo_do_produto = C.codigo_do_produto INNER JOIN notas_fiscais B ON C.NUMERO = B.NUMERO \G;
```

O custo aumenta mais ainda (260.242,51).

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/04/image40.png)

11) Você pode acompanhar o plano de execução pelo Workbench. Execute a consulta:

```css
SELECT A.NOME_DO_PRODUTO FROM tabela_de_produtos A;
```

12) Exiba o resultado através da opção **Execution Plan**:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/04/image22.png)

Você terá:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/04/image16.png)

13) Comparar as outras consultas mais complexas. Primeiramente, execute:

```sql
SELECT A.NOME_DO_PRODUTO, C.QUANTIDADE FROM tabela_de_produtos A INNER JOIN itens_notas_fiscais C ON A.codigo_do_produto = C.codigo_do_produto;
```

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/04/image9.png)

14) Já na outra consulta mais complexa, digite:

```sql
SELECT SELECT A.NOME_DO_PRODUTO, YEAR(B.DATA_VENDA) AS ANO, C.QUANTIDADE FROM tabela_de_produtos A INNER JOIN itens_notas_fiscais C ON A.codigo_do_produto = C.codigo_do_produto INNER JOIN notas_fiscais B ON C.NUMERO = B.NUMERO
```

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/04/image17.png)

15) Quando você vê retângulos verdes, significa que a consulta utilizou algum tipo de índice. Quando você cria chaves primárias e estrangeiras, automaticamente, índices são criados e eles são usados nas consultas. Veja como isso acontece, primeiro criando três novas tabelas, com os comandos abaixo:

```sql
CREATE TABLE `itens_notas_fiscais2` (
  `NUMERO` int(11) NOT NULL,
  `CODIGO_DO_PRODUTO` varchar(10) NOT NULL,
  `QUANTIDADE` int(11) NOT NULL,
  `PRECO` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `notas_fiscais2` (
  `CPF` varchar(11) NOT NULL,
  `MATRICULA` varchar(5) NOT NULL,
  `DATA_VENDA` date DEFAULT NULL,
  `NUMERO` int(11) NOT NULL,
  `IMPOSTO` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `tabela_de_produtos2` (
  `CODIGO_DO_PRODUTO` varchar(10) NOT NULL,
  `NOME_DO_PRODUTO` varchar(50) DEFAULT NULL,
  `EMBALAGEM` varchar(20) DEFAULT NULL,
  `TAMANHO` varchar(10) DEFAULT NULL,
  `SABOR` varchar(20) DEFAULT NULL,
  `PRECO_DE_LISTA` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

Estas tabelas são semelhantes às existentes, mas sem chaves primárias e estrangeiras.

16) Inclua dados nestas tabelas, executando:

```sql
INSERT INTO itens_notas_fiscais2 SELECT * FROM itens_notas_fiscais;
INSERT INTO notas_fiscais2 SELECT * FROM notas_fiscais;
INSERT INTO tabela_de_produtos2 SELECT * FROM tabela_de_produtos;
```

17) Observe o plano de execução da consulta original:

```sql
SELECT A.NOME_DO_PRODUTO, C.QUANTIDADE
FROM tabela_de_produtos A INNER JOIN itens_notas_fiscais C
ON A.codigo_do_produto = C.codigo_do_produto;
```

Aqui, o custo foi de 76517.94.

18) Já executando a consulta com as tabelas sem chaves primárias e estrangeiras:

```sql
SELECT A.NOME_DO_PRODUTO, C.QUANTIDADE
FROM tabela_de_produtos2 A INNER JOIN itens_notas_fiscais2 C
ON A.codigo_do_produto = C.codigo_do_produto;
```

O custo sobe para 769497.31.

19) Veja a influência do índice. Execute e veja o plano de execução:

```sql
SELECT * FROM NOTAS_FISCAIS WHERE DATA_VENDA = '20170101'
```

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/04/image7.png)

20) Crie o índice, executando:

```sql
ALTER TABLE NOTAS_FISCAIS ADD INDEX (DATA_VENDA);
```

21) Veja o plano de execução novamente:

```sql
SELECT * FROM NOTAS_FISCAIS WHERE DATA_VENDA = '20170101'
```

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/04/image3.png)

22) Agora, apague o índice:

```sql
ALTER TABLE NOTAS_FISCAIS DROP INDEX DATA_VENDA;
```

23) E execute novamente:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/04/image11.png)

24) Há outra ferramenta, chamada **mysqlslap**, que simula acessos concorrentes a uma consulta. Você executa-o através da linha de comando. Logo, vá para:

```bash
cd\
cd "Program Files"
cd "MySQL"
cd "MySQL 8.0"
cd Bin
```

25) Execute:

```bash
MYSQLSLAP -uroot -p --concurrency=100 --iterations=10 --create-schema=sucos_vendas --query="SELECT * FROM NOTAS_FISCAIS WHERE DATA_VENDA = '20170101'";
```

26) Você terá:

```sql
Average number of seconds to run all queries: 0.548 seconds
Minimum number of seconds to run all queries: 0.203 seconds
Maximum number of seconds to run all queries: 1.281 seconds
Number of clients running queries: 100
Average number of queries per client: 1
```

A melhor execução da consulta retornou resultados em 0.548 segundos e a pior 1.281.

27) Use as tabelas sem chaves primárias e estrangeiras. Execute:

```bash
MYSQLSLAP -uroot -p --concurrency=100 --iterations=10 --create-schema=sucos_vendas --query="SELECT * FROM NOTAS_FISCAIS2 WHERE DATA_VENDA = '20170101'";
```

28) Você terá:

```sql
Average number of seconds to run all queries: 2.628 seconds
Minimum number of seconds to run all queries: 2.312 seconds
Maximum number of seconds to run all queries: 3.422 seconds
Number of clients running queries: 100
Average number of queries per client: 1
```


-----------------------------------------------------------------------
# 17O que aprendemos?

Nesta aula, aprendemos:

- O que é um índice
- Como funciona os algoritmos de Hash e BTree
- Como analisar um plano de execução
- Como o índice melhora o plano de execução
- Que as chaves primárias e estrangeiras criam índices e ajudam a melhorar o plano de execução
- A usar a ferramenta **mysqlslap**


-----------------------------------------------------------------------
# 02Criando um usuário administrador

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58138

## Transcrição

[00:00] Vamos continuar estudando, se vocês se lembram quando a gente instalou o MySQL, apareceu essa caixa de diálogo aqui em cima, é a definição da senha do usuário Root, o usuário root é um usuário que é criado durante a instalação e esse usuário tem super privilégios, consegue fazer tudo na máquina.

[00:23] Todos os nossos treinamentos, desde o início, até agora, a gente sempre usou o usuário root para fazer tudo, só que, duas coisas. Primeiro, quem cria esse usuário root e define essa senha, não é normalmente o DBA, pode ser um analista de suporte, um analista junior que esteja somente fazendo a instalação do produto e esse cara fica sabendo dessa senha.

[00:51] Claro que depois o DBA recebe desse analista a senha do usuário root e o DBA pode modificar, mas o que normalmente se faz é criar um outro usuário com privilégios de DBA e eventualmente, apagar o usuário root, já que ele somente é usado durante a instalação, ele é criado durante a instalação, para que eu possa acessar pela primeira vez o meu ambiente MySQL.

[01:21] E aí, sim, começar a fazer todo o gerenciamento. Então, o que nós vamos fazer agora nesse vídeo é simplesmente ir no MySQL, criar um usuário administrador e remover o usuário root. Então, eu vou minimizar aqui, eu estou aqui no meu Workbench, normalmente você vai ver aqui os esquemas, estou conectado com o usuário root.

[01:50] Eu vou até repetir essa conexão, eu vou fechar aqui. Na tela principal do Workbench, eu tenho lá essa instância de conexão que foi criada, inclusive automaticamente, quando a gente fez a instalação do produto e aí, eu entro aqui e aí, eu estou aqui conectado com o usuário root.

[02:13] Na aba administração, a gente tem a parte onde a gente administra os usuários do ambiente, então eu clico em administração e eu vou nessa opção aqui, Users and Privileges. Note que eu tenho aqui uma série de usuários já criados, esses usuários foram criados automaticamente pelo instalador.

[02:44] E nós temos aqui a máquina no qual esses usuários podem acessar o MySQL, ou seja, eu só consigo me conectar com o usuário root, se eu tiver na máquina localhost. Se eu tiver com uma outra máquina cliente e quiser entrar como root, eu não consigo.

[03:08] Então, nós vamos fazer o seguinte, nós vamos pegar esse usuário root e nós vamos apaga-lo, mas antes, claro, criar um outro usuário, que a gente vai chamar de administrador. Eu vou vir aqui e clicar aqui nessa caixinha, “A” de account.

[03:34] Eu tenho do lado uma caixa de diálogo pronta e eu vou colocar aqui admin01, aqui eu vou dizer qual é o host que esse cara pode usar, então eu vou colocar o localhost, a senha, eu vou até repetir, vou colocar também admin01 e ele confirma, pede para confirmar a senha.

[04:05] Na segunda aba: Account Limits, eu tenho limites que esse usuário pode fazer, quantas queries ele pode fazer em uma hora, quantos updates ele pode fazer em uma hora, é isso que está... Vou até diminuir um pouquinho para a gente ver o texto, quantas conexões concorrentes e assim por diante.

[04:27] Por enquanto, eu vou deixar 0, se eu deixar 0, significa que eu não tenho limite. Aqui nesse canto, eu tenho as administrações, do lado direito, eu vejo todos os privilégios que um usuário pode fazer no MySQL, alter, alter routine, create, create routine e assim por diante.

[04:55] E do lado esquerdo são algumas regras, algumas funções já previamente definidas. Então, se a gente clicar aqui em user, ele já marca alguns privilégios. Se eu disser: “Esse cara é monitor”, ele já tem aqui automaticamente outros privilégios.

[05:19] No caso do usuário que pode fazer tudo, eu vou marcar aqui como DBA, ao fazer isso, note que do lado direito, todos os privilégios globais foram selecionados, significa que ele pode fazer tudo. Eu vou clicar aqui em Apply e aí, o usuário 01, ele está definido aqui.

[05:50] Vamos testar, será que a gente consegue se conectar no MySQL usando esse usuário admin01? Vamos fazer o seguinte, eu vou fechar e aqui na página principal do Workbench, eu vou selecionar aqui para adicionar uma nova conexão. O nome dessa conexão vai ser Local com Admin01.

[06:21] O host é localhost, ou seja, o servidor onde está o MySQL, o usuário vai ser o admin01 e aí, a gente vai fazer o teste da conexão. Ele vai me pedir a senha, admin01, vou clicar nessa opção para já deixar a senha salva, para que quando eu clicar na conexão, não precise colocar essa senha novamente.

[06:48] Claro que isso não é uma coisa desejável em termos de segurança, mas para facilitar a vida da gente aqui, vamos fazer assim. Eu clico em ok, ele vai me dizer que a conexão foi feita com sucesso e aí, eu vou ter aqui uma segunda aba pronta. Eu vou vir aqui e aí, eu já consigo me conectar.

[07:12] E agora, eu estou conectado com o usuário administrador, admin01. Eu também poderia ter criado o usuário através de linha de comando, não necessariamente preciso usar a aba administrador essa parte aqui, para criar um usuário, eu posso fazer por linha de comando.

[07:46] Claro que pela caixa de diálogo fica até mais fácil de a gente fazer, mas vamos aprender a fazer por linha de comando, porque as vezes é importante que a gente já tenha um script sql pronto para a gente ter que recriar todos os usuários.

[08:02] Então, a gente não precisa, por exemplo, eu perco todas as configurações, eu não preciso ter que ir na caixa de diálogo e ficar clicando em cada um e criando manualmente, eu posso fazer um script para fazer isso de forma rápida. Então, eu vou criar um usuário admin02, com a mesma senha e mostrar a vocês como se faz.

[08:26] Então, eu digito “Create User”, aí, abrindo aspas simples, eu vou colocar o admin02@localhost. Ao fazer isso daqui, eu já estou definindo quem é o login do usuário e qual é o servidor que ele pode acessar, “identifided”, tem até aqui o comando, “BY” e aqui eu vou colocar a senha: admin02, ponto e vírgula.

[09:07] Nesse momento, eu vou criar um usuário, mas esse usuário não vai ter privilégio nenhum, então eu preciso agora adicionar privilégios a esse usuário. Então, eu coloco: `Grant All Privileges On *.* TO admin02@localhost With Grant Option` e acabou o comando.

[09:48] Esse comando aqui específico, ao dar privilégios `*.*`e `with grant option`, eu estou definindo que esse usuário 02, vai poder fazer tudo no MySQL, estou dando todos os privilégios para ele. Então, eu vou rodar o primeiro comando. Executou. Aqui em baixo eu consigo ver o resultado e agora eu vou rodar o segundo comando.

[10:22] Pronto, para a gente ver se o usuário foi criado realmente, se eu venho aqui em User and Privileges, claro que ele não está aparecendo aqui, mas se eu der um Refresh, vamos fechar a caixa de diálogo e abrir de novo, o Refresh não funcionou.

[10:41] Agora, sim, ele agora apareceu, tenho aqui o usuário admin02 criado, se eu clico nele, note, ele tem o privilégio de acesso pelo localhost e se eu for em Administrative Roles, eu tenho tudo selecionado para ele.

[11:03] Então, eu criei nessa aula um usuário administrador de duas formas, através do Workbench e através de linha de comando e preciso agora apagar, tirar fora o usuário root, se eu quiser. Atenção, para eu apagar o usuário root, eu não devo estar conectado como root, apesar do root poder fazer isso.

[11:28] Então, como eu estou já conectado como admin01, eu vou dar aqui `DROP USER 'root'@'localhost'`, tem que fechar aqui aspas simples, fechei. Vou executar o drop. Pronto, o usuário root não existe mais na máquina, quer ver? Eu vou fechar aqui, vou tentar me conectar aqui, naquela conexão original, que usa o usuário root como conexão.

[12:08] Note que ele me pede a senha do usuário root, eu vou colocar, note que eu não consigo, ele fica me perguntando porque, na verdade o usuário root não existe, por isso essa caixa de diálogo fica aparecendo e por mais que eu coloque a senha correta, ela volta e ela não deixa eu me conectar com o usuário root.

[12:29] O único usuário agora que eu posso conectar é o usuário admin, então essa conexão aqui, se eu clicar aqui nesse símbolo de administração das conexões, eu tenho as conexões aqui, então posso pegar essa primeira conexão, que foi aquela que foi criada automaticamente pelo processo de instalação do MySQL e clicar no delete.

[12:55] Vou dar um close. Pronto. Eu tenho agora o meu ambiente, somente com usuário admin01 e admin02, configurados para acesso, com total privilégio sobre o MySQL. Valeu gente. Obrigado.


-----------------------------------------------------------------------
# 04Criando um usuário normal

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58139

## Transcrição

[00:00] Grande parte dos usuários do ambiente de MySQL, claro, não terão privilégios de administrador, eles não poderão fazer tudo, normalmente nós temos o usuário, que seria o usuário comum, o usuário que vai acessar as bases de dados e vai poder fazer inserção, alteração, exclusão, consulta, uma série de coisas na base de dados.

[00:24] Mas ele não vai poder, claro, criar usuário, criar sub-rotina e assim por diante, então vamos agora criar um outro grupo de usuários, nós vamos criar esses usuários pelo Workbench e por linha de comando, agora com privilégio apenas de manutenção normal da base de dados, ou seja, será um usuário comum.

[00:49] Então, eu vou primeiro pelo administrador do Workbench, indo então aqui na aba administração, eu clico aqui Users and Privileges e vou adicionar uma conta. Esse usuário, eu vou chamar de user01, também vai estar limitado ao acesso pelo localhost, a senha, eu vou repetir, user01 e vou confirmar essa senha, user01.

[01:20] Nas regras de administração, claro, eu vou desmarcar aqui DBA, porque eles não vão poder ter todos os privilégios e eu vou marcar aqui alguns privilégios importantes. O primeiro privilégio que eu vou marcar é o select, ou seja, o usuário pode fazer seleções, fazer consultas na base de dados.

[01:44] Um outro privilégio que eu vou estar colocando é o insert, esse usuário pode inserir dados nas bases de dados. Vamos lá, update, ele pode modificar dados e delete, ele pode eventualmente também apagar dados.

[02:06] Existem três outros privilégios interessantes que sempre é bom o usuário normal ter, é create temporary tables, o lock tables e finalmente o execute. Aqui, o execute. Vou dar um Apply e aí, o usuário, digamos assim, ele está criado. Claro, então esse usuário que nós acabamos de criar é um usuário que não tem todos os privilégios.

[02:51] Novamente, a gente atribuiu o privilégio de seleção de tabela, para ele poder ver, de manutenção de tabela, inserir, alterar ou excluir, seria o insert update e delete, em qualquer tabela e qualquer esquema. Normalmente, esses seriam os privilégios básicos para um usuário realmente básico.

[03:17] Mas, por exemplo, o create temporary tables, foi importante eu ter criado também este privilégio, porque normalmente para fazer declaração de variáveis complexas ou eventualmente o usuário está trabalhando com consultas um pouco mais rebuscadas, ele pode querer estar criando tabelas temporárias.

[03:47] E ele poder criar tabelas temporárias, não é uma coisa que configure problema de segurança para o ambiente, porque as tabelas temporárias normalmente, elas são criadas localmente, apenas aquele usuário consegue ver essas tabelas e depois de algum tempo, quando o usuário sai da conexão, desliga, faz o logoff, normalmente essas tabelas temporárias são apagadas.

[04:24] Mas aí, é importante quando a gente atribuir privilégios a um usuário normal, de a gente ter cuidado de não associar a ele privilégios, por exemplo, desnecessários, privilégios que ele realmente não precise ter e aí, impedir que haja, por exemplo, problemas de segurança.

[04:50] Um outro privilégio que a gente colocou aqui, diferente, foi o lock table. O lock table, ele permite que o usuário bloqueie as tabelas, as vezes isso é útil quando eu tenho uma aplicação que tem acessos simultâneos.

[05:12] E aí, fatalmente o MySQL vai ter que locar uma tabela, enquanto esse usuário está fazendo alguma coisa, principalmente porque, não necessariamente o usuário, mas aplicações que utilizam o MySQL, utilizam lock tables para poder fazer o controle de acessos.

[05:36] E aí, o usuário que estiver usando essa aplicação, ele vai se conectar na aplicação, mas vai estar indo banco de dados através de um usuário. Logo o lock tables tem que estar selecionado.

[05:49] Mas, claro que o lock tables é um pouco perigoso, isso pode fazer com que o usuário, por algum motivo, consiga trancar uma tabela e essa tabela fique presa durante muito tempo, torando os dados inúteis e exigindo uma manutenção do DBA, para que essas tabelas fiquem, digamos assim, liberadas.

[06:15] Então o lock table, para um usuário normal, é interessante que você saiba muito bem se realmente vai ser necessário ou não e o que vai tomar a sua decisão, vai ser basicamente o que o aplicativo que acessa o MySQL vai precisar fazer no banco, para que esse lock table ou não, esteja habilitado.

[06:39] Uma outra permissão que a gente colocou aqui para um usuário comum, digamos assim, fora do normal é o execute. O execute da direito ao usuário chamar stored procedure ou funções e executá-las.

[06:54] Isso não permite que o usuário as crie, então isso não é um problema de segurança, ele pode executá-las, mas ao executa-las, ele pode fazer coisas dentro do stored procedure que o privilégio dele não permita.

[07:14] Então, novamente, o uso do execute para o usuário, seria mais focado quando ele está utilizando alguma aplicação que tenha stored procedure armazenadas e aí, sim, essa aplicação vai precisar executar as stored procedure para o seu bom funcionamento.

[07:38] Claro que todas essas... a criação desse usuário e a configuração desses privilégios podem ser também configurados através de linha de comando. Então, eu vou aqui... vou até copiar esses três comandos que eu utilizei, quando a gente configurou por linha de comando usuário/administrador.

[08:02] Eu vou criar um novo script aqui e aí, aqui eu vou editar e eu vou colocar o usuário user02, a senha vai ser user02, vou tirar esse drop, eu não vou mais precisar apagar o usuário root e aí, na (garantia) dos privilégios, eu vou tirar esse all privileges e vou escrever aqui todos os privilégios que ele pode ver.

[08:31] Então, por exemplo, ele vai poder ver select, insert, update, limites, create temporary tables, lock tables, execute e aqui eu vou coloca user02 e eu tiro esse “with grant option”. Então, ficou assim, criei o usuário, o comando de criar o usuário é o mesmo, independente do que esse usuário vai fazer.

[09:18] E aí, eu dou privilégios, grant a fazer esses processos todos, que são os mesmos privilégios daqueles (cheques) que eu coloquei, quando eu usei a caixa de diálogo do Workbench, para criar esse usuário. Específico o usuário e tiro aquela parte final que era usada somente quando a gente cria um usuário que pode fazer tudo.

[09:50] Então, eu vou executar o primeiro comando. Executei. Vou executar o segundo comando. Executei. Então, se eu for aqui de novo no... desaprendemos, tem que fechar e abrir de novo.

[10:09] Clicando em Users and Privileges, pronto, eu tenho o usuário02 aqui criado e se eu selecionar ele e for aqui em privilégios, eu tenho só aqueles privilégios que foram mencionados na linha de comando. Então é isso aí. Valeu.


-----------------------------------------------------------------------
# 06Criando um usuário para somente leitura

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58140

## Transcrição

[00:00] Um outro tipo de usuário que é muito comum ser criado em ambientes MySQL, é aquele usuário que só tem privilégios de leitura, ele só consegue ler dados e não pode inserir, alterar, nem excluir. É claro que a criação é muito parecida com o usuário normal, só que a gente vai cortar alguns privilégios.

[00:23] Vou vir aqui e Users and Privileges, vou dar um Add Account e eu vou criar um usuário read01, localhost e read01, vou confirmar a senha. Vamos aqui em... as regras de administração, para a gente apagar o que está selecionado, a gente faz assim, a gente clica em DBA e desclica de novo, aí tudo fica limpo.

[00:58] E aí, eu vou colocar select e vou colocar execute, já, já vou explicar porque que eu coloquei o execute. Vou dar o Apply, usuário read foi criado. Claro que linha de comando, muito semelhante.

[01:18] Então, eu vou pegar aqui o comando que a gente usou para criar o usuário leitura, vou criar um novo script aqui, vou colar e vou colocar aqui read02, vou manter o select e vou manter o execute. Crio o usuário, dou a ele os privilégios de acesso. Agora, por que que eu coloquei o execute?

[02:02] Novamente vai depender do que você realmente quer que esse usuário faça, normalmente, alguns relatórios possuem consultas muito complexas, que os desenvolvedores acabam criando stored procedures para fazer esse relatório.

[02:21] Então é necessário que esse usuário que só tem privilégio de leitura, possa executar stored procedure, que na verdade, ele vai estar executando consultas complexas, que estão dentro das stored procedure. Mas há perigo, como ele pode executar stored procedure, se dentro da stored procedure tiver um insert, update, delete.

[02:46] Ou seja, tiver algum tipo de comando que não está dentro do privilégio original criado, o MySQL vai ignorar e vai fazer a inserção, a alteração ou a exclusão, ou seja, o usuário leitura, se ele acaba tendo privilégio de execute, ele consegue fazer atualização no banco, se tiver esses comandos dentro do stored procedure.

[03:14] Então tem que se tomar muito cuidado, claro que ele não pode criar uma stored procedure, então ele não pode modificar aquela inclusão, alteração ou exclusão, que o desenvolvedor fez.

[03:25] Então, se ele rodou aquilo, se lá dentro há uma inclusão que não deveria ser feita, uma exclusão ou alteração, claro que a culpa não vai ser do usuário, a culpa vai ser do desenvolvedor que fez uma stored procedure errada e o administrador que permitiu que esse usuário pudesse executá-la.

[03:48] Seria culpa do usuário se ele tivesse colocado o comando insert, ele mesmo, mas como ele não pode, através desses privilégios que estão aqui, isso nunca vai acontecer. Temos aí, então, mais um exemplo de um usuário diferente, que é um usuário somente de tipo leitura. Valeu.

-----------------------------------------------------------------------
# 08Criando um usuário para backup

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58141

## Transcrição

[00:00] Desastres podem ocorrer no nosso banco de dados, a gente pode por algum motivo perder informação ou alguma coisa pode acontecer durante a manutenção da base de dados e lixo pode ser incluída dentro dela. Então, nós vimos já, inclusive nesse curso, que o backup é uma política muito importante.

[00:25] E claro, é função do usuário administrador fazer backups, mas vezes não é ele que vai fazê-los, talvez tenha dentro da área da empresa, uma pessoa preocupada em fazer isso e esse usuário, ele não é o administrador, ele é o DBA, mas ele só vai fazer backups.

[00:47] E esses backups, nós vimos também, por de ser feito de duas maneiras ou a gente copia todo o dado o a gente usa os comandos dentro o MySQL, para fazer o nosso backup. Aqueles comandos que eu preciso entrar no MySQL, para fazer o backup, eu preciso me conectar e esse usuário que faz essa conexão, ele precisa de alguns privilégios especiais.

[01:12] O que nós vamos fazer agora, é criar um usuário que somente possa fazer backup. Usando a nossa forma de estar mostrando esses usuários, eu primeiro vou criar pelo Workbench e depois por linha de comando. Então, eu vou na aba administração, administration, clico em User and Privileges e adiciono uma conta.

[01:37] Vou colocar aqui back01, localohost, back01, back01. Vou aqui em Administrative Roles, marco e desmarco o DBA, para poder limpar tudo e aí, os privilégios que eu preciso são: privilégio de select, de reload, lock tables, ele precisa trancar as tabelas e replication cliente.

[02:27] São esses quatro privilégios aqui, necessários para que possa ser feito backups. Vou dar um Apply, ok. Usuário back01 foi criado. Da mesma maneira a gente pode fazer por linha de comando, vou pegar esses dois comandos do último script que nós criamos, vou criar um script novo, vou colar aqui e eu vou substituir, back02, agora, a senha back02, vou repetir aqui o usuário.

[03:10] E os priviléfios? Select, eu vou manter, ele também tem o reload, ele tem o privilégio lock tables e tem o privilégio replication client. O texto que eu coloco aqui é o mesmo texto que aparece lá nas opções, então é uma forma até de você saber como é que é a sintaxe certa do comendo.

[04:02] Vou criar o usuário back02 e vou dar privilégios a ele. Pronto, eu agora tenho o meu usuário que só pode fazer backup, criado no meu ambiente.


-----------------------------------------------------------------------
# 10Acessando de qualquer servidor

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58142

## Transcrição

[00:00] Todos os usuários que criamos até agora, tem uma característica específica, eles só podem acessar o MySQL, através do localhost. Quando a gente coloca isso daqui, o @localhost, quando cria um usuário, estou dizendo que este usuário, ele somente pode fazer login, se ele estiver usando como cliente uma máquina localhost.

[00:26] Mas, isso normalmente não é assim, ninguém vai entrar no console do servidor para fazer uma conexão, normalmente a pessoa usa (range de IP) ou usa... pode usar qualquer outra máquina para acessar a base.

[00:43] Então, vamos aprender agora a como dar privilégios a usuários e dizer para ele, por exemplo, qual é o (range) de máquinas que ele pode usar para se conectar com a base. Vamos começar criando um usuário genérico, que ele pode, digamos assim, acessar de qualquer lugar.

[01:06] Então, eu vou vir aqui em Users and Privileges, eu vou dar um Add Account e vou criar um admingeneric01. E aí, basta eu usar o default que é apresentado quando a gente abre essa caixa de diálogo.

[01:27] Se eu manter esse percent na caixa de diálogo, significa que o admingeneric01 vai poder acessar de qualquer lugar, então nem vou mexer nisso, vou deixar o percent. Vou botar aqui a senha, repetir a senha e como esse cara vai ser DBA também, eu vou dar todos os privilégios para ele.

[02:02] Dou um Apply e está aqui, a gente consegue ver que o admingeneric, ele vai conseguir acessar de qualquer máquina. Também podemos, claro, dar privilégio... criar isso através do seguinte comando, eu vou pegar aquele script que a gente usou no primeiro vídeo dessa aula, onde a gente criou um usuário administrador, já que o admingeneric, também é administrador.

[02:33] E eu vou colocar aqui, então ele vai ser admingeneric02, vou colocar a senha aqui, só que aí, onde está localhost, eu coloco o percent, desta maneira aqui, coloco o percent. Então, eu estou dizendo que esse cara, ele vai poder acessar a base do MySQL de qualquer cliente, de qualquer lugar.

[03:07] Vamos criar o usuário, criado com sucesso e vamos dar aqui os privilégios de acesso. Se a gente vier aqui, já aprendemos que a gente tem que fechar, clicar aqui na caixa de diálogo de novo para abrir, temos aqui o admingeneric02 criado de qualquer servidor.

[03:35] Eu tenho várias formas de usar esse caractere coringa, esse caractere percent, eu tenho aqui uma apresentação, onde eu posso dar aqui alguns exemplos.

[03:47] Se no lugar de percent, eu colocar 192.168.1.%, tudo daqui para trás é genérico, então qualquer IP deste... se o cara tiver no IP 192.168.1.0, até 192.168.1.255, que é o máximo que ele pode ir, ele vai conseguir acessar na base. Se eu substituir o percent por underscore, o underscore vai substituir qualquer número que esteja aqui ou letra.

[04:20] No caso, se eu usar `192.168.1.1.__`, dois underscore, eu posso ir do 00 ao 255, é o range de IP que eu posso estar usando e por exemplo, se eu colocar não um IP, mas um endereço URL, por exemplo: `client__.mycompany.com`, eu posso usar client dentro do lugar do underscore, pode ser qualquer letra ou número “.mycompany.com”, porque as vezes eu posso ter sites diferentes, mas usando sempre o mesmo sufixo.

[05:02] Aí, eu posso, se eu tiver o domínio, por exemplo, mycompany.com, eu posso acessar o MySQL de qualquer máquina, domínio, por exemplo. Então, no lugar onde eu botei o percent, eu posso botar esses endereços dessa forma, que aí, eu vou estar dando privilégios de conexão através de outras máquinas, sem ser o localhost.

[05:28] É isso aí. Valeu.

-----------------------------------------------------------------------
# 12Limitando o acesso aos esquemas

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58143

## Transcrição

[00:00] A gente, até agora aqui, criou todos os usuários, acessando todos os esquemas, mas nem sempre é assim que temos que fazer, nós temos vários esquemas e pode ser o usuário só possa ver um esquema específico do que está aqui, então vamos fazer agora o seguinte.

[00:18] Vamos criar um usuário do tipo normal, que pode incluir, alterar, excluir, consultar dados com um esquema e vamos fazer a criação desse usuário, tanto através do Workbench, como também através de linha de comando.

[00:37] Então, vou aqui primeiro em Administration, vou clicar aqui em User and Privileges e vou adicionar um usuário novo e esse usuário vai ser o user03. Vou manter aqui o qualquer host, ou seja, ele vai conseguir acessar de qualquer máquina, user03, a senha, user03.

[01:05] Em Administrative Roles, eu marco e desmarco o DBA, para garantir que está tudo limpo e ele vai ter select, update, delete, insert, create temporary tables, lock tables e execute, só que eu não vou parar por aí. Eu preciso agora especificar qual é o esquema que esse usuário pode acessar.

[01:42] E aí, eu venho aqui em Schema Privileges, essa aba aqui do lado e eu tenho um botão meio escondido aqui no canto, que é o Add Entry, eu vou clicar aqui e aí, eu vou escolher aqui um schema, por exemplo, sucos_vendas, vou dar um ok, tenho um schema aqui e poderia, inclusive, fazer um critério de acesso dentro do schema, coisas que ele poderia fazer somente naquele schema.

[02:22] Vou dar um Apply e aí, o usuário foi criado aqui o user03, foi criado com sucesso. Agora, como é que eu faço por linha de comando? Vou repetir o comando de criação de usuário: “Create user ‘user04’ @ ‘%’”, ou seja, todos os sites, “Identified by ‘user04’” e vamos dar o acesso, “Grant, select, insert, update delete, create temporary tables, lock tables, execute on”.

[03:49] Normalmente, a gente colocaria o asterisco, ponto, asterisco, mas no nosso caso, eu quero que ele somente acesso suco_vendas, então eu vou colocar aqui: “suco_vendas.*”, vou até botar em letra minúscula, “To” e eu repito aqui a identificação do usuário.

[04:24] Então, note, invés de usar asterisco, ponto, asterisco, eu coloquei lá o nome do schema, ponto, asterisco. Criei o usuário, adicionei os privilégios. Vamos ver somo é que esse usuário vê o ambiente, se eu me conectar como ele? Então, vou voltar aqui para a área principal, vou criar um acesso novo.

[04:53] Vou botar assim: Local como User04, por exemplo, e eu vou estar colocando aqui localhost, usuário, user04, testar a conexão, senha, user04, salvo a senha, conectei com sucesso. Vamos entrar como user04, deixa eu só modificar aqui, então vamos lá, vou entrar como user04.

[05:33] Entrei, vamos olhar schemas, olha lá, eu cliquei em schema, ele só olha sucos_vendas e mais, eu poderia também limitar o acesso a uma tabela, porque ele está vendo suco_vendas, mas ele consegue ver todas as tabelas.

[05:53] Então, vou voltar aqui para a conexão admin01 e vou criar aqui um usuário05 e vou dar aqui também Grand para eles, só que aqui, no caso, eu vou tirar esses Grands, só vou dar select, insert, update, delete, porque como agora eu vou limitar uma tabela, somente esses grand são válidos.

[06:23] E aí, o que eu coloco é o seguinte, no lugar aqui do asterisco, o nome da tabela, vamos olhar qual é a tabela que a gente vai usar, por exemplo, tabela_de_clientes e não para por aí, se eu quiser dar Grand diferente para outra tabela, eu posso vir aqui, copiar, colar, por exemplo, tabela_de_produtos.

[06:54] Só que para a tabela_de_produtos, ele só pode selecionar, então olha só o que eu estou fazendo aqui, eu estou criando o usuário05, dando Grand de select, insert, update, delete para a tabela de clientes e dando Grand de select, para a tabela de produtos.

[07:14] Então, criei o usuário, dou um tipo de Grand, dou um segundo tipo de Grand, se eu vier de novo aqui na User and Privileges, tem lá o meu usuário05 criado. Vamos olhar aqui, clicando nele, ele não tem nenhum privilégio global, mas ele tem privilégios específicos.

[07:49] Vamos fazer um teste, vamos ver o usuário05, realmente, só vai ver aquelas duas tabelas. Cliquei em home, voltei para a tela principal do Workbench e vou adicionar uma nova conexão, Local como User05, localhost, é a localização do servidor, user05, testa a conexão, está ok, vou dar o ok.

[08:24] Vamos entrar com o user05. Entrei, só vejo sucos_vendas e quando eu abro aqui, só vejo as duas tabelas, ou seja, eu estou limitado a olhar apenas a tabela de clientes e produtos. Sendo que, vamos olhar aqui de novo, no nosso script. A tabela de produtos, eu posso só dar select.

[08:53] Então, se eu quiser dar aqui um... Vamos ver as colunas aqui. A gente pode fazer assim, botão direito do mouse sobre tabela_de_produtos, Send to Editor, Insert Statement.

[09:10] Então já tenho aqui o insert completo, eu só vou alterar aqui o código do produto, eu vou colocar 999999, nome do produto, vou colocar um qualquer coisa, embalagem também qualquer coisa, tamanho, caractere qualquer, sabor também e preço de lista, eu vou colocar um valor aqui 10.

[09:47] Eu estou como usuário05 e vou dar um insert. Olha lá, tive um erro, o insert, o comando insert para o usuário05 não é permitido, porque o usuário05 só pode consultar tabela, ele não pode inserir coisas na tabela. Então tá, era isso aí que eu queria mostrar para vocês. Valeu.

-----------------------------------------------------------------------
# 14Revogando privilégios

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58144

## Transcrição

[00:00] Como é que eu faço para limpar os privilégios de um usuário? A gente já viu aqui no último vídeo, que eu posso, depois que eu criei um usuário ir dando o comando Grants seguidamente, que é como se eu fosse adicionando aos pouquinhos novos privilégios, mas eu quero limpar esses privilégios, para começar de novo do zero, digamos.

[00:24] Pois bem, vamos fazer isso de duas maneiras, usando o administrador e usando o comando, para usar o administrador é muito simples, basta eu ir aqui na aba administração, eu tenho que estar com o administrador, claro, clico em Users and Privileges.

[00:43] A gente vai pegar o usuário user01, que está aqui, que ele tem aqui uma série grants globais e aí, aqui em esquemas, eu vou adicionar, por exemplo, que ele só pode ver o esquema sucos_vendas e eu vou dizer que ele só pode fazer select, insert, update, delete e execute na base sucos_vendas.

[01:18] Então, eu mudei o grant dele, vou dar um Apply, pronto, o grant foi alterado. Agora, como é que eu faço por linha de comando? Eu vou criar um script novo e aqui e aí, a gente vai ver uns comandos também legais. Se eu der um “Select * from mysql.user”, eu consigo ver os usuários que estão no meu ambiente.

[01:49] E aí, eu tenho aqui todas as informações que o usuário possui. Eu posso, por exemplo, verificar as permissões de um usuário de forma específica através de comando, “Show grants for user02@localhost”, deixa eu rodar esse comando, tenho lá todo o grant, todos os privilégios que esse usuário possui.

[02:33] Vamos apagar esses privilégios, deixar ele sem privilégio nenhum “Revoke all privileges grant option from” e aí, eu coloco o meu usuário. Esse comando vai limpar todos os privilégios que o usuário user02 possui. Executei. Se eu der um show grants novamente, note que eu não tenho nada.

[03:13] Aí, eu posso agora, claro, dar o grant, por exemplo, select, insert, update, delete, create temporary tables, lock tables, execute, on _.* to” o usuário. Voltei a criar o grant dele, mas eu posso adicionar, “Grant, select, insert, update, delete, to sucos_vendas._”, ou seja, ele vai poder selecionar, inserir, alterar, excluir todas as tabelas. “To user localhost”.

[04:31] Vamos lá, eu coloquei certo aqui? Sucos_vendas to... é on aqui. Pronto. Grant, os privilégios, on, somente o schema sucos_vendas, to user02@localhost. Pronto. Se eu agora for aqui no... vou fechar o administrador de novo.

[05:09] Vou clicar aqui em administração, abri ele novamente, user02 está aqui, tenho os grants generics e schema, privileges está lá, ele pode ver sucos_vendas, delete, insert, select e update. Então é assim que eu posso revogar e incluir novamente privilégios de um usuário. Valeu.

-----------------------------------------------------------------------
# 16Consolidando o seu conhecimento

Chegou a hora de você pôr em prática o que foi visto na aula. Para isso, execute os passos listados abaixo.

---

1) Quando você instalou MySQL, foi criado um usuário **root**, com privilégios de administrador. Mas, normalmente, este usuário é apagado e substituído por um administrador real.

2) No **Workbench**, clique na aba **Administration**.

3) Clique em **Users and Privileges**.

4) Você terá, do lado esquerdo, a lista de usuários do ambiente, na qual você pode ver o usuário **root**:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image13.png)

5) Clique no botão **Add Account**.

6) Na caixa de diálogo, aba **Login**, preencha os campos **Login Name**, **Limit to Hosts Matching**, **Password** e confirme a senha:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image6.png)

7) Na aba **Administrative Roles**, escolha o que este usuário pode fazer no MySQL. Selecione **DBA**, assim tudo será marcado:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image41.png)

8) Clique em **Apply**, assim o usuário será criado.

9) Feche a aba da conexão do Workbench:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image4.png)

10) Você pode, na tela de conexões, criar uma nova, com o usuário criado nos passos anteriores:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image21.png)

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image23.png)

11) Clique em **Test** e salve a conexão.

12) Entre no Workbench com o usuário criado nos passos anteriores.

13) O usuário poderia ter sido criado via SQL. Crie um outro usuário administrador (**admin02**). Digite:

```sql
CREATE USER 'admin02'@'localhost' identified BY 'admin02';
GRANT ALL PRIVILEGES ON *.* TO 'admin02'@'localhost' WITH GRANT OPTION;
```

14) Se você voltar à tela de **Users and Privileges** e executar um **Refresh**, você irá ver este novo usuário, com seus privilégios:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image29.png)

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image39.png)

15) Para apagar o usuário **root** original, digite:

```sql
DROP USER 'root'@'localhost';
```

16) Se você tentar se conectar com usuário **root**, não irá mais conseguir, porque este usuário não existe mais.

17) O que vai determinar o que um usuário poderá fazer ou não, são seus parâmetros, tanto na caixa de diálogo do Workbench quanto via SQL.

18) Crie um usuário **user01**, usando a aba **Administration** e a opção **Users and Privileges**. Este usuário terá os privilégios: **CREATE TEMPORARY TABLES**, **DELETE**, **EXECUTE**, **INSERT**, **LOCK TABLES**, **SELECT** e **UPDATE**:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image30.png)

19) Clique em **Apply**.

20) Crie um outro usuário normal, mas agora via SQL. Digite:

```sql
CREATE USER 'user02'@'localhost' identified BY 'user02';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE TEMPORARY TABLES,
LOCK TABLES, EXECUTE ON *.* TO 'user02'@'localhost';
```

21) Crie um usuário somente leitura, com login **read01**, através da caixa de diálogo e o **read02**, via SQL. Para estes usuários, os privilégios serão **SELECT** e **EXECUTE**:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image12.png):

```sql
CREATE USER 'read02'@'localhost' identified BY 'read02';
GRANT SELECT, EXECUTE ON *.* TO 'read02'@'localhost';
```

22) Vá para mais dois usuários, com os logins **back01** e **back02**. Aqui, estes usuários somente podem criar backups:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image42.png)

```sql
CREATE USER 'back02'@'localhost' identified BY 'back02';
GRANT SELECT, RELOAD, LOCK TABLES, REPLICATION CLIENT ON *.* TO 'back02'@'localhost';
```

23) Todos os usuários criados até aqui só podem acessar o banco de dados através da máquina **localhost**. Quando você cria um usuário,se você manter **%** ou **_** no campo **Limit to Hosts Matching**, você irá determinar que outros IPs possam ser utilizados para acessar o banco. Estes caracteres funcionam como curinga:

```sql
CREATE USER 'admingeneric02'@'%' identified BY 'admingeneric02';
GRANT ALL PRIVILEGES ON *.* TO 'admingeneric02'@'%' WITH GRANT OPTION;
```

24) Você também pode limitar o acesso às bases e tabelas. Crie o usuário **user03**, mas, em vez de adicionar privilégios globais na aba **Administrative Roles**, acesse a aba **Schema Privileges** e adicione o esquema a ser acessado:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image24.png)

25) O mesmo comando pode ser digitado por SQL. Inclusive, abaixo, você pode criar o usuário simplesmente e depois adicionar, em outro comando, os privilégios:

```sql
CREATE USER 'user04'@'%' IDENTIFIED BY 'user04';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE TEMPORARY TABLES, LOCK TABLES, EXECUTE
ON sucos_vendas.* TO 'user04'@'%';
```

O usuário criado acima somente pode ver a base **sucos_vendas**.

26) Crie uma conexão para o usuário **user04**:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image47.png)

27) Se conecte e note que somente a base **sucos_vendas** é disponibilizada para acesso:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image10.png)

28) Você pode limitar o acesso às tabelas, dando permissões do que pode ser feito nelas:

```sql
CREATE USER 'user05'@'%' IDENTIFIED BY 'user05';
GRANT SELECT, INSERT, UPDATE, DELETE
ON sucos_vendas.tabela_de_clientes TO 'user05'@'%';
GRANT SELECT
ON sucos_vendas.tabela_de_produtos TO 'user05'@'%';
```

Estes comandos estão dando privilégios para inclusão, alteração, exclusão e consulta para o **user05** na **tabela_de_clientes**, mas somente leitura na **tabela_de_produtos**.

29) Crie uma conexão para o usuário **user05** e entre no Workbench.

30) Execute o comando:

```go
INSERT INTO `sucos_vendas`.`tabela_de_produtos` (
    `CODIGO_DO_PRODUTO`,
    `NOME_DO_PRODUTO`,
    `EMBALAGEM`,
    `TAMANHO`,
    `SABOR`,
    `PRECO_DE_LISTA`
) VALUES (
    '999999',
    'BNBNBNBNB',
    'HJHJHJHJ',
    'FGFGFGF',
    'GHGHGH',
    10
);
```

Você verá erros ao tentar incluir um registro na tabela:

![](https://cdn3.gnarususercontent.com.br/1224-mysql-adminstracao/05/image18.png)

31) Existe um comando para verificar os usuários existentes:

```sql
SELECT * FROM mysql.user;
```

32) Há também um comando que mostra os acessos de um usuário, por exemplo:

```sql
SHOW GRANTS FOR 'user02'@'localhost';
```

33) O comando **`REVOKE ALL`** retira os privilégios de acesso dos usuários:

```sql
REVOKE ALL PRIVILEGES, GRANT OPTION FROM 'user02'@'localhost';
```


-----------------------------------------------------------------------
# 17O que aprendemos?

Nesta aula, aprendemos:

- A criar usuários administradores e a remover o usuário **root**
- Como criar um usuário com privilégios para acesso normal (sem ser administrador)
- Como criar um usuário que só pode ler os dados
- Como criar um usuário que somente executa _backups_
- A fazer a criação dos usuários pela caixa de diálogo do Workbench e via SQL
- Como limitar o acesso do usuário pelo IP
- A limitar o acesso por banco e por tabela
- Como revogar os privilégios


-----------------------------------------------------------------------
# 18Conclusão

https://cursos.alura.com.br/course/mysql-dba-administracao/task/58145

## Transcrição

[00:00] Bem gente, se você chegou até aqui, é porque você conseguiu finalizar esse treinamento e ele conclui uma carreira de MySQL, que começou no início, desde o Curso de Introdução ao SQL com MySQL e foi vindo até esse curso de administração.

[00:21] E aí, nesse curso de administração, a gente, claro, começou falando sobre a instalar o MySQL. A primeira função que um administrador de ambiente tem que fazer é justamente instalar a ferramenta e a gente falou um pouquinho também sobre o que é um profissional de DBA, o que esse profissional de DBA faz.

[00:41] E falamos um pouquinho também sobre conectividade, conexões, como o MySQL se conecta com as bases. Aí, pulamos, depois para falar um pouquinho sobre tuning de hardware, quais são os pontos específicos que um DBA tem que saber antes de decidir que hardware será melhor para as necessidades do MySQL.

[01:09] E aí, depois falamos também sobre variáveis de ambiente, que é um instrumento muito forte, que é usado pelo DBA, para parametrizar o ambiente de banco de dados e isso vai ter uma importância muito grande me relação a que o banco de dados possa satisfazer as necessidades dos usuários.

[01:33] Pulamos então para um assunto importante que foi o mecanismo de armazenamento de dados, vimos que esse mecanismo é por tabela, é como se a gente quisesse criar tipos de tabela e falamos de três mecanismos importantes, MyISAM, InnoDB e Memory, vimos as diferenças de cada um e as suas principais características.

[01:59] Depois que a gente falou sobre essas formas de armazenamento dos dados e tabelas, pulamos para um dos assuntos mais importantes que é o backup. O backup é uma coisa super importante para um banco de dados, todos nós sabemos que problemas podem acontecer.

[02:20] Eu posso ter dados que podem ser perdidos ou porque deu problema no meu disco ou então, algum processo interno acabou gravando lixo dentro da base de dados e eu preciso recupera-los. A gente viu nesse treinamento sobre como recuperar os dados e demos ênfase a duas formas.

[02:41] Uma que foi copiar todo o ambiente para outro diretório e outro, tirar um backup, que nós chamamos de um backup lógico, que é um script de comandos sql, que depois podem ser executados. E a gente viu nesse treinamento também, como recuperar a base de dados, através desses dois métodos.

[03:03] Depois, nós passamos a falar um pouquinho sobre performance e entendemos o que é um plano de execução de uma consulta sql e a gente começou a falar também de índices, que tipo de índices que o MySQL possui e como é que eles se relacionam com as formas de armazenamento do dado.

[03:23] Ou seja, quando eu tenho o MyISAM e InnoDB, eu posso ter índices diferentes e a gente viu que existem dois principais tipos de índices dentro do MySQL. O BTREE e o HASH e a gente, inclusive mostrou e falou como é que internamente esses índices funcionam.

[03:43] E aí, com o plano de execução e índice, a gente juntou tudo e viu como é que o índice melhora a performance das nossas consultas. Lembrando que fazer performance de consultas é uma função do administrador no ambiente de dados, do DBA.

[04:00] Finalmente, falamos um pouquinho sobre usuários, vimos como é que o DBA consegue criar usuários, seja ele administradores, usuários normais, usuários de leitura e até mesmo usuários que só podem fazer backup.

[04:16] Vimos também como é que administrador, através do gerenciamento dos usuários consegue, inclusive, limitar o acesso a alguns bancos de dados e inclusive a tabelas e também vimos, finalmente, como é que o administrador, o DBA, ele consegue revogar, limpar privilégios que foram previamente configurados.

[04:41] Bem gente, o assunto administração de ambiente é muito mais amplo que isso que a gente viu, a gente pegou as principais vertentes e deu algumas pinceladas. Espero que vocês tenham entendido.

[04:54] E aí, espero que vocês fiquem... digamos assim, satisfeitos, não só com esse treinamento, mas com todos os treinamentos sobre MySQL, que começaram desde o curso de Introdução ao SQL com MySQL e fechou nesse treinamento de administração.

[05:13] Muito obrigado, espero velos nos próximos treinamentos aqui da Alura. Grande abraço. Tchau, tchau.



-----------------------------------------------------------------------


