---
type: "9"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
fonte_curso: https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados
Url_video_curso: https://dev.mysql.com/doc/
MySql_funcions: https://dev.mysql.com/doc/refman/8.0/en/functions.html
w3schools: https://www.w3schools.com/sql/sql_ref_mysql.asp
---

Tópico:: #MySQL #DataBase

- Aprenda mais sobre a modelagem de um banco relacional
- Crie tabelas e relacionamentos entre elas
- Use importação para popular o banco
- Saiba lidar com COMMIT e ROLLBACK
- Trabalhe com Triggers e define sequências

## Aulas

- [](https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/section/8169/tasks)
    
    [Modelagem do banco de dados](https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/section/8169/tasks) [Ver primeiro vídeo](https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55775)
    
    0 / 12
    
    57min
    
- [
    
    Criando a estrutura do banco de dados
    
    0 / 13
    
    55min
    
    ](https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/section/8170/tasks)
    
- [
    
    Incluindo dados nas tabelas
    
    0 / 10
    
    45min
    
    ](https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/section/8171/tasks)
    
- [
    
    Alterando e excluindo dados existentes nas tabelas
    
    0 / 13
    
    39min
    
    ](https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/section/8172/tasks)
    
- [
    
    Auto incremento, padrões e Triggers
    
    ](https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/section/8173/tasks)

-----------------------------------------------------------------------
# 01Introdução

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55775


-----------------------------------------------------------------------
# 02Instalando o MySQL

## Transcrição

[0:00] Vamos começar? A primeira coisa que a gente precisa fazer é ter nosso ambiente para pode fazer os exercícios práticos desse treinamento, e a primeira coisa que a gente precisa ter é o MySQL instalada na nossa máquina.

[0:13] Se você está fazendo todos os treinamentos na ordem e a máquina que você está usando agora é a mesma que você usou no curso passado, ou seja, você tem o MySQL, o MySQL, o WorkBench também instalado, então você não precisa nem seguir mais esse vídeo.

[0:34] Esse vídeo é mais para que se você tem seguido a carreira de MySQL, mas, por algum motivo, está usando um computador vazio, em branco, onde você não tenha mais o ambiente instalado.

[0:48] Então, você tem que reinstalar o seu MySQL, ou então, caso você tenha começado esse treinamento direto, sem ter passado pelos outros, está legal? Então, se você já tem um MySQL na sua máquina, pode dar pause aí; se você não tem, então eu vou fazer o seguinte: vou colocar, agora, um outro vídeo onde eu mostro a instalação do MySQL, está legal? Então, vamos lá começar.

[1:15] Vamos, então, fazer a instalação do MySQL.

[1:19] Eu posso fazer essa instalação tanto no ambiente Windows quanto Linux.

[1:23] O caso, aqui, devido ao equipamento que eu tenho à disposição para fazer esse treinamento, eu vou fazer a instalação, nesse vídeo, usando o sistema operacional Windows, e, também, nós vamos instalar um IDE chamado WorkBench.

[1:39] Bem, o que é um IDE? É um programa que permite que a gente possa visualizar os objetos do banco de uma maneira mais gráfica.

[1:49] Quando a gente vai trabalhar com MySQL, por exemplo, tudo pode ser feito por linha de comando, mas um IDE fica interessante a gente estar utilizando, porque aí a gente pode ter várias consultas na mesma tela, olhar as tabelas de maneira gráfica, e o WorkBench é um IDE próprio do MySQL, ou seja, é a MySQL que fornece o WorkBench.

[2:16] Isso e vários outros IDEs para MySQL no mercado, mas a gente vai usar o da própria MySQL, e também o WorkBench pode ser instalado tanto em ambiente Windows quanto ambiente Linux.

[2:30] No caso, aqui, eu vou fazer a instalação no Windows, e, inclusive, o pacote de instalação já instala não somente o servidor MySQL, mas, também, o IDE WorkBench.

[2:42] Então, vamos começar.

[2:44] Eu vou abrir aqui o browser e vou procurar por MySQL Downloads.

[2:52] Então, tem aqui o link MySQL Downloads e aqui nesse link eu vou procurar por essa opção aqui: MySQL Community Edition (GLP).

[3:06] Lembra? Eu tenho a versão gratuita e a paga, nós vamos usar a gratuita.

[3:13] Então, eu vou clicar aqui no link Community (GLP) Downloads e eu vou procurar aqui essa opção.

[3:25] No meu caso, eu vou estar usando a MySQL on Windows (Installer & Tools).

[3:40] Eu tenho aqui vários links, por exemplo, se eu quisesse só instalar o WorkBench eu escolheria esse link aqui, mas eu vou selecionar aqui a opção MySQL Installer.

[3:57] E aqui embaixo eu tenho as opções da instalação que eu quero fazer, então, eu vou estar escolhendo essa aqui: (mysql-installer-web-community-8.0.15.0).

[4:13] Não necessariamente a versão que você vai estar instalando é a mesma que está aqui no vídeo, depende da época em que você esteja assistindo esse treinamento, porque as versões de MySQL ficam mudando com uma certa frequência.

[4:27] No caso, se você encontrar uma versão mais atual, não tem problema, instale a que ele estiver sugerindo como sendo a última versão.

[4:35] Vou clicar aqui em download e aí ele vai me pedir pra fazer um login no site da Oracle.

[4:43] Lembra que eu falei? A Oracle comprou a Sun Microsystems e a Sun era dona do MySQL, então a Oracle passou a ser dona do MySQL.

[4:58] Para a gente pode instalar, baixar qualquer produto Oracle a gente precisa se logar usando uma conta da Oracle.

[5:05] Se você não tem conta da Oracle, nenhum problema, você vem aqui, clica em Sign Up, aqui do lado, no botão verde, e faça um cadastro.

[5:14] Você vai colocar lá o nome, um e-mail, uma senha, e só isso, não precisa botar cartão de crédito, não precisa pagar nada.

[5:22] No caso, eu já tenho um login, então eu vou clicar no botão login.

[5:29] Vou colocar aqui meu usuário e vou colocar aqui a minha senha.

[5:40] Vou clicar em Iniciar Sessão.

[5:46] E aí vou clicar agora no botão Download Now.

[5:53] Bem, ele vai fazer o download de um arquivo pequeno, porque, depois, tudo que eu for instalar ele vai fazer o download da internet no momento da instalação.

[6:04] Vou clicar, então, no programa aqui MySQL Installer, aí ele vai dizer uma opção opcional se eu quero já checar se existem updates para serem feitos, para que a gente possa fazer a instalação agora não somente da versão que eu escolhi, mas, também, dos updates mais atuais.

[6:30] Eu vou clicar Yes, nenhum problema de fazer essas instalações desses upgrades.

[6:40] Ele está fazendo aqui o download do instalador com os upgrades.

[6:54] Pronto, comecei a instalação, vou aceitar os termos da licença.

[7:00] Aqui, eu vou escolher a opção Developer Default, que aí eu vou instalar o servidor e uma série de conectores, tudo que é preciso para o MySQL estar funcionando.

[7:17] Vou clicar em Next.

[7:19] Aqui se eu quero fazer um conector com o Python, mas, no caso, não é o meu objetivo, eu vou dar Next. Clico aqui, Yes, e aí eu tenho aqui tudo que ele vai baixar.

[7:32] Note que aqui no meio eu já tenho a instalação do Workbench, ou seja, eu não vou precisar, depois, ter que instalar o WorkBench de forma separada.

[7:46] Vou clicar aqui, Execute, e ele vai começar a fazer o download dos módulos que vão ser usados para a instalação.

[7:57] Então, eu vou fazer o seguinte: vou parar o vídeo um instantinho aqui, quando esse download terminar eu volto para a gente continuar a instalação, tá bom? Bem, acabou o download aqui dos componentes, vou continuar, então, a instalação.

[8:10] Clico aqui em Next, Next novamente, aí eu tenho aqui dois tipos de estrutura de bancos de dados que eu vou estar trabalhando.

[8:21] Eu vou estar usando essa primeira aqui: Standalone MySQL Server / Classic MySQL Replication, ok?

[8:33] Tem aqui as configurações de porta, forma de comunicação entre cliente e servidor, a gente vai manter o que está aqui.

[8:41] Aqui é a forma com que eu vou usar a minha autenticação.

[8:45] Tem dois tipos: uma que é a senha criptografada, que vale pro MySQL 8.0, que é a versão atual, e uma que usa a segurança dos MySQL mais antigos.

[9:00] Eu vou manter a primeira opção selecionada.

[9:04] Aqui eu vou colocar a minha senha.

[9:23] Ele não gostou muito da minha senha, disse que ela está fraca, mas não tem problema.

[9:28] Vou clicar aqui em Next.

[9:32] Deixa eu voltar aqui um instante, eu não vou criar outros usuários por enquanto que eu vou estar usando esse mesmo usuário que a gente chama de root.

[9:41] O que é o usuário root? É o usuário padrão do banco MySQL, e a gente vai usar esse usuário para acessar o banco e tal, utilizando os nossos exercícios práticos.

[9:53] O que eu fiz aqui foi definir a senha desse usuário root.

[9:58] Não esqueçam dessa senha, hein.

[10:02] Next.

[10:04] Aqui é o nome do serviço, porque o MySQL vai ser um serviço do Windows que vai ser sempre inicializado quando a máquina, por exemplo, for dar um boot, alguma coisa.

[10:15] Sempre quando a máquina voltar, o banco vai estar no ar também.

[10:19] E ali embaixo a gente seleciona qual é o usuário que vai gerenciar esse serviço.

[10:25] Aqui nós não vamos mudar nada.

[10:29] Tem aqui tudo que ele vai executar durante a instalação, eu clico Execute, e aí ele vai começar a fazer a instalação, inicializar o banco de dados, o servidor, e assim por diante, tá bom? Então, eu vou parar o vídeo um instantinho e volto assim que todos os passos estiverem... opa, olha, achei que ia demorar, acabou rápido, então eu vou manter, não vou nem parar o vídeo, não.

[11:01] Vamos lá, vou clicar Finish, vou dar um Next.

[11:08] Ele agora vai fazer algumas outras configurações.

[11:13] Por enquanto, eu não vou estar fazendo nada, clico em Finish, Next novamente.

[11:20] Temos aqui a conexão com o servidor, eu vou colocar aqui a minha senha.

[11:29] Posso até usar aqui um Check para saber se a conexão é feita.

[11:31] Ó, conexão entre cliente e servidor foi feita com sucesso, e vou executar essa segunda parte da instalação.

[11:45] Agora sim eu vou parar o vídeo, eu não sei quanto tempo vai demorar... ah, não, olha só, me pegou de novo, eu achei que ia demorar, foi rápido.

[11:54] Vou clicar aqui em Finish, ele vai fazer novas configurações, e aqui, ao dar esse último Finish, ele já vai me inicializar o WorkBench, que é aquela interface de IDE para a gente manipular o banco de dados MySQL.

[12:18] Vou clicar aqui em Finish.

[12:22] Essa tela que ele abriu aqui a gente pode ignorar, e, note: automaticamente ele já me criou uma conexão local da minha máquina, ou seja, a minha máquina tem um servidor, mas tem um cliente também, e o WorkBench já vem com essa conexão previamente configurada.

[12:43] Se eu clicar aqui nesse quadradinho ele vai perguntar a senha do meu usuário root.

[12:51] Vou colocar aqui, vou salvar a senha para não precisar ter que colocar a senha toda hora.

[13:03] E aí pronto, eu entrei aqui e eu tenho aqui já o meu WorBench já configurado.

[13:14] Demonstrar aqui alguns códigos que talvez você não vão ver, mas é porque a minha máquina já tinha, antes de gravar esse treinamento, o MySQL instalado e tinha aí na memória alguns scripts de SQL já salvos.

[13:30] O que você vai ter, caso você tenha feito todos os passos de maneira correta, é essa tela aqui do MySQL WorkBench.

[13:39] Então, pronto, já estamos preparados para começar o nosso treinamento de SQL, está legal? Então tá, gente. É isso aí, um abraço para vocês, até o próximo vídeo.

-----------------------------------------------------------------------
# 03Preparando o ambiente: Linux e Mac

Se você estiver utilizando o sistema operacional Linux ou Mac, temos um excelente artigo que explica de forma detalhada o processo de instalação do MySQL. Recomendamos que você siga os passos descritos neste artigo antes de continuar com o curso:

- [MySQL: da instalação até a configuração](https://www.alura.com.br/artigos/mysql-instalacao-configuracao)

Caso surjam dúvidas durante o processo de instalação, não hesite em procurar assistência no fórum ou no Discord da Alura. Estamos aqui para ajudar você a ter uma experiência de aprendizado tranquila e produtiva.

Desejamos a você ótimos estudos e sucesso em sua jornada de aprendizado!

-----------------------------------------------------------------------
# 04Revisão - Entidades

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55777

## Transcrição

[0:00] Como esse treinamento envolve a manipulação de dados, a primeira coisa que a gente vai aprender é a criar o banco de dados e as entidades dele.

[0:13] Logo, a gente precisa conhecer que entidades são essas, por isso eu vou fazer uma breve revisão, não somente sobre a parte de entidades, que compõe um banco MySQL, mas também os seus tipos de dados, porque essa informação ela é muito importante quando a gente for criar o nosso esquema, ok?

[0:34] Bem, então, basicamente, um banco MySQL possui dentro da sua estrutura do seu servidor um conjunto de uma entidade que nós chamamos de banco de dados.

[0:48] Ou, também, dentro do MySQL chama banco de dados de schema.

[0:54] O banco de dados tem, lá dentro, aí sim, diversas entidades, que auxiliam no armazenamento da informação, ou seja, a informação será armazenada dentro do banco de dados, dentro de diversas entidades que são mencionadas dentro dele.

[1:13] A entidade básica onde a informação fica armazenada, onde o dado está armazenado, a gente chama de Tabela.

[1:21] Então, um banco de dados pode ter uma ou mais tabelas, e cada tabela tem dados armazenados dentro dela.

[1:31] A tabela é como se fosse - fazendo uma analogia - uma planilha de Excel, onde eu tenho linhas e colunas.

[1:38] A única diferença é que lá no Excel, quando a gente cria uma planilha, a gente cria uma área vazia de infinitas colunas e infinitas linhas.

[1:49] No banco de dados, quando a gente cria uma tabela, na hora de criar a gente já tem que dar algumas informações específicas daquela tabela.

[2:02] A informação mais importante são os campos.

[2:05] É como se eu já criasse a planilha de Excel dizendo: "olha, essa planilha vai ter só 20 colunas", eu dou nome para cada coluna e digo que cada coluna só pode ter um tipo de dado.

[2:20] Se eu digo que a terceira coluna só pode ter data, eu só posso colocar data naquela coluna.

[2:26] É aí que há a diferença da tabela para uma planilha de Excel.

[2:32] Então, a tabela é uma planilha de Excel com colunas pré-definidas, cada coluna nomeada e com um tipo específico, e o número de linhas, aí sim, por enquanto ela começa vazia e aí eu posso acrescentar linhas no decorrer da manipulação do dado, e sempre, em cada coluna, o dado que está lá nunca muda.

[2:57] Então, como eu falei, nós temos campos, que são as colunas, e registros, que são as linhas.

[3:07] Tanto faz eu chamar coluna ou campo, registro ou linha, eu às vezes uso uma coisa, às vezes uso outra, mas os dois termos estão corretos.

[3:19] A tabela tem também uma informação chamada Chave Primária.

[3:24] O que é uma chave primária? Eu especifico uma ou mais colunas da tabela, e se eu disser que essas colunas são chaves primárias da tabela, eu não vou poder ter nenhuma linha dentro da minha tabela cuja chave primária se repita.

[3:44] Se isso acontecer, o banco não vai deixar eu colocar essa informação.

[3:49] Por exemplo, se eu tiver uma tabela de clientes e a chave primária é o CPF, eu não vou poder ter nenhum cliente na minha tabela cujo CPF seja repetido.

[4:09] Então, a chave primária é uma entidade muito importante dentro da tabela.

[4:13] Agora, sim, a tabela também tem uma coisa chamada Chave Estrangeira.

[4:19] É uma ligação que a tabela faz com outra tabela.

[4:24] Lembrando, nós estamos trabalhando com banco de dados relacionais, e eles possuem relações, as tabelas se relacionam entre si, e o que liga uma tabela à outra? É a chave estrangeira.

[4:40] Normalmente, a chave estrangeira liga campos de duas tabelas diferentes do mesmo tipo, não precisam ter o mesmo nome, mas o tipo, sim.

[4:52] A partir do momento que a gente cria a chave estrangeira há uma hierarquização do conteúdo das colunas que são chaves estrangeiras.

[5:03] Normalmente, quando a gente cria a chave estrangeira a gente tem uma tabela pai e uma tabela filho.

[5:10] Há uma direção da chave estrangeira, de tal maneira que, na tabela filho, eu só vou poder ter elementos que estão previamente cadastrados na tabela pai.

[5:22] Fazendo a analogia do exemplo do cliente, se eu tenho uma tabela de clientes cuja chave primária é o CPF e tenho uma tabela de vendas onde eu tenho a informação de cada venda que é efetuada na minha empresa, na linha da tabela de vendas eu tenho também o cliente.

[5:41] Se eu crio uma chave estrangeira entre o cliente da tabela de clientes e o cliente da tabela de vendas, o que acontece? Eu só vou poder vender com clientes que existam na tabela cadastral.

[6:00] Também há uma estrutura muito importante na tabela, chamada Índice.

[6:07] O índice é como se fosse um cadastro de posições dos elementos dentro da tabela, de tal maneira que quando eu vou buscar um elemento na tabela, se eu tiver um índice eu acho esse elemento mais fácil, porque, ao invés de eu percorrer a tabela toda, linha a linha, eu vou no índice, procuro o elemento, e vai dizer: "olha, esse cara está na posição 25".

[6:36] Aí eu volto para a minha tabela e acho o elemento que eu quero buscar.

[6:41] Quando a gente cria uma chave primária e uma chave estrangeira, automaticamente o MySQL já cria um índice para esses dois campos.

[6:53] E por que? Porque, claro, chave estrangeira, chave primária, vão fazer com que o banco busque toda hora esses elementos nessas tabelas, justamente pra saber se há um relacionamento íntegro.

[7:07] Por exemplo, na chave primária, toda vez que eu inserir um registro, ele tem que buscar na tabela para saber se aquele registro já existe ou não, para saber se ele deixe incluir ou não.

[7:17] Se aquele campo que eu estou incluindo tem uma chave estrangeira, eu tenho que ir na tabela pai buscar o cara e saber se ele realmente existe, então, há um trabalho muito de buscas quando o cara está envolvido em uma chave primária ou estrangeira, por isso o MySQL já cria o índice, porque vai facilitar esse trabalho.

[7:40] Ok, então meu banco tem várias tabelas, dentro da tabela eu tenho chaves primárias, tenho campos, tenho os registros, e aí as tabelas podem se organizar em esquemas.

[7:52] No MySQL o esquema e o banco de dados é a mesma coisa, mas essa transparência está mostrando grupos de tabelas diferentes porque em outros bancos de dados relacionais há uma diferenciação entre o esquema e o banco de dados.

[8:12] O banco de dados também pode ter o que a gente chama de uma View.

[8:15] A view é uma tabela lógica que é feita através da construção de uma consulta.

[8:24] Então, eu tenho uma consulta complexa, que já faz vários cálculos, e aí eu transformo essa consulta em uma view e eu consigo acessar essa view como se ela fosse uma tabela, mas, na verdade, ela é uma tabela lógica.

[8:40] Toda vez que eu consultar a view, a consulta que está lá vai ser resolvida.

[8:46] Claro que uma view tem uma performance muito menor do que eu fazer a consulta direto em uma tabela, mas as views são muito importantes quando eu quero disponibilizar parte do meu banco para alguém externo, por exemplo, eu construo uma view, nessa view eu limito aquilo que aquela pessoa externa pode ver, e aí lá no usuário do meu banco de dados eu digo: "olha, esse usuário só consegue enxergar tal view".

[9:16] Ok, então eu tenho a minha consulta e aí a minha consulta retorna uma série de valores diferenciados dentro dela, e aí ela pode ter, também relacionamento entre si.

[9:35] E aí, claro, a consulta, depois, se eu transformar ela em uma view, ela será vista como se fosse uma tabela cujo o conteúdo é o mesmo que é o resultado da consulta.

[9:49] Dentro do banco de dados a gente também tem stored procedure.

[9:55] O que são? No caso do MySQL tem, inclusive, esse mesmo nome.

[10:02] São programas estruturados, usando a linguagem SQL, que eu posso fazer para operações mais complexas.

[10:10] O SQL é uma linguagem não muito estruturada, ele não tem IFs, ELSEs, eu não consigo fazer programas fazendo desvios.

[10:21] O padrão ANSI é assim, mas cada banco de dados disponibiliza para o seu usuário uma outra linguagem estruturada que utiliza comandos de SQL diretamente, que faz com que eu possa construir coisas rebuscadas.

[10:38] As stored procedures não respeitam o padrão ANSI, então, cada tipo de banco de dados tem a sua linguagem própria.

[10:47] Então a MySQL tem a sua, o SQL Server tem a sua, o Oracle também tem.

[10:55] Aí reza uma das diferenças entre os diversos bancos de dados relacionais, que é a forma como eu construo as minhas stored procedures.

[11:07] Também tem funções, que podem ser funções já básicas, cadastradas dentro do banco, por exemplo, função para converter uma String em uma Data, para buscar o ano de uma Data, que calcula o cosseno de um número.

[11:29] Enfim, são funções já existentes, mas eu posso também, usando a mesma linguagem de programação das stored procedures, construir a minha própria função, e eu posso usar ela depois, dentro das minhas consultas, de maneira simples e objetiva, da mesma maneira como eu uso as consultas originais que já existem no MySQL.

[11:55] Também temos uma estrutura chamadas Trigger. Trigger são regras que eu vou executar quando algo acontece no banco.

[12:05] Então eu digo: "olha, quando eu incluir um dado no banco, faça isso; quando eu alterar o dado numa tabela, faça aquilo".

[12:14] Essas ordens são triggers.

[12:16] As triggers são muito importantes, porque, às vezes, ao incluir dados de uma tabela eu tenho que fazer algum tipo de pré cálculo em outra tabela, então o trigger pode fazer isso.

[12:30] Então, tá, o meu banco de dados tem, então, todos os conjuntos dessas entidades.

[12:36] É importante eu, que estou projetando e construindo o banco de dados, saber que tipo de entidades são essas, porque, claro, na medida em que meu banco vai crescendo e as necessidades operacionais vão sendo passadas para mim, eu vou criando mais entidades relacionadas ao banco de dados.

[12:57] Tá legal? Então, é isso aí, gente, que eu queria falar um pouquinho sobre a parte de estrutura do banco de dados.

-----------------------------------------------------------------------
# 06Revisão - Tipos de dados

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55778

## Transcrição

[0:00] Além de conhecer as entidades que fazem parte de um banco MySQL, uma informação muito importante que você também deve saber são os tipos de dados que o MySQL trabalha.

[0:12] Todos os bancos de dados relacionais - seja ele MySQL, Oracle ou SQL Server, da Microsoft - eles possuem tipos de campos muito parecidos, mas os nomes e as referências desses campos podem mudar de um campo para outro, e aí antes da modelagem, antes de você projetar o seu banco, é legal que você saiba que tipos de dados você tem à disposição para saber como você vai usar na sua modelagem.

[0:42] Vamos começar falando um pouquinho sobre os campos de tipos inteiros.

[0:46] Número inteiros são número que não têm casas decimais, e aí nós temos, em uma SQL, cinco tipos de número inteiros.

[0:54] Eles vão desde o Tinyint, Smallint, Mediumint, Int e Bigint.

[1:08] A diferença desses campos é o número de bytes que cada um armazena dentro do banco.

[1:16] Essa informação inclusive é importante, porque se você tem um número muito pequeno e você cria um campo do tipo bigint, embora você saiba que aquele número inteiro, quando você for gravar na tua tabela, ele não vai passar de um valor específico, vai ser sempre um valor muito baixo, você vai estar gastando oito bytes para armazenar um número que não vai chegar a um byte.

[1:39] Então, é legal você saber os tipos de campos e o tamanho que eles vão armazenar para você projetar bancos de dados mais otimizados, ok?

[1:53] Claro, então, que esses campos possuem o menor e o maior valor possíveis.

[2:01] O Tinynt vai de -128 a +127; o Smallint vai de -32.768 a 32.767, só que quando a gente cria um campo numérico a gente tem uma propriedade no MySQL chamado Unsigned.

[2:24] O unsigned significa o seguinte: se eu digo que um campo é unsigned, ele não vai ter negativo, ele só vai ter número positivo, e aí o menos do número negativo é uma coisa que ocupa espaço no armazenamento do campo, então, quando eu digo que o número não tem número negativo, o range, ou seja, o espaço que eu tenho armazenado para gravar números positivos aumenta.

[2:55] Então, quando o número é unsigned, o tinyint, que o limite máximo seria 127 passa a ser 255.

[3:05] O smallint, que o valor mínimo era 32.767, passa a ser 65.535.

[3:15] Então há um aumento desse valor do espaço reservado para armazenagem do número inteiro, e isso se aplica ao mediumint, ao int e ao bigint, ok?

[3:33] Agora vamos falar dos números decimais.

[3:37] Nós temos o Float e o Double.

[3:40] A diferença deles é a precisão: uma usa a precisão simples e a outra usa a precisão dupla.

[3:48] Uma ocupa 4 bytes do meu banco e o outro ocupa 8 bytes.

[3:55] O precisão tem muito a ver com a forma com que o número é armazenado, então, às vezes o número, internamente, ele é armazenado com muitas casas decimais, mas a gente, depois, quando visualiza ele, ele faz uma aproximação através desse ponto flutuante no valor decimal que ele realmente tem.

[4:14] Então, se eu digo que um campo, por exemplo, é float de 7 dígitos com 4 casas decimais, ou seja, o primeiro parâmetro do float é o número de dígitos totais do número incluindo os decimais, e o que eu tenho depois da vírgula é só o que eu vou ter na parte decimal.

[4:34] Então, se eu digo que o float é 7 de 4, um número, por exemplo, 999,00009, quando eu armazenar, ele será armazenado como 999,0001, ou seja, ele vai arredondar esse número e armazenar dentro do espaço que foi determinado.

[5:02] Outros números decimais mas que não são de pontos flutuantes é o Decimal ou Numeric, pode ser um ou outro, eles são iguais.

[5:10] Eles armazenam número de até 65 dígitos, incluindo as casas decimais, e esses números são fixos, esse tamanho é fixo, ou seja, quando eu coloco o número lá ele vai ocupar o número de casas decimais até o finalzinho do que o número ocupa, ok?

[5:30] O seu tamanho não é variável, ele já é um tamanho fixo reservado para aquele número, tem uma precisão numérica melhor.

[5:40] O tipo Bit, como o próprio nome diz, é um bit apenas, ok?

[5:46] Mas eu posso ter um campo de bit de 2, de 3, de 4, mas o conteúdo lá dentro vai ser caracteres binários: ou 1 ou 0. Então, se eu digo que é bit de 1, eu posso armazenar ou 1 ou 0, mas se eu digo que o campo é bit de 2 eu posso armazenar 01, 10, 00 ou 11, ou seja, eu tenho 4 tipos de números binários que eu posso armazenar no bit de 2.

[6:20] Normalmente o bit 1 a gente utiliza para armazenar campos lógicos onde eu tenho alguma coisa que é verdadeira ou falsa, e normalmente a gente aplica o 1 para o verdadeiro e o 0 para o falso.

[6:38] Como eu falei, os campos numéricos possuem atributos, signed ou unsigned, se o número vai ter ou não número negativo.

[6:50] Zerofil, alguns números, geralmente os que não são de ponto flutuante, eu preencho com zeros os espaços antes do número inteiro até chegar ao tamanho do número.

[7:03] Então, um número inteiro que eu armazeno, o número 5, eu vou armazenar o número 0005, ou seja, eu vou colocar 3 zeros na frente de tal maneira que o número de dígitos bata com esse número que eu acrescentei aqui.

[7:21] A gente tem também campos numéricos que são do tipo auto incremento.

[7:26] O auto incremento é um número sequencial que vai ser crescido automaticamente na medida em que eu vou inserindo dados da tabela, e aí além de crescimento desse número sequencial eu posso determinar, pode ser um número que cresça de 1 em 1, de 5 em 5, e assim por diante.

[7:46] O auto incremento ele é muito usado quando eu quero criar chaves primárias randômicas, que não vão se repetir nunca.

[7:54] Randômicas, não, sequenciais.

[7:57] Randômicas a gente estaria falando de coisas aleatórias, mas não, o auto incremento respeita um critério, e aí eu sei que todo insert que eu fizer dentro dessa tabela, ou seja, toda inclusão de dados, nunca esse campo vai se repetir, porque ele é do tipo auto incremento.

[8:16] Quando a gente tenta armazenar um número maior do que ele suporta, eu digo que o número é um tinyint ou smallint e eu quero gravar um número grande, eu sempre vou ter erro no momento da gravação, que são os erros chamados de out of range.

[8:33] Então, quando você estiver trabalhando com SQL e ver um erro do tipo out of range, já sabe que é alguma coisa que você que gravar que é maior do que é suportado.

[8:46] A gente tem os campos de data, que são superimportantes no banco de dados, e aí eu posso ter tipos de bancos diferentes.

[8:55] Date é um campo de data que somente vai armazenar ano, mês e dia, e varia do dia 1 de janeiro do ano 1000 até o último dia de dezembro de 9.999.

[9:16] O date time é igual ao date, só que além da data, eu armazeno a hora, então eu posso, também, ter uma precisão maior do dado armazenado, e aqui em cima vocês podem ver o limite inferior e superior.

[9:33] O timestamp é parecidíssimo com o date time, só que ele tem um limite menor e ele utiliza o fuso horário para estar armazenando a informação.

[9:45] Normalmente, a informação vem com o fuso horário de Greenwich, que é o fuso horário padrão do mundo, o fuso zero, e depois eu posso também trabalhar com fusos horários para poder gravar, por exemplo, dados com fuso horário do Brasil, outro com fuso horário dos Estados Unidos, e assim por diante.

[10:07] Aplicações do tipo timestamp normalmente são aplicações em que você envolve, por exemplo, um workflow ou alguma comunicação entre pessoas que estão, por exemplo, em países diferentes.

[10:19] O time ele só armazena a hora, mas não é a hora do relógio, é um valor crescente de hora, que tem os limites ali especificados.

[10:31] E o campo do tipo year ele armazena só ano, e ele varia de 1.901 a 2.155.

[10:40] E o campo year pode ser expresso com 2 dígitos ou com 4 dígitos.

[10:47] Os campos string nós chamamos de dois: varchar e char.

[10:55] O char tem valor fixo, ou seja, quando a gente diz que o char tem 255 caracteres, se eu gravar um caracter com 1 dígito apenas, por exemplo a letra A, ele vai ocupar os 255 dígitos.

[11:13] Ele vai gravar o A e 254 espaços em branco.

[11:18] Já o varchar, não.

[11:19] O varchar, apesar de eu dizer que há um limite máximo de tamanho, se eu gravo a letra A nesse exemplo e o campo tem 255 dígitos, eu só gravo 1 dígito na base.

[11:36] Ou seja, o varchar ele é mais inteligente para controlar tamanhos.

[11:44] Eu tenho também os valores binários, que também podem variar de 0 a 255 caracteres, porém os dados que são gravados são bits, 1, 0, 0, 1 e assim por diante.

[11:59] Não consigo ver, ali, letras nem números, só o número 1 e o número 0.

[12:08] Nós temos alguns strings que nós chamamos de strings longos.

[12:11] O blob é um string desse tipo, e tem alguns tipos: tinyblob, blob, mediumblob, longblob.

[12:20] E o texto, que é o texto longo.

[12:24] O blob tem a ver com binários e o blob com strings.

[12:29] Com texto propriamente dito, claro, como o próprio nome diz.

[12:35] O blob eu uso para gravar coisas binárias, então, por exemplo, eu posso gravar o conteúdo de uma foto, de um arquivo, que é binário, no campo blob.

[12:47] Já no campo texto é só caracteres que respeitam as tabelas ASCIIS dependendo de cada tabela que o computador suporta, que são tabelas que convertem números em letras.

[13:02] O enum são campos que me dão opções, então, por exemplo, eu digo que o campo é do tipo enum e tenho aqui: x-small, small, medium, large, x-large.

[13:16] Ou seja, quando eu dou insert nesse campo, se eu der um string diferente desse conjunto que está aqui, o banco de dados vai me dar um erro, vai dizer que eu não posso.

[13:27] Esses são os campos do tipo enum.

[13:31] Todos os campos string têm um campo chamado set e collate, que têm a ver com o conjunto de caracteres suportados, com aquelas tabelas ASCIIs que eu falei há alguns minutos atrás.

[13:45] Quando a informática começou a ser difundida, a conversão de caracteres em números binários para serem armazenados no computador respeitavam somente uma tabela muito simples onde o acento, por exemplo, não era suportado.

[14:03] Eu não tinha o caracter A com acento ou Ç.

[14:07] Aí começaram a surgir outras tabelas de armazenamento de dados que englobava, por exemplo, os caracteres latinos, russos, ou, por exemplo, os símbolos islâmicos.

[14:19] Enfim, há um conjunto de tabelas que suporta outros símbolos além dos que você vê no seu teclado.

[14:27] Você pode, ao criar um campo com o MySQL, especificar que conjunto de caracteres você vai estar utilizando para aquele campo.

[14:39] Também, agora, somente nas versões mais recentes do MYSQL, surgiram campos do tipo espacial.

[14:47] Com o advento do uso de mapas, você poder desenhar campos nos mapas, poder traçar áreas para poder dizer: "essa é a minha área de venda", ou eu traço uma área de um Estado para pintar, dizer qual foi o valor da venda daquele Estado, esses desenhos em mapas a gente pode armazenar em banco de dados através dos campos espaciais.

[15:13] Então, o geometric ele armazena uma figura geométrica, ou seja, tem todas as coordenadas dentro desse campo que fazem com que eu consiga desenhar essa figura dentro de um mapa.

[15:26] O point é um ponto, o line string é uma linha onde eu coloco o ponto origem e um ponto destino e ele traça uma linha até lá.

[15:35] E o polígono ele é um detalhamento mais específico da área, que geralmente é fechada.

[15:44] É o tipo do campo polígono.

[15:48] Ok. Então, eram esses os campos que eu queria estar mostrando para vocês antes de realmente a gente começar a entrar no MySQL e começar a criar tabelas, está legal? Valeu, gente, obrigado.

-----------------------------------------------------------------------



-----------------------------------------------------------------------
# 08Modelagem

## Transcrição

> **Atenção**: O objetivo desta aula é mostrar que o banco de dados deve ser montado conforme a modelagem. Se é **1:1** ou **1:N** vai depender do tipo de negócio. Apresento aqui um exemplo hipotético que contenha todas as possíveis relações.
> 
> O analista de sistemas deve olhar o resultado do diagrama e montar o banco baseado nele. Se alguém escreveu que a regra é **1:1** ele vai criar assim. Se a regra é **1:N** ele vai criar diferente. Não cabe o analista questionar o negócio. Ser **1:N** não é sempre verdade.
> 
> Um outro exemplo: Se o banco de dados de um Airbus? Apesar do avião ter um modelo, cada avião tem um número de série único e seu cadastro está associado a um único item de uma venda e não se repete.
> 
> O importante é que independente do resultado do modelo, iremos construir um banco de dados baseado no que o diagrama apresentado nos mostra.

[0:01] Quando a gente vai projetar um banco de dados a gente tem que conhecer bem o negócio no qual o banco de dados está modelando.

[0:11] E aí existe toda uma regra - existe livros, inclusive, sobre isso - que nos ajuda a fazer o projeto de um bom banco de dados.

[0:21] Eu não vou entrar a fundo neste curso nem neste vídeo, falando sobre esses processos de modelagem, mas a gente tem que levar em consideração que a gente precisa, claro, ter um grande entendimento das regras de negócio, conversar, fazer entrevistas, entender com o usuário como é que o seu negócio funciona, e tentar desenhar um banco de dados que modelo o processo da empresa na sua maneira mais fiel e próximo à realidade.

[0:57] Bem, a partir do momento que você tem essas informações, você constrói o que nós chamamos de um diagrama de entidade e relacionamento.

[1:08] É como se fosse um diagrama que diz como é que cada entidade da sua empresa se relaciona entre si, e nós vamos estabelecer uma cardinalidade entre essas entidades.

[1:25] Dar um exemplo hipotético: isso aqui é um diagrama de relacionamento.

[1:31] A gente costuma construir as relações usando verbos do tipo "um vendedor realiza venda", "o cliente está contido em uma venda", "a venda, por exemplo, possui itens vendidos" e "o produto está contido em itens vendidos".

[2:00] Eu estou aqui modelando uma modelagem clássica de um sistema vendas, então, eu tenho a entidade vendedor, eu sei que o vendedor vai lá e ele que faz a venda, ele liga para o cliente, ele convence o cliente, estabelece proposta, preço, e aí quando a venda é executada, eu tenho que estar registrado na venda o vendedor que fez isso, então, por isso que o vendedor realiza a venda.

[2:26] Só que ao vender precisa ter um cliente que está fazendo aquela compra.

[2:31] Que foi graças à atuação do vendedor que ela aconteceu.

[2:36] Então, dentro da venda, o cliente contém uma venda com ele.

[2:44] Pois bem, as relações de um pra N aqui, o que significam? Significa o seguinte: um vendedor pode estar relacionado com muitas vendas.

[2:57] Então, a relação vendedor e venda é de 1 para N.

[3:02] Da mesma maneira, o cliente pode ter várias vendas, pode compras várias vezes.

[3:12] Dependendo da situação, pode comprar no mesmo dia, na mesma semana ou no mesmo mês, mas ele vai estar presente em diversas vendas.

[3:21] Então, a relação aqui é de 1 para N.

[3:26] Só que a venda, normalmente, você tem uma informação que é igual para aquela venda, e às vezes você compra alguns itens.

[3:40] Quer dizer, na verdade você está vendendo itens, num documento de venda geralmente você tem um cabeçalho onde são dados específicos, comuns dentro daquela venda, e os itens que estão sendo vendidos.

[3:56] Na minha empresa de suco de frutas, que é a empresa que eu estou modelando aqui, eu tenho vários produtos, então, o cliente, em uma venda, pode comprar 10 produtos do tipo A, 8 produtos do tipo B, e assim por diante.

[4:12] Então, nesse caso, há uma relação entre venda e item vendido.

[4:18] De 1 para ele, uma venda pode ter vários itens vendidos.

[4:25] Um item vendido só pode estar relacionado com uma venda, e o item vendido, propriamente dito, tem só um produto.

[4:35] Eu não posso ter, no mesmo item, vários produtos.

[4:38] Então, o meu cadastro de produtos contém itens na relação de um para um.

[4:47] Então, esse tipo de entendimento do processo da empresa, como é que as entidades se relacionam, constroem esse diagrama de relacionamento.

[5:02] Aí cada entidade daquela, cliente, vendedor, produto, nota fiscal, item de nota fiscal que a gente identificou no processo, a gente tem que estabelecer o que nós chamamos das características das entidades.

[5:19] Então, deixa eu voltar aqui.

[5:23] Essas características são propriedades que aquela entidade possui, por exemplo, nome, idade, tamanho, preço.

[5:31] Aí agora sim eu vou para o próximo slide, então, aquele diagrama de relacionamento que antes era só entre vendedor, venda, cliente, produto, itens vendidos, a gente estende ele e mostra as suas propriedades.

[5:50] Por exemplo, o cliente tem nome, endereço, bairro, cidade, estado, CEP, idade, sexo.

[5:57] O vendedor tem lá nome, bairro, que é onde fica o escritório do vendedor, comissão, data admissão, ou se está de férias ou não.

[6:06] O produto tem lá descritor, sabor, tamanho.

[6:11] E os itens vendidos normalmente eu tenho lá no cabeçalho da venda dados que são globais para a venda como um todo, que normalmente são os dados de imposto, do cliente e do vendedor.

[6:24] E nos itens é que eu tenho dados do código do produto.

[6:29] Então, eu tenho aqui um exemplo da expansão das propriedades em cima daquele modelo que eu estou ilustrando a vocês a modelagem.

[6:41] Cada entidade de relacionamento ele acaba virando uma ou mais tabelas.

[6:47] E cada conexão que está contida entre essas entidades, vai virar um relacionamento do banco de dados.

[6:56] Então, aquele diagrama de entidades que eu criei vai virar tabelas onde eu vou definir como chaves primárias aquilo que não pode se repetir, aquilo que identifica a entidade.

[7:13] Cada propriedade vai virar um campo da tabela, e aí dependendo da propriedade eu já especifico qual é o seu tipo.

[7:22] E os relacionamentos serão as chaves estrangeiras.

[7:25] Então, assim, esse diagrama de relacionamento acaba virando esse esquema de tabelas.

[7:41] Aí quando a gente tem esse diagrama de tabelas pronto, a gente parte para construí-lo fisicamente em uma base de dados relacional.

[7:49] No nosso caso, o MySQL.

[7:51] Existem ferramentas que nós chamamos de ferramentas case, que já facilitam a construção desses bancos, onde a gente, nas ferramentas case, desenha esse esquema de relações, graficamente, e aí automaticamente a ferramenta gera os códigos de criação.

[8:16] A gente, aqui, tem como objetivo conhecer o MySQL, então a gente não vai, claro, pegar uma ferramenta de relacionamento, colocar graficamente as tabelas e depois gerar o banco de forma automática.

[8:31] A gente vai star construindo esse banco na mão, através de comandos SQL, mas baseados nesse esquema aqui em cima que nós estamos olhando, que foi resultado do esquema de entidades e relacionamento que nós construímos aqui, que veio originalmente do entendimento do negócio e das entrevistas com os nossos usuários.

[8:58] Tá legal? Então tá, gente, é isso que eu queria falar um pouquinho sobre modelagem. Valeu.

-----------------------------------------------------------------------
# 11Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Instale o MySQL, conforme o vídeo [**Instalando o MySQL Server**](https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54324), da aula 1 do curso [**Introdução ao SQL: Manipule dados com MySQL**](https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql).

2) Abra o MYSQL Workbench. Use a conexão LOCALHOST e certifique que o ambiente está funcionando.


-----------------------------------------------------------------------
# O que aprendemos?

 [Próxima Atividade](https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/56772/next)

- [](https://cursos.alura.com.br/suggestions/new/mysql-dml-manipulacao-de-dados/56772/question)

Nesta aula, aprendemos:

- Como modelar um banco de dados baseado no negócio da empresa;
- Revisamos todas as entidades envolvidas em um banco de dados;
- Aprendemos os tipos de dados que compõem uma tabela.


-----------------------------------------------------------------------
# 01Criação de banco de dados

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55780


## Transcrição

[0:00] Vamos continuar estudando?

[0:02] Então, nesse momento eu já fiz as entrevistas com os meus usuários, eu conheci como funciona o negócio de vendas da área de suco de frutas, já que meu objetivo é projetar um banco de dados para a área de vendas dessa empresa, e agora chegou a hora de botar a mão na massa.

[0:21] E aí o primeiro passo que eu tenho que fazer é criar um repositório onde as tabelas, as entidades serão criadas, e esse repositório, é claro, nós chamamos de banco de dados.

[0:34] É a primeira entidade que eu tenho que criar dentro do MySQL.

[0:39] E aí é que vem um ponto interessante que eu vou colocar em debate nesse momento.

[0:46] Quem é que cria o banco de dados? Quando eu falo banco de dados eu não estou falando das tabelas, dos índices, das chaves primárias, dos relacionamentos, eu estou falando do repositório vazio onde o analista que projetou o trabalho a ser feito vai começar a trabalhar.

[1:04] Essa área vazia, que é o banco de dados, onde eu vou colocar as minhas entidades, dependendo do tipo de empresa pode ser que seja um profissional especializado que vai fazer isso.

[1:18] Normalmente, esse profissional a gente chama de DBA.

[1:21] O DBA é o profissional responsável por administrar o ambiente de banco de dados, e cabe a ele criar os bancos, mas isso funciona quando a gente está falando de uma empresa coorporativa, grande.

[1:38] Se a gente estiver falando de empresas pequenas ou até mesmo de bancos de dados muito pontuais, muito departamentais, onde tem um servidor que foi comprado exclusivamente para colocar esse banco de dados, aí o próprio profissional que vai realmente criar as tabelas, os índices, as chaves primárias, a estrutura para receber os dados, também pode criar o banco de dados.

[2:11] Então, apesar de que normalmente isso é uma tarefa do DBA e não do analista que está projetando o banco, a gente vai ver um pouquinho sobre como criar banco de dados no MySQL.

[2:24] E aí eu começo mostrando a vocês aqui do lado a sintaxe do comando.

[2:30] Eu posso usar create database ou create schema, está aqui.

[2:42] Posso ter a cláusula if not exist, ou seja, se eu quiser criar um dado que já existe, se eu tiver a cláusula if not exist, não vai dar erro.

[2:53] E aí eu coloco aqui o nome do banco, dependendo do ambiente ele é case sensitive ou não.

[3:03] Se eu estiver em um ambiente Windows, ele não é case sensitive, mas se eu estiver em um ambiente Linus ou ou Unix, ele será case sensitive.

[3:12] E aí eu coloco a especificação da criação.

[3:17] Essa especificação são informações que estão relacionadas com a criptografia do banco, se ele vai ter ou não uma criptografia interna, e sobre o character set, ou seja, quais são os caracteres que o banco de dados vai suportar.

[3:35] Todo mundo sabe que dependendo do país, da língua utilizada, eu tenho alguns caracteres que são fora do padrão.

[3:46] Nós aqui do português temos o Ç, o A com tio, o A com acento, então, normalmente a gente usa o TF8, que é um conjunto de caracteres um pouco mais abrangente, que comportam esses símbolos específicos do português, mas você tem, por exemplo, outras tabelas que comportam outros símbolos, como por exemplo alfabeto grego, russo, japoneses ou chineses, árabes, e assim por diante.

[4:20] Mas se eu não falar nada ele vai usar a padronização do ambiente operacional onde o banco está instalado.

[4:31] Eu posso usar tanto o create database quanto o create schema, os dois são as mesmas coisas, ok?

[4:40] Agora, eu também posso apagar um banco.

[4:43] Para apagar um banco eu uso o comando drop, database ou schema, o if exist e o nome do banco.

[4:53] O if exist, como está mostrado aqui, ele é opcional.

[4:58] Tanto o create quanto o drop podem, ser também executado com um assistente.

[5:03] Então está bom? Agora a gente já fez uma revisão da sintaxe, vamos, então, agora, para o Workbench fazer alguns exemplos.

[5:19] Então está aqui, MySQL Workbench 8.0 CE, que a gente instalou durante o processo de instalação do software.

[5:36] Então tem a minha conexão aqui que já foi configurada durante a instalação.

[5:46] E aí eu tenho a minha área de trabalho onde eu tenho nesse canto esquerdo as bases de dados disponíveis para mim conforme o meu usuário, e do lado direito uma área vazia onde eu posso entrar com os comandos.

[6:03] Então vamos lá, vou entrar aqui com o mando create database vendas sucos, e termino com ponto e vírgula.

[6:15] Se eu clicar sobre esse raio aqui eu executo o comando.

[6:22] Lá embaixo eu tenho o resultado do comando, veja que mostra um ícone verdinho, significa que o comando rodou com sucesso.

[6:31] Aqui do lado, se eu der o botão direito do mouse e der um refresh all, vou vou ver aqui a minha base selecionada.

[6:41] Bem, eu poderia estar usando aquelas tabelas de símbolos, as collections, para especificar o conjunto de caracteres padrões de uma determinada língua, porque eu quero armazenar caracteres especiais caso meu banco esteja, por exemplo, sendo criado com dados em português, em chinês, japonês, e assim por diante.

[7:10] Para mostrar esse exemplo, eu vou escrever aqui: databese, vendas, sucos 2, por exemplo, porque sucos 1 já existe, eu boto default, character set, por exemplo, utf8.

[7:36] Se eu rodar esse comando eu crio a base, só que ele me dá um warning porque ele está dizendo que utf8 já é a tabela corrente do meu banco, isso porque eu estou já em um Windows em português, então ele já sabe e já carrega o utf8.

[8:04] Mas eu mostrei aqui para vocês como é que eu poderia estar criando isso usando uma tabela de caracteres padrões.

[8:14] Eu posso, por exemplo, se eu vier aqui, tentar criar de novo o banco.

[8:22] Se eu tentar criar de novo o banco, claro que ele vai me dar um erro, porque o banco vendas sucos 2 já existe.

[8:31] Ele vai me dar esse erro aqui e a mensagem está aqui embaixo, ó: "não posso criar o database vendas sucos 2 database existe".

[8:42] Mas se eu usar aquela cláusula if not exist...

[8:55] Vamos lá.

[9:01] E aí vamos colocar aqui vendas sucos 2.

[9:08] Se eu rodar com essa cláusula, ele não vai dar erro, mas ele me dá também um warning, dizendo, claro: "olha, eu não posso criar porque já existe".

[9:22] A mensagem inclusive é a mesma de quando tem erro, só que o warning significa que rodou com sucesso.

[9:31] A gente pode, se quiser, apagar o banco.

[9:33] O apagar o banco é o drop, database, aí posso usar o if exist e posso colocar aqui, por exemplo, vendas sucos 2.

[9:54] Aí, ao executar esse comando, tenho lá sucesso, o banco foi apagado.

[10:01] Criar e apagar bancos pode também ser feito por assistentes dentro do Workbench.

[10:08] Se eu der o botão direito do mouse em qualquer área da tela, eu tenho a opção create schema, e eu selecionando ela coloco o nome da base, vendas sucos 2, por exemplo, e aqui eu posso usar os default character 7, no caso que eu vou usar utf32, e o collation, por exemplo, eu quero usar caracter roman.

[10:46] Roman é romano, não é? Polonês, persa,tem um montão de opções aqui, olha. Turco.

[10:56] Se eu der o apply ele me mostra esse comando aqui, então, no caso do caracter turco eu uso utf32, eu dou apply, dou o finish, e aí eu tenho esse banco aqui criado já pronto para receber caracteres turcos.

[11:20] Se eu der botão direito do mouse sobre o nome do banco eu tenho o drop database aqui.

[11:29] E aí eu posso apagar a base de dados, ok?

[11:36] Nesse momento, para você que vai trabalhar apenas como projeto do banco de dados, de manipular os dados, o que diz respeito a criar banco de dados é isso que você deve saber.

[11:49] Mais detalhes, mais informações sobre isso, aí você deve consultar um DBA que vai poder te orientar melhor.

[11:56] Está legal? Então é isso, gente, valeu.

-----------------------------------------------------------------------
# 03Criação de tabela com PK

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55781

## Transcrição

[0:00] Beleza, nesse momento temos o banco de dados criado - seja por você mesmo ou pelo DBA - e eu tenho a estrutura vazia, onde eu vou começar a colocar as entidades ali dentro, e as primeiras coisas que eu tenho que criar são as tabelas.

[0:15] Serão as tabelas em que os dados serão armazenados.

[0:19] E aí, normalmente, quando a gente cria a tabela, a gente já especifica os campos, os seus tipos e quem será a chave primária da tabela.

[0:30] A sintaxe está aqui em cima, ela é bem complicada, tem muito parâmetro.

[0:36] Aqui eu coloquei basicamente o comando create table, onde você especifica aqui se é uma tabela temporária ou não - mais adiante a gente vai falar sobre isso -, mas basicamente a gente vai usar o create table, if not existe é aquela mesma coisa, se não existir a tabela não vai criar.

[0:57] Quer dizer, se a tabela já existir e eu quiser criar de novo ela não vai criar.

[1:03] O nome da tabela, e aí eu tenho uma série de informações, como por exemplo definições de criação, opções de tabelas e opções de partições.

[1:13] Isso mesmo, porque eu posso, por exemplo, ter tabelas particionadas.

[1:19] Existe outro tipo aqui de forma de criação, posso criar, por exemplo, usando essa cláusula like, ou seja, criar uma tabela como uma tabela já existente.

[1:32] Mas, enfim, na medida em que for avançando com esse e com outros treinamentos, a gente vai entrando mais a fundo sobre os comandos de criar tabela.

[1:41] O que a gente quer saber, por enquanto, é isso aqui.

[1:47] A gente vai colocar o nome da tabela, entre parênteses o nome do campo, o tipo do campo e se ele vai ser nulo ou não.

[1:56] O que é isso? Se ele aceita ou não valores nulos na coluna.

[2:06] Obrigatoriamente, quando o campo é chave primária, ele não pode ser nulo.

[2:12] Campos que não são chave primária podem ser ou não nulos.

[2:17] E aí eu coloco a palavra primary key e entre parenteses os campos que fazem parte da chave primária.

[2:25] E, é claro, para eu apagar a tabela eu uso o drop table, o nome da tabela, está bom?

[2:34] Bem, então vamos começar a criar as tabelas no nosso banco.

[2:38] Para a gente lembrar, eu tenho aqui, separado, o nosso esquema.

[2:46] A gente especificou que essas são as tabelas que nós vamos criar, e nós vamos criar, inicialmente, a tabela de produtos e a tabela de vendedores.

[2:56] Então, para a a gente poder seguir bem com esse vídeo, eu vou fazer o seguinte: eu vou manter aqui essa janela mais ou menos aqui salva nesse canto.

[3:17] Vamos tentar ver se consigo de novo.

[3:25] Vou manter ela aqui, e aí eu vou voltar no Workbench e vou criar um novo script.

[3:39] Aí o Workbench eu também vou deixar um pouquinho mais para cá para eu poder olhar aqui a especificação das tabelas e ir digitando o comando.

[3:53] Então, vamos lá, eu vou começar.

[3:57] Uma coisa importante: quando eu digito um comando SQL e vou executá-lo, é importante você ver qual é o banco que está selecionado.

[4:06] No caso, aqui, é meu vendas sucos.

[4:09] Para selecionar o banco dentro do Workbench, basta eu dar double click sobre ele, mas eu posso aqui forçar a entrada do banco, eu coloco use e o nome do banco: vendas sucos.

[4:26] Então, vamos começar: create, table, então eu vou botar o nome da tabela, no caso aqui eu vou botar produtos.

[4:37] Aí eu vou abrir a parenteses e vou começar a colocar os campos, que são esses aqui: código, descritor, sabor, tamanho, ok?

[4:51] Então, eu vou começar aqui: código, o tipo.

[4:58] É string, eu vou usar varchar, por exemplo, de 10, vírgula.

[5:08] Ah, posso especificar aqui o not null, porque o código é chave primária, então não pode ser nulo.

[5:18] Ele vai ser chave primária, porque aqui na minha especificação está dizendo: o código é a chave primária da tabela de produtos, eu não posso ter dois produtos com o mesmo código.

[5:30] Vamos seguindo, depois eu vou colocar descritor, varchar de 100, null.

[5:43] Sabor, varchar de 50, null.

[5:51] Próximo, tamanho, varchar de 50, null.

[5:59] Lembrando, varchar é string, não é texto, que eu estou reservando 50 espaços, mas se ele tiver 10 ele só vai ocupar os 10.

[6:13] Embalagem, varchar de 50, null.

[6:24] Preço lista, é um float, null.

[6:33] E aí antes de terminar a tabela, em vez de eu fechar o parenteses... quer dizer, eu posso até fazer isso aqui, mas se eu fizer eu vou criar a tabela sem primary key.

[6:47] Como eu quero primary key, eu boto vírgula e escrevo a palavra primary key, abre parenteses, e dentro o campo que faz parte da primary key.

[6:58] No caso, é só código, então eu boto o código, fecho o parenteses do primary key e do create produtos, ponto e vírgula.

[7:11] Vamos para a próxima tabela, a de vendedores.

[7:15] Create, table, vendedores, vou abrir parenteses, tem matrícula, que vai ser varchar de 5, not null.

[7:35] Depois é nome, varchar de 100, null.

[7:42] Depois é bairro, varchar de 50, null.

[7:50] Depois tem comissão, é float, null.

[8:01] Depois tem data admissão, é do tipo date, null, e, finalmente, férias.

[8:13] Boolean significa lógico, verdadeiro ou falso, vai ser do tipo bit de 1.

[8:23] Vírgula e agora primary key, primary key, abre parentese, matrícula, fecha o segundo parentese, ponto e vírgula, ok?

[8:39] Vamos ver se eu fiz certo a coisa ou se eu cometi algum erro.

[8:45] Pronto, executei, criari as minhas tabelas.

[8:50] Se eu vier aqui na relação do banco de dados, botão direito do mouse, refresh all, eu já tenho aqui as duas tabelas: produtos e vendedores, está bom?

[9:03] Então, criei aqui já duas tabelas do meu banco, do meu esquema da empresa de suco de frutas.

[9:09] Eu voltei para corrigir um erro.

[9:13] Eu coloquei aqui data admissão, cometi um erro de português, mas foi até bom que eu tenha feito isso, porque eu vou mostrar a vocês como é que, depois que a gente cria uma tabela, quando a gente quer mudar o nome de uma coluna.

[9:31] Mudar nome de colunas é uma coisa que não é sempre que a gente consegue.

[9:37] Se a coluna já for primary key, por exemplo, nós vamos ter dificuldade de fazer isso, aí é melhor você destruir a tabela e colocar de novo.

[9:46] No caso dessa coluna da admissão, é uma coluna comum, então eu vou mudar o nome dela.

[9:54] O que eu vou fazer? Vou vir aqui, vou escrever um comando que é alter table, ou seja, vou alterar a tabela, o nome da tabela, vendedores, vou colocar a cláusula rename colun, coloco o nome da coluna errada.

[10:24] E aí eu coloco o nome da coluna certa.

[10:32] Então, ficou assim: alter table, rename, o nome da coluna errada e o nome da coluna certa.

[10:42] Esse aqui é o nome da coluna que está na tabela.

[10:46] Eu posso querer mudar o nome não porque está escrito errado, porque eu quero que o nome seja diferente.

[10:53] Você seleciona e executa.

[10:57] Pronto, é feita a alteração.

[11:00] Esse comando vai me dizer sempre que tem um erro aqui, mas, nesse caso, a gente ignora, porque essa sintaxe de rename de coluna é uma coisa que veio nova na versão 8 do MySQL.

[11:18] Nas versões anteriores o rename de coluna era um pouco diferente, e, de alguma maneira, o Workbench ainda está interpretando esse comando como se fosse uma versão antiga do MySQL, mas funciona.

[11:32] Então, agora, se eu vier aqui na tabela de vendedores, der um refresh, eu agora vou ter aqui a minha coluna com o nome correto, está legal?

[11:51] Na verdade, quando eu gravei o vídeo eu vi que eu cometi esse erro, e, em vez de eu corrigir e ter que gravar um vídeo de novo, eu preferi mostrar a vocês um comando novo que faz com que a gente altere o nome de uma coluna de uma tabela que já está criada, está legal?

[12:08] Agora eu vou me despedindo de verdade do vídeo, tá bom? Tchau, tchau.


-----------------------------------------------------------------------
# 04Criação de tabela pelo assistente

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55782

## Transcrição

[0:00] Vamos continuar? A gente agora vai criar a tabela de clientes. Só que em vez de fazer isso por comandos, nós vamos criar a tabela de clientes através do assistente do MySQL.

[0:13] Então eu vou aqui nessa parte do lado, chegar um pouquinho essa janela para cá, para eu poder olhar aqui os campos que vão fazer parte da tabela de clientes.

[0:28] Então vai ser CPF, nome, endereço, bairro, e assim por diante.

[0:33] Para a gente criar a tabela de clientes, pelo assistente, eu vou dar botão direito do mouse sobre tables, e vou selecionar a opção Create Table.

[0:46] Ele vai me abrir essa caixa de diálogo aqui, que me mostra as perguntas que eu preciso fazer para criar a tabela através do assistente. E note que eu tenho vários parâmetros, porque a gente quando criou pelo script, a gente não falou muito a fundo sobre todas as possibilidades que a gente podia estar usando no momento de criar uma tabela. E aqui na caixa de diálogo ele mostra mais possibilidades.

[1:21] Então vamos lá, o nome da tabela eu vou colocar aqui em cima, eu vou chamar de clientes.

[1:29] Eu posso também, se quiser, especificar um conjunto de caracteres especiais para apenas aquela tabela.

[1:38] A gente não vai se preocupar com isso nesse momento, mas é possível eu só ter uma tabela especial de caracteres para uma tabela, e não para o banco todo.

[1:49] Essa coisa aqui, engine, significa o seguinte: eu posso ter vários tipos de forma de armazenamento de uma tabela dentro do MySQL, inclusive isso é uma funcionalidade muito interessante, que eu não sei se somente o MySQL, mas eu desconheço o Oracle e o MySQL por exemplo apresentar esse tipo de funcionalidade. Existem vários tipos de engine de formas com que a tabela será criada e armazenada no banco de dados, tanto é que se eu abrir essa caixa de diálogo aqui eu tenho diversas opções, mas as duas opções mais utilizadas é a InnoDB e a MyISAM.

[2:36] O que é o InnoDB e o que é a MyISAM? Vamos dizer o seguinte: o InnoDB tem um controle mais robusto sobre a tabela, porque ele está preparado para gerenciar tabelas que tenham muitas transações.

[2:57] Então se eu tiver uma tabela que tenha muita chave primária ou estrangeira, tiver muita inclusão, alteração, exclusão, ou seja, tabelas que fazem parte de um sistema transacional que se troca muito dado, a gente utiliza InnoDB.

[3:13] O MyISAM é para tabelas que vão mudar muito pouco, vão ser estáticas. Tabelas, por exemplo, de cadastros, que são coisas que depois de criadas, ficam ali meio que paradas, e só uma vez ou outra a gente vai estar, digamos assim, modificando a tabela.

[3:33] Aqui o padrão, quando eu entrei, é InnoDB, e claro, esse padrão está muito ligado com performance e tamanho de banco.

[3:43] Tabelas InnoDBs ocupam muito mais espaço, e elas também não têm tanta performance na consulta, porque elas têm internamente uma série de outros controles para serem feitos, enquanto o MyISAM ocupa menor espaço e é mais performático quando a gente vai fazer uma consulta.

[4:04] Aqui no meu caso, nós vamos manter o InnoDB, e aqui em Column Name e Datatype, eu vou criar os meus campos, e eu vou especificar aqui os campos que vão ser, por exemplo, PK, e NN é Not Null.

[4:27] Só que isso aqui fica muito curto, mas aí eu tenho essa setinha aqui de cima, que eu posso clicar nela, e eu abro a caixa de diálogo aqui de nome das colunas.

[4:38] Então vamos começar, eu vou ter CPF, o Datatype vai ser VARCHAR de 11, vai ser PK e é not null, ele até já me mostrou aqui.

[4:55] Note que quando eu disse que é PK e not null, ele já colocou um símbolo aqui de uma chavinha, dizendo que essa linha é chave da tabela.

[5:09] Depois eu vou entrar com nome, vai ser um varchar de 100. Depois eu entro com endereco, vai ser um varchar de 150.

[5:30] Vamos seguindo. Bairro, varchar de 50. Cidade, varchar de 50 também.

[5:52] Depois de cidade vem Estado, varchar de 50.

[6:01] Eu dei um enter, ele automaticamente já botou uma linha ali para baixo para mim.

[6:06] CEP, vai ser um varchar de oito. Enter. Data nascimento vai ser um campo, vamos lá, tem lá todos os campos aqui, vai ser date.

[6:32] Depois temos idade, vai ser um inteiro, vamos procurar aqui, int. Depois sexo, vai ser um varchar de um. Limite de crédito, vai ser float. Vamos procurar o float aqui.

[7:08] Volume de compra também vai ser float.

[7:19] E finalmente, primeira compra, vai ser um bit de um.

[7:35] Aí eu não vou dar enter, eu clico em cima um pouquinho, só para que todos os meus campos já estão criados, se eu desse enter ele ia querer criar mais uma linha abaixo. E aí eu clico aqui em apply, para poder aplicar essa modificação.

[7:54] Ele vai me mostrar o texto do comando, e aí eu dou apply, e aí a tabela foi criada. Está aqui agora a minha tabela de clientes criada.

[8:08] Então eu já tenho clientes, produtos, e vendedores, tá legal? Valeu, abraço.


-----------------------------------------------------------------------
# 04Criação de tabela pelo assistente

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55782

## Transcrição

[0:00] Vamos continuar? A gente agora vai criar a tabela de clientes. Só que em vez de fazer isso por comandos, nós vamos criar a tabela de clientes através do assistente do MySQL.

[0:13] Então eu vou aqui nessa parte do lado, chegar um pouquinho essa janela para cá, para eu poder olhar aqui os campos que vão fazer parte da tabela de clientes.

[0:28] Então vai ser CPF, nome, endereço, bairro, e assim por diante.

[0:33] Para a gente criar a tabela de clientes, pelo assistente, eu vou dar botão direito do mouse sobre tables, e vou selecionar a opção Create Table.

[0:46] Ele vai me abrir essa caixa de diálogo aqui, que me mostra as perguntas que eu preciso fazer para criar a tabela através do assistente. E note que eu tenho vários parâmetros, porque a gente quando criou pelo script, a gente não falou muito a fundo sobre todas as possibilidades que a gente podia estar usando no momento de criar uma tabela. E aqui na caixa de diálogo ele mostra mais possibilidades.

[1:21] Então vamos lá, o nome da tabela eu vou colocar aqui em cima, eu vou chamar de clientes.

[1:29] Eu posso também, se quiser, especificar um conjunto de caracteres especiais para apenas aquela tabela.

[1:38] A gente não vai se preocupar com isso nesse momento, mas é possível eu só ter uma tabela especial de caracteres para uma tabela, e não para o banco todo.

[1:49] Essa coisa aqui, engine, significa o seguinte: eu posso ter vários tipos de forma de armazenamento de uma tabela dentro do MySQL, inclusive isso é uma funcionalidade muito interessante, que eu não sei se somente o MySQL, mas eu desconheço o Oracle e o MySQL por exemplo apresentar esse tipo de funcionalidade. Existem vários tipos de engine de formas com que a tabela será criada e armazenada no banco de dados, tanto é que se eu abrir essa caixa de diálogo aqui eu tenho diversas opções, mas as duas opções mais utilizadas é a InnoDB e a MyISAM.

[2:36] O que é o InnoDB e o que é a MyISAM? Vamos dizer o seguinte: o InnoDB tem um controle mais robusto sobre a tabela, porque ele está preparado para gerenciar tabelas que tenham muitas transações.

[2:57] Então se eu tiver uma tabela que tenha muita chave primária ou estrangeira, tiver muita inclusão, alteração, exclusão, ou seja, tabelas que fazem parte de um sistema transacional que se troca muito dado, a gente utiliza InnoDB.

[3:13] O MyISAM é para tabelas que vão mudar muito pouco, vão ser estáticas. Tabelas, por exemplo, de cadastros, que são coisas que depois de criadas, ficam ali meio que paradas, e só uma vez ou outra a gente vai estar, digamos assim, modificando a tabela.

[3:33] Aqui o padrão, quando eu entrei, é InnoDB, e claro, esse padrão está muito ligado com performance e tamanho de banco.

[3:43] Tabelas InnoDBs ocupam muito mais espaço, e elas também não têm tanta performance na consulta, porque elas têm internamente uma série de outros controles para serem feitos, enquanto o MyISAM ocupa menor espaço e é mais performático quando a gente vai fazer uma consulta.

[4:04] Aqui no meu caso, nós vamos manter o InnoDB, e aqui em Column Name e Datatype, eu vou criar os meus campos, e eu vou especificar aqui os campos que vão ser, por exemplo, PK, e NN é Not Null.

[4:27] Só que isso aqui fica muito curto, mas aí eu tenho essa setinha aqui de cima, que eu posso clicar nela, e eu abro a caixa de diálogo aqui de nome das colunas.

[4:38] Então vamos começar, eu vou ter CPF, o Datatype vai ser VARCHAR de 11, vai ser PK e é not null, ele até já me mostrou aqui.

[4:55] Note que quando eu disse que é PK e not null, ele já colocou um símbolo aqui de uma chavinha, dizendo que essa linha é chave da tabela.

[5:09] Depois eu vou entrar com nome, vai ser um varchar de 100. Depois eu entro com endereco, vai ser um varchar de 150.

[5:30] Vamos seguindo. Bairro, varchar de 50. Cidade, varchar de 50 também.

[5:52] Depois de cidade vem Estado, varchar de 50.

[6:01] Eu dei um enter, ele automaticamente já botou uma linha ali para baixo para mim.

[6:06] CEP, vai ser um varchar de oito. Enter. Data nascimento vai ser um campo, vamos lá, tem lá todos os campos aqui, vai ser date.

[6:32] Depois temos idade, vai ser um inteiro, vamos procurar aqui, int. Depois sexo, vai ser um varchar de um. Limite de crédito, vai ser float. Vamos procurar o float aqui.

[7:08] Volume de compra também vai ser float.

[7:19] E finalmente, primeira compra, vai ser um bit de um.

[7:35] Aí eu não vou dar enter, eu clico em cima um pouquinho, só para que todos os meus campos já estão criados, se eu desse enter ele ia querer criar mais uma linha abaixo. E aí eu clico aqui em apply, para poder aplicar essa modificação.

[7:54] Ele vai me mostrar o texto do comando, e aí eu dou apply, e aí a tabela foi criada. Está aqui agora a minha tabela de clientes criada.

[8:08] Então eu já tenho clientes, produtos, e vendedores, tá legal? Valeu, abraço.


-----------------------------------------------------------------------
# 06Criação de tabela com FK

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55783

## Transcrição

[0:00] Vamos continuar? Agora vamos criar as tabelas com as chaves estrangeiras.

[0:08] Deixa eu voltar de novo para o nosso esquema.

[0:13] Esse slide que está aqui está mostrando as tabelas normais, mas nós temos aqui as tabelas com relacionamentos.

[0:23] Então nós vamos iniciar primeiro com a tabela de vendas que é essa daqui, que vai ter que ter um relacionamento do CPF com o código do CPF do cliente, da tabela de clientes, e vai ter que ter um relacionamento a matrícula com o código da matrícula da tabela de vendedores.

[0:53] Então nós vamos primeiro criar a tabela, e depois criar o relacionamento.

[1:02] Então eu vou voltar de novo aqui para o modelo onde eu tenho as tabelas.

[1:11] Nós vamos aqui criar então um script novo, vou botar use vendas sucos, e aí vamos criar a tabela create table tabela de vendas.

[1:40] Então vamos começar. Nós temos o número, que é um varchar de cinco, not null, depois temos uma data, nós não vamos chamar esse campo de data, vamos chamar de data venda. É um tipo date, null.

[2:13] CPF que é um varchar de 11. Aí o seguinte, como o CPF vai fazer parte de chave estrangeira com o CPF da tabela de clientes, é legal a gente colocar ele como not null.

[2:32] Matrícula varchar de cinco, not null.

[2:42] Imposto, vai ser um float null.

[2:53] E aí finalmente eu vou botar uma primary key que vai ser número.

[3:04] Bem, vamos ver se isso daqui vai rodar sem problemas.

[3:10] Então eu criei a minha tabela de vendas.

[3:15] Agora eu preciso fazer uma ligação entre a tabela de vendas e a tabela de clientes pelo CPF.

[3:26] Então nós vamos fazer o seguinte, como é que eu faço esse tipo de coisa? Eu faço o comando alter table, o nome da tabela que eu quero mudar que é tabela de vendas, aí eu coloco esse comando add constraint.

[3:54] Todas essas ligações, a gente chama de constraint, seria como se fossem restrições ou relacionamentos, então eu estou dizendo que eu vou alterar a tabela de vendas adicionando um novo relacionamento.

[4:13] E esse relacionamento vai ter um nome. Normalmente a gente coloca FK na frente do nome, e aí como esse cara vai ter um relacionamento com a tabela de clientes, eu vou chamar de FK clientes.

[4:31] Aí eu boto a palavra foreign key, que é chave estrangeira, e o campo, CPF.

[4:43] Ou seja, eu estou ligando uma restrição do tipo foreign key a este campo aqui, da tabela de vendas, e ele vai ter que ter uma referência com quem? Com o campo CPF, aqui. Eu vou ter que ter uma referência com esse código, está aqui a criação da tabela de clientes, com esse código CPF aqui da tabela de clientes.

[5:21] Então eu vou escrever reference, a que tabela é? À tabela clientes, e aqui o campo lá da tabela de clientes, CPF.

[5:42] Vamos rodar. Pronto. Criou a relação.

[5:48] Agora nós vamos fazer a relação entre o campo matrícula da tabela de vendas com o campo matrícula de vendedores. Então vamos lá.

[6:00] Alter table tabela de vendas add constraint fk vendedores, foreign key. Qual é o nome do campo? Matrícula. References, qual é o nome da tabela lá de cima? Vendedores. E qual é o nome do campo? Matrícula.

[6:40] Esse nome aqui, e esse nome aqui, não precisariam estar iguais, porque inclusive eu repito esses nomes.

[6:54] Aqui eu errei, alter table.

[6:58] Vamos rodar agora aqui o comando. Fez com sucesso.

[7:10] Então tá, vamos parar por aqui então, valeu.

-----------------------------------------------------------------------
# 08Mudando o nome da tabela

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55784

## Transcrição

[0:00] Ok, quando eu fui mostrar esse banco de dados aqui temporariamente lá para a empresa de suco de frutas, ou seja, vim aqui, dei refresh, mostrei para eles: "olha, eu estou criando esse banco aqui", o pessoal não gostou muito do nome tabela de vendas.

[0:21] Na verdade, essa tabela se referencia a notas fiscais.

[0:27] Então eles falaram assim para mim: "essa tabela de vendas eu queria que na verdade se chamasse notas".

[0:37] Ok, felizmente eu consigo alterar o nome de uma tabela pelo MySQL.

[0:44] Então eu vou fazer isso para poder transformar essa tabela underscore de vendas em notas.

[0:53] Então eu vou criar aqui um script novo, e aí vou novamente entrar aqui na base.

[1:06] O comando é o seguinte: é alter table, o nome da tabela, tabela de vendas, e aí é muito simples, é rename, e o novo nome, notas.

[1:26] Então ficou assim, alter table, o nome da tabela atual, a cláusula rename, e o nome da nova tabela.

[1:39] Eu vou clicar, fez com sucesso.

[1:43] Se eu vier então aqui do lado esquerdo, botão direito do mouse, e der um refresh, note que agora a minha tabela se chama notas.

-----------------------------------------------------------------------
# 09Finalizando a criação do banco

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55785

## Transcrição

[0:00] Vamos finalizar então a criação das tabelas, e das chaves primárias estrangeiras do nosso banco conforme a especificação.

[0:10] Então eu vou voltar aqui para o diagrama, e eu tenho aqui, vamos chegar um pouquinho mais para o lado, ficou muito pequeno, porque o tamanho da janela diminuiu.

[0:31] Eu tenho aqui a tabela de itens vendidos, que aí eu tomei cuidado de conversar com o pessoal da empresa de suco de frutas, e eles me falaram que eu deveria chamar essa tabela de itens notas.

[0:44] Então vamos lá, vamos criá-la aqui, eu vou adicionar aqui um novo script.

[0:56] Vou dar o use vendas sucos, vamos lá.

[1:05] Create table itens notas, aí eu abro meu parênteses, número, vai ser varchar de cinco, not null.

[1:26] Depois código vai ser varchar de dez, not null.

[1:35] Por que está not null as duas? Porque na especificação, a chave primária, PK, ela vai ser em cima dessas duas linhas, apesar de não estar escrito PK na especificação, mas é assim, uma nota fiscal pode ter vários itens, então se eu colocar somente número como PK, vai dar problema, porque aí não vou conseguir ter mais de um item, mas o que diferencia cada item de uma nota fiscal? É o código do produto.

[2:12] Então número e código do produto é que serão PK.

[2:16] Então será uma PK composta, por isso eu botei not null nas duas linhas.

[2:24] Depois eu vou botar quantidade, vai ser int, e depois preco, float.

[2:38] Note que eu não escrevi aqui o null, porque o null é default. Se eu não colocar nada, ele automaticamente vai considerar o campo como nulo. Então não preciso colocar o null.

[2:56] Primary key, e aí como é uma primary key composta, eu vou colocar número e código.

[3:08] Fiz aí a criação da tabela. Vamos até rodar a criação da tabela. Não deu problema.

[3:17] Se eu der um refresh, tenho aqui as tabelas criadas.

[3:24] Eu vou então agora fazer o alter table, itens notas, add constraint, o nome da constraint, eu vou chamar uma de FK notas, vou dar um enter aqui, FK notas, vai ser o nome da constraint do número da nota fiscal de itens com o número da nota fiscal de notas.

[4:05] Foreign key, o campo, é o campo número.

[4:15] References. Faço referência a que? À tabela notas, que também o campo lá na tabela de notas chama-se número.

[4:27] Vamos fazer agora a referência entre o código do produto da tabela de itens com o código de produto da tabela de produto.

[4:36] Só relembrando, é isso aí, o nome do campo é código mesmo. Mesmo nome que eu coloquei aqui.

[4:46] Então vamos lá, alter table, itens notas, add constraint, FK produtos, foreign key, código, reference, o nome da tabela é produtos, entre parênteses, código.

[5:26] Então tenho aqui a criação da tabela itens notas, e a criação das duas relações.

[5:41] Vou selecionar tudo isso aqui, vamos rodar.

[5:43] Não, na verdade, não posso rodar. Eu já criei a tabela de itens, então só vou rodar esses dois comandos.

[5:53] Ok, rodou com sucesso.

[5:56] E aí eu tenho já o meu banco criado com todas as tabelas, as primary keys, e os relacionamentos. Tá legal? Valeu.

-----------------------------------------------------------------------
# 10Diagrama

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55786

## Transcrição

[0:00] Então ok, nesse ponto eu tenho o meu banco de dados com os componentes internos dele: tabela, relacionamentos, chaves primárias, estrangeiras, criadas.

[0:13] Como eu estou usando aqui o MySQL Workbench, eu tenho a possibilidade de olhar esse banco de forma gráfica, muito parecido com esse desenho mais ou menos que eu fiz durante a especificação da base.

[0:33] Como é que eu faço isso? Olha só, eu estou com o meu vendas sucos aqui selecionado, eu vou aqui em database, reverse engineer. É essa opção aqui.

[0:50] Ele vai me mostrar a conexão local dos meus bancos de dados, eu vou dar next, vou dar next de novo, vou selecionar vendas sucos, que é o meu banco, next, next, e execute.

[1:08] Então note, ele vai escrever aqui, isso daqui.

[1:19] Eu tenho aqui a minha tabela de clientes, se eu boto o mouse aqui, ela tem a relação com a tabela de notas através de CPF, eu tenho a tabela de vendedores, se eu boto o mouse aqui tem uma relação tabela de vendedores com a tabela de notas pelo código da matrícula. Itens de notas, se eu botar o mouse aqui, nesse relacionamento que está passando por detrás da tabela de clientes, eu tenho uma relação de notas com itens notas pelo campo número, e eu tenho a tabela de produtos aqui embaixo, se eu boto o mouse aqui, eu tenho uma relação entre código da tabela de produtos com código da tabela de itens notas.

[2:09] Então com esse esquema aqui, eu tenho o esquema do meu banco, e eu posso, por exemplo, se quiser fazer consultas, na hora de fazer os inserts, eu já tenho essa informação guardada para mim.

[2:31] Eu posso inclusive fazer o seguinte, eu posso com esse banco selecionado, eu posso por exemplo, import, reverse engineer SQL create script.

[2:47] Eu posso, por exemplo, escolher aqui um arquivo no meu computador, eu vou criar aqui no diretório tempo um script chamado script criação base.

[3:14] Na verdade ele está pedindo para eu selecionar um script existente? Não, é ao contrário. Desculpe, é file, export, create script.

[3:24] Então eu me enganei, é file export. Porque eu estou exportando. Tem sentido, cometi um erro grave aqui.

[3:32] Eu estou exportando o esquema para um script, esse esquema que eu estou vendo aqui.

[3:38] Aí sim, eu seleciono aqui um create script DB, por exemplo, e aí eu escolho o que eu quero fazer, se eu quero dropar e criar o esquema, se tivesse dados, eu poderia dizer os comandos inserts para poder colocar dados dentro da tabela, mas eu não vou fazer nada não. Eu vou só clicar aqui em next, next.

[4:09] E olha só o que ele me escreveu, ele me escreveu esse script todo aqui onde eu tenho, eu crio aqui, nesse primeiro ponto, eu crio a base, aqui eu crio a tabela de clientes, note que ele até inseriu aqui algumas coisas a mais, porém muito parecido com o que a gente digitou aqui em cima. Depois eu crio a tabela de vendedores, crio a tabela de notas, e note que ele até fez a criação de um jeito diferente.

[4:55] A criação das constraints, ela ficou dentro do próprio comando create depois da criação do primary key. Aqui eu criei o primary key, e depois eu fiz isso aqui.

[5:12] Isso também funcionaria.

[5:15] Eu crio dois índices, e crio as constraints dizendo a que tabela está se referenciando.

[5:27] E aí eu tenho aqui também a criação da tabela de produtos, e aí finalmente a criação da tabela de itens de notas, com os relacionamentos com a tabela de notas através de número, e a tabela de produtos através de código.

[5:46] Então eu tenho isso daqui, se eu der um finish, se eu for lá para o diretório que eu selecionei, eu tenho um arquivo aqui, create script DB, se eu abrir com editor de texto, eu tenho o script todo aqui de criação do meu banco. Então eu poderia, por exemplo, pegar esse script e rodar em outro banco.

[6:14] Enfim, eu fiz uma engenharia reversa, vi graficamente a minha base, e transformei essa engenharia reversa em um script para criar o banco, por exemplo, novamente, ou criá-lo, por exemplo, em um outro MySQL.

[6:33] Então era isso que eu queria mostrar, mas mais importante era só para a gente poder ver visualmente como é que ficou o nosso esquema de banco de dados depois de ter dado os comandos de create, de criar tabela, create table, e de alter table para criar os relacionamentos entre as tabelas. Valeu então, um abraço.


-----------------------------------------------------------------------
# 12Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Abra o `MYSQL Workbench` e crie um novo script de comandos SQL.

2) Para criar uma base de dados podemos usar o comando `CREATE`. Digite o comando abaixo para criar uma nova base de dados:

```sql
CREATE DATABASE vendas_sucos;
```

1) Podemos usar algumas propriedades para definir o tipo de tabela de caracteres que podem ser usadas na armazenagem dos dados no banco. Digite o comando abaixo para criar um banco que utilize a tabela de caracteres `UTF8`:

```sql
CREATE DATABASE vendas_sucos2 DEFAULT CHARACTER SET utf8;
```

2) Se tivermos dúvida se o banco de dados a ser criado existe ou não, podemos usar o comando `IF NOT EXISTS`. Este comando é usado em diversas entidades do MYSQL e é usado para que o processo de criação aconteça apenas se o componente existe. Digite o comando abaixo para criar novo banco, somente se ele não existir:

```sql
CREATE DATABASE IF NOT exists vendas_sucos2;
```

3) Podemos apagar um banco de dados existente. Para isso digite o comando:

```sql
DROP DATABASE IF EXISTS vendas_sucos2;
```

4) Clique com o botão da direita do mouse sobre a área vazia na lista de bases de dados, a direita no Workbech, e escolha a opção `Create Schema`.

![1.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/02/1.png)

5) Será apresentado um assistente que lhe ajuda a criar um banco de dados sem precisar usar os comandos. Digite no nome da base `vendas_sucos2` e escolha as opções UTF16 para lista de caracteres.

![2.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/02/2.png)

6) Clique em Apply. O comando SQL a ser executado é gerado dinamicamente. Confirme a execução e o banco será criado.

7) Clique com o botão da direita do mouse sobre `vendas_sucos2` e escolha a opção `DROP SCHEMA`.

![3.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/02/3.png)

A base será excluida com este comando.

8) Duplo clique sobre a base de dados `vendas_sucos` para que a mesma fique selecionada. O nome dela deverá ficar em negrito.

9) Crie um novo script de SQL e digite o comando:

```undefined
USE vendas_sucos;
```

Este comando forçará a seleção da base de dados `vendas_sucos`;

10) Vamos criar a primeira tabela no nosso banco. Digite e execute:

```sql
CREATE TABLE PRODUTOS
(CODIGO VARCHAR(10) NOT NULL,
DESCRITOR VARCHAR(100) NULL,
SABOR VARCHAR(50) NULL,
TAMANHO VARCHAR(50) NULL,
EMBALAGEM VARCHAR(50) NULL,
PRECO_LISTA FLOAT NULL,
PRIMARY KEY (CODIGO));
```

11) Vamos criar a segunda tabela (vendedores). Digite:

```sql
CREATE TABLE VENDEDORES
(MATRICULA VARCHAR(5) NOT NULL,
NOME VARCHAR(100) NULL,
BAIRRO VARCHAR(50) NULL,
COMISSAO FLOAT NULL,
DATA_ADIMISSAO DATE NULL,
FERIAS BIT(1) NULL,
PRIMARY KEY (MATRICULA));
```

12) Note que houve um erro proposital ao selecionar o nome do campo que mostra a data de admissão do vendedor. Podemos alterar este nome mesmo com a tabela criada. Para isso digite execute::

```sql
ALTER TABLE VENDEDORES RENAME COLUMN DATA_ADIMISSAO TO DATA_ADMISSAO;
```

13) Clique com o botão da direita do mouse sobre o nó Table e selecione a opção Create Table.

![4.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/02/4.png)

14) Temos a caixa de diálogo para criar uma tabela através de um assistente. Digite na caixa de diálogo:

![5.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/02/5.png)

![6.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/02/6.png)

![7.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/02/7.png)

15) Confirme a criação da tabela acima.

16) Vamos criar mais uma tabela que é a tabela de vendas (Cabeçalho da nota fiscal). Para isso digite execute:

```sql
USE vendas_sucos;

CREATE TABLE TABELA_DE_VENDAS
(NUMERO VARCHAR(5) NOT NULL,
DATA_VENDA DATE NULL,
CPF VARCHAR(11) NOT NULL,
MATRICULA VARCHAR(5) NOT NULL,
IMPOSTO FLOAT NULL,
PRIMARY KEY (NUMERO));
```

17) Podemos criar relacionamentos entre esta tabela e a tabela de clientes e vendedores. Para isso digite e execute:

```sql
ALTER TABLE TABELA_DE_VENDAS ADD CONSTRAINT FK_CLIENTES
FOREIGN KEY (CPF) REFERENCES CLIENTES (CPF);

ALTER TABLE TABELA_DE_VENDAS ADD CONSTRAINT FK_VENDEDORES
FOREIGN KEY (MATRICULA) REFERENCES VENDEDORES (MATRICULA);
```

18) Da mesma maneira que fizemos em alguns passos anteriores, com o campo, o nome da tabela também pode ser alterado depois da mesma ser criada. Digite execute:

```sql
USE vendas_sucos;

ALTER TABLE tabela_de_vendas RENAME Notas;
```


-----------------------------------------------------------------------
# 13O que aprendemos?


Nesta aula, aprendemos:

- Aprendemos a criar o banco de dados.
- Aprendemos a criar uma tabela;
- Vimos que o nome dos campos podem ser modificados mesmo depois da tabela ter sido criada;
- Podemos criar as tabelas por um assistente. Foi mostrado isso nesta aula;
- Vimos como criar os relacionamentos entre as tabelas;
- Vimos que o nome da tabela também pode ser modificada após sua criação.


-----------------------------------------------------------------------
# 02Incluindo dados

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55787

## Transcrição

[0:00] Vamos continuar? Aqui eu tenho retirado do manual do MySQL a sintaxe do comando INSERT. O comando INSERT é aquele que insere dados dentro de uma tabela. Tem aí várias formas de usar o comando INSERT, também não vou entrar muito em detalhe do que está escrito aqui em cima, mas na medida em que a gente for trabalhando a gente vai vendo algumas formas mais ágeis de inserir dados dentro da tabela.

[0:30] O que a gente pode mais ou menos estar trabalhando é que basicamente eu uso INSERT + INTO, o nome da tabela e aí eu coloco entre parêntesis os campos da tabela, depois eu coloco values e os valores que eu vou inserir dentro da tabela. Em values se os campos forem textos eles têm que estar entre aspas simples, se forem números não precisa das aspas. E a gente pode também colocar o INSERT + INTO com o nome da tabela com os campos, values e aí vários conjuntos de campos separados por vírgula.

[1:15] Vamos fazer alguns exemplos bem simples para poder entender como é que funciona esses INSERTS + INTOS. Então eu vou entrar aqui no Workbench, vou criar um novo script e aí a gente vai entrar aqui no banco vendas sucos e aí eu vou colocar lá INSERT + INTO, o nome da tabela, por exemplo produtos, aí eu abro parêntesis e eu coloco o nome dos campos. Então vamos olhar aqui o nome dos campos da tabela de produtos eu tenho eles aqui. Então é CÓDIGO, DESCRITOR, SABOR, TAMANHO, EMBALAGEM, PRECOLISTA. Depois eu coloco VALUES e os valores que vão ser inseridos, então aqui, por exemplo, eu vou colocar aqui alguns valores, 1040107 é o código de um produto, o descritor do produto por exemplo é Light 350 ml, Melancia é o nome do produto. O sabor é Melancia, o tamanho é 350 ml, a embalagem desse produto é lata e o preço de lista dele é 4.56, ponto e vírgula.

[3:09] Atenção, note todos os campos strings com aspas simples entre eles e o campo numérico sem aspas, e a casa decimal sempre ponto, independentemente se você usa o seu sistema operacional e português ou inglês, sempre usar o ponto. Vou selecionar aqui esse conjunto de dados, na verdade eu vou selecionar tudo e vou rodar. Pronto, inseri um campo.

[3:43] Para a gente conferir se inseriu, nós temos o comando SELECT, asterisco FROM PRODUTO, para a gente poder ver conteúdo da tabela produto se tem esse campo que eu acabei de inserir. Você vai rodar esse comando. É PRODUTOS, desculpe, PRODUTOS, vamos lá de novo. Pronto. Às vezes a gente digita umas coisas, comete uns erros simples que a gente fica meio sem saber o que fazer. Eu digitei produto, executei o comando, vi que deu erro e dei aquela travada de três segundos para poder saber onde é que eu estou errando. O nome da tabela está errado, é PRODUTOS com S. Mas está lá o registro que eu inseri.

[4:43] A gente pode colocar um segundo, então eu vou copiar aqui o comando, vamos colocar um segundo produto, por exemplo 1040108, esse vai ser Light 350 só que esse é Graviola, o sabor é Graviola, o tamanho é 350, lata, só que o preço de lista desse cara é 4. Então se eu rodar agora esse comando, mais uma inclusão. Se eu rodar o SELECT eu agora tenho dois produtos.

[5:26] E aí eu posso dar comando INSERT, INSERT, INSERT, eu vou dando INSERT para cada comando. Mas olha só, eu posso também fazer o seguinte, eu posso omitir esses nomes dos campos, por exemplo e eu vou colocar aqui por exemplo o 1040109, esse vai ser Açaí, o sabor é Açaí, também é 350, lata, só que o preço desse cara é 5.60.

[6:09] Qual é a diferença desse comando para o de cima? Bem, a diferença visual é porque o comando de baixo não tem a lista de campos. Então por que que eu coloco a lista de campos em cima? Bem, o comando sem a lista de campos você só pode usar quando a ordem dos values respeita a ordem dos campos da tabela. Então note que aqui a tabela tem uma ordem natural, então como o primeiro campo é código aqui pode ser código, quando o primeiro campo é descritor aqui pode ser descritor, o terceiro campo é sabor, aqui é sabor. Mas vou rodar aqui, ele entrou.

[7:02] Agora, eu poderia ter o seguinte, se eu fizesse isso aqui, eu troquei a ordem, o sabor está vindo na frente do nome. Se eu rodar isso aqui vai dar problema, porque ele vai colocar no nome do produto o sabor e no nome do sabor o nome do produto. Aí neste caso aqui de baixo eu teria que colocar o nome dos campos só que o campo sabor teria que vir na frente do campo descritor para poder ter a correspondência correta. Eu não vou nem rodar esse comando aqui para não dar problema nos dados, mas deixa eu só antes fechar esse raciocínio.

[8:00] Nome dos campos depois do nome da tabela só devo colocar quando a ordem dos campos em values vier diferente da ordem natural da tabela. Então por padrão a gente sempre coloca, porque aí a gente sabe, colocando o nome do campo a gente vai saber a posição de cada um e vai saber se realmente está cometendo erro ou não. Bem, então esse daqui eu vou apagar porque eu não vou rodar ele.

[8:33] Agora, eu poderia também fazer o seguinte, deixa eu copiar aqui de novo esse comando e eu vou colocar aqui, por exemplo... Não, espera aí. Estava assim, não é? É o 9 que eu coloquei, é o sabor Açaí, 350, o preço, isso aqui, esse aqui já coloquei. Eu vou então fazer o seguinte, eu vou colocar aqui o 110, que agora o 110 o sabor é Jaca. Não, minto, vamos lá, deixa eu voltar aqui que eu troquei, não é? Pronto, o comando é assim, primeiro vem o descritor do produto depois o sabor, foi como eu deixei o script antes de mostrar a vocês o comando da troca, então eu vou agora copiar ele, 110, só que agora o sabor é Jaca e o preço é 6 unidades monetárias.

[10:01] Só que aí eu posso também colocar uma vírgula aqui e repetir o values para outro valor, por exemplo 111. 111 é Manga, então o sabor é Manga, o preço aqui é 3.50 e aqui no final eu boto ponto e vírgula. Então aqui, por exemplo, eu estou inserindo duas linhas ao mesmo tempo, não estou colocando o nome dos campos porque eu estou garantindo que a ordem com que os campos estão vindo esteja igual ao que eu tenho lá depois de produtos. Quer dizer, está vindo igual ao que eu tenho na tabela. E aí quando eu uso o values com vários elementos, eu tenho que manter um critério, ou seja, cada coluna dessa aqui tem que estar igual, correspondente ao mesmo tipo para que eu possa rodar o INSERT com mais de uma linha e aí eu posso ter 10, 20, 15, 30, 60 linhas, posso ter bastante linhas aqui. Com um único comando eu insiro em lotes várias linhas. Vamos rodar aqui? Pronto, inseri os dados dentro da tabela de produtos, então se eu rodar aqui agora o meu SELECT eu tenho lá o 107,108, 109, 100 e 111. Estou com meus dados inseridos dentro da tabela de produtos. É isso aí, gente, valeu.


-----------------------------------------------------------------------
# 03Inclusão de registros na tabela

Inclua os seguintes registros na tabela de clientes:

```yaml
CPF: 1471156710
NOME: Érica Carvalho
ENDEREÇO: R. Iriquitia
BAIRRO: Jardins
CIDADE: São Paulo
ESTADO: SP
CEP: 80012212
DATA DE NASCIMENTO: 01/09/1990
IDADE: 27
SEXO: F
LIMITE DE CRÉDITO: 170000
VOLUME DE COMPRA: 24500
PRIMEIRA COMPRA: Não
```

```yaml
CPF: 19290992743
NOME: Fernando Cavalcante
ENDEREÇO: R. Dois de Fevereiro
BAIRRO: Água Santa
CIDADE: Rio de Janeiro
ESTADO: RJ
CEP: 22000000
DATA DE NASCIMENTO: 12/02/2000
IDADE: 18
SEXO: M
LIMITE DE CRÉDITO: 100000
VOLUME DE COMPRA: 20000
PRIMEIRA COMPRA: Sim
```

```yaml
CPF: 2600586709
NOME: César Teixeira
ENDEREÇO: Rua Conde de Bonfim
BAIRRO: Tijuca
CIDADE: Rio de Janeiro
ESTADO: RJ
CEP: 22020001
DATA DE NASCIMENTO: 12/03/2000
IDADE: 18
SEXO: M
LIMITE DE CREDITO: 120000
VOLUME DE COMPRA: 22000
PRIMEIRA COMPRA: Não
```

-----------------------------------------------------------------------
# 04Incluindo múltiplos registros

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55788

## Transcrição

[0:00] Agora eu vou fazer o seguinte, nós vamos fazer uma importação de dados para tabela de produtos em lote baseado em uma outra tabela de um outro banco de dados.

[0:17] Não se assustem se a resolução do vídeo que vocês estão vendo agora está um pouco menor, as letrinhas ficaram um pouco menores, por que? Porque eu vou mostrar agora como é que eu consigo importar dados de um backup externo para o mysql, e aí eu preciso ter uma tela maior porque na resolução que eu normalmente uso para gravar o vídeo eu não consigo acessar os botões de Ok, de Apply para que o processo de recuperação de base possa funcionar. Por isso antes de gravar esse vídeo eu aumentei um pouco a resolução do meu computador para que eu possa ter acesso a esse botão. Talvez vocês estejam vendo as letrinhas menores, mas depois que eu fizer o processo eu volto ao tamanho normal.

[1:14] Bem, então uma coisa, se vocês já fizeram o curso de Consultas Avançadas de slq usando o mysql e estão usando o mesmo computador para fazer esse treinamento vocês já devem ter na máquina de vocês a base sucos vendas. Se vocês estão usando uma outra máquina para fazer esse treinamento ou começaram a ver mysql através desse curso de primeira vocês não devem ter esse banco sucos vendas disponível.

[1:58] Bem, eu vou precisar desse banco para poder fazer a inclusão em lote. Então vamos fazer o seguinte, se você já tem o banco não precisa fazer nada, se você não tem siga os passos que eu vou fazer agora. Então só para eu poder também não ter eu vou clicar no meu banco e vou apagar ele. Então agora eu não tenho o banco e aí eu vou fazer o seguinte, agora o que eu fizer daqui para frente se você não tem um banco por favor faça.

[2:35] Primeiro lugar, vou dar o botão direito do mouse sobre a área vazia, vou criar em Create Schema e vou criar um banco chamado sucos vendas, atenção tem que ser esse nome senão não vai dar certo, sucos vendas. Coloquei o nome, clico lá embaixo no botão apply, apply de novo, finish e aí eu tenho já o meu banco sucos vendas criado, porém vazio, sem tabela, sem nada.

[3:15] Próximo passo é fazer o download do arquivo **Recuperação Ambiente.zip**. Caso você não tenha feito o download na primeira atividade dessa aula, clique [aqui](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/aula-3-arquivos.zip). Descompacte esse arquivo e aí vocês vão ter uma série de dados como mostrados aqui em cima, mas o mais importante por enquanto é esse diretório aqui, Dump Sucos Vendas.

[3:50] O que nós vamos fazer agora? Voltando ao Workbench vocês vão clicar em Administration aqui embaixo e depois vão clicar em Data Import Restore. E aí eu vou escolher aqui um nome de um diretório dessa opção aqui Import from Dump Project Folder. Eu vou escolher um diretório que é aquele diretório que eu destaquei a vocês que veio do arquivo que eu fiz download depois descompactar esse arquivo. Então eu vou clicar aqui nesses três pontinhos e vou selecionar lá o diretório onde eu salvei o arquivo zipado, o arquivo compactado. Está aqui, selecionei aqui o diretório, dou ok. E aí eu vou clicar nesse botão Start Import.

[4:59] Esse botão Start Import que está aqui embaixo que se eu estivesse com a resolução normal do vídeo para que vocês, a que eu uso normalmente para gravar os treinamentos, eu não conseguiria ver se eu estivesse com a resolução normal, mas como eu diminuí a resolução ou aumentei, não sei como é que fala, eu estou vendo mais pixels. A tela está com a letra menor, mas está com uma expansão maior, aí eu consigo ver o botão start import. Eu vou clicar nele e aí eu estou recuperando a base sucos vendas.

[5:42] Bem, a importação terminou. Já que a importação terminou eu agora vou voltar a usar aqui a resolução que eu uso normalmente para gravar os vídeos dos treinamentos que é o 1280 por 720, agora eu volto aqui para o tamanho normal para poder continuar com o trabalho aqui desse vídeo.

[6:10] Se eu voltar aqui em Schemas, dei aqui um Refresh, eu vou ter a base sucos vendas com as tabelas aqui carregadas. Esse banco na verdade é praticamente um espelho do banco que nós criamos, só que tem nome de campos talvez diferentes, nomes de tabelas diferentes, não importa, é até bom que sejam diferentes.

[6:37] Nós vamos fazer o seguinte, eu vou colocar dados na tabela de produtos baseado nos dados existentes nesta tabela de produtos, ou seja, esse banco que eu restaurei vai ser fonte para eu colocar dados no banco que eu estou trabalhando. Isso dentro de uma empresa é muito normal, às vezes eu estou criando um banco de dados e eu quero importar estes dados de um outro lugar. Aqui no caso eu vou importar de um outro banco mysql. Então a gente vai ver como é que a gente faz isso.

[7:18] Vou fazer o seguinte então, eu vou criar aqui um novo script vamos sempre indo para o vendas sucos. Atenção, não vamos confundir agora os nomes, tem um banco que se chama vendas sucos e o outro que se chama sucos vendas. Na verdade o vendas sucos, ou seja, vendas na frente é o banco que nós estamos trabalhando nesse treinamento, e o sucos vendas vai ser o banco fonte.

[7:50] Então eu fui para o banco que nós estamos trabalhando, o vendas sucos. Dentro dele eu posso fazer um SELECT para olhar o conteúdo de uma tabela de um outro banco sem sair do banco que eu estou. Eu faço assim, SELECT asterisco FROM o nome da outra base é sucos vendas, então eu coloco aqui sucos vendas ponto e aí eu tenho a tabela de produtos do banco origem, tabela de produtos. Se eu fizer isso aqui eu estou rodando lá os dados, e note que eu tenho na tabela da fonte, código, descritor, embalagem, o nome dos campos é que não está muito igual.

[8:51] Se a gente olhar aqui na tabela de produtos, a gente vai ver, por exemplo, as seguintes diferenças, na nossa tabela código lá na fonte é código do produto. O descritor na nossa tabela é nome do produto, lá na tabela fonte, embalagem, tamanho e sabor está igual, só preço lista que está aqui preço lista que na tabela fonte chama-se preço de lista.

[9:30] Então eu vou fazer o seguinte, como eu já sei como a maioria dos alunos já fez o curso de Consultas Avançadas eu posso fazer uma consulta se SELECT colocando ALIAS, lembra o que que é o ALIAS? É um apelido que eu dou para o campo original, e eu vou dar como ALIAS, como apelido, os nomes dos campos da minha tabela destino, ou seja, dessa tabela onde eu quero gravar os dados.

[9:59] Então vai ser assim, SELECT CODIGO DO PRODUTO AS CODIGO. Ou seja, originalmente é código do produto, mas eu quero que se chame código, então fiz isso daqui, vírgula NOME DO PRODUTO AS DESCRITOR, vírgula, EMBALAGEM não muda, TAMANHO também não precisa de ALIAS porque o nome do campo está igual, SABOR idem, agora PREÇO DE LISTA vai ter como ALIAS PRECO LISTA FROM aí vou repetir aqui o nome da tabela com o nome do database na frente porque lembra, o meu foco nesse script é o meu banco de dados destino. Então se eu rodar aqui eu tenho os meus dados já com os nomes aqui dos ALIAS igualzinho como eu vou ter na tabela final.

[11:22] Para a gente evitar problema de não incluir caras que já existam, se eu der aqui um SELECT FROM a tabela VENDAS SUCOS, lembrando, agora essa tabela aqui é a tabela do meu banco que eu estou trabalhando. Note que eu tenho aqui, vamos lá de novo, o que houve aqui? Não, é produtos, desculpe. É produtos, VENDAS SUCOS é o nome do banco. Produtos. Quando eu me refiro à outra tabela tem que colocar o nome do banco na frente porque o meu foco está sendo na base vendas sucos, então dei um vacilo aqui, vocês me desculpem, vamos lá.

[12:23] Então eu tenho lá cinco produtos. Eu não quero que na seleção daqui já venha produtos que eu já tenha a tabela aqui, então eu posso colocar isso daqui, WHERE, isso aqui inclusive a gente viu lá no curso de Consultas Avançadas, WHERE CODIGO DO PRODUTO NOT IN, e aqui dentro eu coloco SELECT CODIGO FROM produtos. Então olha o que eu fiz aqui, eu fiz até aqui a seleção da tabela da base fonte já colocando os ALIAS e eu só estou pegando o pessoal que está vindo lá do fonte que não exista na tabela produtos que a tabela que eu vou gravar. Então se eu já tiver um cara lá na tabela fonte que já foi gravada na minha tabela destino ele não vai aparecer nessa consulta. Vamos rodar ela aqui. Eu garanto que nessa lista aqui eu só tenha produtos novos, produtos que não foram incluídos na tabela de produtos do meu banco.

[13:51] Aí agora eu vou fazer isso daqui, agora vamos fazer o INSERT finalmente. INSERT INTO produtos, e aí depois do INSERT INTO eu coloco esse SELECT. Antes de rodar, atenção, lembra que eu falei para vocês, eu estou omitindo aqui o nome dos campos, eu não estou colocando aqui o nome dos campos, então para isso funcionar direito a ordem com que os campos estão aparecendo no SELECT tem que ser a mesma ordem que estão na tabela. Então olha lá, tem um problema. O terceiro campo da tabela é SABOR, o quarto é TAMANHO e o quinto é EMBALAGEM.

[14:47] Então eu vou fazer o seguinte, na verdade SABOR tem que vir na frente, depois TAMANHO e aí por último embalagem. Então agora sim, CODIGO, DESCRITOR, depois SABOR, TAMANHO, EMBALAGEM, PREÇO LISTA. Os ALIAS iguaizinhos ao nome das colunas da tabela destino, a ordem igualzinha a ordem que eu tenho na tabela destino. CODIGO CODIGO, DESCRITOR DESCRITOR, SABOR SABOR, TAMANHO TAMANHO, EMBALAGEM EMBALAGEM, PREÇO LISTA PREÇO LISTA. Agora sim, eu vou selecionar tudo isso e vou rodar. Ele executou.

[15:53] E agora vamos fazer o seguinte, eu vou dar um SELECT asterisco FROM PRODUTOS. Vamos ver agora quantos produtos eu tenho? Tenho vários produtos inseridos na minha tabela.

[16:15] Então assim, esse trabalho todo foi para mostrar a vocês que eu posso inserir dados dentro de uma tabela baseado em uma consulta que eu esteja fazendo. Pode ser no mesmo banco, pode ser em um banco diferente. Aqui no caso, eu fiz vindo de um banco diferente.

[16:37] Bem gente, esse vídeo deve ter sido um pouquinho complicado, mas eu tentei explicar de maneira bem pausada como é que a gente faz esses INSERTS. Se tiverem dúvidas consultem o passo a passo onde eu vou explicar melhor isso ou então vocês revejam mais uma vez o vídeo que eu gravei para poder entender como é que a gente faz esse INSERT usando o SELECT e os cuidados que a gente tem que tomar. Valeu gente, um abraço.

-----------------------------------------------------------------------
# 06Incluindo através do assistente

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55789

## Transcrição

[0:00] O workbench do MySQL também oferece uma interface de edição direto dos dados da tabela.

[0:10] Quer ver?

[0:11] Vamos fazer o seguinte.

[0:13] Vou criar aqui um novo script, vou me certificar que eu estou na tabela, no banco vendas sucos, e eu vou dar aqui select asterisco from cliente.

[0:32] Eu tenho a tabela vazia, porque a tabela de clientes não tem dado nenhum, e aqui do lado eu tenho essa opção aqui: form edictor.

[0:44] Ao clicar em form edictor, eu vou até aumentar um pouquinho aqui a área, eu tenho aqui um formulário onde eu posso entrar manualmente com dado.

[0:56] Então, por exemplo, vou botar aqui o CPF de um cliente.

[0:59] 1471156710, nome, por exemplo, Érica Carvalho, o endereço da Érica é a rua, vou botar aqui rua Iriquiti, o bairro Jardins, a cidade São Paulo, o estado SP, o CEP 80012212, data de nascimento 1999-09-01, note, como eu estou editando direto com a tabela, eu tenho que digitar a data de nascimento no formato que o MySQL entende.

[2:11] E para eu inserir dados do MySQL eu tenho que colocar ano, traço, o mês, traço, o dia, com o mês e o dia com dois dígitos, do jeito que está aqui.

[2:26] A idade 27, sexo F, vamos lá. O limite de crédito dela é 170 mil, o volume de compra mensal que ela pode fazer é 245000 litros, e fez a primeira compra 0, porque é falso.

[2:56] Ou seja, o que eu estou colocando nesse formulário seria o que estaria dentro do values do insert.

[3:08] Não tem muita praticidade, claro, a gente colocar esse, como eu posso dizer, usar esse formulário para inserir muitos dados.

[3:20] É melhor você fazer um sistema específico para isso, mas para, por exemplo, pontualmente fazer a inclusão de um cliente específico é muito bom.

[3:32] Eu vou clicar o apply, aí note, ao clicar apply ele me escreveu o comando.

[3:42] O comando insert.

[3:45] Vou dar um apply, finish.

[3:50] Se eu clicar agora de novo em result grid, note que ele já até me escreveu o campo aqui.

[4:03] Então eu tenho no workbench uma maneira de estar incluindo dados de maneira manual.

[4:13] Como a gente precisa popular as tabelas do nosso banco com dados, nós vamos repetir o que fizemos no vídeo passado, agora com a tabela de clientes.

[4:23] É até uma forma de a gente poder fixar bem o que a gente fez, que é a inclusão em lote.

[4:30] Então, relembrando, a gente vai agora pegar aqui na tabela sucos vendas, vou vir aqui select, asterisco from sucos vendas ponto tabela de clientes.

[4:51] Vamos ver como é que está o nome dos campos.

[4:56] Está CPF, nome, endereço traço um, endereço traço um vazio, bairro, cidade, os campos estão assim.

[5:05] Então vamos agora olhar os campos da tabela destino, que agora é a tabela de clientes e ir fazendo passo a passo.

[5:13] É select, CPF, é CPF mesmo.

[5:21] Nome, nome mesmo.

[5:23] O endereço traço um vai virar endereço.

[5:36] Bairro é bairro.

[5:39] Cidade também não muda.

[5:41] Estado também não, vamos lá.

[5:47] CEP igual.

[5:52] Data, olha só, na nossa tabela é data nascimento, na tabela lá de origem é data de nascimento, então a gente vai colocar data de nascimento AS data nascimento.

[6:14] Idade não muda, sexo também não, limite crédito é na tabela destine, limite de crédito é na tabela origem.

[6:25] Então limite de crédito AS limite crédito.

[6:33] Vamos continuar, volume de compra é a mesma coisa.

[6:37] Volume de compra é na origem, volume compra é no destino.

[6:42] Volume de compra AS volume compra.

[6:51] Primeira compra está igual, primeira compra, primeira compra.

[7:01] From a tabela origem.

[7:08] Vamos só rodar para ver se não tem erro.

[7:09] Está lá, veio com o nome das colunas iguaizinhas à tabela destino.

[7:16] Lembrando que a gente já inclui um cara na nossa tabela de clientes, que é esse CPF aqui, então eu vou colocar aqui where CPF note in select CPF from cliente.

[7:41] Vamos ver se funciona, rodou.

[7:46] Então esse select todo aqui eu vou botar insert into clientes, e aí eu coloco o select completo.

[7:59] Vamos rodar.

[8:01] Eu estou na base vendas sucos, ok?

[8:05] Eu estou na base vendas sucos.

[8:10] Até para garantir vamos botar nesse script aqui isso daqui, use vendas sucos, apesar que eu não vou usar, eu não vou rodar esse comando mais.

[8:22] Já vou rodar esse aqui direto porque eu já sei que eu já estou no vendas sucos.

[8:33] Ok, rodei, agora se eu vier aqui e der um select asterisco from clientes, tenho já todos os clientes inseridos na minha tabela.

[8:48] Então nesse vídeo eu quis mostrar para vocês o formulário só para dizer que realmente tem um jeito de você colocar o dado de maneira mais amigável direto através do workbench, só que eu pessoalmente não considero muito prático.

[9:02] E aí, para a gente poder continuar com os próximos exemplos, a gente teve que fazer um insert em lote pegando lá da tabela fonte os dados de clientes e jogando para o nosso banco, tá legal?

[9:17] Então é isso aí, gente, valeu.


-----------------------------------------------------------------------
# 07Usando importação de dados de arquivos externos

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55790

## Transcrição

[0:00] Vamos continuar estudando?

[0:02] Então agora nós vamos ler dados para uma tabela do MySQL através de um arquivo externo.

[0:11] Então primeiro nós vamos baixar o arquivo externo que nós vamos baixar como fonte. Caso você não tenha feito o download na primeira atividade dessa aula, clique [aqui](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/aula-3-arquivos.zip).

[0:20] Baixa esse arquivo, descompacta na máquina local de vocês, e vocês vão encontrar esses dois arquivos aqui.

[0:28] Nós vamos inicialmente trabalhar com arquivos vendedores.csv.

[0:35] Vamos abrir esse arquivo com um editor de texto.

[0:42] Então eu vou usar aqui o bloco de notas, e aí eu tenho aqui uma primeira linha, onde eu tenho o nome das colunas separados por ponto e vírgula. Tenho aqui uma informação importante, os valores decimais, um ponto com separador de decimal, e as datas, elas estão sendo representadas desta maneira: ano, traço mês, traço dia, e a hora, eu coloquei zero zero, zero zero, zero zero, significa uma hora neutra.

[1:21] Ou seja, está dizendo que o timestamp desse campo, a hora é meia noite.

[1:26] Mas aí quando a gente coloca zero zero, zero zero, zero zero, normalmente nós estamos considerando uma hora neutra.

[1:34] O nome desses campos aqui, serão depois mapeados com os nomes dos campos das tabelas, e é claro que se no meu arquivo CSV o nome do campo já tiver uma coincidência com o nome dos campos das tabelas, fica mais fácil o nosso mapeamento.

[1:54] Então ok, analisamos o conteúdo do nosso arquivo, e vou voltar aqui para o Workbench, e vou clicar aqui sobre a tabela vendedores.

[2:04] É esta a tabela que nós vamos popular com dados vindos do arquivo csv.

[2:11] Eu ou dar botão direito do mouse sobre a tabela vendedores, e vou selecionar a opção table data import wizard.

[2:27] Ao fazer isso, eu vou clicar aqui em Browse, e vou selecionar aquele meu arquivo, que eu baixei.

[2:36] Então eu clico aqui em vendedores, vou em abrir, e dou um next.

[2:42] Agora ele vai me dizer, eu vou criar isso, eu vou popular esses dados numa nova tabela, ou numa tabela já existente? No caso, eu já vou usar uma tabela existente, que é a de vendedores, que está no banco de dados vendas underscore sucos.

[3:00] E essa opção truncate, significa o seguinte: se eu quero apagar tudo o que eu tenho na tabela antes de incluir dados.

[3:09] No nosso caso, nós não vamos apagar, então essa opção não estará selecionada.

[3:17] Aqui ele me mostra o mapeamento. Se eventualmente você tiver problemas na hora de abrir essa tela, vocês selecionem o encode utf-8, que é o encode compatível com o arquivo que vocês baixaram.

[3:35] Mesmo assim, se ainda houver problema, tente algumas outras dessas opções existentes aqui dentro do Workbench, até você conseguir olhar os campos.

[3:48] Então eu tenho aqui embaixo um preview do que vai ser lido, um mapeamento, então aqui eu tenho o nome das colunas que vieram do csv, e aqui do lado, o nome dos campos que eu tenho na tabela.

[4:06] Como os nomes já eram coincidentes, ele já fez o mapeamento automático, mas eu poderia vir aqui, e ir selecionando quem é que corresponde a cada coluna.

[4:22] Parece que não, mas aqui embaixo, tem ainda o bairro, tem um pouquinho escondido.

[4:28] Vamos fazer outra coisa, porque isso vai ser importante para os exercícios posteriores. Vamos desmarcar o campo férias. Ou seja, eu não vou ler este campo.

[4:43] Desmarquei o campo férias, eu vou dar um next, dou um next novamente, e dou novamente o next.

[4:53] Então pronto, eu tenho a mensagem de que quatro registros foram importados com sucesso.

[5:01] Se eu der um finish, eu agora venho aqui na tabela de vendedores, se eu der um select asterisco from vendedores, e executar esse comando, note que eu tenho aqui os meus quatro vendedores que vieram do arquivo externo.

[5:23] A única diferença é que o campo férias veio todo vazio, porque esse campo férias eu vou colocar as informações dos vendedores depois posteriormente, quando a gente for evoluindo com os vídeos desse treinamento.

[5:40] Então eu mostrei para vocês como é que a gente faz uma carga de dados através de um arquivo externo, tá bom? Valeu, um abraço.


-----------------------------------------------------------------------
# 09Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Vamos criar um novo script SQL no Workbench.

2) Iremos inserir um novo produto. Digite:

```sql
USE vendas_sucos;


INSERT INTO PRODUTOS (CODIGO, DESCRITOR, SABOR, TAMANHO, EMBALAGEM, PRECO_LISTA)

VALUES ('1040107', 'Light - 350 ml - Melância', 'Melância', '350 ml', 'Lata', 4.56);
```

1) Vamos conferir se o produto foi realmente incluido na tabela. Digite e execute:

```sql
SELECT * FROM PRODUTOS;
```

![1.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/1.png)

2) No script podemos incluir mais de um comando. Digite e execute:

```sql
INSERT INTO PRODUTOS (CODIGO, DESCRITOR, SABOR, TAMANHO, EMBALAGEM, PRECO_LISTA)

VALUES ('1040108', 'Light - 350 ml - Graviola', 'Graviola', '350 ml', 'Lata', 4.00);

INSERT INTO PRODUTOS

VALUES ('1040109', 'Light - 350 ml - Açai', 'Açai', '350 ml', 'Lata', 5.60);
```

3) Também podemos incluir, num mesmo comando, a inclusão de mais de um registro. Digite e execute:

```sql
INSERT INTO PRODUTOS

VALUES ('1040110', 'Light - 350 ml - Jaca', 'Jaca', '350 ml', 'Lata', 6.00),

       ('1040111', 'Light - 350 ml - Manga', 'Manga', '350 ml', 'Lata', 3.50);
```

4) Faça Download do arquivo RecuperacaoAmbiente.zip.

5) Descompacte o arquivo.

6) Selecione, na área Navigator, em Administration.

7) Selecione o link Data Import/Restore.

8) Na opção Import From Dump Project Folder escolha o diretório DumpSucosVendas.

9) Selecione Start Import.

10) Verifique na base Sucos_Vendas se as tabelas foram criadas.

11) Podemos, da base Vendas_Sucos, acessar tabelas da base Sucos_Vendas.

```sql
USE vendas_sucos;

SELECT * FROM sucos_vendas.tabela_de_produtos;
```

![2.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/2.png)

12) A consulta, a seguir, mostra a lista de produtos, na tabela tabela_de_produtos, da base sucos_vendas que ainda não foram incluídas na tabela produtos, da base vendas_sucos:

```vbnet
SELECT CODIGO_DO_PRODUTO AS CODIGO, NOME_DO_PRODUTO AS DESCRITOR,

EMBALAGEM, TAMANHO, SABOR, PRECO_DE_LISTA AS PRECO_LISTA

FROM sucos_vendas.tabela_de_produtos

WHERE CODIGO_DO_PRODUTO NOT IN (SELECT CODIGO FROM produtos);
```

![3.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/3.png)

13) No comando INSERT podemos incluir os produtos na tabela sucos_vendas.tabela_de_produtos na tabela vendas_sucos.produtos. Digite e execute:

```vbnet
INSERT INTO produtos

SELECT CODIGO_DO_PRODUTO AS CODIGO, NOME_DO_PRODUTO AS DESCRITOR,

SABOR, TAMANHO, EMBALAGEM,  PRECO_DE_LISTA AS PRECO_LISTA

FROM sucos_vendas.tabela_de_produtos

WHERE CODIGO_DO_PRODUTO NOT IN (SELECT CODIGO FROM produtos);
```

14) Vamos conferir a tabela de produtos. Digite e execute:

```sql
SELECT * FROM produtos;
```

![4.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/4.png)

15) Mostraremos como incluir dados na tabela de cliente. Digite e execute:

```sql
SELECT * FROM clientes;
```

![5.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/5.png)

16) Ao lado temos o botão Form Editor:

![6.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/6.png)

Teremos uma caixa de diálogo para editar a tabela de Clientes.

![7.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/7.png)

17) Inclua um novo cliente:

- CPF: 1471156710;
- NOME: Érica Carvalho;
- ENDERECO: R. Iriquiti;
- BAIRRO: Jardins;
- CIDADE: São Paulo;
- ESTADO: SP;
- CEP: 80012212;
- DATA_NASCIMENTO: 1999-09-01;
- IDADE: 27;
- SEXO: F;
- LIMITE_CREDITO: 170000;
- VOLUME_COMPRA: 24500;
- PRIMEIRA_COMPRA: 0;

18) Confirme a inclusão. O comando será apresentado e confirme a execução.

19) Execute a consulta novamente. Digite e execute:

```sql
SELECT * FROM clientes;
```

![8.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/8.png)

O cliente foi incluido.

20) Vamos incluir os clientes usando como fonte o outro banco de dados. Digite e execute:

```vbnet
INSERT INTO CLIENTES

SELECT CPF, NOME, ENDERECO_1 AS ENDERECO, BAIRRO, CIDADE, ESTADO, CEP,

DATA_DE_NASCIMENTO AS DATA_NASCIMENTO, IDADE, SEXO, LIMITE_DE_CREDITO AS LIMITE_CREDITO,

VOLUME_DE_COMPRA AS VOLUME_COMPRA, PRIMEIRA_COMPRA

FROM sucos_vendas.tabela_de_clientes WHERE CPF

NOT IN (SELECT CPF FROM CLIENTES);
```

21) Teste o conteúdo da tabela de clientes:

```sql
SELECT * FROM CLIENTES;
```

![9.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/9.png)

22) Vamos mostrar agora como incluir dados na tabela de vendedores através de arquivos externos. Descompacte o arquivo contido no link desta aula e iremos usar a tabela Vendedores.csv. como fonte.

23) Botão da direita do mouse sobre a tabela Vendedores e escolha a opção Table Data Import Wizard.

![10.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/10.png)

24) Em File Path selecione o arquivo Vendedores.csv.

25) Mantenha os dados padrões como mostrado abaixo:

![11.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/11.png)

26) Observação: Se você visualizar um erro como mostrado abaixo:

![12.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/12.png)

Há erro na interpretação da tabela através da lista de caracteres. Para isso faça:

- Abra o arquivo com Notepad clássico;
- Clique arquivo / Salvar como.
- Escolha o padrão ANSI:

![13.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/13.png)

Volte a caixa de diálogo e escolha:

![14.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/14.png)

Pode existir problemas entre computadores e entre os arquivos baixados. Você deve ver a combinação correta entre o formato do arquivo (Que pode ser modificado no NOTEPAD clássico) e na caixa de diálogo de importação de dados.

![15.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/15.png)

27) Desmarque a opção FERIAS:

![16.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/16.png)

28) Clique em Next várias vezes até os dados serem incluídos na tabela de vendedores.

29) Verifique o conteúdo da tabela de vendedores.

```sql
SELECT * FROM VENDEDORES;
```

![17.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/03/17.png)



-----------------------------------------------------------------------
# 10O que aprendemos?

Nesta aula, aprendemos:

- Aprendemos a incluir dados em uma tabela, através de comando;
- Vimos a inclusão de vários registros em um único comando;
- Foi mostrado como incluir dados na tabela através de um assistente;
- Mostramos como incluir dados usando um arquivo externo.


-----------------------------------------------------------------------
# 01Alterando dados da tabela

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55791

## Transcrição

[0:00] Bem, vamos continuar?

[0:01] A gente até agora então aprendeu a incluir dados dentro das nossas tabelas, seja por um comando insert simples, um comando insert composto, seja por um comando select vindo de uma outra base de dados e um arquivo externo.

[0:18] Agora com dados dentro do nosso banco em alguns momentos a gente também quer modificar esses dados.

[0:26] Então nós vamos aprender agora a usar o comando update.

[0:30] O comando update modifica um dado já existente, e basicamente a gente dá update, o nome da tabela, o conjunto de campos que serão modificados com os seus novos valores e uma condição de filtro.

[0:47] Essa condição de filtro é a semelhante usada quando a gente faz uma seleção de dados da tabela.

[0:54] Então talvez esse slide deixe um pouquinho mais claro, ou seja, update, o nome da tabela Sete, o nome do campo igual ao seu novo valor, e aí virgula, outro nome de campo igual ao novo valor e assim por diante, e uma condição.

[1:16] Vamos fazer isso na prática lá no nosso banco de trabalho.

[1:22] Então eu vou voltar aqui para o workbench, vou criar aqui um script novo e eu vou dar uma olhada aqui na minha tabela de produtos.

[1:38] Tenho aqui os meus dados da minha tabela de produtos, e aí eu posso, por exemplo, mudar o preço de lista de um produto.

[1:50] Vamos pegar esse produto aqui, esse produto que o código, deixa eu fazer de novo, o código é 1889, cujo preço de lista está bem aqui na pontinha, mas dá para notar que é seis ponto trinta.

[2:08] Nós vamos mudar esse código aqui, então vou fazer assim: update, o nome da tabela que eu vou modificar, produtos Sete; o nome do campo que será modificado, então no caso precolista; o novo valor, então esse cara vai ter valor Cinco; o where, a condição.

[2:32] Em que campos que essa modificação será feita.

[2:35] No caso, será em código igual ao número 1000889.

[2:44] Finalizando com ponto e vírgula.

[2:47] Vou selecionar aqui esse comando e vou executar.

[2:51] Executado com sucesso, se eu executar de novo o meu select note que agora campo 1889, o preço de lista não é mais o seis ponto trinta e sim o cinco, que foi o que eu fiz no comando.

[3:11] Posso também não somente mudar valores, posso também mudar uma outra propriedade.

[3:19] No caso aqui, nosso produto sabor da montanha 700 uva, digamos que eu queria mudar a embalagem.

[3:30] Em vez de garrafa, ele vai ser pet.

[3:33] Vai ser meio coerente, que normalmente pet é acima de um litro, e se eu modificar esse cara eu teria que teoricamente também modificar o tamanho, e para modificar o tamanho eu também teria que modificar o nome do produto.

[3:54] Então vamos fazer essas modificações todas.

[3:58] Update, produtos Sete.

[4:03] Primeiro, a embalagem, que é garrafa, vai virar pet, a embalagem igual a pet.

[4:18] Aí eu quero modificar outros campos, então coloco uma vírgula.

[4:22] O campo que eu vou mudar, o tamanho vai ser um litro.

[4:32] Vírgula, e aí eu tenho que modificar o nome também, então o descritor vai ser igual, eu vou continuar aqui embaixo, sabor da montanha um litro uva.

[4:58] É um aqui.

[5:01] Um litro uva.

[5:05] O where, a mesma condição.

[5:08] Código igual a 100889.

[5:16] Ok?

[5:17] Então note que agora o meu comando update está modificando ao mesmo tempo diversos campos.

[5:26] Vamos rodar.

[5:28] Rodou com sucesso, se eu fizer o meu select nome que agora o meu sabor da montanha é um litro, está aqui um litro, e ele é pet.

[5:40] O preço continua cinco porque eu não mudei nada.

[5:48] Bem, eu posso fazer uma modificação em lote ao mesmo tempo em vários registros, e isso somente depende do tipo de filtro que eu vou usar no where, então por exemplo, se eu fizer um select asterisco from produtos where sabor igual a maracujá, vamos ver quantos produtos eu tenho sabor maracujá.

[6:24] Eu tenho dois produtos.

[6:29] Então eu posso, por exemplo, digamos o seguinte, a minha área de negócios disse para mim, que sou da área de tecnologia: "Precisamos aumentar em 10% os preços de lista dos produtos sabor maracujá porque a matéria-prima ficou mais cara, então foi uma decisão estratégica da empresa".

[6:54] Então eu não vou ter que fazer o update para o código igual a 243083 e para o código 723457.

[7:06] Eu posso fazer assim: update, produtos, Sete.

[7:15] O precolista vai ser igual o próprio precolista vez um ponto dez.

[7:23] Isso aqui eu estou pegando o valor atual e aumentando 10%.

[7:31] E aí eu posso colocar where sabor igual a maracujá, então ao colocar esta condição aqui, eu vou aplicar esta modificação a todo mundo que tem sabor maracujá.

[7:52] Que no caso, são dois produtos, então somente nesses dois produtos que o preço de lista vai aumentar em 10%.

[8:01] Eu faço seleção, executo, rodado com sucesso; se eu agora fizer o select de novo, esse preço aqui já foi aumentado em 10% do que estava anteriormente.

[8:16] Então é isso aí, eu posso fazer o update para um ou para um conjunto de campos.

[8:23] Posso fazer a modificação para um campo apenas, modificar apenas o valor de um campo, ou para vários campos separados por vírgula.

[8:33] Então é isso aí, gente, valeu.

-----------------------------------------------------------------------
# 03Usando UPDATE com FROM

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55792

## Transcrição

[0:00] A gente pode também fazer o update através de um comando select.

[0:07] Deixa eu mostrar para vocês o problema que eu tenho que resolver.

[0:10] Nós temos aqui no nosso ambiente dois bancos de dados.

[0:15] Nós temos o venda sucos, que é o banco que nós estamos construindo e inserindo e alterando dados; e nós temos o banco suco vendas, que é um banco de dados de fonte.

[0:28] Vamos fazer o seguinte: mantendo o venda sucos selecionado, ou seja, venda sucos tem que estar em negrito, nós vamos criar aqui um novo script e eu vou fazer dois selects.

[0:40] Eu vou fazer um select, uma tabela de vendedores, da base venda sucos, que é a base que eu estou trabalhando; e eu vou fazer ao mesmo tempo um select da tabela sucos vendas ponto tabela de vendedores.

[1:07] Deixa eu só me certificar para saber se esse nome, tabela de vendedores. Ok.

[1:12] Eu seleciono esses dois selects e eu posso rodá-los.

[1:16] Então, eu tenho aqui na tabela fonte, a tabela de vendedores, eu tenho o campo de férias, com valores; e na tabela do meu banco, o campo férias.

[1:35] Inclusive, o nome do campo é outro.

[1:37] Férias está vazio.

[1:39] O que eu quero fazer é pegar o campo de férias da tabela de vendedores e colocar esses valores, alterar os valores do campo férias da tabela de vendedores com aqueles valores da base fonte.

[1:56] Ficou um pouco complicado?

[1:58] Vamos tentar mostrar isso melhor no desenvolvimento desse update.

[2:03] Então, para primeiro a gente entender, eu vou fazer um select juntando essas duas tabelas.

[2:12] Então, eu vou fazer o seguinte: vou colocar aqui um select asterisco from.

[2:19] Vou pegar a tabela de vendedores, eu vou chamar ela de A.

[2:25] A.

[2:30] Vamos fazer assim.

[2:32] Pronto.

[2:34] Inner join com esta tabela lá do outro banco.

[2:41] B.

[2:42] Qual é o campo em comum das duas? É o campo matrícula.

[2:47] Note que na tabela de vendedores eu tenho o campo matrícula aqui e na tabela de vendedores do outro banco eu tenho o campo matrícula aqui.

[2:56] Só que o campo matrícula da tabela de vendedores da fonte tem uma diferença.

[3:02] Tem esses dois zeros aqui que ele tem que ser tirado na hora que eu for fazer o join, e aí a função que eu uso é a função substring.

[3:16] Quem fez o curso Consultas Avançadas vai lembrar dessa função.

[3:20] Então, eu faço assim.

[3:22] On A ponto matrícula igual a substring de B ponto matrícula três de três.

[3:34] Por que três de três?

[3:37] Que eu estou pegando a partir do terceiro caracter, que é o 2. No caso ali, naquela linha que está destacada, onde está zero zero dois três cinco.

[3:48] O elemento três, que é o elemento inicial da função, é o 2.

[3:53] E eu pego os próximos três, ou seja, eu vou pegar o 2, o 3 e o 5.

[4:00] Três.

[4:03] Vamos rodar essa consulta aqui.

[4:07] Então, eu tenho lá, olha lá.

[4:10] Até aqui são os campos da minha tabela.

[4:15] E depois do lado, os campos da outra tabela.

[4:19] Note que há uma correspondência entre o férias do meu campo, da minha tabela, que está nulo, com o de férias que está aqui.

[4:28] Então, eu quero que esse valor aqui, por exemplo, seja gravado aqui.

[4:33] Que esse valor da segunda linha seja gravado aqui na segunda linha.

[4:39] Que o valor da terceira linha seja gravado na terceira linha.

[4:42] E assim por diante.

[4:44] Como é que fazemos isso?

[4:46] Fazemos assim.

[4:49] Eu pego update, o nome da tabela que eu quero modificar, vendedores, que é a tabela A, e aí eu aplico aqui o inner join, ou seja, esse comando todo aqui.

[5:07] Update a tabela, inner join com outra tabela ou campo e aí aqui embaixo, eu coloco meu set.

[5:18] Quem é que vai ser modificado?

[5:20] Esse campo aqui que vai receber.

[5:23] É o campo férias.

[5:25] O campo férias está na tabela A.

[5:27] A ponto férias recebe o valor de quem?

[5:32] Do campo de férias, que está na tabela B.

[5:37] B ponto de férias.

[5:44] Vamos rodar esse comando update.

[5:48] Rodou com sucesso.

[5:49] Agora eu vou rodar de novo esse meu select aqui que juntava as duas tabelas.

[5:56] Note que agora o campo férias, que estava nulo, tem os mesmos valores que estavam aqui.

[6:08] Então, através de um select pegando dados de uma outra tabela, eu alterei os campos da minha tabela.

[6:18] Um caso prático para isso seria, por exemplo, eu tenho uma tabela master que tem os preços de lista de cada produto e aí eu quero transferir isso para a minha tabela do meu banco de dados, fazendo uma sincronização entre os dois bancos.

[6:40] Então, esse update, rodando ele periodicamente, eu posso fazer essa sincronização.

[6:46] Foi o que eu fiz aqui. Eu sincronizei o campo férias da minha tabela vendedores com o campo de férias da tabela de vendedores do banco fonte.

[7:00] Então tá, gente. Era isso aí que eu queria mostrar a vocês.


-----------------------------------------------------------------------
# 04Mudando o volume de compra dos clientes que possuem vendedores em seus bairros

Podemos observar que os vendedores possuem bairro associados a eles. Vamos aumentar em 30% o volume de compra dos clientes que possuem, em seus endereços bairros onde os vendedores possuam escritórios.

Dica: Vamos usar um **UPDATE** com **FROM** usando o seguinte **INNER JOIN**:

```sql
SELECT A.CPF FROM CLIENTES A
INNER JOIN VENDEDORES B
ON A.BAIRRO = B.BAIRRO
```

-----------------------------------------------------------------------
# 05Excluir dados da tabela

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55793


## Transcrição

[0:00] Vamos continuar estudando?

[0:01] A gente já aprendeu então a incluir, a alterar, e agora a gente precisa aprender a excluir dados de uma tabela do banco de dados de uma SQL.

[0:12] E o comando para fazer isso é o comando Delete.

[0:16] Aqui em cima está a sintaxe mais complexa do comando Delete, mas a gente pode reduzir essa sintaxe a, simplesmente, isto aqui:

[0:29] DELETE ; WHERE (<Condição>), que vai fazer com que eu selecione quem eu quero excluir daquela minha tabela.

[0:42] Vamos fazer alguns exemplos práticos? Diferenciados para podermos mostrar a vocês como conseguimos excluir dados de uma tabela.

[0:52] Mas, antes disso, façam o seguinte: faça o [download desse ZIP](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/04/inclusao-registros.zip), descompacte-o e então nós vamos abrir com um editor de texto o arquivo **Inclusão de Registros.sql**.

[1:13] Abrir com um editor de texto, OK?

[1:18] Eu vou usar aqui o Notepad ++, mas pode ser o Notepad normal.

[1:22] Eu vou copiar esse conjunto de comandos aqui, que farão inclusão de novos produtos na tabela de produtos, tudo bem?

[1:33] Eu vou copiar, vou no meu Workbench, vou criar um Script novo e vou colar.

[1:41] Certifico-me de que estou olhando a base Vendas_Sucos e vou executar esse comando INSERT.

[1:50] Pronto. Eu inseri uma série de produtos novos.

[1:55] Voltando aqui ao arquivo que nós abrimos; se eu agora executar esse comando SELECT aqui, ele vai me mostrar todos os produtos que têm o nome Sabor dos Alpes.

[2:11] Então eu tenho aqui na minha tabela de produtos, no banco Vendas_Sucos, uma série de produtos novos, OK?

[2:22] Bem, fizemos isso porque, claro, iremos excluí-los.

[2:29] Para excluir um produto específico basta colocarmos a condição. Então seria:

[2:33] "Delete From Produtos Where Codigo =" a por exemplo: "1001000".

[2:55] Então eu vou excluir este produto aqui, olhe. Eu coloquei a condição; se eu fizer isso, ele diz lá que uma linha foi afetada, se eu agora fizer a seleção de novo, note que o produto cem mil 1001000 não existe mais na lista.

[3:18] Mas isso foi uma exclusão simples. Eu posso fazer isso também, olhe:

[3:23] "Delete From Produtos Where Tamanho = 1 Litro And", podemos pegar essa condição que está aqui, ou seja: eu vou excluir todos os produtos Sabor dos Alpes do tamanho um litro.

[3:55] Se a gente, novamente, fizer aqui a seleção, temos aqui vários produtos; temos um, dois, três, quatro, cinco, seis.

[4:08] Então se eu rodar esse Delete aqui, seis linhas foram afetadas, podemos olhar aqui, ou seja: apaguei seis registros, e então se eu fizer a minha seleção de novo, eu não tenho mais nenhum produto de um litro.

[4:28] A gente pode também fazer a exclusão usando como base o conteúdo de uma outra tabela. Vamos fazer o seguinte:

[4:37] Eu vou escrever isso aqui, olhe:

[4:38] "Select Codigo_Do_Produto From", então eu vou pegar lá da tabela de produtos que eu tenho lá na base Sucos_Vendas que a gente considera como fonte dos nossos dados, não é? Então é:

[5:01] "Sucos_Vendas.Tabela_de_produtos". OK?

[5:17] Então tem lá uma série de produtos que estão aqui na tabela de produtos no banco Sucos_Vendas.

[5:27] E eu posso fazer então uma seleção que é assim:

[5:29] "Select...", eu, agora, vou selecionar os produtos da tabela de produtos que eu tenho na base Vendas_Sucos, ou seja: aqui.

[5:44] Então: "...Codigo From..." porque o campo no meu banco é Código, não é? "...From...", e se eu fizer isso aqui, olhe:

[6:01] "...Where Codigo Not In", o quê? Esta seleção aqui.

[6:11] Estamos usando uma subquery como condição.

[6:19] Então se eu fizer aqui, olhe, ele vai listar uma série de produtos que são os produtos que existem na tabela de produtos mas não existem na tabela de produtos do outro banco.

[6:34] Digamos que eu quero fazer uma sincronização, ou seja:

[6:36] "olha, a minha tabela de produtos do banco Vendas_Sucos tem que ser igual à tabela de produtos do Sucos_Vendas", então eu posso fazer o seguinte:

[6:52] "Delete From Produtos Where..." e então eu coloco essa condição aqui.

[7:04] Então esse comando que eu estou fazendo aqui de Delete está sincronizando as duas tabelas, ele está apagando quem tem na tabela do meu banco e quem não tem na tabela, digamos modelo, ou padrão, que eu estou usando.

[7:23] Então é uma forma de eu fazer um Delete usando uma condição um pouco mais complexa.

[7:31] Se eu executar aqui, olhe:

[7:34] ele executou nove exclusões, e seu eu rodar essa consulta aqui de cima novamente, virá vazio, por quê? Porque agora as duas tabelas estão sincronizadas, estão com os valores iguais. Tudo bem?

[7:54] É isso aí, gente. Valeu.

-----------------------------------------------------------------------
# 06Excluindo Notas

Desafio: Vamos excluir as notas fiscais (Apenas o cabeçalho) cujos clientes tenham a idade menor ou igual a 18 anos.

Dica: Usaremos consulta abaixo:

```sql
SELECT A.NUMERO FROM NOTAS A
INNER JOIN CLIENTES B ON A.CPF = B.CPF
WHERE B.IDADE <= 18
```

E use uma sintaxe parecida com a usada no **UPDATE** com **FROM**.


-----------------------------------------------------------------------
# 07Alterando e apagando toda a tabela

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55794

## Transcrição

[0:00] Vamos continuar vendo mais uma coisinha de DELETE.

[0:04] Eu vou aqui criar aqui um novo script no workbench.

[0:09] E note uma coisa: se eu clico aqui na tabela de produtos e dou o botão da direita do mouse, eu tenho uma série de opções aqui que me ajudam a construir alguns comandos de SQL.

[0:23] Então, por exemplo, eu venho aqui e escolho essa opção: Send to SQL Editor.

[0:35] E eu vou escolher a opção, por exemplo, Create Statement.

[0:39] Eu estou fazendo isso, botão direito do mouse sobre a tabela de produtos.

[0:45] Ao fazer isso, ele vai escrever o comando de SQL para criar uma tabela igual aquela tabela que já existe.

[0:57] Então, note que ele escreveu aqui create table, os campos, me disse quem é a primary key. Ele não falou nada de chave estrangeira. Nem essa tabela tem chave estrangeira.

[1:13] Bem, e ele colocou, claro, algumas informações a mais aqui a respeito da parte de tipo de caracteres que essa tabela vai poder manipular.

[1:26] Eu vou colocar aqui em vez de produtos, produtos 2. Vou criar uma outra tabela e vou tirar esse engine aqui. Não é importante para mim, por enquanto.

[1:37] Vou rodar.

[1:39] Então, se eu vier aqui no meu ambiente onde eu tenho o banco de dados e dar um refresh all, eu vou ter aqui uma outra tabela chamada produtos 2.

[1:53] Só que ela está vazia.

[1:56] Se eu fizer isso aqui e rodar esse comando, não vai me trazer nada.

[2:04] Mas aí eu posso vir aqui, insert into produto 2, select asterisco from produto.

[2:20] Já que a tabela de produto e produto 2 são iguais, se eu fizer isso daqui, eu vou transferir todo o conteúdo que eu tenho na tabela de produto para a tabela de produto 2.

[2:32] Na verdade, é produtos. Deixa eu colocar aqui o S. Tanto na tabela destino quanto origem.

[2:40] Então, se eu rodar isso daqui, eu agora, se eu fizer um select na tabela de produtos 2, eu tenho dados.

[2:56] Lembrando uma coisa que já fizemos: se eu quiser, por exemplo, alterar todo mundo, todas as linhas num determinado campo, por exemplo, update produtos 2, set preco lista igual a 8.

[3:21] Note que nesse comando aqui update, eu não coloquei um WHERE. Isso significa que ele vai fazer essa alteração em toda a tabela.

[3:34] Vamos ver?

[3:36] Executei.

[3:38] Se eu fizer um select agora, note que preco lista está tudo com número 8.

[3:46] E eu posso também apagar a tabela, apagar o conteúdo dela. Basta fazer delete from produtos 2.

[4:01] Se eu fizer isso daqui, novamente se eu fizer o meu select, minha tabela voltou a ficar vazia.

[4:11] Tomar muito cuidado com o delete from o nome da tabela.

[4:15] Quer dizer, a gente tem que tomar cuidado realmente com qualquer delete, mas o delete from sem o WHERE, você vai perder tudo que você tem dentro da sua tabela e não tem como recuperar.

[4:31] Então era isso que eu queria mostrar a vocês como é que eu consigo fazer update sem ter estes deletes genéricos na tabela toda.


-----------------------------------------------------------------------
# 10COMMIT e ROLLBACK

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55795

## Transcrição

[0:00] Lembra no vídeo passado que eu falei para a gente tomar um certo cuidado quando a gente utilizar update de DELETE? Isso porque eu posso perder os dados, eu posso às vezes apagar uma informação que eu não gostaria de ter apagado, só que existe um mecanismo dentro do MySQL que pode nos dar uma certa segurança caso eu faça uma operação não desejada, é o que a gente chama de uma transação.

[0:29] Até agora a gente tem executado os comandos sem nos preocuparmos em relação a uma transação. Toda vez que eu dou INSERT um dado é inserido, toda vez que eu dou um UPDATE o dado é alterado, toda vez que eu dou um DELETE o dado é apagado.

[0:47] Agora, se eu crio uma transação tudo que eu fizer depois de eu criar a transação vai ficar em memória, não vai ser gravado no banco, ou seja, eu posso dar INSERTS, UPDATES, DELETES, porém depois que eu encerrar a transação aí sim dependendo da forma como eu encerro a transação eu realmente efetivo a gravação, as modificações na base de dados ou não.

[1:20] Como é que eu termino a transação? Bem, na verdade, desculpe, como é que eu inicio uma transação? Através do comando START TRANSACTION, ou seja, lá no MySQL quando eu digitar START TRANSACTION uma transação será inicializada. E como é que eu acabo a transação? Com um COMMIT ou um ROLLBACK. A diferença é que o COMMIT, se eu der COMMIT eu confirmo no banco de dados tudo aquilo que eu modifiquei depois do START TRANSACTION. Se eu der um ROLLBACK eu volto atrás e não consigo ver as modificações, as modificações não são confirmadas no banco.

[2:05] Na prática isso é muito importante quando a gente faz um sistema transacional e aí o nosso usuário tem uma tela lá amigável, uma transação por exemplo, um pagamento ou uma baixa de estoque, que vai afetar aquela operação vários INSERTS ou vários UPDATES ou vários DELETES no banco de dados. Então quando o usuário vai fazer lá a operação normalmente a gente dá um START TRANSACTION, o usuário faz lá o que ele tem que fazer e aí quando ele clicar em salvar eu dou o COMMIT, porque eu vou confirmar aquilo que ele fez, e seu der um CANCEL eu dou um ROLLBACK, ou seja, eu volto tudo que tinha anteriormente ao START TRANSACTION, é como se aquela operação fosse descartada. Vamos ver isso na prática lá no Workbench.

[3:04] Então eu vou entrar aqui no Workbench e vou criar aqui um novo script. Vamos começar uma transação, então para começar a transação é START TRANSACTION. A transação está inicializada. Vamos pegar a nossa tabela de vendedores. Note que eu tenho aqui as comissões dos vendedores que está em 0.08, o segundo também é 0.08, o terceiro é 0.11 o quarto é 0.

[3:45] Digamos que eu vá fazer um UPDATE, eu quero aumentar a comissão de todo mundo em 15%, então eu vou fazer isso aqui. Lembrando que eu estou dentro da transação, certo? UPDATE, VENDEDORES, SET, COMISSÃO igual a COMISSÃO vezes 1.15. Não coloquei o WHERE, significa que eu vou aumentar em 15% todo mundo. Fiz a operação, vamos dar um SELECT em vendedores? Note que agora o número da comissão ele está em 0.092, 0.092 o segundo, aumentou 15%. O 0.08 foi para 0.92 e o 0.11 foi para 0.1265.

[4:44] Agora o que eu vou fazer? Eu vou dar um ROLLBACK. Eu não quero confirmar, ao dar o ROLLBACK a transação vai ser finalizada, e o que eu fiz será descartado, então note, dei um ROLLBACK. Agora se eu der agora de novo um SELECT na tabela, note que a comissão ela está agora, voltou ao que estava antes. Agora vamos fazer o contrário, eu vou dar meu START TRANSACTION, iniciei uma nova transação, dei o meu UPDATE e vou dar aqui o meu SELECT. Está lá de novo a comissão 15%, só que agora em vez de dar um ROLLBACK eu vou dar um COMMIT, ou seja, eu vou confirmar essa alteração. Ao dar o COMMIT se eu der o SELECT de novo agora ficou gravada na base o aumento da comissão em 15%.

[5:54] Isso vale também para o INSERT. Vamos lá de novo, eu vou copiar aqui essa linha, vou colocar aqui. Então vou inicializar uma outra transação, vou fazer aqui o INSERT, INSERT + INTO, vamos aproveitar antes de dar o INSERT manualmente vindo aqui em vendedores Send to SQL Editor, Insert Statement. Olha, ele já escreve para mim o comando todo INSERT e eu aqui só vou colocar os dados. Então a matrícula eu vou botar uma matrícula 999, aqui em nome eu vou colocar 'JOAO DA SILVA', bairro eu vou colocar 'Icaraí', comissão eu vou botar o 0.08, data de admissão eu vou colocar 2012 01 15, por exemplo e está de férias? Eu vou botar o número 0. Então isso aqui é o INSERT. Opa, a matrícula está muito longa, eu botei muitos dígitos, vamos ver agora. Foi. Uma linha afetada. Se eu der aqui o meu SELECT eu tenho lá o 999 inserido.

[7:43] Agora vamos dar aqui um ROLLBACK. Na verdade, eu não vou fazer nem um ROLLBACK, eu vou além de fazer o INSERT olha só, vou ainda fazer o UPDATE. Então eu fiz o INSERT, ainda fiz o UPDATE, então vamos lá, as comissões aumentaram e eu vou por exemplo apagar, eu vou inserir um segundo, ó vou copiar esse cara aqui, esse comando de INSERT, vou colocar aqui embaixo do UPDATE, vou colocar como JOAO DA SILVA2 por exemplo, só modifiquei ali o código e o nome. Então eu tenho aqui dois novos vendedores e aí olha só, agora eu vou dar um ROLLBACK. Ao dar o ROLLBACK, que dizer eu fiz o INSERT, fiz o UPDATE, fiz outro INSERT, ao dar o ROLLBACK se eu vir aqui o conteúdo da tabela de vendedores eu vou ter a original. Novamente, vou dar um START TRANSACTION, iniciei nova transação, vou rodar esses três comandos aqui, ou seja, vou dar dois INSERTS e um UPDATE, rodei. Se eu der o SELECT voltei a ter a tabela lá com os ajustes e os dois novos vendedores, mas agora vou dar um COMMIT. Agora sim, a minha modificação foi confirmada, a transação acabou e aí claro, se eu rodar o meu SELECT estão lá as modificações já confirmadas dentro da base de dados.

[10:00] Tá legal? Então era sobre isso que eu queria falar com vocês, sobre START TRANSACTION, COMMIT e ROLLBACK. Valeu, um abraço.


-----------------------------------------------------------------------
# 12Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Vamos verificar a lista de produtos.

```sql
SELECT * FROM produtos;
```

![1.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/04/1.png)

2) Vamos alterar o preço de lista de um dos produtos. Para isso digite:

```sql
UPDATE produtos SET PRECO_LISTA = 5 WHERE CODIGO = '1000889';
```

1) Podemos alterar os dados da tabela em forma de lote. Digite e execute:

```sql
UPDATE produtos SET EMBALAGEM = 'PET', TAMANHO = '1 Litro', DESCRITOR =

'Sabor da Montanha - 1 Litro - Uva' WHERE CODIGO = '1000889';
```

2) Também podemos alterar o preço de lista baseado no mesmo campo que será alterado. Digite e execute:

```sql
UPDATE produtos SET PRECO_LISTA = PRECO_LISTA * 1.10 WHERE SABOR = 'Maracujá';
```

3) Da mesma maneira que incluímos dados na tabela baseado nos dados de uma outra tabela, podemos também alterar dados desta mesma maneira. Digite e execute:

```sql
UPDATE VENDEDORES A INNER JOIN SUCOS_VENDAS.TABELA_DE_VENDEDORES B

ON A.MATRICULA = SUBSTRING(B.MATRICULA,3,3)

SET A.FERIAS = B.DE_FERIAS;
```

4) É possível apagar dados da tabela. Antes disto vamos incluir novos registros que depois serão excluídos. Digite e execute:

```sql
  INSERT INTO PRODUTOS (CODIGO,DESCRITOR,SABOR,TAMANHO,EMBALAGEM,PRECO_LISTA)

     VALUES ('1001001','Sabor dos Alpes 700 ml - Manga','Manga','700 ml','Garrafa',7.50),

         ('1001000','Sabor dos Alpes 700 ml - Melão','Melão','700 ml','Garrafa',7.50),

         ('1001002','Sabor dos Alpes 700 ml - Graviola','Graviola','700 ml','Garrafa',7.50),

         ('1001003','Sabor dos Alpes 700 ml - Tangerina','Tangerina','700 ml','Garrafa',7.50),

         ('1001004','Sabor dos Alpes 700 ml - Abacate','Abacate','700 ml','Garrafa',7.50),

         ('1001005','Sabor dos Alpes 700 ml - Açai','Açai','700 ml','Garrafa',7.50),

         ('1001006','Sabor dos Alpes 1 Litro - Manga','Manga','1 Litro','Garrafa',7.50),

         ('1001007','Sabor dos Alpes 1 Litro - Melão','Melão','1 Litro','Garrafa',7.50),

         ('1001008','Sabor dos Alpes 1 Litro - Graviola','Graviola','1 Litro','Garrafa',7.50),

         ('1001009','Sabor dos Alpes 1 Litro - Tangerina','Tangerina','1 Litro','Garrafa',7.50),

         ('1001010','Sabor dos Alpes 1 Litro - Abacate','Abacate','1 Litro','Garrafa',7.50),

         ('1001011','Sabor dos Alpes 1 Litro - Açai','Açai','1 Litro','Garrafa',7.50);
```

5) Vamos apagar um registro apenas. Digite e execute:

```sql
DELETE FROM PRODUTOS WHERE CODIGO = '1001000';
```

6) Podemos aplicar um filtro para selecionar dados a serem excluidos. Digite e execute:

```sql
DELETE FROM PRODUTOS WHERE TAMANHO = '1 Litro' AND SUBSTRING(DESCRITOR,1,15) = 'Sabor dos Alpes';
```

7) Outra forma é apagar usando a seleção de dados de outra tabela. Digite e execute:

```sql
DELETE FROM PRODUTOS WHERE CODIGO NOT IN ( SELECT CODIGO_DO_PRODUTO FROM SUCOS_VENDAS.TABELA_DE_PRODUTOS);
```

8) Os comandos UPDATE e DELETE podem ser executados sobre a tabela inteira. Vamos então criar uma tabela de forma temporária para depois alterá-la e apagá-la. Digite e execute:

```sql
CREATE TABLE `produtos2` (

  `CODIGO` varchar(10) NOT NULL,

  `DESCRITOR` varchar(100) DEFAULT NULL,

  `SABOR` varchar(50) DEFAULT NULL,

  `TAMANHO` varchar(50) DEFAULT NULL,

  `EMBALAGEM` varchar(50) DEFAULT NULL,

  `PRECO_LISTA` float DEFAULT NULL,

  PRIMARY KEY (`CODIGO`)

) ;
```

9) Depois inclua os dados nesta tabela:

```sql
INSERT INTO produtos2 SELECT * FROM produtos;
```

10) Altere os dados para toda a tabela:

```sql
UPDATE produtos2 SET preco_lista = 8;
```

11) O comando abaixo apaga todos os registros da tabela. Digite o comando abaixo e execute para apagar os dados da tabela:

```sql
DELETE FROM produtos2;
```

12) Vamos criar uma transação. Digite e execute o comando abaixo para iniciar uma transação:

```sql
START TRANSACTION;
```

13) Vamos verificar a tabela de vendedores:

```sql
SELECT * FROM VENDEDORES;
```

![2.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/04/2.png)

14) Modifique os dados referentes a comissão. Digite e execute:

```sql
UPDATE VENDEDORES SET COMISSAO = COMISSAO * 1.15;


SELECT * FROM VENDEDORES;
```

![3.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/04/3.png)

15) Vamos refazer o comando acima. Digite e execute:

```sql
ROLLBACK;
```

16) Verifique a tabela. Digite e execute:

```sql
SELECT * FROM VENDEDORES;
```

![4.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/04/4.png)

17) Vamos repetir a modificação iniciando nova transação. Digite e execute:

```sql
START TRANSACTION;

UPDATE VENDEDORES SET COMISSAO = COMISSAO * 1.15;

SELECT * FROM VENDEDORES;
```

![5.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/04/5.png)

18) Agora iremos confirmar a inclusão destes dados. Para isso digite:

```sql
COMMIT;
```

19) Verifique novamente a tabela. Para isso digite:

```sql
SELECT * FROM VENDEDORES;
```

![6.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/04/6.png)


-----------------------------------------------------------------------
# 13O que aprendemos?

Nesta aula, aprendemos:

- Alterar e excluir dados de uma tabela, através de comando ou em lotes;
- Vimos que podemos alterar ou excluir todos os dados de uma tabela;
- O que é uma transação e como podemos desfazer modificações efetuadas anteriormente na base de dados.


-----------------------------------------------------------------------
# 01Campos autoincremento

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55796

## Transcrição

[0:00] Um campo do tipo inteiro pode ter uma propriedade que nós chamamos de Auto Incremento; o que é o Auto Incremento?

[0:09] É um número sequencial que será incluído dentro dessa coluna de forma automática, na medida em que eu vou dando INSERTS.

[0:20] Veja o exemplo aqui em cima:

[0:22] vamos supor que eu tenho uma tabela com um campo ID e um campo DESCRITOR, e esse campo ID tem essa propriedade de auto incremento.

[0:35] Quando eu faço a inclusão de um novo registro, automaticamente uma SQL vai dar ID igual a um para esse novo registro, porque a tabela, originalmente, estava vazia.

[0:52] Note aqui em cima que no comando Insert eu nem falei sobre o campo ID, nem mencionei ele, então, automaticamente, ele coloca lá o número um.

[1:04] Se eu der um segundo Insert, automaticamente o campo ID será o dois, por quê? Porque a tabela agora tem dois registros. Ou seja:

[1:15] na medida em que eu vou dando Inserts, esse ID vai crescendo, respeitando uma sequência numérica.

[1:26] Se eu apagar o ID um, por exemplo, então sim, na hora de fazer um Delete, um Select, um Update, eu posso me referenciar na cláusula WHERE aquele campo ID.

[1:39] Se eu quiser dar um Delete no ID = 1 ele vai sumir, só vai ficar o código dois, e então se eu der um novo Insert, automaticamente ele continua fazendo um incremento sequencial, criando o código três. ok?

[1:55] Então é assim que funciona o Auto Incremento.

[1:58] A propriedade chama-se Auto_Increment, como eu falei, não é necessário especificar o campo AutoIncrement no comando Insert; não é necessário, mas pode ser especificado, Ok?

[2:17] Só podemos ter apenas um campo AutoIncrement dentro de uma tabela, e nós podemos forçar o valor do AutoIncrement quando, então sim, mencionamos ele no Insert, ou seja:

[2:30] se eu colocar no Insert o valor do ID, eu estou forçando o valor do auto incremento e depois daquele Insert o auto incremento vai usar como o último valor, aquele valor que eu coloquei.

[2:44] Vamos fazer isso na prática e ver como é que funciona.

[2:48] Então eu vou vir aqui no Workbench, vou criar aqui... espere, porque eu já tenho aqui o meu, eu vou apagar aqui o meu exemplo, porque, claro, eu antes estudo sobre a aula que eu vou treinar e eu já estava lá com o exercício pronto, então, na verdade, é assim:

[3:08] não temos ainda aquele Script pronto no Workbench, eu vou criar um Script novo e então faremos o seguinte:

[3:16] criaremos uma tabela nova comum campo AutoIncrement. Então:

[3:21] "Create Table Tab_Identity...", por exemplo, é o nome da tabela, vou colocar, eu vou criar um campo ID que vai ser Inteiro e vai ser AutoIncrement, e eu vou criar um campo Descritor que vai ser um Varchar de vinte.

[3:50] Então vamos criar essa tabela.

[4:00] Na verdade, eu tenho que definir o auto incremento como chave primária.

[4:11] Vamos ver aqui... agora sim, ok?

[4:15] Essa é uma outra característica: o campo auto incremento sempre deve fazer parte da chave primária da tabela, ok?

[4:24] Esse é um outro detalhe que eu não mencionei lá nos Slides, mas o próprio MySQL já me deu uma dica quando ele me mostrou esse erro aqui, olhe, eu já saquei logo que eu tinha esquecido de colocar o ID como chave primária da tabela.

[4:46] Agora vamos lá: "Insert Into Tab_Identity..." não menciono o ID, só vou mencionar o "...(Descritor) Values Cliente 1", por exemplo.

[5:09] Vamos dar esse Insert? Incluiu.

[5:13] Se eu der um "Select * From Tab_Identity", vamos ver como está o conteúdo da nossa tabela. Está lá.

[5:25] Note que ele colocou o número um para o ID automaticamente, eu não mencionei nada do ID dentro do comando Insert. Então vamos lá.

[0:05:37] Eu vou vir aqui e vou inserir o cliente dois e o cliente três; vou rodar esses dois comandos. Rodei.

[5:47] Se eu faço meu Select, tenho lá, olhe, o número um, o número dois, e o número três.

[5:59] Posso também fazer isso aqui: eu posso mencionar o ID, mas eu posso colocar aqui um Null, ok? Olhe:

[6:11] mencionei o ID, mas coloquei como Null. Isso faz o mesmo efeito de eu não mencionar o ID.

[6:19] Ok, esse cara aqui vai ser o cliente quatro; note que rodou, quando eu dou o Select eu tenho lá o cliente quatro criado, está bem?

[6:33] Bem, eu posso vir aqui apagar, por exemplo, o ID igual a dois.

[6:48] Então estou dando um Delete; From, o nome da tabela; o Where ID igual a dois. Vamos lá, rodou.

[6:57] Note que o ID dois não existe mais, só tem o um, o três e o quatro.

[7:03] Agora se eu incluir aqui um cliente cinco, não importa se tem o Null ou não, incluí, se eu vier aqui, note que ele começou a contar do último valor que eu tinha, tudo bem?

[7:24] Se eu apagar o cinco, olhe, eu vou apagar o cinco, que é o último; apaguei o cinco e eu vou inserir agora o cliente seis; qual será o ID que ele vai colocar? Cinco ou seis?

[7:47] Olha a pergunta, vamos ver: coloquei.

[7:53] Note que ele colocou seis, apesar de eu apagar o cinco. Acontece o seguinte: a estrutura Auto Incremento é uma estrutura do banco de dados chamada Sequência, então quando eu inseri o cliente cinco, ele internamente tem essa sequência salva, do um até o cinco, ele sabe que o próximo valor é o seis.

[8:21] Eu apaguei da tabela o cinco, mas não importa, na hora que eu incluir, o campo é auto incremento, ele vai lá na estrutura sequência; quem é o próximo? É o seis.

[8:31] Não importa se o cinco não existe mais, o próximo é o seis.

[8:35] Então ele coloca seis lá no ID quando eu faço o Insert daquela linha.

[8:42] E eu posso também forçar e dar um pulo para essa sequência. Assim:

[8:53] eu, ao invés de Null, vou colocar 100; vou rodar; rodou.

[9:01] Se eu der o meu Select, note que eu tenho agora aqui o cliente cem, e esse cem eu forcei, eu disse:

[9:08] "olha, eu quero que o ID seja cem"; ao fazer isso, a sequência interna foi para cem.

[9:17] Então se eu agora inserir um novo cliente, cliente sete, quando eu dou o meu Select, note que o valor foi para cento e um. Ou seja:

[9:36] a sequência pulou e então vai crescendo de um em um e vai embora. Tudo bem?

[9:43] Bem, gente, era isso que eu queria falar com vocês sobre Campo de Auto Incremento, tudo bem? Valeu, um abraço.

-----------------------------------------------------------------------
# 02Valor da sequência
Qual será o valor final da sequência após a execução dos comandos abaixo?

```sql
CREATE TABLE TAB_IDENTITY2 (ID INT AUTO_INCREMENT, DESCRITOR VARCHAR(20), PRIMARY KEY(ID));

INSERT INTO TAB_IDENTITY2 (DESCRITOR) VALUES ('CLIENTE1');

INSERT INTO TAB_IDENTITY2 (DESCRITOR) VALUES ('CLIENTE2');

INSERT INTO TAB_IDENTITY2 (DESCRITOR) VALUES ('CLIENTE3');

INSERT INTO TAB_IDENTITY2 (ID, DESCRITOR) VALUES (NULL, 'CLIENTE4');

DELETE FROM TAB_IDENTITY2 WHERE ID = 3;

INSERT INTO TAB_IDENTITY2 (ID, DESCRITOR) VALUES (NULL, 'CLIENTE6');

INSERT INTO TAB_IDENTITY2 (ID, DESCRITOR) VALUES (NULL, 'CLIENTE7');

DELETE FROM TAB_IDENTITY2 WHERE ID = 2;
```


-----------------------------------------------------------------------
# 03Definindo padrões para os campos

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55797

## Transcrição

[0:00] Quando a gente cria um campo inteiro do tipo Auto Incremento, é como se eu tivesse determinado um padrão para aquele campo, caso ele não seja mencionado no Insert.

[0:14] Eu posso definir outros padrões para campos, então vamos fazer um exemplo:

[0:22] Eu vou, novamente, criar um Script novo, e eu vou criar uma tabela assim:

[0:29] "Create Table Tab_Padrao", vou criar um ID que vai ser Inteiro do tipo AutoIncrement.

[0:46] Vou criar um campo chamado Descritor que será Varchar, por exemplo, de vinte.

[0:58] Colocarei um campo Endereço Varchar de cem, só que eu vou escrever a palavra Null do lado; vocês vão entender por que eu fiz isso.

[1:11] Vou colocar aqui Cidade Varchar de cinquenta; só que aqui eu farei o seguinte, eu escreverei isso aqui:

[1:21] "Default Rio de Janeiro", e, por exemplo: Data, criação, eu vou colocar como um Timestamp; lembrando que Timestamp é data com hora, minuto e segundo; Default, e aqui eu vou usar uma função que é a Current Timestamp.

[2:04] A função Current Timestamp me dá a data e hora do computador.

[2:11] E então, como eu criei um campo Auto Incremento, Primary Key, ID. Pronto.

[2:29] Antes de rodar este comando, vamos explicar:

[2:33] o campo ID é Auto Incremento, ou seja: terá aquela sequência numérica.

[2:40] O campo Descritor, note que depois da vírgula eu não coloquei nada; significa o seguinte:

[2:45] que esse campo não tem um padrão Default, um padrão para o seu valor; logo, ele será sempre obrigatório ser colocado.

[3:00] O campo endereço tem um padrão Null, significa que se eu não falar nada ele será nulo.

[3:08] Já o campo cidade, ele tem como Default Rio de Janeiro, ou seja: se eu não falar nada durante o Insert, o valor a ser colocado será Rio de Janeiro, enquanto que o campo Data_Criação, o padrão será a hora do computador.

[3:28] Então olhe lá: vou dar um Insert Into Tab Padrao, vou colocar os campos, o ID eu não preciso colocar, não é?

[3:42] Descritor, Endereço, Cidade, Data, Criação; Values, então vamos botar um descritor para ele... Cliente X, o endereço: rua Projetada a, cidade São Paulo, e a data da criação eu vou colocar 2019-01-01.

[4:22] Vou rodar esse Insert... na verdade, eu não rodei o cliente, não é? Vou ter que rodar o cliente antes. Pronto.

[4:34] Agora criei a tabela, agora sim eu posso rodar o Insert. Pronto.

[4:40] Se eu der aqui um "Select * From Tab_Padrao" a gente pode observar o conteúdo da tabela.

[4:53] Tenho lá os valores; o um que é o sequencial, e os valores que foram especificados.

[5:00] Agora, por exemplo, se eu fizer isso aqui: "Insert Into Tab_Padrao (Descritor) Values ('Cliente Y')", note que agora aqui, eu não coloquei nada sobre endereço, sobre cidade e sobre data da criação.

[5:31] Só coloquei sobre o Descritor.

[5:33] Mas endereço, cidade e data da criação, se vocês se lembrarem, aqui em cima, eles possuem padrões, ou seja:

[5:44] caso não seja mencionado no Insert valores para estes três campos, uma SQL vai colocar na tabela os valores padronizados que foram colocados durante a criação da tabela.

[5:58] Vamos ver aqui, eu vou rodar esse Insert, rodou; se eu faço o meu Select, note que o cliente Y tem endereço nulo, a cidade foi Rio de Janeiro, porque eu disse que era o padrão, e a data da criação é a hora e data do computador no momento em que eu estou gravando este vídeo. OK?

[6:24] Então note que ele colocou tudo.

[6:29] O Auto Incremento eu também não mencionei, mas ele já colocou aqui o dois, ele só colocou o descritor do cliente porque é o único campo que não tem um padrão. Tudo bem?

[6:44] Nós usamos muito, quando desenvolvemos sistemas, esse cara aqui, olhe:

[6:52] Timestamp Default Current_Timestamp, por quê?

[6:57] Porque é sempre legal você ter um registro na tabela para te dizer em que momento aquele campo foi alterado ou inserido; é muito legal, às vezes, para fazer manutenção de sistema, precisa saber quais foram os últimos registros colocados na base, então, normalmente, quando o pessoal desenvolve um sistema transacional, todas as tabelas têm um campo lá perdido, porque eu não preciso mencionar ele no Insert, não é?

[7:29] Então tem um campo lá que tem um nome padronizado que é do tipo Timestamp e tem como Default o Current Timestamp, tudo bem?

[7:38] Então é isso, gente. Valeu.

-----------------------------------------------------------------------
# 05TRIGGER

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55798

## Transcrição

[0:00] Existe uma funcionalidade no MySQL chamada TRIGGER, e é uma funcionalidade inclusive que eu considero muito poderosa e que pouca gente usa no banco de dados.

[0:13] O que seria uma TRIGGER? A TRIGGER seria um, como o próprio nome em inglês diz, é um gatilho. É uma regra que é disparada no momento em que uma tabela sofre uma modificação nos seus dados, ou seja, uma inclusão, alteração ou exclusão.

[0:34] Veja esse exemplo aqui, digamos que eu tenha uma TRIGGER associada a essa tabela da esquerda que escreve o que foi feito em uma outra tabela da direita. Então eu vou incluir um cliente, por exemplo, e ao fazer isso eu posso disparar uma TRIGGER dizendo: "olha, o cliente 1 foi incluído". Depois eu posso fazer um outro INSERT e aí eu escrevo nessa tabela ID LOG aqui outro cliente foi incluído, ou por exemplo, eu apago um cliente, eu escrevo no LOG que um cliente foi excluído e assim por diante. Ou seja, a regra que eu vou especificar para ser executada pela TRIGGER pode ser um ou mais comandos de SQL. E o gatilho eu digo no momento de definir a TRIGGER, eu digo se ela vai ser executada antes ou depois de um INSERT, UPDATE ou DELETE.

[1:45] Vamos fazer um exemplo prático lá no Workbench. Vou criar aqui um script novo e a ideia é a seguinte, eu vou criar uma tabela que vai ter a totalização das vendas, ou seja, na medida em que vendas forem incluídas dentro do sistema vendas sucos, essa tabela de totalização vai ser preenchida.

[2:16] Então, primeiro eu vou criar essa tabela. Então eu vou colocar aqui CREATE TABLE TAB PADRÃO, não, eu vou dar um nome melhor para essa tabela, TAB FATURAMENTO. E eu vou colocar como campos a data da venda que vai ser um DATE e depois eu vou colocar o TOTAL VENDA que vai ser um FLOAT. Então essa tabela bem pequena auxiliar, não tem nem primary key, vou criar ela. Então é claro, se eu vier aqui e der um SELECT nela eu tenho aqui vazia.

[3:19] Bem, nós temos duas tabelas que nos dão o faturamento da empresa, é a tabela de notas que tem os cabeçalhos das notas e a tabela de itens de notas que tem os itens das notas fiscais. Se a gente pegar aqui a tabela de notas, ela está vazia e a de itens notas também está vazia. Vamos incluir um faturamento, ou até dois faturamentos dentro dessas tabelas. Então sempre tem que estar inserindo o cabeçalho da nota e os itens das notas fiscais, então vamos lá.

[4:04] INSERT, INTO, NOTAS, a gente vai colocar aqui, vamos ver os campos, é NÚMERO, DATA da VENDA, CPF, MATRÍCULA, IMPOSTO. VALUES, vamos colocar aqui um número de nota fiscal, começa com 100, data da venda eu vou colocar a data de hoje que está aqui no meu computador. CPF vou escolher um CPF qualquer que tem aqui na tabela de clientes, então deixa eu pegar aqui algum cliente qualquer que tenha cadastro, vou pegar esse cara aqui, o primeiro, então vou colocar aqui esse CPF. Matrícula é o código do vendedor, então deixa eu pegar aqui um código de um vendedor qualquer, o 235 pode ser. E o imposto 0.10.

[5:28] Esse aqui é o cabeçalho da nota. Itens da nota, pode ter até mais de um item, então vai ser INSERT, INTO, ITENS, NOTAS, vamos pegar aqui a tabela de itens notas e ver o que temos aqui. Temos número, temos código que é o código do produto, quantidade e o preço. Então vamos lá, o número sempre tem que ser o mesmo número da nota porque são os itens dessa nota fiscal que eu estou incluindo, código do produto vamos pegar aqui alguns produtos, vamos pegar esses dois códigos aqui que a gente vai criar mais de um item, vamos jogar o código para cá, então o primeiro código vai ser esse. Quantidade eu vou botar 100 unidades e o preço 10, e eu vou copiar essas duas linhas, colar aqui e eu só vou modificar o código do produto. Então essas três linhas aqui correspondem a uma venda, é uma nota fiscal que tem um cabeçalho e dois itens. Eu fiz até muito rápido, vamos ver se vai funcionar. Incluí. Então se eu vier agora aqui eu tenho na minha tabela de notas uma nota fiscal, na tabela de itens notas tem dois itens.

[7:11] Vamos até para poder funcionar direito eu vou incluir aqui uma nota 101, vou manter os mesmos valores, vou executar, aí agora se a gente ver o conteúdo da tabela de notas e de itens notas já temos quatro itens e duas notas. Então nós temos já informações da tabela de notas. Qual seria o SELECT para a gente saber o faturamento e a data do faturamento? Seria esse aqui.

[7:53] Vamos primeiro fazer o JOIN depois a gente volta para colocar os campos. A gente pegaria, na tabela de notas eu vou chamar de A INNER JOIN com a tabela ITENS, NOTAS que eu vou chamar de B ON, qual é o campo em comum das duas? É um número. Só que eu quero ver isso. Só um instantinho, vamos rodar isso aqui para ver se vai. Tudo bem, eu tenho as quatro linhas, o cabeçalho se repetindo aqui e os itens separados. Só que eu preciso fazer isso aqui, eu quero ver a data da venda que é da tabela de notas e um SUM de isso aqui, TOTAL VENDA. Como eu coloquei um SUM GROUP BY, a data da venda. Então se eu rodar esse SELECT, vamos ver aqui onde é que foi o erro.

[9:13] Na verdade quantidade e preço vem da tabela B, que é a tabela de itens. A tabela de notas não tem quantidade nem preço. Vamos rodar de novo, agora sim. Então está ali, o total de vendas foi 4000 unidades financeiras, reais, vamos supor, no dia 8 do 5. Se eu por acaso incluir uma terceira nota fiscal, vou botar aqui 103, incluir, eu rodo o SELECT, foi para 6000. Como eu criei essa tabela aqui, TAB FATURAMENTO, eu posso fazer isso aqui, INSERT INTO TAB FATURAMENTO SELECT, porque o nome do campo data da venda eu coloquei aqui e o campo TOTAL VENDA eu coloquei aqui. Então rodei, se eu der um SELECT asterisco FROM TAB FATURAMENTO tem lá o valor total. Então a tabela TAB FATURAMENTO tem um valor total.

[00:10:43] Agora, imagina o seguinte, isso tudo foi a preparação do problema. Se eu for inserir uma venda nova aqui embaixo, a 104, o que eu preciso fazer é que ao incluir uma nova venda eu devo também rodar esse INSERT. Quer dizer, quando eu incluo uma venda nova eu tenho que atualizar a tabela de faturamento, então são esses quatro comandos aqui que eu tenho que rodar sempre para que quando eu olhar a tabela de faturamento já vá de 6 para 8000. Na verdade, eu até me enganei, eu tenho que fazer isso aqui, DELETE FROM TAB FATURAMENTO para depois inserir de novo que senão ele vai repetir os dias como ele fez isso, isso foi um erro meu.

[00:11:48] Então, novamente, se eu colocar aqui a nota 105, vamos manter o 104 aqui porque depois eu vou reaproveitar todos esses INSERTS aqui. Vamos fazer agora aqui para 105, 105. Então toda vez que eu rodar uma nota, uma asserção de uma nota eu tenho que apagar a tabela de faturamento e inserir de novo fazendo o cálculo da venda total. Foi, e aí se eu ver o conteúdo da tabela de faturamento eu tenho lá, e aí a tabela vai aumentando na medida que eu incluo novas vendas.

[12:32] Pois bem, só que imagina a cada INSERT desse eu vou ter que depois fazer isso. Tem um jeito automático de fazer? A resposta é sim, através de TRIGGER. Ou seja, na minha TRIGGER eu vou dizer no momento que eu inserir dados na minha tabela eu vou executar alguma coisa. Ou seja, no momento que eu inserir dados na tabela de itens que é a tabela realmente final eu vou dizer, olha, toda vez que eu fizer um INSERT execute esses dois comandos aqui. Ou seja, inserir um novo item atualiza automaticamente a tabela de faturamentos, para toda vez que eu veja a tabela de faturamentos eu possa ver o valor total. Então vamos fazer isso.

[13:25] Antes de fazer isso, claro, eu vou fazer a seguinte coisa, eu vou apagar a tabela de notas, de itens e vou apagar a tabela de notas. Então eu deixei tudo vazio, a tabela de notas e de itens agora estão vazias, as duas. Vamos então aqui embaixo, como é que eu crio uma TRIGGER?

[14:05] Primeiro eu vou colocar um comando que eu vou explicar por que eu estou colocando ele. DELIMITER, por exemplo, barra barra. Barra barra poderia ser outro símbolo qualquer, pode usar dólar, per cent, não importa, eu vou usar o barra barra. Já vou explicar o porquê do DELIMITER. Abaixo do DELIMITER eu vou colocar o comando CREATE TRIGGER e aí eu vou colocar o nome de uma TRIGGER, eu vou chamar TG CALCULA FATURAMENTO INSERT. TG de TRIGGER, CALCULA FATURAMENTO que é o que eu vou fazer, os comandos serão disparados pela TRIGGER e INSERT porque isso vai ser executado quando fizer um INSERT na tabela. AFTER, ou seja, eu quero fazer depois de eu incluir o dado, eu não posso fazer antes porque se eu fizer antes de incluir o dado eu não consigo calcular o faturamento, o faturamento só vai poder ser calculado quando o dado estiver inserido na tabela. AFTER INSERT ON o nome da tabela.

[15:25] Lembra que eu falei? Não basta eu apenas colocar uma tabela de notas, eu só vou ter o faturamento quando colocar a tabela de itens, então eu vou botar aqui itens notas. E aí eu coloco a seguinte cláusula, FOR EACH ROW BEGIN. E aqui eu boto um END, só que esse END você pensaria, END é o final do comando, eu boto ponto e vírgula, mas não, eu vou colocar o barra barra, porque eu disse que o delimitador, o DELIMITER é barra barra, então o meu END ele vai terminar com barra barra.

[16:18] Porque que eu coloquei o barra barra e não o ponto e vírgula? Porque dentro do FOR EACH eu vou colocar vários comandos e aqui dentro do FOR EACH entre o FOR EACH ROW BEGIN e END vão ter comandos delimitados aí sim por ponto e vírgula. E se eu não coloco esse comando DELIMITER barra barra o MySQL vai pensar que o meu comando TRIGGER acabou aqui no meio.

[16:45] Quer ver? Deixa eu escrever o comando e aí vocês vão entender melhor. O que que eu vou fazer aqui no meio? Eu vou justamente calcular o faturamento total e gravar ele na tabela de faturamento. Ou seja, eu vou fazer esses comandos, esses dois comandos que teoricamente eu teria que fazê-los toda vez que eu insiro alguém na tabela de itens notas. Então eu vou colar aqui dentro. Então o comando ficou assim, deixa eu aumentar um pouquinho aqui o espaço para a gente poder olhar melhor isso daqui.

[17:29] Bem, aí vamos falar um pouquinho sobre DELIMITER de novo. Tá vendo que aqui o meu comando ele termina com ponto e vírgulas? Eles estão mostrando para o MySQL que aqui dentro FOR EACH ROLL BEGIN END tem dois comandos que são separados por ponto e vírgula. Se eu não uso o DELIMITER o que que vai acontecer? Eu vou ter um erro porque ele vai achar que o CREATE TRIGGER terminou aqui porque ele vai achar o CREATE TRIGGER vai dizer: "poxa, mas eu não posso terminar o CREATE TRIGGER sem um END", porque ele achou esse ponto e vírgula primeiro. Então eu digo para o MySQL: "olha, no caso do CREATE TRIGGER você vai usar como delimitador o barra barra". Então ele vai somente terminar o comando quando ele achar esse barra barra, e ele vai ignorar esse ponto e vírgula. Para ele o ponto e vírgula não é mais final de comando, mas para o comando TRIGGER esse ponto e vírgula é importante porque separa o espaço que eu tenho que executar quando a TRIGGER for disparada. Entendido?

[18:56] Então vamos lá. Vou rodar agora o meu comando DELIMITER aqui, o DELIMITER não, o TRIGGER. Rodou. Agora vamos fazer o seguinte, vamos ver como é que é o valor da tabela. Vamos fazer o seguinte aqui, como é que está a TAB FATURAMENTO? Ela está até com dados lá, vamos apagar ela. Agora sim. Olha lá, está vazia. Eu vou apenas inserir as notas, note que eu não estou aqui fazendo o cálculo do faturamento e inserindo na TAB FATURAMENTO, não estou, só estou inserindo as notas. Inseri as notas. Agora eu vou rodar o SELECT na TAB FATURAMENTO. A TAB FATURAMENTO passou a ter 2000. Foi mágica? Não. Quando eu dei o INSERT ele disparou a TRIGGER e ao disparar a TRIGGER ele apagou a tabela de faturamento e inseriu o valor total.

[20:34] Então toda vez que eu tiver uma inclusão da tabela de itens notas ele vai fazer o cálculo. Agora eu vou inserir a nota 101. Se a gente vier aqui calcular o valor do faturamento foi para 4000. Agora eu vou inserir a nota 103, inseri. Se eu fizer o SELECT do faturamento foi para 6000. Se eu agora inserir a nota 104 e eu rodar o código do faturamento 8000.

[21:26] Então esse foi o exemplo de TRIGGER no caso de a gente colocar um INSERT. Isso aí, gente, valeu.

-----------------------------------------------------------------------
# 06BEFORE INSERT

O `BEFORE INSERT` é responsável por disparar a `TRIGGER` antes que um evento de inserção ocorra na tabela. Sua sintaxe é demonstrada abaixo:

```sql
DELIMITER//
CREATE TRIGGER nome_do_trigger
    BEFORE INSERT
    ON nome_da_tabela FOR EACH ROW
BEGIN
-- codigo_a_ser_executado
END//
```

Seguindo o exemplo da aula, é demonstrado um SQL que calcula a idade em anos baseado na data atual:

```sql
SELECT CPF, IDADE, DATA_NASCIMENTO, timestampdiff(YEAR, DATA_NASCIMENTO, NOW()) AS ANOS FROM
CLIENTES
```

Caso seja necessário calcular a idade de um(a) novo(a) cliente, que será inserido(a) na tabela CLIENTES, podemos utilizar o `BEFORE INSERT`. Antes do registro ir para a tabela, o cálculo da idade será realizado como é demonstrado abaixo:

```sql

DELIMITER//

CREATE TRIGGER TG_CLIENTES_IDADE_INSERT BEFORE INSERT ON CLIENTES

FOR EACH ROW

BEGIN

SET NEW.IDADE = timestampdiff(YEAR, NEW.DATA_NASCIMENTO, NOW());

END//
```

Vale ressaltar que o código acima é válido para novos(as) clientes. Em caso de registros já existentes no banco de dados, a idade não se altera. Observe que não utilizamos o `UPDATE`, mas sim a cláusula `SET` diretamente. Uma vez que não podemos utilizar um comando `UPDATE` em uma trigger, na qual a tabela a ser atualizada é a mesma que sofrerá a ação para acionar a trigger (neste caso, a tabela "clientes"), utilizamos o comando `SET` atualizando apenas os novos registros a serem inseridos na tabela. O operador `NEW` representa o novo registro que será incluído.

-----------------------------------------------------------------------
# 07TRIGGER UPDATE e DELETE

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55799

## Transcrição

[0:00] OK. Agora, e se eu alterar um valor na minha tabela de itens de nota, ou até mesmo excluir um item, ou excluir uma nota... o que vai acontecer com a minha tabela de faturamento?

[0:16] Vamos fazer um teste, aqui, criando um novo script.

[0:20] Então, deixa eu relembrar aqui quais são as notas fiscais nós temos.

[0:29] Então, temos lá a 100, 101, 103, 104 e os itens que eu tenho. Tenho lá os itens daquelas notas todas.

[0:44] E nós vamos fazer aqui uma tabela faturamento. Tab_faturamento que tá lá no valor de 8000.

[0:59] Então, digamos que eu vá aqui e esse item aqui da nota 104, a quantidade é 100, eu vou botar quantidade 200. Isso vai implicar em um aumento de 1000 no meu faturamento, né?

[1:15] Então, olha lá, vamos ver aqui. Update itens_notas, set quantidade vai ser igual a 200. Where número igual a 0104 and código igual a 100 2 3 3 4.

[1:54] Então, vou alterar esse cara aqui. Vamos relembrar: a minha tabela de faturamento, o total tá 8000. Eu vou fazer o update. Fiz o update.

[2:05] Se eu vier no tab_faturamento continuou 8000, mas na verdade, o faturamento total aumentou em 1000 porque eu acrescentei mais 100 unidade a uma venda. E melhor: eu posso dar um delete from essa tabela aqui; usar esse mesmo where aqui.

[2:31] Então, na verdade, agora eu estou diminuindo de 1000, tirei um item. E a tabela de faturamento continua a mesma.

[2:41] É que, na verdade, quando a gente criou o trigger - vamos relembrar o outro script do vídeo anterior - a gente só disse que esse script era para ser executado no after insert. Eu tenho que, na verdade, criar trigger também para o after update e para o after delete. É o que nós vamos fazer agora.

[3:03] Então eu vou pegar o mesmo script que está aqui, vou colar aqui na... vou pegar o mesmo comando, desculpe. Vou colar nesse novo script. Eu só vou colocar aqui um outro nome, vou chamar esse cara aqui de update e aí vai ser after update, e vou criar o faturamento delete after delete.

[3:41] Então vou rodar aqui o update. Deixa eu dar uma olhada para ser se rodou corretamente... ok, rodou corretamente. E agora eu vou criar um trigger para ser executado após a exclusão. Rodou com sucesso.

[4:04] Se eu vier aqui do lado, der um refresh all, eu tenho as três triggers aqui criadas, associadas à tabela de itens de nota.

[4:17] Então agora a gente pode fazer o seguinte. Para a gente poder calcular a coisa correta, eu vou pegar aqui alguns comandos... vou jogar para cá. Vou incluir uma nota 106 aqui. Vou inserir ainda, não estou fazendo update nem delete. Vamos lá?

[4:54] Tab_faturamento, vamos ver... Está lá 9000, ok? Aí eu vou dar um... vou pegar esse comando delete aqui. Vou deletar, só que agora a nota é a 106. Vou deletar um item dessa nova nota que eu coloquei.

[5:23] Rodei. Como eu dei o delete, ele recalculou o faturamento. Então, de 9000 passou a ser 8000. E eu vou pegar o... Vamos pegar aqui os itens_notas que nós temos. E eu vou pegar aqui, por exemplo, update itens_notas set quantidade igual - vou botar 400, vou aumentar bastante a quantidade - where número igual a 0 100 end, o código vou usar esse mesmo aqui.

[6:10] Ou seja, eu vou fazer uma modificação. Vamos ver de novo, o faturamento está em 8000. Vou fazer uma modificação em um item que já existe na tabela. Fiz a modificação, o faturamento agora foi para 11000. Ok?

[6:29] Bem, uma observação: diferente de alguns outros bancos de dados, eu só posso criar uma trigger para fazer ou insert, ou update, ou delete, ok? E aí eu repeti o código. Teoricamente, isso pode ser um procedimento meio... não muito elegante.

[6:55] Imagina que eu tenha que recalcular a forma com que eu calculo o faturamento: eu vou ter que modificar a trigger de insert, de update e de delete para os mesmos comandos.

[7:09] E que, na verdade, quando a gente cria uma trigger, a gente não cria assim do jeito que eu mostrei a vocês. Normalmente a gente pega esses grupos de comandos aqui e nós transformamos eles em uma stored procedure.

[7:25]Uma stored procedure é como se fosse um programa onde eu tenho uma lista de comandos a serem executados. E aí a trigger não chama comando, ele executa stored procedure. Então aí sim eu posso ter a chamada da stored procedure tanto no insert, quanto no update, quanto no delete e aí no código da stored procedure é que eu coloco a regra de cálculo do faturamento. E aí se essa regra mudar, eu mudo somente dentro da stored procedure e aí as minhas triggers, não preciso nem mexer nelas.

[8:01] Bem, eu não fiz dessa maneira porque a gente ainda não aprendeu stored procedures. Stored procedure e funções são temas de um curso a seguir esse curso. Ele é um curso que está dentro da carreira de SQL com MySQL, que seria o próximo treinamento após esse, tá legal?

[8:22] Inclusive, durante o curso de stored procedure, a gente até volta a esse exemplo aqui e faz ele de uma maneira mais elegante.

[8:31] Tá legal? Então tá, gente, é isso aí que queria falar com vocês. Valeu.

-----------------------------------------------------------------------
# 08Outras formas de manipulação de dados

https://cursos.alura.com.br/course/mysql-dml-manipulacao-de-dados/task/55800

## Transcrição

[0:00] Esse curso se dedicou a mostrar a vocês como é que a gente consegue, pela linguagem SQL, fazer manipulação de dados. Ou seja: incluir, alterar ou excluir dados e tabelas.

[0:14] Mas, na prática, você não vai fazer isso no seu dia a dia usando o Workbench. Claro, eventualmente você pode entrar para fazer algum tipo de manipulação pontual, mas na verdade quem vai fazer essas atualizações são interfaces mais amigáveis que os usuários vão usar através de sistemas. Ou, então, ferramentas que vão fazer processos de transferência ou de integração de dados.

[0:48] Uma outra forma também de manipular as informações das tabelas é através de stored procedures. Como eu já falei no curso, na parte de história do SQL, stored procedures são programas estruturados dentro do ambiente de banco de dados, que foge um pouquinho ao padrão sequel. Porque o padrão sequel não tem uma estrutura de programação.

[1:18] Já nos stored procedures você tem ifs, whiles, fors e assim por diante. Você consegue construir uma estrutura lógica muito bem definida. Então uma maneira de manipular dados é através de stored procedures do MySQL.

[1:37] A outra forma é você utilizar o que a gente chama de ferramentas de integração ou de ETL. ETL vem de uma sigla que chama-se extract, transform e load. Traduzindo do inglês para o português seria extrair, transformar e carregar.

[1:57] Os processos de ETL servem para você transferir dados de um lugar para outro. E isso é muito utilzado, por exemplo, quando eu faço cargas de informações gerenciais, que a gente chama de business intelligence. Ou mesmo integrações onde dois sistemas devem se falar. Acontece uma coisa em um sistema, automaticamente essas ferramentas pegam essa informação e colocam em outro.

[2:22] Quando ele coloca no sistema final, ele vai falar com esse sistema, se esse sistema final, por exemplo, for o MySQL, ele vai falar com ele usando linguagem SQL, usando insert, update ou delete.

[2:39] Mas também a gente pode trabalhar através de programação. A gente pode fazer um programa, seja ele em .NET, Java, PHP ou Phyton, onde eu vou me conectar com o banco através de drivers de conexão, onde eu vou passar as propriedades de acesso, e aí o que eu vou jogar para esses drivers nada mais são do que os meus comandos inserts, updates ou deletes. Só que eu vou montar eles de forma dinâmica através da programação, dependendo da ação que o usuário está fazendo no meu sistema.

[3:18] Bem, aqui na Alura, a gente tem alguns outros treinamentos, e aí eu vou puxar um pouco a sardinha pro meu lado, desculpe, eu vou mostrar alguns treinamentos que eu mesmo ministro que falam um pouquinho desses assuntos. Então a gente vai poder ver outras formas de manipular dados em bancos de dados não diretamente através da interface nativa do banco, no aqui do MySQL do Workbench.

[3:51] Por exemplo: nesse curso aqui VB.NET com Windows Forms Parte 11, trabalhando com bancos de dados, eu dedico aqui uma aula específica para MySQL, ou seja, aqui eu mostro como é que a gente consegue, através de um programa, manipular dados no MySQL. Claro que o curso é de VB.NET, mas a forma com que a gente faz isso no VB.NET é muito parecida com o que a gente faz no C#, no Java, ou em outras linguagens.

[4:32] Um outro curso interessante é o curso de Pentaho Data Integration. Pentaho Data Integration é uma daquelas ferramentas de ETL que eu falei para vocês que pega dados de um lugar e traz para outros lugares. Inclusive, nesse treinamento, a base de dados que é a gente manipula é também o MySQL.

[4:51]Então esse curso aqui é um exemplo muito legal, mostrando como é que uma ferramenta de integração consegue falar com o MySQL. E aí vocês vão ver que, nesse treinamento, você acaba usando insert, update, delete, select, para fazer esses trabalhos.

[5:10] E um terceiro curso que eu aconselho é o curso de ETL e Integration Services. Integration Services é uma ferramenta da Microsoft que faz a mesma coisa que o Pentaho Data Integration.

[5:23] Apesar de ser Microsoft, ela está, digamos assim, aberta para qualquer outro banco. Então eu posso pegar dados do MySQL e colocar em outro MySQL utilzando o Integration Services. Tá legal?

[5:41] Bem, então nesse vídeo eu só queria ilustrar a vocês na prática como é que a gente trabalha com tudo aquilo que a gente aprendeu nesse treinamento. Tá lega? Então valeu, gente, um abraço.

-----------------------------------------------------------------------
# 09Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com os próximos cursos que tenham este como pré-requisito.

1) O campo do tipo auto incremento cria uma sequência numérica de números inteiros em um campo. Para definir este campo precisamos configurá-lo na criação da tabela. Logo digite o comando abaixo e execute:

```sql
CREATE TABLE TAB_IDENTITY (ID INT AUTO_INCREMENT, DESCRITOR VARCHAR(20), PRIMARY KEY(ID));
```

1) Para inserir um registro não precisamos nos referenciar ao campo auto incremento no comando **INSERT**. Digite e execute:

```sql
INSERT INTO TAB_IDENTITY (DESCRITOR) VALUES ('CLIENTE1');
```

1) Verifique o conteúdo da tabela. Digite e execute:

```sql
SELECT * FROM TAB_IDENTITY;
```

![1.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/05/1.png)

1) Abaixo vemos diversas formas de inclusão de novos registros. Digite e execute:

```sql
INSERT INTO TAB_IDENTITY (DESCRITOR) VALUES ('CLIENTE2');

INSERT INTO TAB_IDENTITY (DESCRITOR) VALUES ('CLIENTE3');

INSERT INTO TAB_IDENTITY (ID, DESCRITOR) VALUES (NULL, 'CLIENTE4');
```

1) Verifique o conteúdo da tabela. Digite e execute:

```sql
SELECT * FROM TAB_IDENTITY;
```

![2.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/05/2.png)

1) Ao apagar um registro não interrompemos a sequência do contador. veja também que, se quisermos manter o campo auto incremento no comando **INSERT** temos que referencia-lo com null para não interromper a sequência. Digite e execute:

```sql
DELETE FROM TAB_IDENTITY WHERE ID = 2;

INSERT INTO TAB_IDENTITY (ID, DESCRITOR) VALUES (NULL, 'CLIENTE5');

SELECT * FROM TAB_IDENTITY;
```

![3.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/05/3.png)

1) Caso a gente force um valor para o campo auto incremento a sequência será re- atualizada. Digite e execute:

```sql
INSERT INTO TAB_IDENTITY (ID, DESCRITOR) VALUES (100, 'CLIENTE5');

DELETE FROM TAB_IDENTITY WHERE ID = 5;

INSERT INTO TAB_IDENTITY (ID, DESCRITOR) VALUES (NULL, 'CLIENTE6');

SELECT * FROM TAB_IDENTITY;
```

![4.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/05/4.png)

1) Podemos definir padrões para os campos. Com isto um campo pode ter um valor default caso não seja referenciado no comando **INSERT**. Digite e execute:

```sql
CREATE TABLE TAB_PADRAO

(ID INT AUTO_INCREMENT,

DESCRITOR VARCHAR(20),

ENDERECO VARCHAR(100) NULL,

CIDADE VARCHAR(50) DEFAULT 'Rio de Janeiro',

DATA_CRIACAO TIMESTAMP DEFAULT CURRENT_TIMESTAMP(),

PRIMARY KEY(ID));
```

1) Padrões foram criados para o campo **ENDERECO**, **CIDADE** e **DATA_CRIACAO**. Digite e execute:

```sql
INSERT INTO TAB_PADRAO (DESCRITOR, ENDERECO, CIDADE, DATA_CRIACAO)

VALUES ('CLIENTE X', 'RUA PROJETADA A', 'SÃO PAULO', '2019-01-01');

SELECT * FROM TAB_PADRAO;
```

![5.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/05/5.png)

Aqui o comando **INSERT** funciona normalmente porque todos os campos foram referenciados.

1) Vamos repetir o comando **INSERT**, mas agora usando somente os campos que não possuem padrões. Digite e execute:

```sql
INSERT INTO TAB_PADRAO (DESCRITOR) VALUES ('CLIENTE Y');

SELECT * FROM TAB_PADRAO;
```

![6.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/05/6.png)

Note que os campos que não foram referenciados no comando **INSERT** os seus valores padrões foram incluídos na tabela.

1) Vamos criar uma tabela auxiliar que irá sempre ter o faturamento consolidado por data da venda. Execute o comando:

```sql
CREATE TABLE TAB_FATURAMENTO

(DATA_VENDA DATE NULL, TOTAL_VENDA FLOAT);
```

1) O objetivo é que, a cada inclusão de dados na tabela de **NOTAS** e **ITENS_NOTAS** o valor da **TAB_FATURAMENTO** seja atualizado. Para isso digite e execute:

```sql
INSERT INTO NOTAS (NUMERO, DATA_VENDA, CPF, MATRICULA, IMPOSTO)

VALUES ('0100', '2019-05-08', '1471156710' , '235', 0.10);

INSERT INTO ITENS_NOTAS (NUMERO, CODIGO, QUANTIDADE, PRECO)

VALUES ('0100', '1000889', 100, 10);

INSERT INTO ITENS_NOTAS (NUMERO, CODIGO, QUANTIDADE, PRECO)

VALUES ('0100', '1002334', 100, 10);


INSERT INTO NOTAS (NUMERO, DATA_VENDA, CPF, MATRICULA, IMPOSTO)

VALUES ('0101', '2019-05-08', '1471156710' , '235', 0.10);

INSERT INTO ITENS_NOTAS (NUMERO, CODIGO, QUANTIDADE, PRECO)

VALUES ('0101', '1000889', 100, 10);

INSERT INTO ITENS_NOTAS (NUMERO, CODIGO, QUANTIDADE, PRECO)

VALUES ('0101', '1002334', 100, 10);


INSERT INTO NOTAS (NUMERO, DATA_VENDA, CPF, MATRICULA, IMPOSTO)

VALUES ('0103', '2019-05-08', '1471156710' , '235', 0.10);

INSERT INTO ITENS_NOTAS (NUMERO, CODIGO, QUANTIDADE, PRECO)

VALUES ('0103', '1000889', 100, 10);

INSERT INTO ITENS_NOTAS (NUMERO, CODIGO, QUANTIDADE, PRECO)

VALUES ('0103', '1002334', 100, 10);
```

1) Para atualizarmos a tabela **TAB_FATURAMENTO** temos que executar o comando abaixo. Para isso digite e execute:

```sql
INSERT INTO TAB_FATURAMENTO

SELECT A.DATA_VENDA, SUM(B.QUANTIDADE * B.PRECO) AS TOTAL_VENDA FROM

NOTAS A INNER JOIN ITENS_NOTAS B

ON A.NUMERO = B.NUMERO

GROUP BY A.DATA_VENDA;


SELECT * FROM TAB_FATURAMENTO;
```

![7.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/05/7.png)

1) Se queremos manter a tabela **TAB_FATURAMENTO** atualizada temos que repetir sempre o cálculo atual do valor total das vendas sempre que novos registros forem incluídos. Para isso digite e execute:

```sql
INSERT INTO NOTAS (NUMERO, DATA_VENDA, CPF, MATRICULA, IMPOSTO)

VALUES ('0104', '2019-05-08', '1471156710' , '235', 0.10);

INSERT INTO ITENS_NOTAS (NUMERO, CODIGO, QUANTIDADE, PRECO)

VALUES ('0104', '1000889', 100, 10);

INSERT INTO ITENS_NOTAS (NUMERO, CODIGO, QUANTIDADE, PRECO)

VALUES ('0104', '1002334', 100, 10);


INSERT INTO NOTAS (NUMERO, DATA_VENDA, CPF, MATRICULA, IMPOSTO)

VALUES ('0105', '2019-05-08', '1471156710' , '235', 0.10);

INSERT INTO ITENS_NOTAS (NUMERO, CODIGO, QUANTIDADE, PRECO)

VALUES ('0105', '1000889', 100, 10);

INSERT INTO ITENS_NOTAS (NUMERO, CODIGO, QUANTIDADE, PRECO)

VALUES ('0105', '1002334', 100, 10);


DELETE FROM TAB_FATURAMENTO;


INSERT INTO TAB_FATURAMENTO

SELECT A.DATA_VENDA, SUM(B.QUANTIDADE * B.PRECO) AS TOTAL_VENDA FROM

NOTAS A INNER JOIN ITENS_NOTAS B

ON A.NUMERO = B.NUMERO

GROUP BY A.DATA_VENDA;


SELECT * FROM TAB_FATURAMENTO;
```

![8.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/05/8.png)

1) Podemos criar uma **TRIGGER** para que a tabela **TAB_FATURAMENTO** seja recalculada sempre que um novo registro for incluído na tabela de **ITENS_NOTAS**. Para isso digite e execute:

```sql
DELIMITER //

CREATE TRIGGER TG_CALCULA_FATURAMENTO_INSERT AFTER INSERT ON ITENS_NOTAS
FOR EACH ROW BEGIN

  DELETE FROM TAB_FATURAMENTO;

  INSERT INTO TAB_FATURAMENTO

  SELECT A.DATA_VENDA, SUM(B.QUANTIDADE * B.PRECO) AS TOTAL_VENDA FROM
  NOTAS A INNER JOIN ITENS_NOTAS B
  ON A.NUMERO = B.NUMERO
  GROUP BY A.DATA_VENDA;
END//
```

1) Ao inserir novos registros não é mais preciso executar o cálculo da tabela consolidada. Para isso digite e execute:

```sql
INSERT INTO NOTAS (NUMERO, DATA_VENDA, CPF, MATRICULA, IMPOSTO)
VALUES ('0106', '2019-05-08', '1471156710' , '235', 0.10);

INSERT INTO ITENS_NOTAS (NUMERO, CODIGO, QUANTIDADE, PRECO)
VALUES ('0106', '1000889', 100, 10);

INSERT INTO ITENS_NOTAS (NUMERO, CODIGO, QUANTIDADE, PRECO)
VALUES ('0106', '1002334', 100, 10);

SELECT * FROM TAB_FATURAMENTO;
```

![9.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/05/9.png)

1) Porém foi criado uma **TRIGGER** somente para inclusão de registros na tabela. Vamos incluir **TRIGGERS** para a atualização e exclusão. Para isso digite e execute:

```sql
DELIMITER //

CREATE TRIGGER TG_CALCULA_FATURAMENTO_UPDATE AFTER UPDATE ON ITENS_NOTAS
FOR EACH ROW BEGIN
  DELETE FROM TAB_FATURAMENTO;

INSERT INTO TAB_FATURAMENTO
  SELECT A.DATA_VENDA, SUM(B.QUANTIDADE * B.PRECO) AS TOTAL_VENDA FROM
  NOTAS A INNER JOIN ITENS_NOTAS B
  ON A.NUMERO = B.NUMERO
  GROUP BY A.DATA_VENDA;
END//
DELIMITER //

CREATE TRIGGER TG_CALCULA_FATURAMENTO_DELETE AFTER DELETE ON ITENS_NOTAS
FOR EACH ROW BEGIN
  DELETE FROM TAB_FATURAMENTO;

INSERT INTO TAB_FATURAMENTO
  SELECT A.DATA_VENDA, SUM(B.QUANTIDADE * B.PRECO) AS TOTAL_VENDA FROM
  NOTAS A INNER JOIN ITENS_NOTAS B
  ON A.NUMERO = B.NUMERO
  GROUP BY A.DATA_VENDA;
END//
```

1) Vamos incluir novos registros e verificar a tabela consolidada. Para isso digite e execute:

```sql
INSERT INTO NOTAS (NUMERO, DATA_VENDA, CPF, MATRICULA, IMPOSTO)
VALUES ('0107', '2019-05-08', '1471156710' , '235', 0.10);

INSERT INTO ITENS_NOTAS (NUMERO, CODIGO, QUANTIDADE, PRECO)
VALUES ('0107', '1000889', 100, 10);

INSERT INTO ITENS_NOTAS (NUMERO, CODIGO, QUANTIDADE, PRECO)
VALUES ('0107', '1002334', 100, 10);
SELECT * FROM TAB_FATURAMENTO;
```

1) E alterar/excluir alguns registros. Para isso digite e execute:

```sql
DELETE FROM ITENS_NOTAS WHERE NUMERO = '0107' AND CODIGO = '1002334';
UPDATE ITENS_NOTAS SET QUANTIDADE = 400
WHERE NUMERO = '0100' AND CODIGO = '1002334';
SELECT * FROM TAB_FATURAMENTO;
```

![10.png](https://cdn3.gnarususercontent.com.br/1222-mysqlmanipulacaodedados/05/10.png)


-----------------------------------------------------------------------
# 0O que aprendemos?

Nesta aula, aprendemos:

- Vimos como funciona campos de auto incremento;
- Aprendemos a determinar valores padrões para os campos;
- Foi mostrado como trabalhar com **TRIGGERs** para executar comandos no momento da inclusão, alteração e exclusão de registros.


-----------------------------------------------------------------------



-----------------------------------------------------------------------