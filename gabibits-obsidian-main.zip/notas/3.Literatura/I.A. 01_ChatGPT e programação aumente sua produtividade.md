---
type: "9"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
fonte_curso: https://cursos.alura.com.br/course/chatgpt-programacao-aumente-produtividade
---

Tópico:: #Java #JPA #Spring_Boot #chatgpt #claude #IA #Inteligencia_Artifical 


## Nessa aula, você aprendeu como:

- Utilizar o ChatGPT como ferramenta de aprendizado;
- Identificar um bug com o auxílio do ChatGPT;
- Aprender conceitos de programação por meio de perguntas ao ChatGPT.

-----------------------------------------------------------------------
## Nessa aula, você aprendeu como:

- Utilizar o ChatGPT para aprender sobre expressões regulares (regex);
- Utilizar o ChatGPT para entender cada parte de uma regex;
- Criar uma regex com o auxílio do ChatGPT.


-----------------------------------------------------------------------
## Nessa aula, você aprendeu como:

- Utilizar o ChatGPT para aprender sobre SQL;
- Utilizar o ChatGPT para explicar sobre uma consulta SQL;
- Criar uma consulta SQL de um relatório utilizando o ChatGPT.

-----------------------------------------------------------------------
## Nessa aula, você aprendeu como:

- Utilizar o ChatGPT como ferramenta de geração de códigos de testes automatizados;
- Gerar códigos de testes de unidade com o ChatGPT;
- Gerar códigos de testes de integração com o ChatGPT.

-----------------------------------------------------------------------


# 02Preparando o ambiente: instalações

O foco desse curso será na utilização do ChatGPT como ferramenta de aprendizado e de automatização de tarefas comuns no dia a dia de uma pessoa que trabalha com programação, independente da linguagem, frameworks ou tecnologias utilizadas.

Entretanto, para que o curso seja bem prático e realista, ou seja, para que se aproxime bastante da realidade de uma pessoa que trabalha com programação, utilizaremos um projeto de uma API Rest, já desenvolvido e que será disponibilizado ao longo do curso.

Para que você consiga o executar em seu computador, será necessário realizar algumas instalações que detalharemos a seguir.

**Observação importante**: O projeto do curso foi desenvolvido em Java, mas você não precisa ter conhecimentos da linguagem, pois o foco do curso não será no Java e nas tecnologias do projeto em si, mas sim na utilização do ChatGPT para auxílio em um projeto de programação. Ao longo do curso será ensinado como baixar, executar, explorar e modificar o projeto.

# Instalação do Java

Será necessário instalar o Java na versão 17. Caso você não tenha o Java instalado em seu computador, siga o passo a passo a seguir, de acordo com o seu sistema operacional:

## Linux

1) No terminal, vamos executar o seguinte comando para atualizar a lista de pacotes disponíveis para download nos repositórios do sistema:

```sql
sudo apt update
```

2) Feito isso, agora vamos instalar a versão 17 do Java com o comando:

```undefined
sudo apt install openjdk-17-jdk
```

## MacOS

1) Para instalar no Mac, podemos acessar o [site da Oracle](https://www.oracle.com/java/technologies/downloads/#jdk17-mac) ou buscar no navegador por “Java Download Oracle” e acessar o primeiro link.

2) Agora, precisamos escolher a versão do Java. Neste curso vamos utilizar o **Java 17 LTS**, por ser a versão de suporte de longo prazo mais recente para a plataforma Java SE.

![alt: Tela de download do JDK da Oracle com informações sobre o Java 19 e Java 19. Abaixo há duas opções clicáveis: “Java 19” e “Java 17”, a opção “Java 17” está destacada.](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img1.png)

3) Selecione o Mac como sistema operacional e faça o download.

![alt: Tela de download do JDK da Oracle com informações sobre o Java 17 e agradecimento. A seguir há três opções, da esquerda para direita: “Linux”, “macOS” e “Windows”, a opção “macOS” está destacada. Mais abaixo tem uma lista com opções de Download, a primeira opção “Arm 64 Compressed Archive" está destacada.](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img2.png)

## Windows

1) Para instalar no Windows, podemos acessar o [site da Oracle](https://www.oracle.com/java/technologies/downloads/#jdk17-windows) ou buscar no navegador por “Java Download Oracle” e acessar o primeiro link.

2) Agora, precisamos escolher a versão do Java. Neste curso vamos utilizar o **Java 17 LTS**, por ser a versão de suporte de longo prazo mais recente para a plataforma Java SE.

![alt: Tela de download do JDK da Oracle com informações sobre o Java 19 e Java 19. Abaixo há duas opções clicáveis: “Java 19” e “Java 17”, a opção “Java 17” está destacada.](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img1.png)

3) Selecione o Windows como sistema operacional e faça o download.

![alt: Tela de download do JDK da Oracle com informações sobre o Java 17 e agradecimento. A seguir há três opções, da esquerda para direita: “Linux”, “macOS” e “Windows”, a opção “Windows” está destacada. Mais abaixo tem uma lista com opções de Download, a última opção “x64 MSI Installer” está destacada.](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img3.png)

4) Após baixado, vamos executar o instalador e prosseguir com a instalação.

![alt: Tela do instalador do JDK na janela de seleção de pasta destinatária. No canto inferior direito tem três botões, da esquerda para a direita: "Back", "Next" e "Cancel", com destaque ao botão do centro “Next”](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img4.png)

![alt: Tela do instalador do JDK na janela de progresso da instalação com uma barra de carregamento escrito “Status: Removing files”.](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img5.png)

![alt: Tela do instalador do JDK na janela “Complete”. É mostrado que a instalação foi feita, há um botão “Next Steps” para acessar um tutorial da JDK. No canto inferior direito tem um botão “Close” destacado.](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img6.png)

# Instalação do IntelliJ

Utilizaremos a IDE IntelliJ, da empresa JetBrains.

Precisamos entrar na [página principal do IntelliJ](https://www.jetbrains.com/pt-br/idea/), onde encontraremos algo parecido com a imagem abaixo. Vamos clicar no botão "Baixar":

![alt: Imagem de um print de tela da página principal do site de referência da IDE IntelliJ. Centralizado à esquerda há informações sobre a ferramenta e logo abaixo um botão branco com o texto "Baixar", destacado em vermelho.](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img7.png)

Após clicar nesse botão, seremos levados à página de downloads da ferramenta, que apresenta opções para os sistemas Windows, Linux e MacOS em um menu que deve ser clicado baseado em seu sistema operacional. Logo abaixo do menu vemos duas opções de download, que se tratam das duas versões da IDE: a edição Ultimate e Community.

A versão Ultimate apresenta mais recursos, como suporte a mais linguagens e gerenciamento de banco de dados embutido, no entanto é paga; A edição Community é a opção gratuita da ferramenta e apresenta todos os recursos que vamos precisar durante o curso, por este motivo vamos instalar esta versão.

Para fazer o download o IntelliJ Community Edition, vamos clicar no botão "Baixar" como apresentado na imagem abaixo:

![alt: Imagem de um print de tela da página de downloads do IntelliJ IDEA. A página apresenta informações sobre o download da ferramenta. Centralizado à direita há um menu para escolher o sistema operacional utilizado e abaixo há duas colunas: à esquerda o download da versão Ultimate da ferramenta e à direita o download da versão Community, com um botão preto com o texto "Baixar" destacado em vermelho.](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img8.png)

Após clicar em "Baixar", será feito o download da ferramenta e sua instalação varia com o sistema operacional.

## Windows

No Windows será baixado o instalador da ferramenta, com nome similar a "ideaIC-2022.3.2", dependendo da versão baixada. Para iniciar a instalação, vamos executar esse arquivo.

Após executado, vai ser aberta uma janela de instalador padrão do Windows, como na imagem abaixo, onde vamos clicar no botão "Next":

![alt: Imagem de um print de tela do instalador do IntelliJ na aba de boas-vindas. São mostradas informações sobre a instalação da ferramenta. No canto inferior direito tem dois botões, da direita para a esquerda: "cancel" e "Next", este último destacado em vermelho.](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img9.png)

Que vai nos direcionar para uma página onde vamos selecionar em qual pasta será feita a instalação. Aqui nós podemos deixar no diretório padrão e novamente clicar no botão "Next", como mostrado abaixo:

![alt: Imagem de um print te dela to instalador do IntelliJ na página de seleção do local de instalação. São mostradas informações sobre como selecionar a pasta de instalação e centralizado à direita existe um botão "browse" para trocar o caminho de instalação. No canto inferior direito tem três botões, da direita para a esquerda: "cancel" e "Next" e "Back", Com destaque ao do centro.](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img10.png)

Após isso, seremos direcionados para uma tela com várias caixas de seleção, com opções de instalação da ferramenta. São opções referentes à se queremos criar um atalho no desktop, adicionar o IntelliJ ao PATH, para que possa ser acessado via linha de comando, adicionar uma nova ação ao menu de contexto, para que quando clicarmos em um arquivo com o botão direito do mouse aparece a opção de abri-lo no IntelliJ, e criar associações aos tipos de arquivo, para que eles sejam abertos diretamente na IDE.

Aqui podemos selecionar todas as caixas, como na imagem:

![alt: Imagem de um print de tela do instalador do IntelliJ na tela de seleção de opções de instalação. São mostradas diversas caixas de seleção centralizadas na tela, de cima para baixo: "Create Desktop Shortcut", "Update PATH Variable", "Update Context Menu" e "Create Associations".Todas as caixas estão selecionadas, com destaque em vermelho para a caixa com o texto ".java" na aba "Create Associations". No canto inferior direito tem três botões, da direita para a esquerda: "cancel" e "Next" e "Back", Com destaque ao do centro.](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img11.png)

Caso você não queira marcar todas as caixas, a mais importante é na aba "Create Associations", onde vamos criar as associações dos arquivos `.java` ao IntelliJ, como destacado na imagem acima. Após marcar as opções desejadas, podemos seguir clicando no botão "Next".

Após isso, vamos para a seleção da pasta do menu iniciar onde poderemos localizar a nossa IDE. Nessa tela podemos simplesmente deixar a opção padrão e clicar no botão "Install" para instalar a ferramenta no computador, como mostrado abaixo:

![alt: Imagem de um print de tela do instalador do IntelliJ na tela de seleção de pasta no menu Iniciar. É mostrada uma lista de pastas que podem ser selecionadas centralizada na tela, com a pasta "JetBrains" pré-selecionada em uma caixa de texto. No canto inferior direito tem três botões, da direita para a esquerda: "cancel" e "Next" e "Back", Com destaque ao do centro](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img12.png)

Será iniciada a instalação dos arquivos da ferramenta, o que pode demorar um tempinho. Hora de pegar um café e esperar!

Ao final da instalação, seremos direcionados a uma tela com a opção de reiniciar o computador agora ou depois. É recomendável reiniciar o computador, para que as alterações no PATH funcionem corretamente, no entanto a ferramenta já pode ser utilizada mesmo sem a reinicialização.

Por fim, podemos clicar no botão "Finish", para finalizar o instalador, como na imagem abaixo:

![alt: Imagem de um print de tela do instalador do IntelliJ na tela de finalização da instalação. São mostradas informações sobre a instalação e duas caixas de seleção centralizadas, de cima para baixo: "Reboot now" e "I want to manually reboot later". A primeira opção está selecionada. No canto inferior direito tem três botões, da direita para a esquerda: "cancel" e "Finish" e "Back", Com destaque ao do centro.](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img13.png)

## Linux

Em sistemas Linux, o arquivo baixado é um arquivo compactado já com a IDE pré-instalada. Para conseguir executá-la, precisamos navegar até a pasta onde o arquivo baixado está e descompactá-lo com o comando:

```sh
tar -xf <arquivoBaixado>.tar.gz
```

O nome do arquivo pode variar conforme a versão baixada, mas sempre segue um padrão como "ideaIC-2022.3.2.tar".

Após descompactar o arquivo, será criada uma pasta com nome similar a "idea-IC-xxx.xxx.xx" onde os "x" representam a versão da ferramenta. Para abrir a IDE, é necessário navegar até a pasta, através do comando:

```bash
cd idea-IC-xxx.xxx.xx
```

E acessar a subpasta "bin", a partir do comando:

```bash
cd bin
```

Onde está localizado o arquivo "idea.sh", que é o script de inicialização do IntelliJ. Agora, para abrir a IDE basta rodar o script com o comando:

```bash
./idea.sh
```

Que vai inicializar a ferramenta que já está pronta para ser utilizada!

## MacOS

No MacOS, assim como no Windows, é baixado um instalador com a instalação ".dmg" e a instalação é bastante simples.

Para isso, vamos navegar até a pasta de download do arquivo e executá-lo com duplo clique. Será aberta uma janela pedindo para que o ícone do IntelliJ seja arrastado até o ícone da pasta Applications, como mostrado na imagem:

![alt: Imagem de um print de tela da janela aberta após a execução do arquivo de instalação. É mostrado um ícone da ferramenta IntelliJ centralizada à esquerda seguida do texto "dragTo", apontando para o ícone da pasta "Applications" do sistema.](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img14.png)

Após arrastar, vai ser iniciado o processo de cópia de arquivos e a IDE será instalada. Ao término da instalação basta pesquisar no menu de pesquisa por "IntelliJ" e executar o programa "IntelliJ IDEA CE”.

# Instalação do Postman

Utilizaremos o Postman como ferramenta para testes da API. Caso você não o tenha instalado em seu computador, confira nesse [artigo sobre como realizar a instalação do Postman](https://www.alura.com.br/artigos/postman-como-instalar-dar-seus-primeiros-passos).

# Instalação do MySQL

Utilizaremos o MySQL como banco de dados da aplicação. Caso você não o tenha instalado em seu computador, confira nesse [artigo sobre como realizar a instalação do MySQL](https://www.alura.com.br/artigos/mysql-do-download-e-instalacao-ate-sua-primeira-tabela).

-----------------------------------------------------------------------
# 03Preparando o ambiente: projeto do curso

Após a instalação do Java, IntelliJ, Postman e MySQL, já podemos baixar e configurar o projeto do curso.

O [projeto inicial do curso](https://github.com/alura-cursos/3177-chatgpt-programacao/archive/refs/heads/projeto_inicial.zip) deve ser baixado e descompactado em algum diretório do seu computador.

Após isso, importe o projeto no IntelliJ clicando no botão **open** (ou pelo menu superior **File -> Open…**) e escolhendo o diretório no qual você o descompactou.

![Alt text: Tela inicial do IntelliJ após o projeto do curso ser importado. À esquerda da tela, na aba project, deve aparecer a estrutura de arquivos e diretórios do projeto](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img15.png)

O próximo passo será importar no Postman as requisições que serão disparadas para realizar os testes na API.

Baixe os [arquivos json das requisições](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/requisicoes-postman.zip) e descompacte o zip em algum diretório do seu computador.

Agora, na tela inicial do Postman, clique no menu superior File e escolha a opção Import…

![Alt text: Tela inicial de importação de arquivos no Postman](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img16.png)

Na janela que foi aberta, clique no botão Upload Files e escolha todos os arquivos .json baixados.

![Alt text: Tela de importação no Postman listando os arquivos selecionados](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img17.png)

Clique no botão Import para realizar a importação e a seguinte tela deve ser exibida:

![Alt text: Tela principal do Postman com as coleções de requisições importadas](https://cdn3.gnarususercontent.com.br/3177-chatgpt-programacao/aula1-img18.png)

Prontinho! Na sequência veremos como executar a aplicação e explorar suas funcionalidades, disparando requisições pelo Postman.


-----------------------------------------------------------------------
# 04Identificando um bug

interface, então testaremos por meio de algum aplicativo de testes de API. Nesse caso, o _**Postman**_.

O instrutor já importou as coleções com as requisições. São elas:

- Agenda Consultas
- CRUD Médicos
- CRUD Pacientes
- Relatórios

Estamos trabalhando no projeto de uma clínica médica. Na coleção de CRUD de **médicos**, temos as requisições referentes às funcionalidades de médicos, que são: "Cadastrar médico", "Listar médicos", "Detalhar médico", "Atualizar médico", e "Excluir médico".

Além disso, temos um CRUD de **pacientes**, com as mesmas funcionalidades; uma parte de **relatórios**, que contém somente 1 relatório; e a parte de **agendamento de consultas**, contendo duas requisições.

Essa é a aplicação e suas funcionalidades!

## Identificando bugs

No Postman, conseguimos simular e testar a API.

Vamos começar, por exemplo, com o teste de cadastro de paciente. Para isso, acessamos a coleção "CRUD Pacientes" e abrimos a requisição do tipo POST "Cadastrar paciente".

```json
{
    "nome": "Paciente 1",
    "email": "paciente1@email.com",
    "cpf": "123.123.123-00",
    "telefone": "61999998888",
    "endereco": {
        "logradouro": "Rua",
        "bairro": "Bairro",
        "cep": "12345678",
        "cidade": "Cidade",
        "uf": "UF",
        "numero": "1",
        "complemento": "Complemento"
    }
}
```

Na seção direita do Postman, são exibidos os detalhes da requisição. Na barra de endereços, temos o "localhost:8080/pacientes", e no corpo da requisição (aba "_Body_"), temos um JSON representando os dados que serão enviados para a aplicação.

Estamos basicamente cadastrando um novo paciente, então temos campos como `nome`, `email`, `cpf`, `telefone`, e os dados de `endereco`.

Vamos clicar no botão azul "_**Send**_", à direita da barra de endereço, para disparar a requisição. Feito isso, será aberta uma barra inferior contendo a resposta devolvida pelo servidor, nesse caso, "_**201 Created**_".

Será devolvido também o corpo da resposta. No caso, a API devolveu um JSON com os dados do paciente recém-cadastrado:

```json
{
    "id": 1,
    "ativo": true,
    "nome": "Paciente 1",
    "email": "paciente1@email.com",
    "cpf": "123.123.123-00",
    "telefone": "61999998888",
    "endereco": {
        "logradouro": "Rua",
        "bairro": "Bairro",
        "cep": "12345678",
        "numero": "1",
        "complemento": null,
        "cidade": "Cidade",
        "uf": "UF"
    }
}
```

Nesse momento, já identificamos um problema: observando os dados cadastrados no corpo da requisição, preenchemos todas as informações; porém, no retorno do servidor, o campo `complemento` do endereço foi devolvido com o valor `null`.

Então, temos um bug no nosso código. Podemos usar o ChatGPT para identificar onde ele está!

Com a ferramenta aberta no navegador, vamos utilizá-la para resolver o problema. O ideal é fazer uma pergunta bastante objetiva e detalhada para o ChatGPT, para que ele consiga nos auxiliar da melhor maneira possível.

Podemos explicar o contexto e solicitar ajuda da seguinte forma:

> Tenho uma aplicação desenvolvida em Java, utilizando o framework Spring Boot, com uma funcionalidade de cadastro de pacientes que está com um bug. Poderia me auxiliar na detecção desse bug?

Geralmente, o ChatGPT é bastante simpático e aberto, então foi obtida a mensagem abaixo:

> Claro, ficarei feliz em ajudar você a encontrar o bug em sua aplicação Java com o Spring Boot. Por favor, forneça mais informações sobre o problema em questão. Descreva o comportamento indesejado que está ocorrendo e inclua qualquer mensagem de erro ou trecho de código relevante. Quanto mais detalhes você puder fornecer, melhor será a minha compreensão do problema e mais precisa será minha assistência.

Agora, sim, forneceremos os detalhes. Começamos com o contexto inicial, então nessa segunda etapa já podemos colar o código e pedir para que a ferramenta tente encontrar o erro.

Retornando ao IntelliJ, vamos buscar pelo método de cadastro de paciente. Ele está localizado na linha de código 29 do arquivo `PacienteController.java`:

```java
@PostMapping
@Transactional
public ResponseEntity<DadosDetalhamentoPaciente> cadastrar(@RequestBody @Valid DadosCadastroPaciente dados, UriComponentsBuilder uriBuilder) {
    var detalhesPaciente = service.cadastrar(dados);
    var uri = uriBuilder.path("/pacientes/{id}").buildAndExpand(detalhesPaciente.id()).toUri();
    return ResponseEntity.created(uri).body(detalhesPaciente);
}
```

Com o código copiado, vamos retornar ao ChatGPT e colar o trecho no campo de perguntas. Em seguida, vamos pressionar "Shift" e teclar "Enter" para dar um espaço após o código.

Além do método, precisamos levar também o restante das classes do projeto, para que o ChatGPT possa analisar. O método `cadastrar()` recebe como parâmetro a classe `DadosCadastroPaciente`. Ela é muito importante, pois o ChatGPT precisará analisá-la para tentar identificar o problema.

Então, vamos copiar todo o código da classe, presente no arquivo `DadosCadastroPaciente.java`, e colar logo abaixo do método no campo da pergunta.

```java
public record DadosCadastroPaciente(
        @NotBlank
        String nome,
    
        @NotBlank
        @Email
        String email,

        @NotBlank
        @Pattern(regexp = "^(\\(\\d{2}\\)|\\d{2})\\s?\\d{4,5}-?\\d{4}$")
        String telefone,
    
        @NotBlank
        @Pattern(regexp = "\\d{3}\\.?\\d{3}\\.?\\d{3}\\-?\\d{2}")
        String cpf,

        @NotNull @Valid 
        DadosEndereco endereco) {
}
```

A classe `DadosCadastroPaciente` é composta por outra classe, a `DadosEndereco`, localizada no arquivo `DadosEndereco.java`. Também iremos colá-la no ChatGPT.

```java
public record DadosEndereco(
        @NotBlank
        String logradouro,
    
        @NotBlank
        String bairro,
    
        @NotBlank
        @Pattern(regexp = "\\d{8}")
        String cep,
        
        @NotBlank
        String cidade,
        
        @NotBlank
        String uf,
        
        String complemento,
        String numero) {
}
```

Com essas 3 classes, a ferramenta deve conseguir identificar o bug. Caso contrário, ela irá solicitar mais códigos.

A princípio, obtivemos a seguinte resposta:

> Obrigado por compartilhar o código. Vou analisar e tentar identificar possíveis problemas ou bugs.
> 
> À primeira vista, o código parece estar correto. No entanto, alguns detalhes estão faltando para entender completamente o contexto e a natureza do bug que você está enfrentando.
> 
> 1. Você poderia fornecer mais informaçõe sobre o comportamento indesejado ou o erro específico que está ocorrendo quando você tenta cadastrar um paciente? Isso ajudará a direcionar minha análise.
> 2. Além disso, você pode fornecer o código da classe `service` onde o método `cadastrar` está implementado? Isso me ajudaria a entender melhor o fluxo de trabalho e verificar se há algum problema nessa parte do código.
> 3. Certifique-se de que todas as dependências necessárias estão corretamente configuradas no arquivo `pom.xml`. Se houver algum problema de configuração ou incompatibilidade entre as versões das bibliotecas, isso pode causar erros ou comportamento indesejado.
> 
> Por enquanto, com base no código fornecido, não parece haver erros óbvios. O método `cadastrar` no controlador Spring Boot parece receber dados de cadastro de pacientes, validar as entradas usando as anotações do Bean Validation e, em seguida, chamar o método `cadastrar` no serviço correspondente. O resultado desse cadastro é retornado como uma resposta HTTP 201 (Created) com o URI do paciente recém-criado.
> 
> Por favor, forneça as informações adicionais solicitadas para que eu possa ajudá-lo de maneira mais efetiva a resolver o problema.

Conforme solicitado pelo ChatGPT, vamos informar onde está o bug que buscamos:

> O bug está no campo `complemento` do endereço, que está sendo enviado no JSON, porém está sendo salvo como `null`.

Com essa informação, a ferramenta encontra o problema:

> Obrigado por fornecer mais informações sobre o bug. Com base na sua descrição, o problema parece estar relacionado ao campo "complemento" do objeto `DadosEndereco` não sendo persistido corretamente. Vamos verificar algumas possíveis causas:
> 
> 1. Certifique-se de que o campo "complemento" esteja sendo enviado corretamente no JSON da requisição. Verifique se o nome do campo no JSON está correspondendo exatamente ao nome do atributo na classe `DadosEndereco`.
> 2. Verifique se o campo "complemento" está configurado corretamente como um parâmetro opcional no construtor do `DadosEndereco` e se está sendo atribuído corretamente ao atributo correspondente.
> 3. Verifique se a tabela do banco de dados que armazena os dados dos pacientes possui uma coluna correspondente ao campo "complemento". Se não houver uma coluna para o campo "complemento", pode ser necessário atualizar o esquema do banco de dados para refletir essa alteração.
> 4. Certifique-se de que o mapeamento do objeto `DadosEndereco` para a tabela do banco de dados esteja configurado corretamente. Verifique se o mapeamento das colunas está alinhado com os nomes e tipos dos atributos da classe `DadosEndereco`.
> 
> Se nenhuma dessas sugestões resolver o problema, seria útil fornecer o código da classe `service` onde o método `cadastrar` está implementado. Isso ajudaria a identificar se há alguma lógica adicional que possa estar causando o comportamento indesejado.
> 
> Além disso, verificar os logs e possíveis mensagens de erro relacionados à persistência dos dados também pode ser útil para entender melhor o problema específico que você está enfrentando.

O ChatGPT informa que, com base na informação sobre o bug, foi identificado que o campo `complemento` está no objeto `DadosEndereco`, então vamos verificar esse objeto específico no IntelliJ.

No arquivo `DadosEndereco.java`, temos a classe `DadosEndereco`, que representa o JSON enviado no Postman. Retornando ao Postman, temos o envio do JSON como requisição, contendo os dados do paciente. Porém, dentro dele há outro objeto que representa os dados do endereço.

```json
// Código suprimido

"endereco": {
    "logradouro": "Rua",
    "bairro": "Bairro",
    "cep": "12345678",
    "cidade": "Cidade",
    "uf": "UF",
    "numero": "1",
    "complemento": "Complemento"
}
```

Esse trecho específico, contendo os dados do endereço, está sendo mapeado para a classe `DadosEndereco`. Mas em algum lugar desse código está o problema, justamente no caso do complemento. Como enviamos um texto como complemento e o retorno foi nulo, esse campo não foi enviado ou não chegou corretamente.

Analisando esse trecho no código do IntelliJ, o erro está na digitação da String, que deveria ser `complemento` e está escrita como `complemeto`. No código Java, o nome do campo está diferente do nome enviado no JSON, porém eles precisam ser iguais.

Com o arquivo `DadosEndereco.java` aberto, vamos clicar com o botão direito sobre `complemeto` e ir até "Refactor > Rename…". Será aberta uma janela onde iremos renomear a String como para `complemento`. Dessa forma, a renomeação irá acontecer também no restante do projeto.

Vamos verificar a aba "Run". Se a configuração estiver correta, ao mexer no código, o projeto será reinicializado.

> Para conferir se a configuração está correta, podemos usar o atalho "Ctrl + Alt + S" para abrir a janela "_Settings_" e acessar "Build, Execution, Deployment > Compiler". A opção "Build project automatically" deve estar **ativada**.

Finalizada a mudança, vamos retornar o Postman. Agora, precisaremos cadastrar outro paciente, pois há uma regra no projeto que não nos permite cadastrar dois paciente com o mesmo nome, email e CPF. Então, cadastraremos o seguinte:

```json
{
    "nome": "Paciente 2",
    "email": "paciente2@email.com",
    "cpf": "333.333.333-00",
    "telefone": "61999998888",
    "endereco": {
        "logradouro": "Rua",
        "bairro": "Bairro",
        "cep": "12345678",
        "cidade": "Cidade",
        "uf": "UF",
        "numero": "1",
        "complemento": "Complemento"
    }
}
```

Note que estamos enviando o complemento normalmente, da mesma forma que fizemos antes. Disparada a requisição, teremos o seguinte retorno:

```json
{
    "id": 2,
    "ativo": true,
    "nome": "Paciente 2",
    "email": "paciente2@email.com",
    "cpf": "333.333.333-00",
    "telefone": "61999998888",
    "endereco": {
        "logradouro": "Rua",
        "bairro": "Bairro",
        "cep": "12345678",
        "numero": "1",
        "complemento": "Complemento",
        "cidade": "Cidade",
        "uf": "UF"
    }
}
```

Agora o complemento foi salvo corretamente!

Perceba que usamos o ChatGPT para nos auxiliar, indicando o problema e enviando o código necessário para identificar o bug.

Eventualmente, a ferramenta passará a perceber que existe algum erro de digitação. Mas nem sempre ela conseguirá detectar logo a princípio. Nesse caso, podemos dar dicas, detalhar melhor, colar novamente apenas trechos específicos do código, entre outras ações.

Fica uma lição importante: o ChatGPT é uma ferramenta que **irá nos auxiliar, não nos substituir**. Além disso, a ferramenta comete erros.

Nem sempre a resposta será a melhor possível, e nem sempre será retornado um código correto, então cabe a nós **avaliarmos a resposta** e usar as dicas dadas pela IA, em vez de simplesmente copiar e colar qualquer código trazido como solução.

## Conclusão

Esse é um dos usos possíveis do ChatGPT em programação: **identificação de bugs**. Se você tem um projeto (independentemente da linguagem de programação, das tecnologias e dos frameworks), existe algum bug, e está complicado encontrar a origem apenas analisando o código, ou deseja agilizar esse processo, basta perguntar para o ChatGPT!

Primeiro, tente explicar a tecnologia, a funcionalidade, e o bug. Em seguida, você pode colar o código para que a ferramenta faça sua análise. Talvez seja apontado diretamente o problema, ou talvez sejam dadas dicas, como aconteceu no nosso caso.

Podemos usar o ChatGPT para muitas outras coisas. **Veremos na sequência!**

 [](https://cursos.alura.com.br/forum/curso-chatgpt-programacao-aumente-produtividade/exercicio-identificando-um-bug/131235/novo)

-----------------------------------------------------------------------
# 05Entendendo um código

## Transcrição

No último vídeo, aprendemos a identificar bugs com o auxílio do ChatGPT. Agora daremos continuidade a isso, explorando outras maneiras possíveis de utilizar essa ferramenta para nos ajudar no dia a dia de programação.

## Entendendo um código

Vamos retornar ao Postman, onde estamos fazendo os testes da nossa API. Já disparamos algumas requisições para cadastrar médico e cadastrar paciente.

Na funcionalidade de listagem de pacientes (método **GET** "Listar pacientes"), temos o paciente de `id` 1 e o de `id` 2.

Já na funcionalidade de listagem de médicos (método **GET** "Listar médicos"), temos um médico de `id` 1, com as informações de `nome`, `email`, `crm` e `especialidade`.

> _Listar pacientes:_

```json
{
    "content": [
        {
            "id": 1,
            "ativo": true,
            "nome": "Paciente 1",
            "email": "paciente1@email.com",
            "cpf": "123.123.123-00"
        },
        {
            "id": 2
            "ativo": true,
            "nome": "Paciente 2",
            "email": "paciente2@email.com",
            "cpf": "333.333.333-00"
        }
}
```

> _Listar médicos:_

```json
{
    "content": [
        {
            "id": 1,
            "ativo": true,
            "nome": "Médico 1",
            "email": "medico1@voll.med",
            "crm": "123456",
            "especialidade": "CARDIOLOGIA"
        },
    ]

// Código suprimido
```

Além dessas funcionalidades, temos outra muito interessante: a de marcação de consulta (método **POST** "Marcar consulta"). Como ela funciona? Nós disparamos uma requisição levando 3 informações: o ID do paciente (`idPaciente`), o ID do médico (`idMedico`), e a data (`data`), que deve estar no formato "ANO-MÊS-DIATHORA:MINUTO".

```json
{
    "idPaciente": 1,
    "idMedico": 1,
    "data": "2025-10-11T10:00"
}
```

Vamos disparar a requisição acima. Será devolvido o código **200 OK**, indicando que a requisição foi processada, e teremos o seguinte corpo da resposta:

```json
{
    "id": 1,
    "idMedico": 1,
    "idPaciente": 1,
    "data": "2025-10-10T10:00:00"
}
```

Foi marcada a consulta, cujo `id` é 1, pois é a primeira consulta do nosso banco de dados.

A princípio, não identificamos nenhum bug. Porém, vamos analisar o código dessa funcionalidade. Como será que ela foi implementada?

Como não estamos falando nem de médico nem de paciente, vamos acessar o arquivo `ConsultaController.java`, da classe `ConsultaController`.

Essa é a classe que recebe as requisições da rota "/consultas", e ela contém o método `agendar()`, notado com `@PostMapping`, ou seja, com a requisição POST, caímos nesse método específico.

```java
// Código suprimido

@PostMapping
@Transactional
public ResponseEntity<DadosDetalhamentoConsulta> agendar(@RequestBody @Valid DadosAgendamentoConsulta dados) {
    var detalhesAgendamento = agendaConsultas.agendar(dados);
    return ResponseEntity.ok(detalhesAgendamento);
}

// Código suprimido
```

Esse é o método chamado quando disparamos a requisição no Postman. Ele recebe como parâmetro um objeto do tipo `DadosAgendamentoConsulta`. Vamos pressionar a tecla "Ctrl" e clicar sobre ele para abrir essa classe específica no seu respectivo arquivo (`DadosAgendamentoConsulta.java`).

```java
public record DadosAgendamentoConsulta(
        Long idMedico,

        @NotNull
        Long idPaciente,

        @NotNull
        @Future
        LocalDateTime data,

        Especialidade especialidade) {
}
```

A classe `DadosAgendamentoConsulta` representa o JSON enviado na requisição. Então, ela contém basicamente os campos presentes no arquivo JSON do Postman: `idMedico`, `idPaciente`, `data`, e `especialidade` (opcional).

Retornando ao arquivo `ConsultaControloler.java`, no mesmo método `agendar()`, identificamos que o agendamento propriamente dito, isto é, a regra de negócio, o algoritmo, não está contido na classe _controller_.

Nesse caso, o controller chama o objeto `agendaConsultas` seguido do método `agendar()` passando os `dados` entre parênteses.

É no método `agendar()` da outra classe `agendaConsultas` que está o algoritmo. Vamos pressionar "Ctrl" novamente e clicar sobre esse método para acessá-lo na respectiva classe (arquivo `AgendaConsultaService.java`).

```java
@Service
public class AgendaConsultaService {

    @Autowired
    private ConsultaRepository consultaRepository;

    @Autowired
    private MedicoRepository medicoRepository;

    @Autowired
    private PacienteRepository pacienteRepository;

    @Autowired
    private List<ValidadorAgendamentoConsulta> validadoresAgendamento;

    public DadosDetalhamentoConsulta agendar(DadosAgendamentoConsulta dados) {
        if (!pacienteRepository.existsById(dados.idPaciente())) {
            throw new ValidacaoException("Id do paciente informado não existe!");
        }

        if (dados.idMedico() != null && !medicoRepository.existsById(dados.idMedico())) {
            throw new ValidacaoException("Id do médico informado não existe!");
        }

        validadoresAgendamento.forEach(v -> v.validar(dados));

        var paciente = pacienteRepository.getReferenceById(dados.idPaciente());
        var medico = escolherMedico(dados);
        if (medico == null) {
            throw new ValidacaoException("Não existe médico disponível nessa data!");
        }

        var consulta = new Consulta(medico, paciente, dados.data());
        consultaRepository.save(consulta);

        return new DadosDetalhamentoConsulta(consulta);
    }

    private Medico escolherMedico(DadosAgendamentoConsulta dados) {
        if (dados.idMedico() != null) {
            return medicoRepository.getReferenceById(dados.idMedico());
        }

        if (dados.especialidade() == null) {
            throw new ValidacaoException("Especialidade é obrigatória quando médico não for escolhido!");
        }

        return medicoRepository.escolherMedicoAleatorioLivreNaData(dados.especialidade(), dados.data());
    }

}
```

Nesse arquivo, temos a classe `AgendaConsultaService`, que contém o serviço de agendamento de consultas. O método `agendar()`, por sua vez, tem o algoritmo necessário para fazer o agendamento de consultas. **Vamos tentar entender o que faz o código do método?**

Primeiro, ele chama o `pacienteRepository`, quem acessa a tabela no banco de dados de paciente. Depois ele verifica se existe um paciente com o ID enviado, com o método `existsById()`. Se não for encontrado, é lançada uma `ValidacaoException` para interromper a requisição.

O mesmo processo é feito para validar o ID do médico (`idMedico`).

Em seguida, é chamada uma lista de validadores de agendamento, usando o método `forEach()` junto a `validadoresAgendamento`. Ele valida o agendamento passando os dados (`v -> v.validar(dados))`)

Depois é recuperado o `paciente` do banco de dados e escolhido o `medico`. Se o médico for nulo (`if (medico == null)`), será lançado um erro informando que não existe médico disponível na data selecionada.

Caso contrário, será criada a variável `consulta`, a qual ficará salva no banco de dados (`consultaRepository.save(consulta)`), e serão devolvidas as informações que serão retornadas como JSON para o Postman ou para quem disparar a requisição.

Vamos imaginar o seguinte cenário: não foi você quem escreveu esse código; foi outra pessoa da sua equipe que desenvolveu e você o abriu para dar manutenção, fazer ajustes. Agora, considere que você não entendeu tão bem o algoritmo.

Essa é uma situação comum quando analisamos códigos de outras pessoas. Nesse caso, podemos usar o ChatGPT para nos explicar! Podemos simplesmente colar o código e pedir para a ferramenta explicar o que o código faz a cada linha. Dessa forma, ela detalha passo a passo.

Essa é outra forma de utilizar o ChatGPT: como uma **ferramenta de aprendizado**, para entender trechos de códigos de bibliotecas, de frameworks, ou de outras pessoas, seja do seu time ou de outros.

Nesse momento, podemos continuar usando o mesmo chat de antes, pois ele já terá o contexto do projeto, então não precisaremos informar novamente. Basta continuar a conversa!

Vamos fornecer o contexto da próxima pergunta:

> Agora outra dúvida. Tenho outra funcionalidade nesse mesmo projeto que faz o agendamento de consultas, mas eu não entendi o código. Posso colar o código e você me explica linha por linha o que ele faz?

Teremos uma resposta como a seguinte:

> Claro, vou ajudar você a entender o código da funcionalidade de agendamento de consultas. Por favor, cole o código aqui para que eu possa analisá-lo e explicar linha por linha o que cada parte faz.

Vamos retornar ao arquivo `AgendaConsultaService.java` no IntelliJ e copiar tanto o método `agendar()` quanto o método `escolherMedico()`, método **privado** que está sendo chamado pelo método de agendamento. Se não levarmos ele para a pergunta, a ferramenta não conseguirá entender o código completamente.

```java
public DadosDetalhamentoConsulta agendar(DadosAgendamentoConsulta dados) {
    if (!pacienteRepository.existsById(dados.idPaciente())) {
        throw new ValidacaoException("Id do paciente informado não existe!");
    }

    if (dados.idMedico() != null && !medicoRepository.existsById(dados.idMedico())) {
        throw new ValidacaoException("Id do médico informado não existe!");
    }

    validadoresAgendamento.forEach(v -> v.validar(dados));

    var paciente = pacienteRepository.getReferenceById(dados.idPaciente());
    var medico = escolherMedico(dados);
    if (medico == null) {
        throw new ValidacaoException("Não existe médico disponível nessa data!");
    }

    var consulta = new Consulta(medico, paciente, dados.data());
    consultaRepository.save(consulta);

    return new DadosDetalhamentoConsulta(consulta);
}

private Medico escolherMedico(DadosAgendamentoConsulta dados) {
    if (dados.idMedico() != null) {
        return medicoRepository.getReferenceById(dados.idMedico());
    }

    if (dados.especialidade() == null) {
        throw new ValidacaoException("Especialidade é obrigatória quando médico não for escolhido!");
    }

    return medicoRepository.escolherMedicoAleatorioLivreNaData(dados.especialidade(), dados.data());
}
```

Enviado esse código como próxima pergunta, teremos como resposta a análise do código, explicando-o linha por linha.

> Vou explicar o código linha por linha para ajudar você a entender a funcionalidade de agendamento de consultas. Aqui está a explicação:
> 
> ```java
> public DadosDetalhamentoConsulta agendar(DadosAgendamentoConsulta dados) {
>     if (!pacienteRepository.existsById(dados.idPaciente())) {
>         throw new ValidacaoException("Id do paciente informado não existe!");
>     }
> ```
> 
> Nessa parte, o método `agendar` recebe um objeto `DadosAgendamentoConsulta` como parâmetro. Ele verifica se o ID do paciente fornecido existe no repositório de pacientes. Caso não exista, é lançada uma exceção do tipo `ValidacaoException` com uma mensagem informando que o ID do paciente não existe.

Inicialmente, a ferramenta explicou o que faz o primeiro trecho de código, correspondente à assinatura do método.

Em seguida, temos o segundo trecho de código e sua respectiva explicação:

> ```java
> if (dados.idMedico() != null && !medicoRepository.existsById(dados.idMedico())) {
>     throw new ValidacaoException("Id do médico informado não existe!");
> }
> ```
> 
> Aqui, é verificado se o ID do médico foi fornecido. Se foi fornecido e o ID do médico não existe no repositório de médicos, é lançada uma exceção do tipo `ValidacaoException` informando que o ID do médico não existe.

Para a linha dos validadores também há uma explicação:

> ```java
> validadoresAgendamento.forEach(v -> v.validar(dados));
> ```
> 
> Essa linha executa uma sequência de validadores de agendamento, que foram previamente definidos e armazenados na lista `validadoresAgendamento`. Cada validador é aplicado ao objeto dados passado como parâmetro.

Esse mesmo processo é feito linha a linha até o final do código.

A resposta tem um limite de caracteres, então o texto ficou incompleto. Porém, temos a opção de continuar gerando a resposta (botão "_Continue generating_"). Ao final, será retornada uma mensagem como a seguinte:

> Espero que essa explicação ajude você a entender o código de agendamento de consultas. Se você tiver mais alguma dúvida, fique à vontade para perguntar.

Conforme dito anteriormente, essa é uma situação bastante comum para quem trabalha com programação, independentemente da linguagem, da tecnologia, das bibliotecas e frameworks utilizados. Geralmente, não trabalhamos individualmente em projetos. Eles são complexos, têm várias funcionalidades, e trabalharemos com outras pessoas.

Nesse contexto, é comum precisar observar e fazer manutenções em códigos desenvolvidos por pessoas diferentes do seu time. Pode ser que a pessoa responsável pelo código não esteja disponível para tirar dúvidas no momento, então a ferramenta do ChatGPT pode ser útil!

Caso houver mais dúvidas, ainda podemos complementar a pergunta, indicando algum trecho específico que talvez não tenha sido tão bem-explicado. Também podemos colar outras partes do código, de classes diferentes.

## Conclusão

Assim, conhecemos mais uma utilidade super importante do ChatGPT para quem trabalha com programação. Você pode usar essa ferramenta para **entender um código**, seja do seu projeto ou de alguma biblioteca externa que esteja utilizando e queira entender melhor o que ela faz.

> Outra situação semelhante: você está trabalhando em um projeto com determinada tecnologia e precisará migrar para outra, trocar o framework e a linguagem de programação. Nesse caso, você quer entender melhor como determinado trecho de código funciona nessa tecnologia nova. O ChatGPT pode te auxiliar nesse processo! Ele pode até mesmo ajudar na própria migração.

Descobrimos uma nova funcionalidade muito interessante para a ferramenta, que já temos o costume de fazer, porém, usando o _Google_, o _Stack Overflow_, o _YouTube_… Podemos concentrar todos esses estudos e aprendizados de código no ChatGPT.

Na sequência, aprenderemos outras formas de usar essa ferramenta no nosso dia a dia!


-----------------------------------------------------------------------
# 06Aprendendo conceitos

## Transcrição

Vamos dar continuidade aos nossos estudos usando o ChatGPT?

## Aprendendo conceitos

Ainda no chat que usamos no último vídeo para entender melhor o código, há outra coisa que podemos fazer e que está relacionada ao aprendizado: **reforçar conceitos** de programação.

Quando a ferramenta explicava o código linha a linha, ela passou pelo trecho dos validadores de agendamento, que fazia um loop e iterava pelas validações.

```java
validadoresAgendamento.forEach(v -> v.validar(dados));
```

Você pode estar se perguntando, por exemplo: será que esse tipo de código implementa algum padrão de projeto? Algum princípio de orientação a objetos? Ou princípios como o _solid_?

Nesse caso, podemos perguntar para o ChatGPT se existe, nesse trecho específico, algum padrão que não conseguimos identificar. Além disso, se quisermos reforçar esse conhecimento, podemos pedir para que a ferramenta detalhe e explique melhor esse padrão, até mesmo usando exemplos diferentes do que trouxemos.

Então, também podemos usar o ChatGPT com a funcionalidade de aprender ou reforçar algum conceito de programação, usando ou não um código.

No mesmo chat, faremos a seguinte pergunta:

> No trecho de código que itera pela lista de validadores, existe algum padrão de projeto ou princípio sendo implementado?

Para o instrutor, foi retornada a resposta abaixo:

> Sim, o trecho de código que itera pela lista de validadores segue o padrão de projeto chamado "Padrão de Projeto _Chain of Responsibility_" (Corrente de Responsabilidade). Esse padrão de projeto é utilizado quando se tem uma cadeia de objetos que podem processar uma requisição sequencialmente, até que um deles seja capaz de lidar com a requisição.
> 
> No seu código, a lista `validadoresAgendamento` contém uma sequência de objetos validadores, e a chamada `validadoresAgendamento.forEach(v -> v.validar (dados))` percorre essa lista, invocando o método "validar (dados) em cada objeto validador.
> 
> Cada validador é responsável por verificar se os dados de agendamento estão de acordo com alguma regra específica. Caso um validador identifique uma inconsistência, ele pode lançar uma exceção `ValidacaoException` para indicar que a validação falhou.
> 
> Dessa forma, o padrão Chain of Responsibility permite que vários validadores sejam aplicados sequencialmente a um objeto de dados até que um deles identifique uma violação de validação ou até que todos os validadores tenham sido executados sem lançar exceções.
> 
> Esse padrão ajuda a manter um código modular, permitindo adicionar ou remover validadores facilmente e evitando acoplamento excessivo entre os validadores.
> 
> Portanto, no seu código, o uso do padrão Chain of Responsibility permite a aplicação de uma sequência de validadores de agendamento de consultas para garantir a conformidade dos dados antes de prosseguir com o agendamento da consulta.

Perceba que suspeitávamos que o código tinha algum padrão, alguma prática, algum princípio, mas não tínhamos certeza. Então, usamos o mesmo chat, que já contém todo o contexto anterior do código, para fazer a pergunta e confirmar nossa suposição.

Na sequência, poderíamos usar a ferramenta para reforçar o conteúdo:

> Poderia me dar outro exemplo de aplicação desse padrão de projeto?

O ChatGPT continuará respondendo conforme solicitado:

> Claro! Aqui está um exemplo de aplicação do padrão Chain of Responsibility em um contexto diferente:
> 
> Suponha que você esteja desenvolvendo um sistema de suporte técnico, onde diferentes níveis de suporte são responsáveis por lidar com diferentes tipos de solicitações de suporte. Nesse cenário, o padrão Chain of Responsibility pode ser útil para encadear os diferentes níveis de suporte e direcionar as solicitações corretamente.
> 
> Vamos ver como seria a implementação simplificada desse exemplo:
> 
> ```java
> // Classe abstrata que representa o nível de suporte
> abstract class NivelSuporte {
>     private NivelSuporte proximo;
> 
>     public void setProximo (NivelSuporte proximo) {
>         this.proximo = proximo;
>     }
> 
>     public void lidarComSolicitacao (Solicitacao suporte) {
>         if (podeLidarComSolicitacao (suporte)) { 
>             processarSolicitacao (suporte);
>         } else if (proximo != null) {
>             proximo.lidarComSolicitacao (suporte);
>         } else {
> 
> // Código suprimido
> ```

Nós também poderíamos fazer a pergunta usando outro tipo de código, para obter mais detalhamentos e exemplos diferentes.

No caso acima, o próprio ChatGPT trouxe um novo exemplo. Ele traz um trecho de código, explica esse trecho, e explica também o padrão identificado anteriormente no código da funcionalidade de agendamento de consultas.

Nessa linha de aprendizado, aprendemos uma nova forma de usar o ChatGPT. Podemos utilizá-lo para entender algum trecho de código, conforme abordado no vídeo anterior, ou para aprender sobre algum conceito, conforme visto nesse vídeo.

Seja para aprender sobre padrão de projeto, para identificar padrões em determinado código, ou para reforçar algum conhecimento específico, independentemente de qual for o conhecimento (referente a linguagem de programação, a bibliotecas, a frameworks, a padrões de projeto, a boas práticas…), **podemos perguntar para o ChatGPT**!

Ele irá detalhar e explicar, inclusive com exemplos em códigos. Com isso, conseguimos reforçar nosso aprendizado.

## Conclusão

Nessa aula, fechamos com 3 primeiros casos de uso do ChatGPT para programação:

> - Identificar bugs em um código, utilizando-o também para auxiliar no processo de correção do problema;
> - Como ferramenta de aprendizado para entender melhor um código;
> - E também como ferramenta de aprendizado para conhecer conceitos e reforçar conhecimentos.

Na próxima aula, veremos outras formas de utilizar o ChatGPT no dia a dia em programação, para facilitar seus processos e melhorar sua agilidade. **Te vejo na sequência!**


-----------------------------------------------------------------------
# 07Para saber mais: Cuidados ao enviar códigos para o ChatGPT

Ao longo do curso aprenderemos a utilizar o ChatGPT para nos auxiliar com códigos em nosso projeto, sendo que para isso será necessário compartilhar trechos de códigos de nosso projeto com a ferramenta. Certamente isso nos leva a uma preocupação em relação à segurança e privacidade das informações de nosso projeto.

É importante lembrar que o ChatGPT é um modelo de inteligência artificial que opera na nuvem e, como tal, há questões de segurança e privacidade que precisam ser consideradas. Um dos pontos mais delicados é a prática de colar códigos de projetos das empresas diretamente no ChatGPT. Essa ação, aparentemente inofensiva, pode resultar em sérios riscos para a segurança das informações e a privacidade dos dados sensíveis da empresa. Vejamos as principais considerações quanto à essa prática:

1. **Exposição de códigos sensíveis**
    
    Ao colar códigos de projetos empresariais no ChatGPT, você está, de fato, enviando essas informações para um servidor remoto controlado por terceiros, que é onde o modelo de linguagem está operando. Esses servidores podem não ser controlados pela empresa ou equipe de desenvolvimento, o que abre espaço para a exposição de informações sensíveis.
    
    Os códigos podem conter dados confidenciais, como senhas, chaves de API, tokens de autenticação, entre outros detalhes cruciais para a segurança dos sistemas da empresa. O acesso a essas informações por terceiros mal-intencionados pode levar a violações de segurança e comprometimento de projetos e dados.
    
2. **Riscos de vazamento de informações**
    
    Colar códigos da empresa no ChatGPT também pode representar um risco de vazamento de informações proprietárias. Mesmo que os servidores da empresa possuam medidas de segurança adequadas, o ato de copiar e colar o código pode expor detalhes de projetos internos que deveriam permanecer restritos a um grupo específico de pessoas da empresa.
    
    Essas informações podem ser capturadas e armazenadas em outros locais por meios maliciosos, e isso pode levar a concorrência desleal, perda de propriedade intelectual e danos à reputação da empresa.
    
3. **Compliance e regulamentações**
    
    Muitas indústrias estão sujeitas a regulamentações específicas relacionadas à segurança e privacidade dos dados, como a Lei Geral de Proteção de Dados (LGPD) ou o Regulamento Geral de Proteção de Dados (GDPR). Colar códigos de projetos empresariais no ChatGPT pode violar essas regulamentações, uma vez que dados sensíveis podem estar sendo compartilhados com terceiros não autorizados, resultando em multas e penalidades significativas para a empresa.
    

## Boas práticas de segurança

Para evitar esses riscos, é importante adotar algumas práticas seguras ao utilizar o ChatGPT ou qualquer outra ferramenta de inteligência artificial:

1. **Criação de ambientes controlados**: Em vez de colar códigos diretamente no ChatGPT, desenvolva ambientes controlados para realizar testes e experimentações com segurança, sem expor informações sensíveis.
    
2. **Uso de dados fictícios**: Utilize dados fictícios ou exemplos genéricos em vez de informações reais e sensíveis durante as interações com o ChatGPT.
    
3. **Conscientização da equipe**: Certifique-se de que toda a equipe de desenvolvimento esteja ciente dos riscos e instrua-os sobre as melhores práticas para proteger informações confidenciais.
    
4. **Revisão das políticas de segurança e privacidade**: Revise as políticas de segurança e privacidade da empresa para garantir que estejam alinhadas com o uso de ferramentas de inteligência artificial e estabeleçam diretrizes claras sobre o manuseio de dados sensíveis.
    

Ao seguir essas práticas, é possível aproveitar os benefícios do ChatGPT e outras ferramentas similares, sem comprometer a segurança e a privacidade dos projetos empresariais. O cuidado na manipulação de códigos de projetos empresariais e a conscientização sobre os riscos associados são fundamentais para garantir a segurança e a privacidade dos dados da empresa.


-----------------------------------------------------------------------
# 01Aprendendo sobre Regex

## Transcrição

Vamos continuar nossos estudos com ChatGPT, entendendo como ele pode nos auxiliar no cotidiano de programação.

Relembrando nosso projeto, nós tínhamos uma funcionalidade de cadastro de pacientes com validações e regras executadas na aplicação. Vamos retornar para o IntelliJ.

Toda requisição para as funcionalidades de paciente passam pela classe `PacienteController`, onde temos o método `cadastrar`.

```typescript
 @PostMapping
 @Transactional
 public ResponseEntity<DadosDetalhamentoMedico> cadastrar(@RequestBody @Valid DadosCadastroMedico dados, UriComponentsBuilder uriBuilder) {
    var detalhesMedico = service.cadastrar(dados);
    var uri = uriBuilder.path("/medicos/{id}").buildAndExpand(detalhesMedico.id()).toUri();
    return ResponseEntity.created(uri).body(detalhesMedico);
}
```

Este método é chamado na requisição de cadastro de um novo paciente. No parâmetro do método, há uma classe _record_ do Java: `DadosCadastroPaciente`. Ela representa o JSON enviado pelo cliente que está disparando a requisição.

Existem algumas anotações no Java que servem para fazer validações. Essas validações são para os campos que estão vindo no JSON.

```less
public record DadosCadastroPaciente(
    @NotBlank
    String nome,

    @NotBlank
    @Email
    string email, 

    @NotBlank
    String telefone,

    @NotBlank
    @Pattern(regexp = "\\d{3}\\.?\\d{3}\\.?\\d{3}\\-?\\d{2}")
    String cpf, 

    @NotNull @Valid DadosEndereco endereco) {
}
```

Por exemplo, para a validação do campo `nome`, temos uma notação `@NorBlank` para dizer que o campo não pode ser nulo nem vazio, isto é, estar em branco. Todos os campos tem anotações que fazem validações.

O campo `cpf` tem uma validação `@Pattern()` para validar um padrão usando `regexp`, que é uma expressão regular. A expressão regular que aparece é bem complicada: `"\\d{3}\\.?\\d{3}\\.?\\d{3}\\-?\\d{2}"`.

Utilizamos a **expressão regular** para fazer validações e para encontrar padrões em um texto (string). É um pouco complicado aprender e utilizar este recurso. Geralmente, estudamos, utilizamos e depois esquecemos. Então, sempre que precisamos trabalhar com as expressões regulares, temos que reaprender o processo. Podemos utilizar o ChatGPT para nos auxiliar.

Considerando um cenário em que temos uma expressão regular no código, por exemplo, `"\\d{3}\\.?\\d{3}\\.?\\d{3}\\-?\\d{2}"`, e não entendemos o que ela faz ou queremos entender o que significa cada uma de suas partes, podemos usar o ChatGPT para obter essas informações.

Então, vamos retornar ao ChatGPT e abrir um novo chat. Basta apertar o botão "New chat" no canto superior esquerdo. Nós explicaremos ao ChatGPT que queremos aprender sobre uma expressão regular. Vamos perguntar:

```plaintext
Tenho um código que utiliza expressão regular, mas não entendi o que ela faz. Poderia me explicar se eu colar a regex aqui? 
```

> Claro, ficarei feliz em ajudar! Por favor, cole a expressão regular que você deseja entender e eu farei o possível para explicar o que ela faz.

Para prosseguir, vamos até o código, copiaremos a notação `@Pattern()` inteira, colaremos no ChatGPT, apertaremos "Enter" e aguardaremos a resposta.

```plaintext
@Pattern(regexp = "\\d{3}\\.?\\d{3}\\.?\\d{3}\\-?\\d{2}")
```

> Essa expressão regular é usada para validar um padrão específico de CPF (Cadastro de Pessoa Física) no Brasil. Vou explicar cada parte da expressão para que você possa entender o que ela faz:
> 
> • "\d(3)" corresponde a três dígitos numéricos consecutivos. Isso significa que a expressão espera encontrar um número composto por três dígitos.
> 
> • ".?" verifica se há um ponto "." opicional após três dígitos iniciais. O ponto é representado por "" porque o caractere "." é um metacaractere na expressão regular e precisa ser escapado.
> 
> • "\d{3}" novamente corresponde a três dígitos numéricos consecutivos.
> 
> • ".?" verifica novamente se há um ponto "." opcional após os três dígitos.
> 
> • "\d{3} corresponde a três dígitos numéricos consecutivos.
> 
> • "-?" verifica se há um hífen "-" opcional ao final do padrão.
> 
> • "\d{2}" corresponde a dois dígitos numéricos consecutivos no final do padrão.
> 
> Resumindo, a expressão regular que você forneceu busca validar uma sequência de nove dígitos numéricos seguida de dois dígitos numéricos opcionais e pode conter pontos "." e um hífen "-" em posições específicas. Essa sequência de caracteres é comumente usada para representar um número de CPF válido no Brasil.
> 
> Cabe ressaltar que essa expressão regular pode ser utilizada em conjunto com a classe `Pattern` do Java para verificar se uma determinada string corresponde ao padrão de CPF esperado.

O ChatGPT explicou trecho por trecho da expressão regular e citou até o `Pattern`. Poderíamos continuar dizendo que o código está sendo feito em uma aplicação Java e pedir mais detalhes de seu funcionamento em Java.

É muito mais fácil aprender expressões regulares usando o ChatGPT que pesquisando pela internet, usando sites como "regex101". Com certeza, existem muitos sites úteis, mas o ChatGPT fornece informações detalhadas e em português de forma muito mais prática.

Na sequência, continuaremos estudando mais detalhes sobre expressão regular!


-----------------------------------------------------------------------
# 02Gerando uma Regex

## Transcrição

Aprendemos a usar o ChatGPT para aprender sobre expressões regulares. Também podemos usar o ChatGT para nos auxiliar na **criação de uma expressão regular**. Vamos retomar o exemplo do cadastro de paciente, com o código que está no IntelliJ e tem a expressão regular de cadastro do CPF.

```less
public record DadosCadastroPaciente(
    @NotBlank
    String nome,

    @NotBlank
    @Email
    string email, 

    @NotBlank
    String telefone,

    @NotBlank
    @Pattern(regexp = "\\d{3}\\.?\\d{3}\\.?\\d{3}\\-?\\d{2}")
    String cpf, 

    @NotNull @Valid DadosEndereco endereco) {
}
```

O campo `telefone` só tem uma validação: ele está verificando se o campo não está vazio, apenas para dizer que ele é obrigatório. Mas, se tentarmos cadastrar um paciente com o telefone "ABC", ele vai aceitar. Não estamos validando se o telefone é válido.

Podemos usar uma expressão regular no campo `telefone`. Copiaremos a linha do `@Pattern` com "Ctrl + C" e colaremos em cima do campo `telefone`.

```less
public record DadosCadastroPaciente(
    @NotBlank
    String nome,

    @NotBlank
    @Email
    string email, 

    @NotBlank
    @Pattern(regexp = "\\d{3}\\.?\\d{3}\\.?\\d{3}\\-?\\d{2}")
    String telefone,

    @NotBlank
    @Pattern(regexp = "\\d{3}\\.?\\d{3}\\.?\\d{3}\\-?\\d{2}")
    String cpf, 

    @NotNull @Valid DadosEndereco endereco) {
}
```

Agora, temos que fazer as adaptações necessárias. Como fazer uma expressão regular para validar um telefone? Vamos pedir ajuda ao ChatGPT. No mesmo chat do vídeo anterior, onde discutimos `regex`, vamos escrever:

```plaintext
Pode me ajudar na criação de uma regex para validar um campo telefone? 
```

> Claro! Vou ajudá-lo a criar uma expressão regular para validar um campo de telefone. No entanto, é importante notar que os formatos de telefone podem variar dependendo do país ou região. Vou fornecer um exemplo geral que pode funcionar em alguns casos, mas pode precisar ser ajustado de acordo com as regras específicas que você deseja aplicar.

```swift
@Pattern(regexp = "^\\+?\\d{1,4}?[-,\\s]?\\(?(\\d{2,3})\\)?[-,\\s]?\\d{3,4}[-\\s]?\\d{3,4}$")
```

> Vamos analisar essa expressão em partes:
> 
> • "^" indica o início da string.
> 
> • "\+?" verifica se há um sinal de "+" opcional no início do número de telefone.
> 
> • "\d{1,4}?" corresponde a um a quatro dígitos opcionais, representando o possível código do país.
> 
> • "[-,\s]?" verifica se há um hífen "-", uma vírgula "," ou um espaço em branco opcional após o código do país.
> 
> • "\(?" verifica se há um parêntese aberto "(" opcional.
> 
> • "(\d{2,3})" captura um grupo de dois a três dígitos, representando o código de área.
> 
> • "\)?" verifica se há um parêntese fechado ")" opcional após o código de área.
> 
> • "[-,\s]?" verifica se há um hífen "-", uma vírgula "," ou um espaço em branco opcional após o código de área.
> 
> • "\d{3,4}" corresponde a três ou quatro dígitos, representando o prefixo do telefone.
> 
> • "[-\s]?" verifica se há um hífen "-" ou um espaço em branco opcional após o prefixo do telefone.
> 
> • "\d{3,4}" corresponde a três ou quatro dígitos, representando os últimos dígitos do telefone.
> 
> • "$" indica o final da string.
> 
> Essa expressão regular valida números de telefone em vários formatos comuns, permitindo variações na formatação de códigos de país, códigos de área, prefixos e os últimos dígitos. No entanto, é importante observar que diferentes países ou regiões podem ter formatos específicos para números de telefone, então essa expressão regular pode precisar ser ajustada para atender a requisitos específicos.

Pedimos ajuda com a validação do telefone, mas não dissemos qual o formato ou máscara, se era só do Brasil ou internacional, então, o ChatGPT responde de maneira genérica. Uma dica importante, é: quanto mais específica for a pergunta, mais assertiva será a resposta.

O ChatGpt gerou uma expressão regular gigante. É difícil saber o que ela significa. Felizmente, ele també gerou uma explicação da expressão em partes.

Não era bem isso que queríamos. Nosso sistema só será usado no Brasil. Não teremos um telefone dos Estados Unidos ou China no cadastro. Não precisamos de uma expressão tão complexa. Então, vamos complementar nossa pergunta.

```plaintext
Pode alterar considerando telefones apenas no formato brasileiro? 
```

> Certamente! Aqui está a expressão regular ajustada para validar telefones no formato brasileiro:

```swift
@Pattern(regexp = "^\\(\\d{2}\\)\\s?\\d{4,5}-\\d{4}$")
```

> • "^" indica o início da string.
> 
> • "\(" corresponde ao caractere "(" literal.
> 
> • "\d{2}" corresponde a exatamente dois dígitos.
> 
> • "\)" corresponde ao caractere ")" literal.
> 
> • "\s?" verifica se há um espaço em branco opcional.
> 
> • "\d{4,5}" corresponde a quatro ou cinco dígitos.
> 
> • "-" corresponde ao caractere "-" literal.
> 
> • "\d{4}" corresponde a exatamente quatro dígitos.
> 
> • "$" indica o final da string.
> 
> Essa expressão regular valida números de telefone no formato "(XX) XXXXX-XXXX", onde "X" representa um dígito. Ela permite um código de área entre parênteses, um espaço em branco opcional após o código de área, um hífen "-" e, em seguida, os quatro últimos dígitos do número de telefone.
> 
> Essa expressão regular é específica para números de telefone no formato brasileiro com código de área fixo. Tenha em mente que existem diferentes formatos de números de telefone no Brasil, incluindo números de celular com prefixo "9" e variações regionais. Se você precisar validar esses formatos também, a expressão regular precisará ser ajustada.

Podemos continuar pedindo mudanças segundo o formato que desejamos.

```plaintext
Poderia fazer a regex para aceitar telefones no formato (xx)xxxxx-xxxx ou 
(xx)xxxx-xxxx também considerando que os parênteses e hífen são opcionais
```

> Claro" Aqui está a expressão regular atualizada para aceitar telefones no fomato (XX)XXXXX-XXXX ou (XX)XXXX-XXXX, considerando que os parênteses e o hífen são opcionais:

```swift
@Pattern(regexp = "^\\(\\d{2}\\)?\\s?\\d{4,5}-?\\d{4}$")
```

> Explicação da expressão regular:
> 
> • "^" indica o início da string.
> 
> • "\(" corresponde ao caractere "(" literal.
> 
> • "\d{2}" corresponde a exatamente dois dígitos.
> 
> • "\)?" verifica se há um parêntese fechado ")" opcional após o código de área.
> 
> • "\s?" verifica se há um espaço em branco opcional.
> 
> • "\d{4,5}" corresponde a quatro ou cinco dígitos, representando o prefixo do telefone.
> 
> • "-?" verifica se há um hífen "-" opcional após o prefixo do telefone.
> 
> • "\d{4}" corresponde a exatamente quatro dígitos, representando os últimos dígitos do telefone.
> 
> • "$" indica o final da string.
> 
> Essa expressão regular valida números de telefone no formato "(XX) XXXX-XXXX" ou "(XX) XXXXX-XXXX", onde "X" representa um dígito. Ela permite um código de área entre parênteses, um espaço em branco opcional após o código de área, um hífen "-" opcional após o prefixo do telefone e, em seguida, os quatro últimos dígitos do número de telefone.
> 
> No entanto, é importante lembrar que essa expressão regular pode não abranger todas as variações possíveis de números de telefone, especialmente se houver outros formatos específicos para números de telefone em sua aplicação. Portanto, verifique se a expressão regular atende aos requisitos específicos do seu caso de uso.

Ele mudou a expressão regular, considerando os campos opcionais, assim como pedimos. Essa é outra maneira de utilizar o ChatGPT para expressões regulares, um assunto complexo e que, geralmente, sabemos apenas o básico. Quando precisamos fazer algo mais elaborado, temos que recorrer a estudos e pesquisas.

Ao invés de ficar assistindo vários vídeos e lendo tutoriais, podemos usar o ChatGPT, seja na explicação ou criação de uma expressão regular. Vamos copiar a expressão gerada e colar no campo `@Pattern()`.

```less
public record DadosCadastroPaciente(
    @NotBlank
    String nome,

    @NotBlank
    @Email
    string email, 

    @NotBlank
    @Pattern(regexp = "^\\(\\d{2}\\)?\\s?\\d{4,5}-?\\d{4}$")
    String telefone,

    @NotBlank
    @Pattern(regexp = "\\d{3}\\.?\\d{3}\\.?\\d{3}\\-?\\d{2}")
    String cpf, 

    @NotNull @Valid DadosEndereco endereco) {
}
```

Colamos a expressão regular e salvamos. Vamos acessar a aba inferior "Run". Os _logs_ começaram a ser gerados, o projeto foi reiniciado com a mudança e agora podemos testar se a expressão regular está correta.

> Não podemos confiar completamente no ChatGPT, porque, como toda ferramenta, ele pode cometer erros. Nem sempre a resposta será precisa. É importante testar, analisar e validar essa resposta!

No Postman, vamos acessar a requisição `POST Cadastrar paciente` e realizar um teste. Nós cadastraremos o `"Paciente 3"`, mudaremos o campo de cpf e o telefone.

```perl
{
  "nome": "Paciente 3",
    "email": "paciente3@gmail.com",
    "cpf": "333.333.3333-99",
    "telefone": "(61)900000000"
    "endereco": {
         "logradouro": "Rua",
             
             //código omitido. 
```

Disparando a requisição (botão "Send"), recebemos um retorno `201 created`, portanto, o telefone foi criado corretamente. Vamos disparar uma nova requisição, com o cadastro do `"Paciente 4"`.

```perl
{
  "nome": "Paciente 4",
    "email": "paciente4@gmail.com",
    "cpf": "333.333.3333-77",
    "telefone": "1188888888"
    "endereco": {
         "logradouro": "Rua",
             
             //código omitido. 
```

Esperávamos que ele aceitasse o formato de telefone sem os parênteses e com 8 dígitos, mas recebemos um erro:

```swift
[
    { 
           "campo": "telefone",
             "mensagem": "must match \"^\\(\\d{2}\\)?\\s?\\d{4,5}-?\\d{4}$""
        }
]
```

O aviso é de que o telefone não é compatível com a expressão regular. O ChatGPT falhou. Podemos retornar ao chat e dizer:

```plaintext
testei com esse telefone 1188888888 e não deu certo
```

> Peço desculpas pelo equívoco. Parece que a expressão regular não está aceitando o número de telefone "1188888888" porque o código de área "11" possui apenas dois dígitos, enquanto a expressão espera exatamente três dígitos para o código de área.
> 
> Se você deseja que o código de área tenha dois dígitos, você pode atualizar a expressão regular da seguinte forma:

```swift
@Pattern(regexp = "^(\\(\\d{2}\\)|\\d{2})\\s?\\d{4,5}-?\\d{4}$")
```

> Nessa expressão regular modificada, fizemos a seguinte alteração: Adicionamos a alternativa `(\\d{2})` para permitir um código de área com apenas dois dígitos.
> 
> Usamos o operador `|` para indicar a alternância entre o formato `(\\(\\d{2}\\))` (com parênteses) e `(\\d{2})` (sem parênteses);
> 
> Com essa modificação, a expressão regular deve aceitar números de telefone no formato "(XX)XXXXX-XXXX", "(XX)XXXX-XXXX" e "XX XXXXX-XXXX", onde "XX" representa o código de área.

Vamos substituir a expressão regular no código.

```less
public record DadosCadastroPaciente(
    @NotBlank
    String nome,

    @NotBlank
    @Email
    string email, 

    @NotBlank
    @Pattern(regexp = "^(\\(\\d{2}\\)|\\d{2})\\s?\\d{4,5}-?\\d{4}$")
    String telefone,

    @NotBlank
    @Pattern(regexp = "\\d{3}\\.?\\d{3}\\.?\\d{3}\\-?\\d{2}")
    String cpf, 

    @NotNull @Valid DadosEndereco endereco) {
}
```

Basta aguardar alguns minutos até que o servidor seja reiniciado com a mudança no código. Vamos testar o código novamente no Postman. Disparamos a requisição do `"Paciente 4"` e funcionou!

Então, é importante reforçar: não confie completamente na saída indicada pelo ChatGPT, porque não se trata de uma ferramenta perfeita. Ela consegue gerar códigos, mas comete erros.

Essa ferramenta e outras similares não vieram para substituir o nosso trabalho, e, sim, facilitar nosso dia a dia, seja para aprendermos coisas novas ou automatizar processos. Como ela comete erros, a análise técnica de pessoas que conheçam programação sempre será necessária para avaliar se uma resposta está correta ou não.

Lembre-se de sempre testar os códigos!

Na próxima aula, conheceremos outras áreas em um projeto de _software_ em que podemos usar o ChatGPT. Até lá!!


-----------------------------------------------------------------------

# 01Aprendendo SQL

## Transcrição

Uma das funcionalidades que estudamos, em aulas anteriores, foi a de agendamento de consultas.

Podemos verificar no Postman do projeto que temos uma requisição para marcar consulta.

Nesse projeto existe uma regra de negócio que indica que a marcação de consultas pode ser feita de duas maneiras: podemos informar na requisição quem é o paciente, quem é o médico e a data:

```json
{
  "idPaciente": 1,
  "idMedico": 1,
  "data": "2025-10-10T10:00"
}
```

Ou podemos informar apenas qual é o paciente e a data. Mas nesse caso precisamos também informar qual é a especialidade, assim o sistema escolherá aleatoriamente alguma pessoa médica que esteja disponível nessa data:

```json
{
  "idPaciente": 2,
  "data": "2025-10-10T12:00",
  "especialidade": "CARDIOLOGIA"
}
```

Mas como foi gerada essa funcionalidade? Como é que o sistema escolhe um médico de forma aleatória para uma data e horário?

Vamos analisar o código.

No arquivo `ConsultaController.java` temos o método que faz o agendamento, e ele chama uma classe service que tem o método `agendar(dados)`:

```typescript
@PostMapping
@Transactional
public ResponseEntity<DadosDetalhamentoConsulta> agendar(@RequestBody @Valid DadosAgendamentoConsulta dados) {
    var detalhesAgendamento = agendaConsultas.agendar(dados);
    return ResponseEntity.ok(detalhesAgendamento);
}
```

No `AgendaConsultaService` temos o algoritmo para fazer o agendamento de consultas. Nesse algoritmo tem um método chamado `escolherMedico` que verifica se está vindo o `idMedico` na requisição. Se não estiver vindo o `idMedico`, ele verifica se está vindo a `especialidade` e se a especialidade não vier, será lançado um erro.

No caso de vir uma `especialidade`, ele chama o `medicoRepository`, que é a classe que faz a consulta no banco de dados. E ele chama o método escolher `escolherMedicoAleatorioLivreNaData`. Passa como parâmetro a especialidade e a data que estão chegando na requisição.

```kotlin
private Medico escolherMedico(DadosAgendamentoConsulta dados) {
    if (dados.idMedico() != null) {
        return medicoRepository.getReferenceById(dados.idMedico());
    }

    if (dados.especialidade() == null) {
        throw new ValidacaoException("Especialidade é obrigatória quando médico não for escolhido!");
    }

    return medicoRepository.escolherMedicoAleatorioLivreNaData(dados.especialidade(), dados.data());
}
```

Vamos clicar no método `escolherMedicoAleatorioLivreNaData` para analisar melhor como ele funciona.

Ao clicar sobre ele, aparece o método e acima dele tem uma notação `@Query` com uma consulta usando uma linguagem chamada **JPQL (_Java Persistence Query Language_)**, que é bem parecida com SQL. É como se fosse um SQL orientado a objetos. Basicamente, é uma consulta que será feita no banco de dados.

Hoje em dia, quase todo framework, independentemente da linguagem, tem alguma biblioteca, segue aquele padrão ORM (_Object Relational Mapping_). ou seja, tem algum framework ORM que abstrai o acesso ao banco de dados.

Então, é bem comum não precisarmos mais escrever comandos SQL nos projetos. Via métodos e código, já conseguimos escrever o que desejamos e o framework gera a consulta no banco de dados.

Porém, eventualmente, vamos esbarrar com uma consulta SQL. Embora não seja muito comum, é importante conhecermos a SQL. Podemos nos deparar com uma consulta que não seja tão óbvia como encontramos aqui. Ele faz uma consulta, faz alguns filtros, um `not in`, etc.

```python
@Query("""
   select m from Medico m
   where
   m.ativo = true
   and
   m.especialidade = :especialidade
   and
   m.id not in(
     select c.medico.id from Consulta c
     where
     c.data = :data
   )
   order by rand()
   limit 1
 """)
```

Já que não entendemos o que esse comando SQL podemos perguntar para o ChatGPT.

## Utilizar o ChatGPT para aprender SQL

Vamos perguntar para o GTP o que essa query faz. Podemos copiar a notação `@Query` e a linha de código do método.

No ChatGPT, vamos abrir uma nova conversa clicando no botão "New Chat". E vamos explicar o que queremos.

```plaintext
Tenho uma aplicação Java com uma consulta SQL que não entendi. Você poderia me explicar se eu colar o código aqui?
```

Ele respondeu:

> Claro! Ficarei feliz em ajudar a esclarecer sua consulta SQL. Por favor, cole o código aqui e farei o possível para explicar o que ele faz.

Vamos colar o código no prompt do ChatGPT.

```python
@Query("""
   select m from Medico m
   where
   m.ativo = true
   and
   m.especialidade = :especialidade
   and
   m.id not in(
     select c.medico.id from Consulta c
     where
     c.data = :data
   )
   order by rand()
   limit 1
 """)
 
 Medico escolherMedicoAleatorioLivreNaData(Especialidade especialidade, LocalDateTime data);
```

Ele analisou e deu a seguinte resposta:

> Essa consulta SQL está escrita em uma sintaxe específica para consultas JPQL (Java Persistence Query Language). Parece ser um trecho de código de um método em uma aplicação Java que usa uma biblioteca de persistência, como o Hibernate ou o EclipseLink.
> 
> Vou explicar cada parte do código para ajudar você a entender o que está acontecendo:
> 
> Essa anotação `@Query` é comumente usada em frameworks de persistência para mapear consultas personalizadas em métodos de repositório.
> 
> A consulta em si começa com a palavra-chave `select`, indicando que você deseja recuperar registros da tabela "Medico". A letra "m" após a palavra-chave `from` é um alias para a tabela "Medico", permitindo que você se refira a ela posteriormente.
> 
> A cláusula `where` contém as condições para filtrar os resultados. As condições são as seguintes:
> 
> - `m.ativo = true`: A coluna "ativo" do médico deve ter o valor "true". Isso indica que o médico está ativo.
> - `m.especialidade = :especialidade`: A coluna "especialidade" do médico deve ser igual ao parâmetro `especialidade` fornecido na consulta. Isso filtra os médicos por especialidade.
> - `m.id not in (...)`: O ID do médico não deve estar presente nos resultados da subconsulta interna. A subconsulta interna está filtrando consultas (tabela "Consulta") pela coluna "data" igual ao parâmetro `data`. Em outras palavras, essa condição exclui médicos que já possuem consultas marcadas na data fornecida.
> 
> A cláusula `order by rand()` é usada para ordenar os resultados de forma aleatória. A função `rand()` é comumente usada em bancos de dados para gerar um número aleatório.
> 
> A cláusula `limit 1` limita o resultado a apenas um registro.
> 
> Por fim, o método `escolherMedicoAleatorioLivreNaData` tem como objetivo executar a consulta e retornar um objeto do tipo "Medico" que corresponda às condições estabelecidas. Espero que isso esclareça a consulta para você. Se você tiver alguma dúvida adicional, fique à vontade para perguntar.

Então, podemos usar o GPT para aprender alguma coisa que não é tão comum, é um pouco chata ou sobre algo que você não tenha muitos conhecimentos. algo que você queira aprender rapidamente, sem pesquisar em vários lugares diferentes. O ChatGPT pode nos ajudar nisso.

Se alguma coisa na explicação do ChatGPT não ficou tão óbvia, você pode complementar seu prompt.

Podemos, por exemplo, pedir que ele detalhe algum trecho que não foi tão explicado:

```plaintext
Pode me explicar melhor essa função rand()?
```

Uma curiosidade, será que essa função é padrão do SQL ou é uma função específica do banco de dados que está sendo utilizado pela aplicação? No caso, neste curso estamos utilizando o MySQL. Será que essa função `rand()` é do MySQL ou serve para qualquer banco? Vamos perguntar para o ChatGPT.

```plaintext
Essa função é padrão do SQL ou específica do MySQL?
```

O ChatGPT respondeu:

> Peço desculpas pelo equívoco na minha resposta anterior. A função `rand()` é específica do MySQL e não faz parte do padrão SQL ANSI.
> 
> Em SQL ANSI, não há uma função `rand()` padronizada para geração de números aleatórios. No entanto, muitos bancos de dados oferecem funções semelhantes com nomes diferentes. Alguns exemplos são:
> 
> - No PostgreSQL, a função equivalente é `random()`.
> - No Oracle, você pode usar `dbms random.value`.
> - No SQL Server, a função equivalente é `rand()`.
> 
> Portanto, é importante verificar a documentação específica do banco de dados que você está usando para obter informações precisas sobre a função de geração de números aleatórios disponível.
> 
> Mais uma vez, peço desculpas pela resposta incorreta anterior. Obrigado por apontar isso, e se você tiver mais dúvidas, estou à disposição para ajudar.

Ele explicou uma coisa importante: "a função `rand()` é específica do MySQL e não faz parte do padrão SQL ANSI." Então, se um dia precisarmos trocar o banco de dados da aplicação, essa função vai dar erro. Precisamos estar cientes de que essa função não é padrão universal do SQL.

Acabamos de aprender isso com o ChatGPT.

Então, neste vídeo aprendemos que podemos usar o ChatGPT para explicar consultas, detalhar funções e coisas mais complexas do SQL.

Na sequência continuaremos mexendo com SQL em uma outra situação.


-----------------------------------------------------------------------
# 02Criando consulta de relatório

## Transcrição

Ainda em relação ao SQL, também é possível usar o ChatGPT para criar uma consulta de alguma funcionalidade do projeto. E é justamente isso que faremos agora.

No Postman, uma das funcionalidades que temos é a funcionalidade "Consultas por médico". Essa funcionalidade funciona da seguinte forma:

Disparamos uma requisição via método GET para o endereço `/consultas/relatorio-mensal/` seguido do ano, traço, mês:

```bash
http://localhost:8080/consultas/relatorio-mensal/2025-10
```

Em seguida, a API deve devolver um JSON com um relatório de consultas por médico.

Então a API precisa verificar a data, ano e mês, que foi passada como parâmetro e trazer como resposta um JSON indicando cada médico, a quantidade de consultas realizadas nesse mês solicitado.

Mas essa funcionalidade está incompleta. Ela não está finalizada no projeto e usaremos o ChatGPT para nos auxiliar a finalizar essa funcionalidade.

Primeiro, vamos verificar o código do projeto. Dentro do arquivo `ConsultaController.java` temos um método chamado `gerarRelatorioConsultaMensal`. Esse é o método chamado quando disparamos aquela requisição.

```less
@GetMapping("/relatorio-mensal/{mes}")
public ResponseEntity<List<DadosRelatorioConsultaMensal>> gerarRelatorioConsultaMensal(@PathVariable YearMonth mes) {
    //var relatorio = consultaRepository.?
    return ResponseEntity.ok(null);
```

Esse método recebe como parâmetro o mês e ano que chega via URL. Mes e ano é representado pela classe `YearMonth` do Java.

E temos um código comentado, `//var relatorio = consultaRepository.?`. Esse método precisa chamar o Repository para disparar a consulta no banco de dados e essa consulta vamos implementar usando o SQL e a linguagem JPQL. Isso ainda não está sendo feito. Por isso, quando devolve a resposta, a aplicação está devolvendo um nulo.

Esse é o trecho de código que precisamos finalizar. Vamos pedir ajuda ao ChatGPT.

Podemos usar a mesma conversa do vídeo anterior, ele já sabe que estamos falando sobre Java e JPQL, já tem um contexto inicial.

Podemos escrever:

```plaintext
Obrigado! Agora preciso de ajuda com outra funcionalidade no meu projeto. Preciso criar uma consulta com JPQL para fazer um relatório mensal de consultas agrupado por medicos. Essa consulta SQL deve retornar a quantidade de consultas realizadas em determinado mês para cada medico cadastrado. Posso mandar o código atual e você me ajuda a finalizar? 
```

Ele respondeu:

> Com certeza! Ficarei feliz em ajudar com a consulta JPQL para criar o relatório mensal de consultas agrupadas por médico. Por favor, compartilhe o código atual e vamos trabalhar juntos para finalizá-lo.

Vamos levar para o ChatGPT o código do método no Controller. Abaixo desse primeiro bloco, mandaremos o trecho de código do `ConsultaRepository` e mandaremos também o código da classe `Consulta`, que é a classe de modelo que representa a tabela de consultas no banco de dados.

```plaintext
@GetMapping("/relatorio-mensal/{mes}")
public ResponseEntity<List<DadosRelatorioConsultaMensal>> gerarRelatorioConsultaMensal(@PathVariable YearMonth mes) {
    //var relatorio = consultaRepository.?
    return ResponseEntity.ok(null);

public interface ConsultaRepository extends JpaRepository<Consulta, Long> {

@Table(name = "consultas")
@Entity(name = "Consulta")
@Getter
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
public class Consulta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "medico_id")
    private Medico medico;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "paciente_id")
    private Paciente paciente;

    private LocalDateTime data;

    public Consulta(Medico medico, Paciente paciente, LocalDateTime data) {
        this.medico = medico;
        this.paciente = paciente;
        this.data = data;
    }

}
```

Após colarmos esses três trechos de códigos podemos pressionar "Enter" e aguardar a resposta do ChatGPT.

> Claro! Com base no código que você compartilhou, podemos construir a consulta JPQL para obter o relatório mensal de consultas agrupadas por médico. Vamos trabalhar na implementação dentro do método `gerarRelatorioConsultaMensal`.

```java
@GetMapping("/relatorio-mensal/{mes}")
public ResponseEntity<List<DadosRelatorioConsultaMensal>> gerarRelatorioConsultaMensal(@PathVariable YearMonth mes)
   LocalDateTime inicioMes = mes.atDay(1).atStartOfDay();
   LocalDateTime fimMes = mes.atEndOfMonth()atTime(23, 59 59);

   List<DadosRelatorioConsultaMensal> relatorio = consultaRepository.gerarRelatorioConsultaMensal(inicioMes, fimMes);
   return ResponseEntity.ok(relatorio);
```

> Aqui, usamos `inicioMes`e `fimMes` para definir o intervalo de tempo dentro do mês selecionado. A consulta JPQL será responsável por obter o relatório de consultas durante esse período.

Neste momento, reforço que devemos sempre analisar o código gerado pelo ChatGPT. Nem sempre o código que ele devolver será o correto. Não devemos usar essa ferramenta apenas para copiar e colar código sem prestar atenção a o que estamos copiando. Nem sempre o ChatGPT acerta como gostaríamos.

No Controller, ele pediu para criarmos duas datas, `inicioMes` e `fimMes`; chamar o método passando essas datas e devolver a resposta no relatório.

A princípio, tudo bem. Talvez esteja certo. Vamos copiar esse trecho e colar isso no `ConsultaController`

```java
@GetMapping("/relatorio-mensal/{mes}")
public ResponseEntity<List<DadosRelatorioConsultaMensal>> gerarRelatorioConsultaMensal(@PathVariable YearMonth mes) {
    LocalDateTime inicioMes = mes.atDay(1).atStartOfDay();
    LocalDateTime fimMes = mes.atEndOfMonth().atTime(23, 59, 59);

    List<DadosRelatorioConsultaMensal> relatorio = consultaRepository.gerarRelatorioConsultaMensal(inicioMes, fimMes);
    return ResponseEntity.ok(relatorio);
}
```

Vamos ver o que o ChatGPT indicou para fazermos no `ConsultaRepository`:

> Agora, no repositório `ConsultaRepository` precisamos adicionar um novo método para a consulta JPQL:

```python
public interface ConsultaRepository extends JpaRepository<Consulta, Long> {

  @Query("""
    SELECT new com.example.DadosRelatorioConsultaMensal (c.medico, COUNT(c))
    FROM Consulta c
    WHERE c.data >= :inicioMes AND c.data <= :fimMes
    GROUP BY c.medico
""")
List<DadosRelatorioConsultaMensal> gerarRelatorioConsultaMensal(
      @Param("inicioMes") LocalDateTime inicioMes,
      @Param("fimMes") LocalDateTime fimMes);
}
```

Ele trouxe o método e as anotações corretas. Vamos copiar esse bloco de código e colar no ConsultaRepository, pode ser abaixo do último método que já existe.

Vamos fazer algumas alterações necessárias nesse código.

Como não passamos os pacotes da aplicação para o ChatGPT, ele não sabe onde é o pacote dessa classe `DadosRelatorioConsultaMensal`. Por isso, ele colou um pacote aleatório, `com.example`.

Vamos substituir pelo pacote de onde está a classe `DadosRelatorioConsultaMensal`. Ela está no pacote `med.voll.api.domain.consulta.dto`. Agora teremos o pacote do nosso projeto na consulta:

```less
  @Query("""
    SELECT med.voll.api.domain.consulta.dto.DadosRelatorioConsultaMensal (c.medico, COUNT(
    FROM Consulta c
    WHERE c.data >= :inicioMes AND c.data <= :fimMes
    GROUP BY c.medico
""")
List<DadosRelatorioConsultaMensal> gerarRelatorioConsultaMensal(
      @Param("inicioMes") LocalDateTime inicioMes,
      @Param("fimMes") LocalDateTime fimMes);
}
```

Também faremos algumas otimizações nos parâmetros que ele trouxe na consulta. Como os parâmetros `inicioMes` e `fimMes` já estão na query é opcional colocar o `@Param`, podemos apagar o `@Param("inicioMes")` e o `@Param("fimMes")`. Não está errado colocar, mas como é opcional podemos apagar para deixar o código mais simples.

```python
  @Query("""
    SELECT med.voll.api.domain.consulta.dto.DadosRelatorioConsultaMensal (c.medico, COUNT(
    FROM Consulta c
    WHERE c.data >= :inicioMes AND c.data <= :fimMes
    GROUP BY c.medico
""")
List<DadosRelatorioConsultaMensal> gerarRelatorioConsultaMensal(
       LocalDateTime inicioMes,
       LocalDateTime fimMes);
}
```

O ChatGPT não teve essa sacada, entregou um pouco mais complexo. Por isso, devemos usar o nosso conhecimento em programação para fazer os ajustes necessários!

Podemos salvar. Agora, o controller está compilando e estamos chamando o método que criamos.

O ChatGPT continuou a resposta explicando que o DadosRelatorioConsultaMensal precisa ser uma classe, mas já temos o record aqui no projeto, acabamos não enviando essa classe para o ChatGPT. Então, esse não precisa.

## Testes

Agora, podemos testar nossa aplicação no Postman. Vamos disparar a requisição "Listar próximas consultas" que está dentro da pasta "Agenda Consultas". Apareceu que temos duas consultas para o dia 10 de outubro.

```bash
{
  "id": 1,
  "data": 2025-10T10:00:00",
  "especialidade": "CARDIOLOGIA",
  "medico": Medico 1,
  "paciente": "Paciente 1"
},
{
  "id": 2,
  "data": 2025-10T12:00:00",
  "especialidade": "CARDIOLOGIA",
  "medico": Medico 1,
  "paciente": "Paciente 2"
}
```

Agora, vamos abrir a requisição GET do relatório e digitar na URL `/2025-10`:

```bash
http://localhost:8080/consultas/relatorio-mensal/2025-10
```

O Postman retornou um erro informando que não conseguiu determinar o construtor. Justamente porque ele não sabia que essa consulta usa aquela classe que está diferente da classe que o ChatGPT sugeriu.

Por isso, vamos no DadosRelatorioConsultaMensal.Java e vamos copiar o seguinte trecho de código.

```csharp
public record DadosRelatorioConsultaMensal(String nome, String crm, Long quantidadeConsultasNoMes) {}
```

E passaremos esse código para o ChatGPT, explicando mais um pouco. Quanto mais detalhados formos no prompt, mais assertiva será a resposta.

No ChatGPT, vamos escrever:

```plaintext
Preciso de apenas uma mudança. Minha classe DadosRelatorioConsultaMensal está assim:

public record DadosRelatorioConsultaMensal(String nome, String crm, Long quantidadeConsultasNoMes) {}
```

Vamos pressionar "Enter" e aguardar a resposta dele. Vamos ver se ele vai entender o que precisamos. Ele respondeu e gerou um código. Desse código vamos copiar apenas o trecho da `@Query` que precisamos:

```sql
DadosRelatorioConsultaMensal(m.nome, m.crm, COUNT(c))
         FROM Consulta c JOIN c.medico m
         WHERE c.data >= :inicioMes AND c.data <= :fimMes
         GROUP BY m.nome, m.crm
```

Colaremos esse trecho na `ConsultaRepository` que ficará da seguinte forma:

```python
 @Query("""
         SELECT new med.voll.api.domain.consulta.dto.DadosRelatorioConsultaMensal(m.nome, m.crm, COUNT(c))
         FROM Consulta c JOIN c.medico m
         WHERE c.data >= :inicioMes AND c.data <= :fimMes
         GROUP BY m.nome, m.crm
         """)
    List<DadosRelatorioConsultaMensal> gerarRelatorioConsultaMensal(LocalDateTime inicioMes, LocalDateTime fimMes);
```

Agora ele trouxe o nome, crm e a quantidade de consultas. Como não havíamos explicado antes que era isso que queríamos, ele tentou adivinhar algumas coisas.

Cabe a nós identificar onde está o problema, complementar e pedir uma nova resposta.

Agora, podemos testar no Postman novamente.

Vamos disparar a seguinte requisição GET:

```bash
http://localhost:8080/consultas/relatorio-mensal/2025-10
```

E o Postman retornou:

```json
{
  "nome": "Médico 1",
  "crm": "123456",
      "quantidadeConsultasNoMes": 2
}
```

Agora está funcionando como esperávamos. Funcionou! Conseguimos implementar uma funcionalidade com uma consulta no banco de dados usando o ChatGPT para nos auxiliar.

## Recapitulando

- Quanto mais detalhes dermos sobre o nosso projeto, mais assertiva será a resposta do ChatGPT.
- Sempre analise e teste as respostas.

Na próxima aula, estudaremos um outro cenário bem interessante em que o ChatGPT pode nos ajudar no dia a dia da área de programação.


-----------------------------------------------------------------------
# 03Respostas geradas pelo ChatGPT

Suponha que você fez a seguinte pergunta ao ChatGPT:

“Tenho no meu banco de dados uma tabela de produtos, uma de clientes, uma de vendedores e uma de vendas. Preciso de uma consulta SQL que me traga os top 10 vendedores dos últimos 90 dias e o valor que eles venderam no período.”

E ele te respondeu com:

“Claro! Para obter os top 10 vendedores dos últimos 90 dias e o valor que eles venderam no período, você pode usar a seguinte consulta SQL:

```vbnet
SELECT v.nome AS nome_vendedor, SUM(vd.valor) AS total_vendas
FROM vendedores v
JOIN vendas vd ON v.id = vd.id_vendedor
WHERE vd.data > DATE_SUB(CURDATE(), INTERVAL 90 DAY)
GROUP BY v.nome
ORDER BY total_vendas;
```

”

Escolha as alternativas que indicam afirmações **verdadeiras** quanto ao uso do ChatGPT nesse cenário:

- Alternativa correta
    
    O ChatGPT conseguiu inferir automaticamente o nome das tabelas e suas colunas.
    
- Alternativa correta
    
    O ChatGPT ofereceu uma solução completa e pronta para uso, sem a necessidade de ajustes adicionais.
    
    Embora o ChatGPT tenha fornecido uma consulta SQL, ainda pode ser necessário ajustar a consulta de acordo com a estrutura específica das tabelas no banco de dados.
    
- Alternativa correta
    
    Será necessário realizar ajustes no código gerado apenas quanto aos nomes das tabelas e suas colunas.
    
    Mesmo após realizar tais ajustes a consulta ainda pode conter erros ou não trazer os registros como esperado.
    
- Alternativa correta
    
    O código SQL gerado está incorreto.
    
    Esse foi um exemplo no qual o ChatGPT gerou um código incorreto, que não vai atender as necessidades esperadas, necessitando ajustes adicionais.



-----------------------------------------------------------------------
# 04Faça como eu fiz: aprendendo sobre o group by do SQL

Suponha que você se deparou com o seguinte código SQL em uma aplicação que você está desenvolvendo:

```sql
SELECT 
  p.categoria, 
  c.pais, 
  COUNT(*) AS total_produtos
FROM 
  produtos p
JOIN 
  categorias c ON p.id_categoria = c.id
WHERE 
  p.preco > 100
GROUP BY 
  p.categoria, 
  c.pais
HAVING 
  COUNT(*) > 5
ORDER BY 
  total_produtos DESC;
```

Você entendeu boa parte do comando anterior, com exceção do trecho que contém a cláusula GROUP BY. Utilize o ChatGPT para te auxiliar a entender o código SQL anterior.


-----------------------------------------------------------------------
# 01Gerando testes automatizados

## Transcrição

Vamos continuar nossos estudos de utilização do ChatGPT para auxílio no dia a dia de quem trabalha com programação. Nessa aula, vamos focar em outra utilidade.

O Postman é a ferramenta que usamos desde o início do curso para testar o projeto, já que é uma API Rest e não temos uma interface gráfica ou tela para simular.

Por isso, simulamos as requisições com o Postman. Isso que fazemos são **testes**, pois estamos testando a API e também testando se o sistema está funcionando conforme o esperado.

Só que esse teste é manual, porque tivemos que criar cada requisição, dispará-las manualmente, analisar o que foi devolvido, enviar o JSON. É possível automatizar alguns detalhes com Postman, mas podemos considerar nossos testes manuais ainda que usemos essa ferramenta.

Uma boa prática de programação é fazer **testes automatizados**. Normalmente, são testes de código como testes de unidade, integração, _end-to-end_, entre outros.

Para esses testes, criam-se classes para testar outras classes. É uma prática comum e muito recomendada nos projetos, porque conseguimos validar de uma maneira mais ágil se o código que escrevemos funciona conforme o esperado, além de detectar bugs e rastrear onde está o problema.

Apesar dos benefícios, pode ser tedioso e repetitivo na perspectiva de quem desenvolve o programa. Afinal, você tem que escrever o código e depois o código de teste - que muitas vezes é maior que o código testado já que temos que simular vários cenários.

Ou seja, dá para usar o chatGPT para nos auxiliar com esse tipo de tarefa.

Nessa aula, vamos aprender a usar o ChatGPT para fazer a geração de código de teste automatizado.

## Escolhendo a classe para teste

No IntelliJ, vamos em "src > main > java > med > voll > api > domain". O pacote do projeto chamado "domain" é onde ficam as classes de domínio da aplicação e que representam partes importantes do projeto, como paciente, médico e consulta.

No pacote de "consulta > validacoes > agendamento", temos várias classes que executam as regras de negócio em relação ao agendamento de consultas. Por exemplo, vamos analisar o código da classe `ValidadorHorarioFuncionamentoClinica.java`.

> `ValidadorHorarioFuncionamentoClinica.java` :

```java
package med.voll.api.domain.consulta.validacoes.agendamento;

import med.voll.api.domain.ValidacaoException;
import med.voll.api.domain.consulta.dto.DadosAgendamentoConsulta;
import org.springframework.stereotype.Component;

import java.time.DayOfWeek;
@Component
public class ValidadorHorarioFuncionamentoClinica implements ValidadorAgendamentoConsulta {

    public void validar(DadosAgendamentoConsulta dados) {
        var dataConsulta = dados.data();

        var domingo = dataConsulta.getDayOfWeek().equals(DayOfWeek.SUNDAY);
        var antesDaAberturaDaClinica = dataConsulta.getHour() < 7;
        var depoisDoEncerramentoDaClinica = dataConsulta.getHour() > 18;
        if (domingo || antesDaAberturaDaClinica || depoisDoEncerramentoDaClinica) {
            throw new ValidacaoException("Consulta fora do horário de funcionamento da clínica");
        }
    }

}
```

É uma classe que implementa uma interface `ValidadorAgendamentoConsulta`. Tem um método chamado `validar` que recebe a classe dos `DadosAgendamentoConsulta` que representa o JSON que chega.

Nessa classe `DadosAgendamentoConsulta`, temos o `idMedico`, `idPaciente`, `data` e `especialidade`.

Esse método `validar` recebe essas informações e realiza uma validação. Por exemplo, verifica o horário da consulta que chega para confirmar se está dentro do horário de atendimento da clínica.

Também faz checagens para verificar se o agendamento não é em um domingo, ou antes da abertura da clínica ou depois do encerramento da clínica. Se for uma data inválida, é lançada uma exceção. Caso a data seja válida, nada acontece já que o método é `void` e não tem nenhum retorno.

Essa é uma classe que executa uma regra de negócio do projeto, portanto, é importante testá-la. Será que esse algoritmo cobre todas as possibilidades? Se alguém alterar esse código e gerar um bug, quão rápido podemos descobrir que tem um problema?

Por isso, poderíamos criar um teste automatizado para essa classe. Porém, não vamos fazer esse teste manualmente. Vamos pedir para o ChatGPT gerar o teste dessa classe `ValidadorHorarioFuncionamentoClinica`.

## Gerando teste automatizado com ChatGPT

No ChatGPT, vamos abrir um novo chat já que é um nova conversa com outro assunto.

> Lembre-se de ser **específico** ao perguntar para que a resposta dada seja mais próxima daquilo que esperamos.

Primeiro, vamos perguntar se ele consegue nos ajudar a criar um teste e citar as tecnologias que temos no projeto, como a biblioteca de testes JUnit na versão 5 e a biblioteca de _mocks_ chamada Mockito.

```plaintext
Tenho uma aplicação em Java e preciso criar um código de teste automatizado utilizando JUnit 5 e Mockito, você consegue me ajudar?
```

Como o ChatGPT é proativo, já começa a explicar o que é o JUnit, pede para verificar se já temos configurado o ambiente de desenvolvimento com as dependências corretas para o JUnit 5 e Mockito. Além disso, dá alguns passos de exemplo para importar as bibliotecas necessárias, anotar a classe de teste e criar métodos de teste.

Porém, não queremos um exemplo aleatório. Queremos um teste para o nosso código. Por isso, enquanto ele digita a resposta, vamos voltar no projeto e copiar a classe `ValidadorHorarioFuncionamentoClinica` completa com "Ctrl + C".

Agora, vamos pedir para criar testes para a nossa classe.

```plaintext
Crie testes para a seguinte classe:

@Component
public class ValidadorHorarioFuncionamentoClinica implements ValidadorAgendamentoConsulta {

    public void validar(DadosAgendamentoConsulta dados) {
        var dataConsulta = dados.data();

        var domingo = dataConsulta.getDayOfWeek().equals(DayOfWeek.SUNDAY);
        var antesDaAberturaDaClinica = dataConsulta.getHour() < 7;
        var depoisDoEncerramentoDaClinica = dataConsulta.getHour() > 18;
        if (domingo || antesDaAberturaDaClinica || depoisDoEncerramentoDaClinica) {
            throw new ValidacaoException("Consulta fora do horário de funcionamento da clínica");
        }
    }

}
```

> Claro! Vou criar alguns exemplos de testes para a classe `ValidadorHorarioFuncionamentoClinica` usando JUnit 5 e Mockito. Aqui estão alguns casos que você pode considerar ao testar essa classe:

```java
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.time.DayOfWeek;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class ValidadorHorarioFuncionamentoClinicaTest {

    @InjectMocks
    private ValidadorHorarioFuncionamentoClinica validador;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void validar_ConsultaDentroDoHorario_NaoDeveLancarExcecao() {
        // Cenário
        DadosAgendamentoConsulta dados = criarDadosAgendamentoConsulta(LocalDateTime.of(2023, 6, 1, 9, 0)); // Segunda-feira, 9:00

        // Execução
        validador.validar(dados);

        // Verificação
        // Nenhuma exceção deve ser lançada
    }

    @Test
    void validar_ConsultaForaDoHorario_LancaValidacaoException() {
        // Cenário
        DadosAgendamentoConsulta dados = criarDadosAgendamentoConsulta(LocalDateTime.of(2023, 6, 1, 19, 0)); // Segunda-feira, 19:00

        // Execução e Verificação
        assertThrows(ValidacaoException.class, () -> validador.validar(dados));
    }

    @Test
    void validar_ConsultaNoDomingo_LancaValidacaoException() {
        // Cenário
        DadosAgendamentoConsulta dados = criarDadosAgendamentoConsulta(LocalDateTime.of(2023, 6, 4, 10, 0)); // Domingo, 10:00

        // Execução e Verificação
        assertThrows(ValidacaoException.class, () -> validador.validar(dados));
    }

    private DadosAgendamentoConsulta criarDadosAgendamentoConsulta(LocalDateTime data) {
        // Implemente a criação dos dados de agendamento de consulta conforme necessário para seus testes
        return null;
    }
}
```

> Nesses exemplos de teste, criamos três casos de teste diferentes:
> 
> 1. `validar ConsultaDentroDoHorario_NaoDeveLancarExcecao`: Verificamos se uma consulta agendada dentro do horário de funcionamento da clínica não lança uma exceção.
> 2. `validar ConsultaForaDoHorario_LancaValidacaoException`: Verificamos se uma consulta agendada fora do horário de funcionamento da clínica lança a exceção `ValidacaoException`.
> 3. `validar ConsultaNoDomingo LancaValidacaoException`: Verificamos se uma consulta agendada para um domingo lança a exceção `ValidacaoException`.
> 
> Você precisará implementar o método `criarDadosAgendamentoConsulta()` de acordo com as necessidades específicas do seu caso de teste.
> 
> Esses exemplos de teste devem ajudar você a começar a validar o comportamento da classe `ValidadorHorarioFuncionamentoClinica` em diferentes cenários. Certifique-se de ajustar e expandir esses testes de acordo com as regras e requisitos específicos do seu sistema.
> 
> Lembre-se de que os testes de unidade devem cobrir casos de sucesso, casos de falha e exceções esperadas, bem como situações limite, para garantir uma cobertura adequada dos requisitos e comportamentos do código testado.
> 
> Espero que isso seja útil! Se você tiver mais dúvidas, sinta-se à vontade para perguntar.

Com isso, o ChatGPT gera uma classe de testes automatizados para o projeto Java de acordo com as tecnologias especificadas, como JUnit 5 e Mockito.

Por isso, é importante ser específico e detalhar ao fazer uma pergunta. Senão ele poderia gerar o código para outra biblioteca e teríamos que pedir para corrigir.

Após o código, ele explica o que faz cada um dos métodos e dá algumas orientações.

Vamos copiar o código, incluindo as importações.

## Criando classe de teste

Vamos novamente abrir o IntelliJ.

Geralmente, os testes do projeto ficam separados do código. No caso do Java, não ficam dentro da pasta "src > main > java". Mas, sim, de "src > test > java" para ter a separação entre código da aplicação e código de teste automatizado.

Para não ser preciso criar o pacote e a classe do zero, vamos até a classe `ValidadorHorarioFuncionamentoClinica` para a qual queremos criar o teste.

Vamos usar um atalho "Alt + Enter" do IntelliJ e escolher a opção "_Create Test_". Assim, já vai criar a classe com o nome correto e no diretório correto. Na janela que se abre, vamos somente apertar o botão "OK".

Provavelmente, as IDEs nas outras linguagens também já tem um atalho para facilitar a criação de testes, sem precisar fazê-lo manualmente.

Foi criada a classe `ValidadorHorarioFuncionamentoClinicaTest.java` em "src > test > java > med > voll > api > domain > consulta > validacoes > agendamento". Inclusive, com o mesmo pacote da classe que estamos testando.

```java
package med.voll.api.domain.consulta.validacoes.agendamento;

class ValidadorHorarioFuncionamentoClinicaTest {
}
```

Agora, vamos substituir a classe vazia pelo código que copiamos do ChatGPT. Vamos conferir o que esse código faz?

O ChatGPT criou um método chamado `validar_ConsultaDentroDoHorario_NaoDeveLancarExcecao()`, onde instanciou um objeto `DadosAgendamentoConsulta` e criou um método privado `criarDadosAgendamentoConsulta()`, passando os parâmetros de horário dentro do horário de funcionamento da clínica.

Em seguida, chamou o `validador` sem retorno. No final, não fez nada já que nesse caso, não é para lançar exceção.

No outro cenário, fez um método `validar_ConsultaForaDoHorario_LancaValidacaoException()`. Nela, cria os dados com o horário que está fora do horário de atendimento. Depois, verifica se o código vai lançar uma _exception_. Também fez o teste para o cenário de consulta no domingo.

Porém, o método `criarDadosAgendamentoConsulta()` deixou com retorno nulo, já que não sabe como é nossa classe de consulta e dados de agendamento. Por isso, não soube como criar esse objeto.

## Alterando classe de teste

Vamos abrir a classe `DadosAgendamentoConsulta.java` e copiar seu código. Assim, podemos pedir ao ChatGPT para mudar o método `criarDadosAgendamentoConsulta()` de acordo com esse objeto, colando o código da classe.

```plaintext
Você poderia implementar o método criarDadosAgendamentoConsulta?

public record DadosAgendamentoConsulta(
        Long idMedico,

        @NotNull
        Long idPaciente,

        @NotNull
        @Future
        LocalDateTime data,

        Especialidade especialidade) {
}
```

> Certamente! Aqui está uma implementação básica do método `criarDadosAgendamentoConsulta` considerando a estrutura da classe `DadosAgendamentoConsulta` fornecida:

```java
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

public class ValidadorHoraoFuncionamentoClinicaTest {

// … outros métodos de teste…

    private DadosAgendamentoConsulta criarDadosAgendamentoConsulta(LocalDateTime data) {
        Long idMedico = 1L; // ID do médico desejado
        Long idPaciente = 2L; // ID do paciente desejado
        Especialidade especialidade = Especialidade.PEDIATRIA; // Especialidade desejada

        return new DadosAgendamentoConsulta(idMedico, idPaciente, data, especialidade);
    }
```

> Neste exemplo, definimos valores arbitrários para o ID do médico (`1dMedico`), ID do paciente (`idPaciente`) e especialidade (`especialidade`). Você pode ajustar esses valores de acordo com as necessidades dos seus casos de teste.

O ChatGPT não colocou o código inteiro novamente. Em vez disso, omitiu o código de teste e colocou apenas o método para substituir o `criarDadosAgendamentoConsulta()`.

Na classe de teste no IntelliJ, vamos substituir esse método. Porém, vamos modificar a especialidade, já que ele colocou `PEDIATRIA` que não existe no nosso código. Vamos colocar `Especialidade.CARDIOLOGIA`.

```java
// código omitido…

    private DadosAgendamentoConsulta criarDadosAgendamentoConsulta(LocalDateTime data) {
        Long idMedico = 1L; // ID do médico desejado
        Long idPaciente = 2L; // ID do paciente desejado
        Especialidade especialidade = Especialidade.CARDIOLOGIA; // Especialidade desejada

        return new DadosAgendamentoConsulta(idMedico, idPaciente, data, especialidade);
    }
```

A princípio está pronto o código de teste. Mas, será que esse código está certo?

Afinal, não podemos simplesmente confiar em tudo que o ChatGPT gerou. É preciso validar se faz sentido e se não tem erros.

Vamos rodar os testes automatizados ao clicar no botão de play (ou "Ctrl + Shift + F10") à esquerda da linha 15 onde está a definição da classe `ValidadorHorarioFuncionamentoClinicaTest`.

> Tests passed: 3 of 3 tests - 674 ms

Simulamos os três cenários e todos funcionaram. Assim, verificamos que código da classe do projeto chamada `ValidadorHorarioFuncionamentoClinica` parece estar funcional. Independentemente de quem o desenvolveu, criamos um teste que garante o funcionamento desse algoritmo para esses cenários.

A geração de testes automatizados é uma excelente utilização do ChatGPT.

Foram simulados três cenários de teste. Mas será que existem mais cenários possíveis? Na sequência, vamos fazer esse questionamento para o ChatGPT.

-----------------------------------------------------------------------
# 02Criando mais cenários de testes

## Transcrição

Conseguimos gerar testes automatizados com o ChatGPT. Porém, a IA só gerou três métodos de testes, isto é, três cenários possíveis.

Será que não existem mais cenários para a classe `ValidadorHorarioFuncionamentoClinica` e seu algoritmo?

> É uma boa prática aplicar testes automatizados em vários cenários distintos.

Um teste para cada cenário é suficiente para não repetir e criar testes desnecessários.

## Mais cenários de testes

Vamos perguntar ao ChatGPT se existem mais possíveis cenários que ele poderia gerar para esse código. Assim, garantimos uma boa cobertura de teste.

Caso contrário, podemos ter uma falsa sensação de segurança já que temos uma classe de testes automatizados e passamos em todos os testes. Podemos pensar que não tem bug no código, mas apenas o que foi testado não tem bug. Mas, e se esquecemos algum cenário?

Na mesma conversa anterior sobre testes JUnit e Mockito, vamos escrever a seguinte pergunta:

```plaintext
Existem mais cenários de testes possíveis para essa classe?
```

> Sim, existem outros cenários de teste que você pode considerar para a classe ValidadorHorarioFuncionamentoClinica. Aqui estão alguns exemplos adicionais:
> 
> 1 - Teste para uma consulta exatamente no horário de abertura da clínica

```java
@Test
void validar_ConsultaNoHorarioDeAbertura_NaoDeveLancarExcecao() {
    DadosAgendamentoConsulta dados = criarDadosAgendamentoConsulta(LocalDateTime.of(2023, 6, 1, 7, 0)); // Segunda-feira, 7:00

    assertDoesNotThrow(() -> validador.validar(dados));
}
```

> 2 - Teste para uma consulta exatamente no horário de encerramento da clínica

```java
@Test
void validar_ConsultaNoHorarioDeEncerramento_NaoDeveLancarExcecao() {
    DadosAgendamentoConsulta dados = criarDadosAgendamentoConsulta(LocalDateTime.of(2023, 6, 1, 18, 0)); // Segunda-feira, 18:00

    assertDoesNotThrow(() -> validador.validar(dados));
}
```

> 3 - Teste para uma consulta agendada em um dia da semana diferente de domingo

```java
@Test
void validar_ConsultaEmDiaDeSemana_NaoDeveLancarExcecao() {
    DadosAgendamentoConsulta dados = criarDadosAgendamentoConsulta(LocalDateTime.of(2023, 6, 5, 10, 0)); // Segunda-feira, 10:00

    assertDoesNotThrow(() -> validador.validar(dados));
}
```

> 4 - Teste para uma consulta agendada em um horário antes do horário de abertura da clínica em um dia de semana

```java
@Test
void validar_ConsultaAntesDoHorarioDeAberturaEmDiaDeSemana_LancaValidacaoException() {
    DadosAgendamentoConsulta dados = criarDadosAgendamentoConsulta(LocalDateTime.of(2023, 6, 1, 6, 59)); // Segunda-feira, 6:59

    assertThrows(ValidacaoException.class, () -> validador.validar(dados));
}
```

> 5 - Teste para uma consulta agendada em um horário depois do horário de encerramento da clínica em um dia de semana

```java
@Test
void validar_ConsultaDepoisDoHorarioDeEncerramentoEmDiaDeSemana_LancaValidacaoException() {
    DadosAgendamentoConsulta dados = criarDadosAgendamentoConsulta(LocalDateTime.of(2023, 6, 1, 18, 1)); // Segunda-feira, 18:01

    assertThrows(ValidacaoException.class, () -> validador.validar(dados));
}
```

> Estes são apenas alguns exemplos adicionais de cenários de teste que você pode considerar. Lembre-se de testar casos de sucesso, casos de falha e exceções esperadas, cobrindo uma variedade de situações dentro do horário de funcionamento da clínica e fora dele.
> 
> Adapte esses exemplos de acordo com as regras e requisitos específicos do seu sistema. Quanto mais cenários de teste você cobrir, melhor será a cobertura do seu código e mais confiança você terá em sua implementação.
> 
> Espero que isso ajude! Se você tiver mais dúvidas, fique à vontade para perguntar.

A IA começa a listar cinco novos cenários e seus respectivos códigos. Perceba como nem sempre a primeira resposta vai ser completa e cobrindo todos os cenários. Foi preciso questioná-lo.

Em suas orientações, a IA ressalta que devemos testar casos de sucesso e casos de falha. Além disso, é bom testar os casos de borda. Por exemplo, se deve devolver um valor numérico de 1000 reais, o ideal é testar com valores próximos e distantes desse limite.

Por isso, é preciso ter conhecimento em programação para conseguir usar o ChatGPT para programar. Afinal, devemos saber perguntar e julgar se o que foi respondido está correto.

Vamos copiar os cinco cenários que foram gerados para garantir que o nosso código funciona de acordo com as principais possibilidades. Basta copiar o código e colar na classe `ValidadorHorarioFuncionamentoClinicaTest.java`.

Houve um erro de compilação em `validar_ConsultaNoHorarioDeAbertura_NaoDeveLancarExcecao()` e `validar_ConsultaNoHorarioDeEncerramento_NaoDeveLancarExcecao()`, pois chamou um método `assertDoesNotThrow()` que não está importado.

Usamos o atalho "Alt + Enter" e aceitamos a sugestão "_import static method org.junit.jupiter.api.Assertions.assertDoesNotThrow_".

## Executando os testes

Agora temos oito cenários de testes com várias situações possíveis, vamos executá-los para garantir que a classe está funcionando. Se algum teste falha, o teste pode ter sido gerado errado ou o código tem um bug.

Novamente clicamos no ícone de "play" à esquerda da assinatura da classe e escolhemos a opção "Run ValidadorHorarioFuncionamentoClinicaTest".

> Tests failed: 1, passed 7 of 8 testes - 663 ms

No painel inferior, percebemos que falhamos no teste `validar_ConsultaDepoisDoHorarioDeEncerramentoEmDiaDeSemana_LancaValidacaoException()`.

É sempre bom avaliar o cenário de teste para garantir que o teste está válido e, só depois, verificar o código.

Nesse cenário, o ChatGPT criou um agendamento pra o dia primeiro de junho de 2023 às 18:01. A clínica funciona até às 19:00, só que o último horário possível de consulta é às 18:00, já que a consulta tem 1 hora de duração. Por isso, não deveria aceita às 18:01.

De fato, era para lançar uma exceção, pois tentamos agendar em um horário não permitido. Repare como esse é um cenário na borda.

Como não foi lançada a _exception_, sabemos que existe um bug no código. Vamos até `ValidadorHorarioFuncionamentoClinica.java` para analisar o código e tentar descobrir onde está o bug.

Podemos analisar linha por linha e fazer o ajuste manualmente ou usar o ChatGPT para nos ajudar a corrigir o bug no código.

Vamos falar para a IA qual cenário falhou. Não precisamos colocar o código da classe testada, pois já havíamos mandado-o anteriormente nessa conversa.

```plaintext
O cenário "validar_ConsultaDepoisDoHorarioDeEncerramentoEmDiaDeSemana_LancaValidacaoException" falhou, pois o método de validação não lançou uma exception. Você poderia corrigir o código?
```

O ChatGPT não entende a nossa pergunta. Ele acha que estávamos falando que o código do teste estava errado. Na verdade, é o código do algoritmo. Por isso, vamos clicar em "_Stop generating_" para parar sua resposta equivocada. Vamos reforçar em uma nova linha:

```plaintext
Na verdade, o código da classe "ValidadorHorarioFuncionamentoClinica" que está incorreto, pois ao agendar uma consulta as 18:01, ele não lançou exception. Poderia corrigir o código do método "validar" da classe "ValidadorHorarioFuncionamentoClinica"?
```

Agora que fomos mais específicos, o ChatGPT entende a pergunta e corrige o código pedido.

> Peço desculpas pela confusão anterior. Vamos corrigir o código do método `validar` na classe `validadorHorarioFuncionamentoClinica`. Aqui está a versão corrigida:

```java
@Component
public class ValidadorHorarioFuncionamentoClinica implements ValidadorAgendamentoConsulta {

    public void validar(DadosAgendamentoConsulta dados) {
        LocalDateTime dataConsulta = dados.data();

        boolean domingo = dataConsulta.getDayOfWeek().equals(DayOfWeek.SUNDAY);
        boolean antesDaAberturaDaClinica = dataConsulta.getHour() < 7 || (dataConsulta.getHour() == 7 && dataConsulta.getMinute() < 1);
        boolean depoisDoEncerramentoDaClinica = dataConsulta.getHour() > 18 || (dataConsulta.getHour() == 18 && dataConsulta.getMinute() > 0);

        if (domingo || antesDaAberturaDaClinica || depoisDoEncerramentoDaClinica) {
            throw new ValidacaoException("Consulta fora do horário de funcionamento da clínica");
        }
    }

}
```

Não podemos assumir que a inteligência artificial não erra, afinal foi feito por humanos.

Vamos copiar a alteração no algoritmo gerado pelo ChatGPT. Podemos copiar somente o corpo do método `validar()`, desde `LocalDateTime` até o `if` e substituir o método `validar()` da classe `ValidadorHorarioFuncionamentoClinica` no IntelliJ.

Será que a modificação está correta? Será que corrigiu o bug, mas não criou um bug em outra possibilidade? Por isso, é tão importante fazer esses testes automatizados.

Vamos rodar todos os testes novamente para conferir se será necessário fazer uma correção em outro cenário.

> Tests failed: 1, passed 7 of 8 testes - 675 ms

O teste anterior foi corrigo, mas gerou bug em outro método `validar_ConsultaNoHorarioDeAbertura_NaoDeveLancarExcecao()`.

Conferimos que nesse método, ele criou uma consulta em primeiro de junho às 7:00 e não lançou exceção. O teste está correto. Contudo, na classe `ValidadorHorarioFuncionamentoClinica` foi lançada uma exceção.

Podemos analisar o código gerado ou insistir e pedir para o ChatGPT corrigir. Nesse caso, vamos conferir manualmente o que foi feito nesse novo algoritmo.

Primeiro, é verificado se a data não é domingo. Depois, é verificado se a `dataConsulta` é antes das 7 ou é às 7 com minuto menor do que 1. Em seguida, é verificado se a consulta é depois das 18 ou às 18 com minuto maior do que 0. Nesses casos, é lançado um erro.

Contudo, podemos marcar uma consulta no horário de abertura da clínica às 7 em ponto. Por isso, não precisamos do "ou" em `antesDaAberturaDaClinica`. Assim, apagamos o trecho `|| (dataConsulta.getHour() == 7 && dataConsulta.getMinute() < 1)`.

```java
@Component
public class ValidadorHorarioFuncionamentoClinica implements ValidadorAgendamentoConsulta {

    public void validar(DadosAgendamentoConsulta dados) {
        LocalDateTime dataConsulta = dados.data();

        boolean domingo = dataConsulta.getDayOfWeek().equals(DayOfWeek.SUNDAY);
        boolean antesDaAberturaDaClinica = dataConsulta.getHour() < 7;
        boolean depoisDoEncerramentoDaClinica = dataConsulta.getHour() > 18 || (dataConsulta.getHour() == 18 && dataConsulta.getMinute() > 0);

        if (domingo || antesDaAberturaDaClinica || depoisDoEncerramentoDaClinica) {
            throw new ValidacaoException("Consulta fora do horário de funcionamento da clínica");
        }
    }

}
```

Se for antes das 7:00, não será possível marcar uma consulta. Mas, às 7:00 já deveria ser permitido criar uma consulta.

Agora, precisamos testar novamente para confirmar se foi solucionado o problema.

> Tests passed: 8 of 8 tests - 665 ms

Deu certo! Conseguimos concluir mais um objetivo de testes automatizados.

Lembre-se se você não pedir para todos os cenários, pode ser que o ChatGPT gere testes para apenas poucos cenários. Caso isso aconteça, peça mais possibilidades e os avalie.

Se alguém do seu time é analista de testes ou QA, você pode chamar essa pessoa para te orientar, ajudar a entender os cenários e perceber se falta alguma possibilidade. Além disso, tenha em mente que nem sempre o ChatGPT vai acertar tudo e é preciso avaliar a saída gerada.

Na sequência, vamos continuar a tratar de testes, mas com outra abordagem e outro tipo de código.

-----------------------------------------------------------------------
# 03Testando uma consulta SQL

## Transcrição

Conseguimos gerar os testes da nossa classe de validação com todos os cenários e corrigindo os bugs. Porém, a classe que estávams testando é uma classe Java que não acessa banco de dados, API ou serviço externo e este é um **teste de unidade**.

Para testar uma classe que acessa um serviço externo, precisamos fazer um **teste de integração**, que é um pouco mais complexo. Vamos descobrir se o ChatGPT consegue testar esse tipo de código!

Vamos abrir **src** > **main** > **java** > **domain** > **consulta** > **MedicoRepository.java**. A interface **ConsultaRepository.java**, no caso do Java, é o tipo de código que faz o acesso ao banco de dados. Anteriormente, fizemos o código que cria o relatório de consultas para cada médico em determinado mês:

```python
@Query("""
     SELECT new med.voll.api.domain.consulta.dto.DadosRelatorioConsultaMensal(m.nome, m.crm, COUNT(c))
     FROM Consulta c JOIN c.medico m
     WHERE c.data >= :inicioMes AND c.data <= :fimMes
     GROUP BY m.nome, m.crm
     """)
List<DadosRelatorioConsultaMensal> gerarRelatorioConsultaMensal(LocalDateTime inicioMes, LocalDateTime fimMes);
```

Mas será que esta consulta está correta e testa todas as possibilidades?

Para testar este método, precisamos de um teste de integração, onde acessamos o banco de dados, inserimos os registros e fazemos simulações para ver se ele devolve informações conforme o esperado. Vamos voltar ao ChatGPT para que ele nos auxilie!

Podemos continuar no mesmo chat. Então vamos agradecer e, na mensagem seguinte, enviar o texto:

```plaintext
Agora, tenho um outro tipo de código para gerar testes automatizados. Minha aplicação Java utiliza o Spring Boot e possui interfaces Repository, que acessam o banco de dados. Você consegue gerar código de teste automatizado para uma interface repository se eu te mandar o código dela e das classes de modelo que ela utiliza?
```

Como retorno, o Chat nos informa que é possível e nos dá uma dica de funcionamento do teste:

```plaintext
Sim, eu posso ajudar a gerar código de teste automatizado para uma interface Repository do Spring Boot. Por favor, forneça o código da interface Repository e também das classes de modelo associadas. Assim, poderei criar exemplos de testes para você.
Por favor, certifique-se de incluir as seguintes informações:
•Código da interface Repository
•Código das classes de modelo (entidades) associadas, incluindo suas anotações e relacionamentos relevantes.
Com essas informações, poderei gerar exemplos de testes automatizados para a interface Repository. Fico no aguardo do seu código.
```

Além disso, note que ele solicita o código da interface Repository e das classes de modelo associadas.

Neste caso, faremos o teste usando o banco de dados em memória. No projeto, o banco de dados H2 já está nas dependências, então explicaremos isso ao Chat passando o código do método que queremos testar.

```plaintext
Leve em consideração que desejo utilizar um banco de dados em memória para gerar os testes.

@Query("""
     SELECT new med.voll.api.domain.consulta.dto.DadosRelatorioConsultaMensal(m.nome, m.crm, COUNT(c))
     FROM Consulta c JOIN c.medico m
     WHERE c.data >= :inicioMes AND c.data <= :fimMes
     GROUP BY m.nome, m.crm
     """)
List<DadosRelatorioConsultaMensal> gerarRelatorioConsultaMensal(LocalDateTime inicioMes, LocalDateTime fimMes);
```

Lembre-se que este método está usando outras classes do projeto, então precisamos passar os códigos delas também. Ele nos devolve `List<DadosRelatorioConsultaMensal>`, por isso também passaremos seu código.

```plaintext
Leve em consideração que desejo utilizar um banco de dados em memória para gerar os testes.

@Query("""
     SELECT new med.voll.api.domain.consulta.dto.DadosRelatorioConsultaMensal(m.nome, m.crm, COUNT(c))
     FROM Consulta c JOIN c.medico m
     WHERE c.data >= :inicioMes AND c.data <= :fimMes
     GROUP BY m.nome, m.crm
     """)
List<DadosRelatorioConsultaMensal> gerarRelatorioConsultaMensal(LocalDateTime inicioMes, LocalDateTime fimMes);
        
public record DadosRelatorioConsultaMensal(String nome, String crm, Long quantidadeConsultasNoMes) {}
```

Além disso, a query desse método faz uma consulta SQL na tabela de consulta, então também precisamos passar o código da entidade `Consulta.java`.

```plaintext
Leve em consideração que desejo utilizar um banco de dados em memória para gerar os testes.

@Query("""
     SELECT new med.voll.api.domain.consulta.dto.DadosRelatorioConsultaMensal(m.nome, m.crm, COUNT(c))
     FROM Consulta c JOIN c.medico m
     WHERE c.data >= :inicioMes AND c.data <= :fimMes
     GROUP BY m.nome, m.crm
     """)
List<DadosRelatorioConsultaMensal> gerarRelatorioConsultaMensal(LocalDateTime inicioMes, LocalDateTime fimMes);
        
public record DadosRelatorioConsultaMensal(String nome, String crm, Long quantidadeConsultasNoMes) {}

@Table(name = "consultas")
@Entity(name = "Consulta")
@Getter
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
public class Consulta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "medico_id")
    private Medico medico;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "paciente_id")
    private Paciente paciente;

    private LocalDateTime data;

    public Consulta(Medico medico, Paciente paciente, LocalDateTime data) {
        this.medico = medico;
        this.paciente = paciente;
        this.data = data;
    }

}
```

Ao enviar, o Chat nos retorna o código de teste automatizado. Neste teste, ele usa o repository, cria os registros e os salva no banco, chama o método da consulta e faz as assertivas.

> Retorno omitido.

Vamos copiar o código recebido. Em seguida, no arquivo `ConsultaRepository.java`, clicamos no nome da interfa `ConsultaRepository`, na linha 12, teclamos "ALT + Enter" e selecionamos a opção "Create test". Uma janela se abrirá e, nela, clicamos em "OK".

Feito isso, a classe de teste é criada e enviada ao diretório. Um arquivo `ConsultaRepositoryTest.java` é aberto, onde substituímos a classe pelo código gerado pelo Chat.

Note que, no código, o Chat instanciou um objeto `Medico`, mas não mandamos a classe `Medico` e por isso ela foi criada erroneamente. Pensando nisso, vamos mandar as classes para ele:

```plaintext
Esqueci de te mandar as classes Medico e Paciente. Vou te mandar e você pode ajustar o código que instancia objetos desse tipo?

@Table(name = "medicos")
@Entity(name = "Medico")
@Getter
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
public class Medico {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    private String email;

    private String telefone;

    private String crm;

    @Enumerated(EnumType.STRING)
    private Especialidade especialidade;

    @Embedded
    private Endereco endereco;

    private Boolean ativo;

    public Medico(DadosCadastroMedico dados) {
        this.ativo = true;
        this.nome = dados.nome();
        this.email = dados.email();
        this.telefone = dados.telefone();
        this.crm = dados.crm();
        this.especialidade = dados.especialidade();
        this.endereco = new Endereco(dados.endereco());
    }

    public void atualizarInformacoes(DadosAtualizacaoMedico dados) {
        if (dados.nome() != null) {
            this.nome = dados.nome();
        }
        if (dados.telefone() != null) {
            this.telefone = dados.telefone();
        }
        if (dados.endereco() != null) {
            this.endereco.atualizarInformacoes(dados.endereco());
        }
    }

    public void desativar() {
        this.ativo = false;
    }
}


@Table(name = "pacientes")
@Entity(name = "Paciente")
@Getter
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
public class Paciente {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    private String email;

    private String telefone;

    private String cpf;

    @Embedded
    private Endereco endereco;

    private Boolean ativo;

    public Paciente(DadosCadastroPaciente dados) {
        this.ativo = true;
        this.nome = dados.nome();
        this.email = dados.email();
        this.telefone = dados.telefone();
        this.cpf = dados.cpf();
        this.endereco = new Endereco(dados.endereco());
    }

    public void atualizarInformacoes(DadosAtualizacaoPaciente dados) {
        if (dados.nome() != null) {
            this.nome = dados.nome();
        }
        if (dados.telefone() != null) {
            this.telefone = dados.telefone();
        }
        if (dados.endereco() != null) {
            this.endereco.atualizarInformacoes(dados.endereco());
        }
    }

    public void desativar() {
        this.ativo = false;
    }

}
```

Neste projeto, para criar um objeto Paciente, o construtor não passa os dados diretamente, mas sim através das classes `DadosCadastroPaciente.java` e `DadosCadastroMedico.java`, então precisamos passá-las também.

```plaintext
Esqueci de te mandar as classes Medico e Paciente. Vou te mandar e você pode ajustar o código que instancia objetos desse tipo?

@Table(name = "medicos")
@Entity(name = "Medico")
@Getter
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
public class Medico {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    private String email;

    private String telefone;

    private String crm;

    @Enumerated(EnumType.STRING)
    private Especialidade especialidade;

    @Embedded
    private Endereco endereco;

    private Boolean ativo;

    public Medico(DadosCadastroMedico dados) {
        this.ativo = true;
        this.nome = dados.nome();
        this.email = dados.email();
        this.telefone = dados.telefone();
        this.crm = dados.crm();
        this.especialidade = dados.especialidade();
        this.endereco = new Endereco(dados.endereco());
    }

    public void atualizarInformacoes(DadosAtualizacaoMedico dados) {
        if (dados.nome() != null) {
            this.nome = dados.nome();
        }
        if (dados.telefone() != null) {
            this.telefone = dados.telefone();
        }
        if (dados.endereco() != null) {
            this.endereco.atualizarInformacoes(dados.endereco());
        }
    }

    public void desativar() {
        this.ativo = false;
    }
}


@Table(name = "pacientes")
@Entity(name = "Paciente")
@Getter
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
public class Paciente {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    private String email;

    private String telefone;

    private String cpf;

    @Embedded
    private Endereco endereco;

    private Boolean ativo;

    public Paciente(DadosCadastroPaciente dados) {
        this.ativo = true;
        this.nome = dados.nome();
        this.email = dados.email();
        this.telefone = dados.telefone();
        this.cpf = dados.cpf();
        this.endereco = new Endereco(dados.endereco());
    }

    public void atualizarInformacoes(DadosAtualizacaoPaciente dados) {
        if (dados.nome() != null) {
            this.nome = dados.nome();
        }
        if (dados.telefone() != null) {
            this.telefone = dados.telefone();
        }
        if (dados.endereco() != null) {
            this.endereco.atualizarInformacoes(dados.endereco());
        }
    }

    public void desativar() {
        this.ativo = false;
    }

}


public record DadosCadastroPaciente(
        @NotBlank
        String nome,
        
        @NotBlank
        @Email
        String email,

        @NotBlank
        @Pattern(regexp = "^(\\(\\d{2}\\)|\\d{2})\\s?\\d{4,5}-?\\d{4}$")
        String telefone,
        
        @NotBlank
        @Pattern(regexp = "\\d{3}\\.?\\d{3}\\.?\\d{3}\\-?\\d{2}")
        String cpf,

        @NotNull @Valid 
        DadosEndereco endereco) {
}


public record DadosCadastroMedico(
        @NotBlank
        String nome,
       
        @NotBlank
        @Email
        String email,

        @NotBlank
        String telefone,
        
        @NotBlank
        @Pattern(regexp = "\\d{4,6}")
        String crm,
       
        @NotNull
        Especialidade especialidade,

        @NotNull @Valid 
        DadosEndereco endereco) {
}
```

Vamos enviar.

> Retorno omitido.

Como retorno, obtemos o código ajustado, criando o objeto de `DadosCadastroMedico` com as informações e instanciando os objetos `Medico` e `Paciente` com seus respectivos dados.

Ele nos envia apenas parte do código com a mensagem "Restante do código de teste" ao final. Então, basta substituirmos o trecho que estava instanciando `Medico` e `Paciente`.

O trecho no primeiro código é este:

```java
Medico medicol = new Medico ("Dr. João", "CRM123"); Medico medico2 = new Medico ("Dr. Maria", "CRM456"); Paciente pacientel = new Paciente ( dados: "João"); Paciente paciente2 = new Paciente ( dados: "Maria");|
```

Então o substituiremos pelo seguinte trecho do código ajustado:

```java
Medico medico1 = new Medico (dadosMedico1); Medico medico2 = new Medico (dadosMedico2); 
Paciente pacientel = new Paciente (dadosPaciente1);
Paciente paciente2 = new new Paciente (dadosPaciente2);
```

Não mandamos as especialidades e, portanto, o Chat não sabe quais temos no projeto, colocando aleatórias, como pediatria. Vamos alterar para especialidades existentes como cardiologia ou dermatologia.

Além disso, não mandamos o endereço, então vamos pedir que ele instancie este objeto:

```plaintext
Pode corrigir a instância do objeto endereco de acordo com esse record?


public record DadosEndereco(
        @NotBlank
        String logradouro,
        
        @NotBlank
        String bairro,
        
        @NotBlank
        @Pattern(regexp = "\\d{8}")
        String cep,
        
        @NotBlank
        String cidade,
        
        @NotBlank
        String uf,
        
        String complemento,
        String numero) {
}
```

> Retorno omitido.

Como retorno, obtemos somente os dados de endereço. Vamos copiar apenas um desses dados, contendo `new`, e substituir nas ocorrências de endereço.

Como estava estruturado:

```less
new DadosEndereco(logradouro: "Rua A", bairro: "Cidade X", cep: "12345-678")
```

Como deve ficar:

```less
new DadosEndereco(
    logradouro:"Rua A",
    bairro: "Bairro X",
    cep: "12345678",
    cidade: "Cidade X",
    uf: "UF",
    complemento: null,
    numero: null
);
```

No projeto, o endereço é indiferente para os testes, por isso optamos por substituir todas as ocorrências de endereço por apenas um deles, como se todos tivessem as mesmas informações de endereço.

Com isso, percebemos que é preciso conhecer o código do projeto para saber o que aproveitar dos códigos feitos pelo ChatGPT.

Note que o código está indicando um erro, pois as variáveis `dadosMedico1` e `dadosMedico2` já existem. Vamos renomeá-las para `relatorio1` e `relatorio2`, respectivamente, em todas as suas ocorrências no código.

Vamos pedir que ele gere o código novamente para evitar possíveis problemas, já que os ajustes foram enviados por parte:

```plaintext
pode gerar novamente o código de teste completo, levando em consideração todas as classe que enviei?
```

> Retorno omitido.

Como retorno, obtemos o código completo. Ou seja, conseguimos usar o ChatGPT, mas ainda precisamos analisar o código gerado para evitar possíveis falhas.

Vamos copiar o código inteiro e substituir no arquivo. Em seguida, nos certificamos de incluir especialidades que existam no nosso projeto para não gerar erro.

Note que foi gerado apenas um cenário, mas vamos testar. Para isso clicamos em "Run Teste", representado por um botão de _play_, na cor verde, à esquerda de `public class ConsultaRepositoryTest`. Em seguida, selecionamos "Run 'ConsultaRepositoryTest'".

O teste será executado. Ao finalizar, o relatório é gerado e as informações estão corretas.

A princípio, o método da interface `Repository` está funcionando corretamente, mas apenas para este cenário. Pensando nisso, podemos solicitar que o ChatGPT gere mais cenários.

Concluímos, então, que independente do tipo de teste, o Chat consegue nos ajudar!


-----------------------------------------------------------------------
# 07Conclusão

## Transcrição

**Parabéns por finalizar este curso de ChatGPT e programação!**

Conseguimos alcançar nossos objetivos e aprendemos a utilizar o ChatGPT como ferramenta de auxílio nos casos mais comuns de programação.

Começamos entendendo nosso projeto e vimos que havia bugs no código, então utilizamos o ChatGPT para nos auxiliar na correção desses bugs. Neste processo, vimos que ele não fez a identificação correta, embora tenha nos ajudado a detectar o problema.

Além disso, aprendemos a usar o Chat como ferramenta de aprendizado ao solicitar que explicasse as linhas de um código.

Partindo para conceitos mais específicos, aprendemos sobre expressões regulares (regex), SQL e, por fim, testes automatizados.

Há muitos outros cenários que nos permitem utilizar esta ferramenta, como, por exemplo, para refatoração de códigos. Mas precisamos estar atentos, pois eventualmente o Chat pode gerar um código com falhas. Pensando nisso, precisamos sempre fornecer o máximo de contexto possível.

Por fim, lembre-se que o ChatGPT não substitui o trabalho de uma pessoa desenvolvedora! É preciso saber usá-lo e, principalmente, saber avaliar as respostas retornadas por ele. Trata-se, então, de uma ferramenta de apoio!

Esperamos que você tenha aproveitado este curso. Na plataforma, temos vários outros sobre I.As, não deixe de conferir!



-----------------------------------------------------------------------
