---
type: "9"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
---

Tópico:: #Java #JPA #Spring_Boot

### O que aprenderemos neste curso

- Implementar uma nova funcionalidade no projeto;
- Avaliar quando é necessário criar uma classe Service na aplicação;
- Criar uma **classe Service**, com o objetivo de isolar códigos de regras de negócio, utilizando para isso a anotação `@Service`;
- Implementar um algoritmo para a funcionalidade de agendamento de consultas;
- Realizar **validações de integridade** das informações que chegam na API;
- Implementar uma consulta JPQL (_Java Persistence Query Language_) complexa em uma _interface repository_, utilizando para isso a anotação `@Query`.

## Nesta aula, você aprendeu como:

- Isolar os códigos de validações de regras de negócio em classes separadas, utilizando nelas a anotação `@Component` do Spring;
- Finalizar a implementação do algoritmo de agendamento de consultas;
- Utilizar os **princípios SOLID** para deixar o código da funcionalidade de agendamento de consultas mais fácil de entender, evoluir e testar.

## Nesta aula, você aprendeu como:

- Isolar os códigos de validações de regras de negócio em classes separadas, utilizando nelas a anotação `@Component` do Spring;
- Finalizar a implementação do algoritmo de agendamento de consultas;
- Utilizar os **princípios SOLID** para deixar o código da funcionalidade de agendamento de consultas mais fácil de entender, evoluir e testar.

## Nesta aula, você aprendeu como:

- Adicionar a **biblioteca SpringDoc** no projeto para que ela faça a geração automatizada da documentação da API;
- Analisar a documentação do SpringDoc para entender como realizar a sua configuração em um projeto;
- Acessar os endereços que disponibilizam a documentação da API nos formatos yaml e html;
- Utilizar o **Swagger UI** para visualizar e testar uma API Rest;
- Configurar o JWT na documentação gerada pelo SpringDoc.


## Nesta aula, você aprendeu como:

- Escrever **testes automatizados** em uma aplicação com Spring Boot;
- Escrever testes automatizados de uma interface _Repository_, seguindo a estratégia de usar o mesmo banco de dados que a aplicação utiliza;
- Sobrescrever propriedades do arquivo `application.properties`, criando outro arquivo chamado `application-test.properties` que seja carregado apenas ao executar os testes, utilizando para isso a anotação `@ActiveProfiles`;
- Escrever testes automatizados de uma classe Controller, utilizando a classe `MockMvc` para simular requisições na API;
- Testar cenários de erro 400 e código 200 no teste de uma classe controller.

## Nesta aula, você aprendeu como:

- Funciona o build de uma aplicação com Spring Boot;
- Utilizar arquivos de propriedades específicos para cada profile, alterando em cada arquivo as propriedades que precisam ser modificadas;
- Configurar informações _sensíveis_ da aplicação, como dados de acesso ao banco de dados, via **variáveis de ambiente**;
- Realizar o build do projeto via Maven;
- Executar a aplicação via terminal, com o comando `java -jar`, passando as variáveis de ambiente como parâmetro.



Um dos objetivos deste curso é implementarmos a funcionalidade de **agendamento de consultas**. Anteriormente, desenvolvemos o CRUD de médicos e o de pacientes. Faltou implementar a funcionalidade mais importante do projeto, o agendamento de consultas.

Também aprenderemos a **documentar a nossa API** para facilitar a vida de quem precisa consumi-la, ou seja, a equipe que desenvolverá o aplicativo mobile ou a aplicação Front-End da nossa API.

Essas pessoas precisam saber quais as URLs da nossa API, os métodos HTTP suportados, os parâmetros, o formato, o que é devolvido pela API e assim por diante. Geraremos uma documentação automática usando uma biblioteca que se integra com o Spring Boot.

Também aprenderemos a **fazer testes automatizados** em um projeto com Spring Boot. Já que implementamos _repository_ e _controllers_, precisaremos fazer testes automatizados destes componentes.

Mas como escrever um teste com a biblioteca JUnit padrão do Java para testar essas classes e componentes que dependem de informações e recursos do Spring? Aprenderemos a fazer isso neste curso.

Por fim, aprenderemos sobre o _build_ do projeto. Imagine que terminamos o nosso projeto e queremos fazer o seu _deploy_ em algum servidor, seja um servidor Cloud ou interno da empresa.

Como geramos o pacote do projeto e fazemos o _build_? Como funciona o build de uma aplicação que utiliza o Spring Boot? Como executamos o projeto dentro de um servidor independentemente da plataforma utilizada? Também falaremos de tudo isso neste curso.

Além disso, continuaremos trabalhando no projeto da clínica médica, com mesmo quadro Trello com o detalhamento da funcionalidade e aprenderemos a usar esses recursos ao longo do curso.


-----------------------------------------------------------------------
# Nova funcionalidade

## Transcrição

Vamos começar o projeto! Estou com o Trello dele aberto no navegador. Na coluna "DONE", podemos observar que já implementamos as funcionalidades do CRUD do médico e de pacientes. À esquerda, na coluna "TO DO", faltaram as funcionalidades de agendamento e cancelamento de consultas.

Começaremos implementando o agendamento. Por isso, arrastaremos o cartão "Agendamento de Consultas" para a coluna "DOING". Com um clique sobre o cartão, abriremos as informações dele e, como de costume, leremos a descrição da funcionalidade para entender o que precisamos fazer.

A descrição diz o seguinte:

> "O sistema deve possuir uma funcionalidade que permita o agendamento de consultas, na qual as seguintes informações deverão ser preenchidas: Paciente, Médico, Data/Hora da consulta".

> "As seguintes regras de negócio devem ser validadas pelo sistema: (segue lista com regras de negócio)".

Essa é uma funcionalidade similar às que já implementamos. A nossa API receberá uma requisição com o ID de paciente ou de médico e a data em que a consulta será realizada.

Com essas informações, faremos as validações e as salvaremos no banco de dados. A diferença é que agora temos regras de negócio mais complexas do que as que vimos anteriormente para médico e paciente.

Abrirei o nosso layout do Figma com um modelo de aplicativo mobile para o nosso projeto.

![Três telas com o layout de aplicativo mobile para agendar consultas médicas. Na primeira, da esquerda para a direita, há o cabeçalho "Consultas" no canto superior esquerdo, seguido do menu estilo kebab (três pontos alinhados na vertical) à direita. A primeira tela tem dois subtítulos principais: "Envolvidos" e "Data e horário". No primeiro subitem, há dois campos para preenchimento do usuário ("Nome do paciente" e "Nome do médico"). O segundo subitem permite a escolha da Data da Consulta e o seu Horário. A segunda tela apresenta o mesmo layout, agora com três dos quatro campos de preenchimento com o texto em vermelho e contendo a mensagem "Campo obrigatório" na parte inferior. A última tela mostra o layout com todos os campos preenchidos pela pessoa usuária. Os três layouts têm dois botões na parte inferior ("Agendar Consulta" e "Cancelar"), mas somente na última tela o botão "Agendar Consulta" pode ser selecionado, estando em destaque na cor azul.](https://cdn1.gnarususercontent.com.br/1/1135860/27c54178-b0a2-4d4a-a48c-826311fa938a.png)

No aplicativo mobile, a pessoa terá uma tela para agendar uma nova consulta, que contém o nome do ou da paciente e do médico ou médica. Essas informações serão puxadas do nosso banco de dados. Além disso, haverá dois campos para escolha do dia e do horário da consulta, bem como um botão para confirmar o agendamento.

Com isso, o aplicativo mobile precisa fazer validações dos campos obrigatórios, sendo opcional apenas o campo "Nome do médico".

Quando a pessoa preencher todos os campos obrigatórios e clicar em "Agendar consulta", uma requisição será disparada para a nossa API. Precisaremos receber esses dados e fazer o tratamento deles conforme já fizemos nas outras funcionalidades.

Voltando ao cartão no Trello, a única diferença são algumas das validações, que exigirão a escrita de um algortimo, consulta no banco de dados etc.

Assim, estas não são só validações de formulário como aquelas com as quais trabalhamos anteriormente com _BIN validation_ (campo obrigatório, campo número ou texto, tamanho mínimo e máximo etc.). Agora, teremos que aprender a trabalhar com validações um pouco mais complexas.

### Códigos para novas funcionalidades

Se pararmos para pensar, boa parte do código que usaremos para implementar essa funcionalidade será reaproveitado dos passos que fizemos anteriormente.

Assim, para implementar esta ou quaisquer outras funcionalidades, seguimos uma espécie de passo-a-passo. Precisamos criar sempre os seguintes tipos de códigos:

- Controller, para mapear a requisição da nova funcionalidade;
- DTOs, que representam os dados que chegam e saem da API;
- Entidade JPA;
- Repository, para isolar o acesso ao banco de dados;
- Migration, para fazer as alterações no banco de dados.

Estes são os cinco tipos de código que sempre desenvolveremos para uma nova funcionalidade. Isso também se aplica ao agendamento das consultas, incluindo um sexto item à lista, as **regras de negócio**. Nesta aula, entenderemos como implementar as regras de negócio com algoritmos mais complexos.

### Implementando a funcionalidade

Agora que já entendemos o que precisa ser feito, desenvolveremos a funcionalidade por partes. Começaremos pelos cinco primeiros itens da lista, que são mais básicos. Em seguida, abordaremos a parte de regras de negócio.

Abrirei o IntelliJ com o projeto importado na IDE. É o mesmo projeto do curso anterior, que finalizamos com a parte de segurança e tratamento de erros.

Como a primeira parte seguirá um mesmo padrão, deixei essas classes prontas no código. Criei um novo `ConsultaController` no pacote "src > main > java > med.voll.api > controller".

Já que não estaremos mais cadastrando pacientes, mas consultas, a ideia é ter um Controller para receber essas requisições relacionadas a agendamento de consultas.

Ela é uma classe Controller, com as anotações do Spring: `@RestController` e `@RequestMapping("consultas")`. Ele mapeia requisições que chegam com a URI "/consultas", sabendo que deve chamar este controller e não os outros.

Em seguida, temos um método anotado com `@PostMapping`. Então, a requisição para agendar uma consulta será do tipo Post, assim como observamos nas outras funcionalidades.

Ele recebe um DTO com os dados do agendamento (`DadosAgendamentoConsulta`) e, no momento, a única coisa que fiz de diferente foi dar um `System.out` nos dados, para garantir que eles cheguem corretamente. Por fim, o método devolve um código 200 com o DTO de resposta.

Perceba que temos um DTO que representa os dados que chegam da API, ou seja, o nome da pessoa paciente, do médico ou médica e a data e hora da consulta (`DadosAgendamentoConsulta`).

```less
// Trecho de código suprimido

@RestController
@RequestMapping("consultas")
public class ConsultaController {

    @PostMapping
    @Transactional
    public ResponseEntity agendar(@RequestBody @Valid DadosAgendamentoConsulta dados) {
        System.out.println(dados);
        return ResponseEntity.ok(new DadosDetalhamentoConsulta(null, null, null, null));
    }

}
```

Ao abrirmos o `DadosAgendamentoConsulta`, perceberemos que se trata de um `record` conforme os outros que vimos anteriormente. Ele tem os campos que chegam da API (`Long idMedico`, `Long idPaciente` e `LocalDateTime data`) e as anotações do BIN validation `@NotNull` para o ID da pessoa paciente e para a data, além de a data ter que ser no futuro (`@Future`), ou seja, não podemos agendar uma consulta para dias que já passaram.

```less
// Trecho de código suprimido

public record DadosAgendamentoConsulta(
        Long idMedico,

        @NotNull
        Long idPaciente,

        @NotNull
        @Future
        LocalDateTime data,

        Especialidade especialidade) {
}
```

Voltando ao Controller, o nosso outro DTO é o de resposta, chamado `DadosDetalhamentoConsulta`. Ele devolve o ID da consulta criada, do médico, da pessoa paciente e a data da consulta cadastrada no sistema.

Além disso, no pacote "src > main > java > med.voll.api > domain", criamos o subpacote "consulta", que abrange as classes relacionadas ao domínio de consulta.

Dentre elas, temos a entidade JPA "Consulta.java", que contém as anotações da JPA e do Lombok, além das informações da consulta: médico, paciente e data.

```less
// Trecho de código suprimido

@Table(name = "consultas")
@Entity(name = "Consulta")
@Getter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = "id")
public class Consulta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "medico_id")
    private Medico medico;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "paciente_id")
    private Paciente paciente;

    private LocalDateTime data;

}
```

Neste caso, `medico` e `paciente` são relacionamentos com as outras entidades `Medico` e `Paciente`.

Também criamos o "ConsultaRepository.java", vazio por enquanto.

```kotlin
package med.voll.api.domain.consulta;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsultaRepository extends JpaRepository<Consulta, Long> {

}
```

Por fim, temos a migration em "src > main > java > med.voll.api > resources", na pasta "db.migration". Tínhamos cinco migrations, mas agora criei a migration de número 6 ("V6"), que cria a tabela de consultas:

```sql
create table consultas(

    id bigint not null auto_increment,
    medico_id bigint not null,
    paciente_id bigint not null,
    data datetime not null,

    primary key(id),
    constraint fk_consultas_medico_id foreign key(medico_id) references medicos(id),
    constraint fk_consultas_paciente_id foreign key(paciente_id) references pacientes(id)

);
```

Nela, temos o ID da consulta, o ID de paciente, ID de médico e a data, sendo que `medico_id` e `paciente_id` são chaves estrangeiras que apontam para os IDs das tabelas de médico e paciente.

Estes são os códigos padrão para qualquer funcionalidade, com as suas respectivas mudanças de acordo com o projeto. Cada uma criará um controller ou uma entidade distinta, mas o funcionamento é o mesmo.

Eu já rodei o projeto e ele gerou um log na aba "Run", localizada no menu inferior do IntelliJ. Ele detectou a versão 6 da migration, executou esta última e criou a tabela de consultas.

O projeto foi inicializado sem nenhum erro. Já podemos tentar disparar uma requisição para esse endereço "/consultas" e verificar se ele cai no "ConsultaController.java" e nos dá o `System.out` exibindo os dados que chegaram no JSON da requisição.

Para disparar a requisição, continuaremos usando o Insomnia. Aberta a sua interface, clicaremos no botão com o símbolo "+", no painel à esquerda, escolheremos a opção "HTTP Request". Dando um duplo clique sobre a request, vamos renomea-la para "Agendar Consulta".

No painel central, trocaremos a requisição de GET para POST e o endereço será [http://localhost:8080/consultas](http://localhost:8080/consultas). Logo abaixo, na aba "Body", clicaremos na seta para baixo e escolheremos a opção "JSON".

Se observarmos o "ConsultaController" no IntelliJ, o método `agendar` recebe como parâmetro o DTO `DadosAgendamentoConsulta`, com os seguintes campos: ID do médico, ID de paciente e data. Precisamos mandar no JSON os campos que têm exatamente estes nomes.

Voltando ao Insomnia, escreveremos:

```json
{
"idPaciente": 1,
"idMedico": 1,
"data": 
}
```

Perceba que o atributo `data` é representado pelo `LocalDateTime`, a classe de datas que entrou no Java 8. Como fazemos para enviar uma data na requisição do JSON de maneira que o Spring consiga criar o objeto `LocalDateTime` corretamente? Que máscara usamos para a data?

É preciso que a data fique entre aspas, como se fosse uma `string` e tenha o formato de data americano: AAAA-MM-DD. Para separar a data da hora, escrevemos a letra "T" maiúscula e a hora no formato HH:MM:SS. Os segundos são opcionais.

Assim, a requisição ficará da seguinte forma:

```json
{
"idPaciente": 1,
"idMedico": 1,
"data": "2023-10-10T10:00"
}
```

Clicaremos no botão "Send" para disparar a requisição. Recebemos uma mensagem de erro "**403 Forbidden**". Isso aconteceu porque estamos usando o Spring Security e não levei o cabeçalho com o token.

Então, clicaremos em "Efetuar login" no menu lateral esquerdo e faremos o login primeiro. Dispararemos a requisição de login com o usuário que temos no nosso banco de dados, a Ana Souza.

Feito isso, recebemos um token de volta na aba Preview, no canto direito da tela. Vamos copiá-lo e voltar à requisição Agendar Consulta". Na aba "Auth" da janela central, clicaremos no ícone de seta para baixo e escolheremos a opção "Bearer Token". No campo "Token", colaremos o token copiado e clicaremos em "Send".

Recebemos o código "200 OK". Ele nos devolveu o DTO de resposta, mas todos os campos estão `null`, pois não salvamos nada no banco de dados.

Voltaremos ao IntelliJ e abriremos a aba "Run" no canto inferior da tela. Veremos que ele nos deu o `System.out` com as informações que inserimos no Insomnia:

```css
DadosAgendamentoConsulta[idMedico=1, idPaciente=1, data=2023-10-10T10:00]
```

Conseguimos disparar a requisição para a nossa API e recebemos os dados do agendamento de consulta. A primeira parte foi concluída: já temos todo o código necessário para receber a requisição, ter a entidade, ter o repository e ter a tabela no banco de dados.

O nosso "ConsultaController.java", por enquanto, apenas dá um `System.out`. Podemos até apagá-lo porque agora começaremos a fazer as validações das regras de negócio. Mostrarei como implementá-las da maneira mais apropriada no próximo vídeo.

-----------------------------------------------------------------------
# Para saber mais: anotação @JsonAlias
Aprendemos que os nomes dos campos enviados no JSON para a API devem ser idênticos aos nomes dos atributos das classes DTO, pois assim o Spring consegue preencher corretamente as informações recebidas.

Entretanto, pode acontecer de um campo ser enviado no JSON com um nome diferente do atributo definido na classe DTO. Por exemplo, imagine que o seguinte JSON seja enviado para a API:

```css
{
    “produto_id” : 12,
    “data_da_compra” : “01/01/2022”
}
```

E a classe DTO criada para receber tais informações seja definida da seguinte maneira:

```java
public record DadosCompra(
    Long idProduto,
    LocalDate dataCompra
){}
```

Se isso ocorrer, teremos problemas, pois o Spring vai instanciar um objeto do tipo `DadosCompra`, mas seus atributos não serão preenchidos e ficarão como `null` em razão de seus nomes serem diferentes dos nomes dos campos recebidos no JSON.

Temos duas possíveis soluções para essa situação:

1) Renomear os atributos no DTO para terem o mesmo nome dos campos no JSON;

2) Solicitar que a aplicação cliente, que está disparando requisições para a API, altere os nomes dos campos no JSON enviado.

A primeira alternativa citada anteriormente não é recomendada, pois os nomes dos campos no JSON não estão de acordo com o padrão de nomenclatura de atributos utilizado na linguagem Java.

A segunda alternativa seria a mais indicada, porém, nem sempre será possível “obrigar” os clientes da API a alterarem o padrão de nomenclatura utilizado nos nomes dos campos no JSON.

Para essa situação existe ainda uma terceira alternativa, na qual nenhum dos lados (cliente e API) precisam alterar os nomes dos campos/atributos. Basta, para isso, utilizar a anotação `@JsonAlias`:

```java
public record DadosCompra(
    @JsonAlias(“produto_id”) Long idProduto,
    @JsonAlias(“data_da_compra”) LocalDate dataCompra
){}
```

A anotação `@JsonAlias` serve para mapear “apelidos” alternativos para os campos que serão recebidos do JSON, sendo possível atribuir múltiplos _alias_:

```java
public record DadosCompra(
    @JsonAlias({“produto_id”, “id_produto”}) Long idProduto,
    @JsonAlias({“data_da_compra”, “data_compra”}) LocalDate dataCompra
){}
```

Dessa forma resolvemos o problema, pois o Spring, ao receber o JSON na requisição, vai procurar os campos considerando todos os _alias_ declarados na anotação `@JsonAlias`.

-----------------------------------------------------------------------
# Para saber mais: formatação de datas

Como foi demonstrado no vídeo anterior, o Spring tem um padrão de formatação para campos do tipo data quando esses são mapeados em atributos do tipo `LocalDateTime`. Entretanto, é possível personalizar tal padrão para utilizar outras formatações de nossa preferência.

Por exemplo, imagine que precisamos receber a data/hora da consulta no seguinte formato: **dd/mm/yyyy hh:mm**. Para que isso seja possível, precisamos indicar ao Spring que esse será o formato ao qual a data/hora será recebida na API, sendo que isso pode ser feito diretamente no DTO, com a utilização da anotação `@JsonFormat`:

```java
@NotNull
@Future
@JsonFormat(pattern = "dd/MM/yyyy HH:mm")
LocalDateTime data
```

No atributo **_pattern_** indicamos o padrão de formatação esperado, seguindo as regras definidas pelo padrão de datas do Java. Você pode encontrar mais detalhes nesta [página do JavaDoc](https://docs.oracle.com/javase/7/docs/api/java/text/SimpleDateFormat.html).

Essa anotação também pode ser utilizada nas classes DTO que representam as informações que a API devolve, para que assim o JSON devolvido seja formatado de acordo com o pattern configurado. Além disso, ela não se restringe apenas à classe `LocalDateTime`, podendo também ser utilizada em atributos do tipo `LocalDate` e `LocalTime`.


-----------------------------------------------------------------------
# Classe Service

## Transcrição

Já implementamos o esqueleto da funcionalidade. Agora, precisamos implementar as regras de negócio.

Antes, abriremos novamente o cartão do Trello que descreve a funcionalidade. Precisamos implementar agora uma série de validações com objetivos distintos.

O nosso trabalho será um pouco diferente do que já fizemos com a validação de campos de formulário via BIN validation. Agora, as validações são mais complexas. Mas como fazemos para implementá-las?

Voltando ao IntelliJ e observando o "ConsultaController.java", poderíamos fazer todas as validações no método `agendar()`, antes do retorno. No entanto, essa não é uma boa prática.

> A classe controller não deve trazer as regras de negócio da aplicação.

Ela é apenas uma classe que controla o fluxo de execução: ao chegar uma requisição, ela chama a classe X, devolve a resposta Y. Se a condição for Z, ela devolve outra resposta e assim por diante. Ou seja, ela só controla o fluxo de execução e, por isso, não deveria ter regras de negócio.

Assim, isolaremos as regras de negócio, os algoritmos, os cálculos e as validações em outra classe que será chamada pelo Controller.

Expandiremos o menu "Project" na lateral esquerda da interface, selecionaremos o pacote "consulta" e usaremos o atalho "ALT + Insert", escolhendo em seguida a opção "Java Class". Com isso, criaremos uma classe para conter as regras de agendamento de consultas. Vamos chamá-la de "AgendaDeConsultas".

O nome é bem autoexplicativo: essa classe conterá a agenda de consultas. Podemos ter nesta classe outras funcionalidades ainda relacionadas ao agendamento de consultas.

Como acabamos de criar a classe e ela ainda não tem nenhuma anotação, o Spring Boot não consegue carregá-la automaticamente. Por isso, precisamos inserir alguma anotação primeiro.

No entanto, esta não é uma classe Controller tampouco uma classe de configurações. Esta classe representa um serviço da aplicação, o de agendamento de consultas. Por isso, será uma classe de serviços (_Service_) e levará a anotação `@Service`. O objetivo desta anotação é declarar o componente de serviço ao Spring Boot.

Dentro desta classe, criaremos um método `public void agendar()`, que recebe como parâmetro o DTO `DadosAgendamentoConsulta`.

```java
package med.voll.api.domain.consulta;

import org.springframework.stereotype.Service;

@Service
public class AgendaDeConsultas {

    public void agendar(DadosAgendamentoConsulta dados) {

    }

}
```

> A classe _Service_ executa as regras de negócio e as validações da aplicação.

Precisaremos usar esta classe em "ConsultaController.java". Precisamos declarar um atributo do tipo `AgendaDeConsultas`, chamando-o de `agenda`. Para pedir ao Spring instanciar este objeto, usaremos o `@Autowired` acima do atributo.

```java
// Trecho de código suprimido

@Autowired
private AgendaDeConsultas agenda;

// Trecho de código suprimido
```

Com isso, injetamos a classe `AgendaDeConsultas` no Controller. Já no método `agendar` do Controller, pegaremos o objeto `agenda` e chamaremos o método `agendar()`, passando como parâmetro os dados que chegam ao Controller. Tudo isso antes do retorno.

```less
@PostMapping
@Transactional
public ResponseEntity agendar(@RequestBody @Valid DadosAgendamentoConsulta dados) {
    agenda.agendar(dados);
    return ResponseEntity.ok(new DadosDetalhamentoConsulta(null, null, null, null));
}
```

O Controller recebe as informações, faz apenas a validação do BIN validation e chama a classe Service `AgendaDeConsultas`, que executará as regras de negócio. Esta é a forma correta de lidar com as regras de negócio.

Agora, abriremos a classe `AgendaDeConsultas` e escreveremos todas as validações que constam no cartão do Trello dentro do método `agendar()`.

No fim das contas, o nosso objetivo é salvar o agendamento no banco de dados: recebemos a requisição com os dados de agendamento e precisamos salvá-los na tabela de consultas.

Por isso, precisamos acessar o banco de dados e a tabela de consultas nesta classe. Assim, declararemos um atributo `ConsultaRepository`, chamando-o de `consultaRepository`.

Logo acima do atributo, usaremos a anotação `@Autowired` para que o Spring Boot injete este repository na nossa classe _Service_.

No fim do método `agendar()`, inseriremos `consultaRepository.save()` e passaremos um objeto do tipo `consulta`, a entidade JPA. Obviamente, só podemos chamar este método se todas as validações tiverem sido executadas conforme as regras de negócio.

```typescript
@Service
public class AgendaDeConsultas {

    @Autowired
    private ConsultaRepository consultaRepository;

    public void agendar(DadosAgendamentoConsulta dados) {
        consultaRepository.save(consulta);
    }

}
```

Já chamamos o `save`, mas ele está dando um erro de compilação, porque a variável `consulta` ainda não foi criada. Por isso, precisaremos executar essa ação.

```typescript
@Service
public class AgendaDeConsultas {

    @Autowired
    private ConsultaRepository consultaRepository;

    public void agendar(DadosAgendamentoConsulta dados) {
        var consulta = new Consulta();
        consultaRepository.save(consulta);
    }

}
```

A entidade `Consulta` está anotada com `@AllArgsConstructor`, do Lombok, que gera um construtor com todos os atributos. Podemos usar esse mesmo construtor no "AgendamentoDeConsultas". O primeiro parâmetro é o ID `null`, pois é o banco de dados que passará o ID. Já o segundo é `medico`, `paciente` e `data`. Esta última virá no DTO, por meio do parâmetro `dados`.

Acontece que `medico` e `paciente` não chegam na requisição, mas sim o ID do médico e o ID do paciente. Por isso, precisamos setar o objeto inteiro na entidade, e não apenas o ID.

Por isso, precisaremos carregar `medico` e `paciente` do banco de dados. Precisaremos injetar, então, mais dois Repositories na nossa Service: `MedicoRepository` e `PacienteRepository`.

No método `agendar()`, precisamos criar um objeto `paciente` também. Usaremos o `pacienteRepository.findById()` para buscar o objeto pelo ID, que está dentro do DTO `dados`.

Na requisição só vem o ID, mas precisamos carregar o objeto inteiro. Assim, usamos o Repository para carregar pelo ID do banco de dados. O médico seguirá a mesma dinâmica.

```typescript
@Service
public class AgendaDeConsultas {

    @Autowired
    private ConsultaRepository consultaRepository;

    @Autowired
    private MedicoRepository medicoRepository;

    @Autowired
    private PacienteRepository pacienteRepository;

    public void agendar(DadosAgendamentoConsulta dados) {
        var paciente = pacienteRepository.findById(dados.idPaciente());
        var medico = medicoRepository.findById(dados.idMedico());
        var consulta = new Consulta(null, medico, paciente, dados.data());
        consultaRepository.save(consulta);
    }

}
```

Aparecerá um erro de compilação porque o método `findById()` não devolve a entidade, mas um `Optional`. Assim, no fim da linha, antes do ponto e vírgula, precisamos escrever `.get()` ao lado de `findById()`. Isso faz com que ele pegue a entidade carregada.

```csharp
// Trecho de código suprimido

var paciente = pacienteRepository.findById(dados.idPaciente()).get();
var medico = medicoRepository.findById(dados.idMedico()).get();
var consulta = new Consulta(null, medico, paciente, dados.data());
consultaRepository.save(consulta);
```

O nosso método `agendar()` na classe Service fará o seguinte: pegamos o ID e carregamos o paciente e o médico do banco de dados; criamos uma entidade `consulta` passando o médico, o paciente e a data que vem no DTO; e salvamos isso no banco de dados.

Porém, antes disso, precisamos escrever o código para fazer todas as validações que fazem parte das regras de negócio.

O código das regras de negócio aparecerá antes do último trecho que implementamos neste vídeo. Na sequência, abordaremos como fazer as validações da melhor maneira possível.

-----------------------------------------------------------------------
# Validações de integridade

## Transcrição

Antes de implementar as regras de negócio listadas no cartão do Trello, precisamos fazer algumas checagens de integridade.

Por exemplo, em "AgendaDeConsultas", recebemos o ID de um paciente e o ID de um médico. Precisamos checar se existem cadastrados no banco de dados um médico e um paciente com esses IDs.

Pode ser que chegue uma requisição de ID "99999", por exemplo, sem que haja um registro correspondente no banco de dados. É bom fazermos a checagem e, neste caso, devolver uma mensagem de erro que indique o problema para o cliente que disparou a requisição.

Faremos a checagem no método `agendar()` da classe "AgendaDeConsultas.java", antes do código que cria as variáveis médico, paciente e consulta.

Para checar o ID do paciente, usaremos um `if`. A ideia é verificar se o ID do paciente existe. Quem faz consultas ao banco de dados é o `Repository`.

Existe um método na interface `Repository` no próprio Spring Data chamado `existsById`. Ele já realiza uma consulta ao banco de dados para conferir se existe um registro com um determinado ID. Ele devolve um `boolean`: `true` se existir e `false` se não existir.

É esse método `existsById` que usaremos, passando como parâmetro `dados.idPaciente()`. Negaremos a expressão inserindo uma exclamação no início. Com isso, se não existir no banco de dados um paciente com o ID, precisamos interromper a execução do programa.

Podemos lançar uma `exception` dentro do `if`, que exiba uma mensagem relatando o problema. Podemos até criar uma `exception` personalizada para o nosso projeto, chamada `ValidacaoException()`.

Dentro dos parênteses, escrevemos a mensagem como uma `string` (`"Id do paciente informado não existe"` ou algo semelhante).

```typescript
// Trecho de código suprimido

public DadosDetalhamentoConsulta agendar(DadosAgendamentoConsulta dados) {
    if (!pacienteRepository.existsById(dados.idPaciente())) {
        throw new ValidacaoException("Id do paciente informado não existe!");
    }
}

// Trecho de código suprimido
```

Receberemos um erro de validação porque a classe `exception` não existe. Com o cursor do mouse sobre ela, usaremos o atalho "ALT + Enter" e selecionar a opção "Create Class".

Em "Destination package", deixaremos a classe no pacote "domain" ("med.voll.api.domain"), já que ela não é específica de nenhuma funcionalidade. Em seguida, selecionaremos o botão "OK".

Com isso, o IntelliJ criou a `exception` automaticamente. Ele herdou de `Throwable`, mas trocaremos para `RuntimeException`.

Ele já cria um construtor que recebe a `string`, mas coloca o parâmetro com o nome `s`. Renomearemos este parâmetro para `mensagem`.

Dentro do construtor, chamaremos o construtor da classe mãe usando a palavra `super` e passando o parâmetro `mensagem`.

```java
package med.voll.api.domain;

public class ValidacaoException extends RuntimeException {
    public ValidacaoException(String mensagem) {
        super(mensagem);
    }
}
```

Voltando à classe "AgendaDeConsulta", faremos a checagem com o `if` criado. Primeiro, verificaremos se existe um paciente com o ID que está chegando ao banco de dados. Se ele não existir, será lançada uma `exception` com uma mensagem de erro.

Para o médico, faremos o mesmo:

```cpp
if (!medicoRepository.existsById(dados.idMedico())) {
    throw new ValidacaoException("Id do médico informado não existe!");
}
```

Acontece que a nossa última regra de negócio no Trello diz o seguinte:

> "A escolha do médico é **opcional**, sendo que nesse caso o sistema deve escolher aleatoriamente algum médico **disponível** na data/hora preenchida".

Assim, é possível que um ID de médico não chegue na requisição. Voltando ao IntelliJ, não podemos chamar o `existsById` se o ID do médico estiver nulo. Isso resultará em um erro para a JPA.

Só podemos chamar o `if` se o ID não for nulo. Por isso, acrescentaremos uma condição ao `if` antes da condição atual:

```csharp
if (dados.idMedico() != null && !medicoRepository.existsById(dados.idMedico())) {
    throw new ValidacaoException("Id do médico informado não existe!");
}
```

Os dois `if`s servem para garantir que esteja chegando um ID existente no banco de dados. A `exception` devolve uma mensagem que descreve o erro de maneira mais apropriada para o cliente da aplicação.

O código só chegará ao trecho que cria as variáveis se o ID que chegar estiver no banco de dados. No caso do médico, por ser um campo opcional, pode ser que a linha `var medico = medicoRepository.findById(dados.idMedico()).get()` tenha um `idMedico` nulo.

Ainda segundo a regra de negócio que acabamos de analisar, precisamos escrever um algoritmo que escolhe aleatoriamente um médico no banco de dados.

Por isso, a linha acima precisa ser substituída. Como ainda não temos o algoritmo, criaremos um método privado na classe para chamá-lo:

```csharp
// Trecho de código suprimido

var medico = escolherMedico(dados);

// Trecho de código suprimido
```

Obteremos um erro indicando que o método `escolherMedico` não existe. Pressionaremos o atalho "ALT + Enter" e escolheremos a opção "_Create method 'escolherMedico' in 'AgendaDeConsultas'_". O método é criado como privado, mas o seu retorno é `void`, que substituiremos por um objeto tipo `Medico`.

```typescript
private Medico escolherMedico(DadosAgendamentoConsulta dados) {

}
```

Isso serve para isolar o algoritmo e ele não ficar solto dentro do método de agendamento. Em `escolherMedico`, precisamos verificar se está chegando o ID do médico na requisição ou não.

Se estiver, puxamos o médico correspondente do banco de dados. Se não, temos que escolher um profissional aleatoriamente, conforme indica a regra de negócio. Na sequência, abordaremos a implementação desse algoritmo e como podemos escolher um médico aleatório do banco de dados.

-----------------------------------------------------------------------
# Para saber mais: Service Pattern

O **Padrão Service** é muito utilizado na programação e seu nome é muito comentado. Mas apesar de ser um nome único, _Service_ pode ser interpretado de várias maneiras: pode ser um **_Use Case_** (_Application Service_); um **_Domain Service_**, que possui regras do seu domínio; um **_Infrastructure Service_**, que usa algum pacote externo para realizar tarefas; etc.

Apesar da interpretação ocorrer de várias formas, a ideia por trás do padrão é separar as regras de negócio, as regras da aplicação e as regras de apresentação para que elas possam ser facilmente testadas e reutilizadas em outras partes do sistema.

Existem duas formas mais utilizadas para criar Services. Você pode criar Services mais genéricos, responsáveis por todas as atribuições de um Controller; ou ser ainda mais específico, aplicando assim o **S[](https://cursos.alura.com.br/course/spring-boot-3-documente-teste-prepare-api-deploy/task/122582)** do **SOLID**: _Single Responsibility Principle_ (Princípio da Responsabilidade Única). Esse princípio nos diz que uma classe/função/arquivo deve ter apenas uma única responsabilidade.

Pense em um sistema de vendas, no qual provavelmente teríamos algumas funções como: _Cadastrar usuário_, _Efetuar login_, _Buscar produtos_, _Buscar produto por nome_, etc. Logo, poderíamos criar os seguintes Services: `CadastroDeUsuarioService`, `EfetuaLoginService`, `BuscaDeProdutosService`, etc.

Mas é importante ficarmos atentos, pois muitas vezes não é necessário criar um Service e, consequentemente, adicionar mais uma camada e complexidade desnecessária à nossa aplicação. Uma regra que podemos utilizar é a seguinte: se não houverem regras de negócio, podemos simplesmente realizar a comunicação direta entre os controllers e os repositories da aplicação.

-----------------------------------------------------------------------
# Escolha de médico aleatório


## Transcrição

Agora, precisamos implementar o algoritmo que escolhe o médico de maneira aleatória, caso a pessoa usuária não tenha escolhido um profissional de saúde para atendê-la quando fez o agendamento.

Precisamos abranger todos os cenários possíveis. A primeira checagem que faremos é se a pessoa escolheu um médico ao fazer a requisição, usando `if (dados.idMedico() != null)`.

Neste caso, carregaremos a informação do banco de dados com `return medicoRepository.getReferenceById(dados.idMedico())`. Em vez de usar o `findById()`, podemos usar o `getReferenceById()` e não precisamos chamar o `.get()` que usamos anteriormente.

Podemos trocar o `findById()` pelo `getReferenceById()` também na variável `paciente`, pois não queremos carregar o objeto para manipula-lo, mas só para atribui-lo a outro objeto.

Voltando ao método `escolherMedico()`, a primeira coisa que estamos fazendo é conferir se a pessoa usuária solicitou um médico específico para o seu atendimento. Se sim, basta carregar as informações do médico que vêm do banco de dados.

```typescript
private Medico escolherMedico(DadosAgendamentoConsulta dados) {
    if (dados.idMedico() != null) {
        return medicoRepository.getReferenceById(dados.idMedico());
    }
}
```

Se não houver um médico, precisamos usar o algoritmo para atribuir um profissional aleatoriamente. Porém, se conferirmos o cartão do Trello, veremos que só existem três informações que cheguem para a nossa API: paciente, médico e data da consulta.

Porém, quando não vem um médico, existe outra informação importante: a especialidade desejada. Imagine que, ainda que você não tenha uma preferência quanto ao profissional que irá te atender, existe uma especialidade desejada.

Por isso, quando não informamos o médico, deveríamos ao menos informar a especialidade. Esse detalhe está faltando na documentação.

Isso pode acontecer: a pessoa que documentou os requisitos pode ter esquecido de um detalhe. Nesse caso, o ideal seria chamar a pessoa responsável e o(a) cliente da clínica para conversar.

Agora, sabemos que a especialidade do médico é uma informação que chegará à nossa API. Mudaremos então o nosso DTO, que representam os dados que chegam, o "DadosAgendamentoConsulta".

Por enquanto, as informações que constam no DTO são o `idMedico`, o `idPaciente` e o `LocalDateTime data`. Adicionaremos uma vírgula depois de `data` e declararemos a especialidade: `Especialidade especialidade`.

Porém, não podemos acrescentar a anotação `@NotNull`, pois ela é opcional. Ela só é obrigatória quando não temos o ID do médico.

```less
public record DadosAgendamentoConsulta(
    Long idMedico,

    @NotNull
    Long idPaciente,

    @NotNull
    @Future
    LocalDateTime data,

    Especialidade especialidade) {
}
```

Voltaremos à classe "AgendamentoDeConsultas" para editar o método `escolherMedico()`. Se o registro não entrou no `if` (não há médico específico solicitado), isso quer dizer que o ID do médico é nulo. Neste caso, a especialidade deve ter sido preenchida. Se ela não for preenchida, lançaremos uma `exception`.

```csharp
// Trecho de código suprimido

if (dados.especialidade() == null) {
    throw new ValidacaoException("Especialidade é obrigatória quando médico não for escolhido!");
}
```

Se nenhum destes `if`s foi aplicado, está tudo certo. Isso significa que não foi escolhido um médico, mas foi escolhida uma especialidade. Agora, precisamos selecionar um médico aleatório que atenda pela especialidade escolhida.

Precisamos fazer, então, uma consulta ao banco de dados. Mas como fazemos para escolher um médico aleatório da especialidade escolhida, que esteja disponível na data e horário selecionados?

Existem várias maneiras de fazer isso: poderíamos carregar os médicos, filtrando-os pela especialidade, e checar a data da consulta no próprio Java.

O ideal é carregar um profissional aleatório diretamente do banco de dados. Porém, essa consulta é específica para o nosso projeto, ou seja, ela não está pronta pelo Spring Data JPA.

Precisaremos criar um método para fazer isso:

```kotlin
return medicoRepository.escolherMedicoAleatorioLivreNaData(dados.especialidade(), dados.data());
```

Obteremos um erro de compilação porque este método ainda não existe no nosso `medicoRepository`. Usaremos o atalho "ALT + Enter" e escolheremos a primeira opção sugerida pelo IntelliJ: "_Create method 'escolherMedicoAleatorioLivreNaData' in 'MedicoRepository'_".

No entanto, escrevemos este método em português. Não estamos seguindo o padrão de nomenclatura em português, como o `findAllByAtivoTrue()`. Desse modo, o Spring Data não conseguirá montar o SQL automaticamente. A ideia é justamente essa: para este método, nós é que digitaremos o comando SQL.

Para fazer isso, usaremos a anotação `@Query()` logo acima do método. Ela vem do pacote "org.springframework.data.jpa". Importaremos a anotação e, entre os parênteses, montaremos a `query` usando a sintaxe do **Java Persistence Query Language (JPQL)**.

No nosso caso, montaremos uma consulta. Para facilitar a visualização, deixaremos a consulta quebrada linha por linha e usaremos o **Text block**. Isso nos permite digitar o código e quebrar as linhas de maneira mais simples, sem ter que concatenar tudo com "+".

Como começamos? Pelo óbvio: digitando `select m from Medico m` dentro da `query`. Se a deixarmos dessa forma, haverá um carregamento de todos os médicos do banco de dados.

Não é isso que queremos. Então, precisamos filtrar usando `m.ativo = 1`. Lembre-se que queremos carregar apenas os médicos ativos. Essa é uma das regras de negócio que estão no nosso Trello.

No entanto, ainda estamos trazendo todos os médicos ativos. Por isso, filtraremos mais uma vez com foco na especialidade: `m.especialidade = :especialidade`. O `:` serve para dizer que se trata do mesmo parâmetro do método.

```python
@Query("""
                select m from Medico m
                where
                m.ativo = 1
                and
                m.especialidade = :especialidade
                """)
```

Com isso, estamos pedindo que o código nos traga todos os médicos ativos que sejam da especialidade selecionada pela pessoa usuária.

Acontece que não queremos que ele traga todos os médicos daquela especialidade, mas apenas um. Como fazemos isso? Escrevendo `limit 1`. Assim, só um registro será trazido.

Porém, dessa forma teremos sempre o mesmo médico para a especialidade. Como fazemos para obter um médico escolhido aleatoriamente? Escrevendo `order by rand()`, onde `rand()` vem de "_random_" (aleatório).

Agora, ele trará todos os médicos, ordenando-os de modo aleatório. Em seguida, pedimos para ser trazido só o primeiro registro.

```python
@Query("""
                select m from Medico m
                where
                m.ativo = 1
                and
                m.especialidade = :especialidade
                order by rand()
                limit 1
                """)
```

Ainda não terminamos. Por enquanto, estamos trazendo um médico de determinada especialidade de maneira aleatória. Porém, precisamos de um profissional que esteja livre no dia e horário selecionado pela pessoa usuária.

Com o código atual, é possível que estejamos trazendo um médico com a agenda cheia na data escolhida. Como fazemos esse filtro? Precisaremos consultar a tabela de consultas.

Após a `especialidade`, acrescentaremos outro `and` e escreveremos `m.id not in()`. Com isso, estamos pedindo que sejam trazidos os médicos cujo ID não esteja nesta subseleção.

Dentro da subseleção, escreveremos:

```csharp
select c.medico.id from Consulta c
where
c.data = :data
```

Este subselect está trazendo o ID dos médicos que têm consulta na data escolhida. Com o `not in()`, evitaremos os médicos desta lista. O código completo ficou da seguinte forma:

```python
@Query("""
                select m from Medico m
                where
                m.ativo = 1
                and
                m.especialidade = :especialidade
                and
                m.id not in(
                        select c.medico.id from Consulta c
                        where
                        c.data = :data
                )
                order by rand()
                limit 1
                """)
```

Essa é uma das maneiras de executar a regra de negócio que prevê a escolha aleatória de um médico disponível na data selecionada pela pessoa usuária.

É possível fazer isso via código Java também, mas eu prefiro usar o `select` diretamente no banco de dados. Assim, filtramos a informação como queremos e trazemos a informação uma única vez, em vez de carregar uma lista de registros e fazer essa manipulação em memória. Dessa forma, o trabalho fica otimizado no banco de dados.

Está implementado o esqueleto desta validação, mas ainda temos muitas outras para fazer. Além da regra que prevê a seleção aleatória de um médico, todas as outras são validações de integridade, para verificar se o ID do paciente e do médico existem e assim por diante.

Falta implementar as demais validações. Perceba que o código da classe "AgendaDeConsultas" está crescendo. Na próxima aula, abordaremos como implementar as demais validações sem deixar o código muito complexo, além de facilitar a sua manutenção e extensão.

-----------------------------------------------------------------------
# Para saber mais: Novas versões do Spring Boot

**ATENÇÃO!**

No vídeo anterior foi utilizada a seguinte query para escolher um médico aleatório:

```csharp
select m from Medico m
where
m.ativo = 1
and
m.especialidade = :especialidade
and
m.id not in(
    select c.medico.id from Consulta c
    where
    c.data = :data
)
order by rand()
limit 1
```

Entretanto, nas versões mais recentes do Hibernate, utilizadas nas versões mais recentes do Spring Boot, a comparação **m.ativo = 1** não mais funciona.

Embora o atributo **ativo** seja do tipo **Boolean** e não **Integer**, o Hibernate fazia automaticamente a conversão de 1 para true. Porém, essa conversão deixou de ser feita pelo Hibernate, e com isso a query deve ser alterada para:

```csharp
select m from Medico m
where
m.ativo = true
and
m.especialidade = :especialidade
and
m.id not in(
    select c.medico.id from Consulta c
    where
    c.data = :data
)
order by rand()
limit 1
```


![[Pasted image 20250102184732.png]]

-----------------------------------------------------------------------
# Classes de validação

## Nesta aula, você aprendeu como:

- Isolar os códigos de validações de regras de negócio em classes separadas, utilizando nelas a anotação `@Component` do Spring;
- Finalizar a implementação do algoritmo de agendamento de consultas;
- Utilizar os **princípios SOLID** para deixar o código da funcionalidade de agendamento de consultas mais fácil de entender, evoluir e testar.

## Transcrição

Já implementamos o esqueleto da classe Service, que tem o agendamento da consulta, e só fizemos as validações de integridade, validamos os IDs e fizemos a lógica para escolher um médico livre aleatório caso ele não venha na requisição.

Agora vamos implementar as regras de negócio que estão descritas no card "Agendamento de consultas" do Trello:

> **As seguintes regras de negócio devem ser validadas pelo sistema:**
> 
> - O horário de funcionamento da clínica é de segunda a sábado, das 07:00 às 19:00;
> - As consultas tem duração fixa de 1 hora; As consultas devem ser agendadas com antecedência mínima de 30 minutos;
> - Não permitir o agendamento de consultas com pacientes inativos no sistema;
> - Não permitir o agendamento de consultas com médicos inativos no sistema;
> - Não permitir o agendamento de mais de uma consulta no mesmo dia para um mesmo paciente;
> - Não permitir o agendamento de uma consulta com um médico que já possui outra consulta agendada na mesma data/hora;
> - A escolha do médico é opcional, sendo que nesse caso o sistema deve escolher aleatoriamente algum médico disponível na data/hora preenchida.

Por enquanto só fizemos a última regra, para a escolha do médico ser opcional. Falta implementar as outras validações.

Para algumas dessas validações precisaremos ir para o banco de dados e para outras não.

Como vamos implementar o código para essas validações das regras de negócio?

Será que seria interessante colocar na classe `AgendaDeConsultas`? Será que, antes de criar a variável do paciente, do médico e da consulta, devemos colocar cada uma dessas validações e adicionar mais `if`s?

Essa é a alternativa mais comum que se utiliza nos projetos, mas não recomendo essa alternativa. Porque o método `agendar()` já está grande, ele já tem responsabilidades de validar os IDs, de escolher o médico aleatório, por exemplo.

Se colocarmos todas aquelas validações aqui no `agendar()`, a tendência é que esse método fique gigante e cada vez mais difícil de dar manutenção. Pensando em testes automatizados, que abordaremos aqui no curso, ficaria mais difícil testar essa classe.

A ideia é extrair as validações e, de alguma forma, fazer com que a _Service_ chame essas validações que estarão em outro lugar. Essa é a abordagem que usaremos para deixar o código enxuto, mais fácil de escrever, de dar manutenção e testar de maneira automatizada.

Como faremos?

Para cada validação das regras de negócio, vamos criar uma classe específica para cada uma delas.

A primeira regra trata do horário da clínica: "O horário de funcionamento da clínica é de segunda a sábado, das 07:00 às 19:00".

Vai chegar uma requisição para nossa API com uma data agendada para consulta. E se, por acaso, o cliente está tentando agendar uma consulta para domingo? Ou numa segunda-feira às 4h da manhã? Por isso precisamos validar o horário da consulta.

Vamos criar uma classe para executar essa validação.

De volta ao IntelliJ, vamos abrir o menu lateral do projeto e, para organizar essa classe, criaremos um subpacote. Com a pasta "consulta" selecionada pressionaremos o atalho "Alt + insert" e selecionaremos a opção "Package". Criaremos um novo pacote chamado "validacoes".

Dentro do pacote "validacoes" criaremos as classes. Primeiro, criaremos uma nova classe chamada `ValidadorHorarioFuncionamentoClinica`.

A ideia é criar dentro dessa classe um método para realizar a validação do horário de funcionamento da clínica.

Vamos criar o método `validar()` e receberemos o DTO `DadosAgendamentoConsulta` como parâmetro:

```java
package med.voll.api.domain.consulta.validacoes;

import med.voll.api.domain.consulta.DadosAgendamentoConsulta;

public class ValidadorHorarioFuncionamentoClinica {

    public void validar(DadosAgendamentoConsulta dados) {


    }
}
```

Qual é a ideia desse método? Estamos recebendo os dados do agendamento e precisamos executar a validação da regra de negócio.

A regra é: "O horário de funcionamento da clínica é de segunda a sábado, das 07:00 às 19:00". Então, não pode ter agendamento no domingo e nem antes das 7h ou depois das 19h nos dias de segunda a sábado.

No DTO já temos a data. Para realizar essa validação não precisamos consultar o banco de dados, podemos fazer direto no Java. É só validar a data que está chegando dentro do DTO.

Vamos criar uma variável `dataConsulta` é igual a `dados.data()` e vamos criar uma variável para checar se essa data é no domingo, por exemplo.

Vamos escrever `var domingo` igual a `dataConsulta.getDayOfWeek()`, usaremos esse método para pegar o dia da semana, e para verificar se é igual vamos usar `equals` com parâmetro informando o dia da semana que queremos comparar, no caso o domingo, `equals(DayOfWeek.SUNDAY)`. Isso vai me devolver um booleano, _true_ se for domingo e _false_ se não for domingo.

```java
package med.voll.api.domain.consulta.validacoes;

import med.voll.api.domain.consulta.DadosAgendamentoConsulta;

public class ValidadorHorarioFuncionamentoClinica {

    public void validar(DadosAgendamentoConsulta dados) {
        var dataConsulta = dados.data();

        var domingo = dataConsulta.getDayOfWeek().equals(DayOfWeek.SUNDAY);

    }
}
```

Beleza! Mas além de checar se a data é num domingo, precisamos checar se está de acordo com os horários de funcionamento.

Seguiremos a mesma lógica, será um booleano. Criaremos uma variável chamada `antesDaAberturaDaClinica`, sinal de igual, `dataConsulta.getHour` e vamos verificar se é menor do que 7:

```csharp
var antesDaAberturaDaClinica = dataConsulta.getHour() < 7;
```

Faremos a mesma coisa para verificar se o horário é depois do fechamento. Criaremos uma variável chamada `depoisDoEncerramentoDaClinica` sinal de igual, `dataConsulta.getHour` e vamos verificar se é menor do que 18.

```csharp
var depoisDoEncerramentoDaClinica = dataConsulta.getHour() > 18;
```

> O horário de funcionamento da clínica é de 7h às 19h. Não pode ter uma consulta Às 19h, a última consulta deve ser às 18h. Até porque uma das regras de negócio diz que "As consultas tem duração de 1 hora".

Em seguida, vamos fazer um `if`. Se for domingo, antes da abertura da clínica ou após o encerramento da clínica, lançaremos uma _exception_ para indicar que está inválido, `throw new ValidacaoException("Consulta fora do horário de funcionamento da clínica")`.

```cpp
 if (domingo || antesDaAberturaDaClinica || depoisDoEncerramentoDaClinica) {
    throw new ValidacaoException("Consulta fora do horário de funcionamento da clínica");
}
```

Nosso código ficou assim:

```java
package med.voll.api.domain.consulta.validacoes;

import med.voll.api.domain.ValidacaoException;
import med.voll.api.domain.consulta.DadosAgendamentoConsulta;

import java.time.DayOfWeek;

public class ValidadorHorarioFuncionamentoClinica {

    public void validar(DadosAgendamentoConsulta dados) {
        var dataConsulta = dados.data();

        var domingo = dataConsulta.getDayOfWeek().equals(DayOfWeek.SUNDAY);
        var antesDaAberturaDaClinica = dataConsulta.getHour() < 7;
        var depoisDoEncerramentoDaClinica = dataConsulta.getHour() > 18;
        if (domingo || antesDaAberturaDaClinica || depoisDoEncerramentoDaClinica) {
            throw new ValidacaoException("Consulta fora do horário de funcionamento da clínica");
        }

    }

}
```

Pronto! Temos a nossa primeira validação. O único objetivo dessa classe é executar essa única validação. O código fica pequeno, simples e fácil de dar manutenção e de testar de maneira automatizada.

Agora temos que fazer o código das outras validações. A próxima validação da lista é "As consultas tem duração fixa de 1 hora". Essa não precisamos checar, já vai ser implícita, o aplicativo vai colocar disponível de uma em uma hora para agendar consulta.

Próxima validação: "As consultas devem ser agendadas com antecedência mínima de 30 minutos". Vamos criar um validador para essa.

No nosso projeto, dentro do pacote de validações, vamos inserir uma nova classe chamada `ValidadorHorarioAntecedencia`.

Criaremos um método parecido com o que fizemos anteriormente.

```java
package med.voll.api.domain.consulta.validacoes;
import med.voll.api.domain.consulta.DadosAgendamentoConsulta;

public class ValidadorHorarioAntecedencia {

    public void validar(DadosAgendamentoConsulta dados) {


    }
}
```

Vamos inserir as variáveis de `dataConsulta` e `agora`:

```typescript
public void validar(DadosAgendamentoConsulta dados) {
    var dataConsulta = dados.data();
    var agora = LocalDateTime.now();
}
```

Agora vamos comparar a diferença de minutos entre essas datas para enviar uma _exception_ caso seja menos de trinta.

Vamos criar uma variável `diferencaEmMinutos` igual a `Duration.between` pasando como parâmetro `agora` e `dataConsulta`, seguido de `.toMinutes()` para pegar a duração e minutos.

```typescript
public void validar(DadosAgendamentoConsulta dados) {
    var dataConsulta = dados.data();
    var agora = LocalDateTime.now();
    var diferencaEmMinutos = Duration.between(agora, dataConsulta).toMinutes();

}
```

Agora basta fazer um `if`. Se `diferencaEmMinutos` for menor que 30, lançaremos uma _exception_ com a mensagem: "Consulta deve ser agendada com antecedência mínima de 30 minutos".

```typescript
public void validar(DadosAgendamentoConsulta dados) {
    var dataConsulta = dados.data();
    var agora = LocalDateTime.now();
    var diferencaEmMinutos = Duration.between(agora, dataConsulta).toMinutes();

    if (diferencaEmMinutos < 30) {
        throw new ValidacaoException("Consulta deve ser agendada com antecedência mínima de 30 minutos");
    }

}
```

Pronto! Fizemos outra validação sem precisar consultar o banco de dados.

Essa é a ideia, realizar cada uma das validações em classes separadas para que o código fique mais simples, fácil de entender e de dar manutenção.

> Aos 11:20 do vídeo, Rodrigo faz um corte para não perder muito tempo digitando códigos já que as validações a serem criadas são bastante parecidas.

Após o corte no vídeo, já criei as classes e validações para o restante das regras de negócio, os arquivos são:

- `ValidadorMedicoAtivo`
- `ValidadorMedicoComOutraConsultaNoMesmoHorario`
- `ValidadorPacienteAtivo`
- `ValidadorPacienteSemOutraConsultaNoDia`

Na classe `ValidadorMedicoAtivo`, a única diferença é que usamos o `Repository`, ele só não está sendo injetado, em breve falaremos sobre isso.

Estamos buscando só o atributo ativo do médico, filtrando pelo ID. E se o médico não tiver ID, ele joga uma _exception_.

Foi criado o método `findAtivoByID`. No caso, não quero carregar o objeto médico inteiro só para checar se o atributo `ativo` está _true_. Então, podemos fazer uma consulta personalizada trazendo apenas um único atributo, `select m.ativo`.

Em seguida temos a classe `ValidadorMedicoComOutraConsultaNoMesmoHorario`. Aqui também precisa consultar o banco de dados, para verificar se existe uma consulta com esse médico em uma mesma data.

Fizemos uma consulta usando o padrão de nomenclatura do SpringData: `existsByMedicoIdAndData(idMedico, data)`.

O `ValidadorPacienteAtivo` ficou parecido com `ValidadorMedicoAtivo`.

E temos a validação para o paciente não ter consulta na mesma data, `ValidadorPacienteSemOutraConsultaNoDia`. Ele também consulta o banco de dados para ver se existe uma consulta para esse paciente, colocamos a data de início e a data de encerramento daquele dia, pegando o primeiro e último horário do dia.

Beleza! Temos os validadores executando as regras de negócio. Agora existe essa dúvida: como chamar todas essas classes na _service_ de agendamento de consultas? E como injetar o `Repository` nessas classes? No próximo vídeo aprenderemos a fazer isso.

-----------------------------------------------------------------------
# Aplicando princípios SOLID

## Transcrição

Já criamos cada validador em classes separadas. Agora vem a questão: como chamar cada um desses validadores na classe _service_, a classe de `AgendadeConsultas`?

Será que vamos instanciar uma por uma e chamar uma por uma? Não, isso não seria produtivo. Até porque se surgir uma nova regra de negócio teríamos que criar a classe implementando a regra e lembrar de vir na classe `AgendadeConsultas` para chamar a classe que foi criada.

Mesmo se removermos alguma validação, teríamos que apagar a classe e lembrar de tirar a chamada à classe excluída.

Para deixar o código o mais flexível possível, usaremos outra abordagem.

Note que as validações são classes distintas, mas têm algo em comum: o método `validar(DadosAgendamentoConsulta dados)`. São várias classes com o mesmo método em que o retorno é void e recebem como parâmetro o objeto do tipo `DadosAgendamentoConsulta`. Ou seja, a assinatura, o comportamento da validação é igual.

Talvez você já tenha percebido que esse é o cenário de utilização de **interfaces** do Java. Podemos criar uma interface para padronizar esse tipo de validador no nosso projeto e, com interfaces, conseguiremos ganhar o polimorfismo. É assim que deixaremos nosso código bastante flexível.

## Interface

Vamos criar uma interface no projeto. No painel lateral, com o pacote de validações selecionado vamos usar o atalho "Alt + Insert", escolher a opção "Java Class", nomeá-la como `ValidadorAgendamentoDeConsulta` e escolheremos a opção "Interface".

Criou a interface, e dentro dela vamos declarar aquele método que as classes têm em comum, `validar(DadosAgendamentoConsulta dados)`.

```java
package med.voll.api.domain.consulta.validacoes;

import med.voll.api.domain.consulta.DadosAgendamentoConsulta;

public interface ValidadorAgendamentoDeConsulta {

    void validar(DadosAgendamentoConsulta dados);

}
```

Aqui não precisa do `public` porque é implícito que todos os métodos de uma interface são públicos.

Agora, vamos alterar cada uma das classes para implementar essa interface.

Começando pela classe `ValidadorHorarioAntecedencia`, vamos colocar na assinatura da classe, antes de abrir as chaves: `implements ValidadorAgendamentoDeConsulta`.

```java
public class ValidadorHorarioAntecedencia implements ValidadorAgendamentoDeConsulta
```

Pronto! Faremos a mesma coisa nos outros validadores. temos 6 validadores, faremos isso para cada uma das 6 classes.

Assim conseguimos padronizar o projeto. Todo validador deve implementar essa interface `ValidadorAgendamentoDeConsulta` e, obrigatoriamente, tem que implementar o método `validar(DadosAgendamentoConsulta)`. Só o corpo do método de cada classe é que será diferente.

Outra coisa importante: para conseguirmos injetar essas classes em algum lugar, o Spring precisa conhecê-las. Então, em cima delas precisa ter alguma anotação do Spring.

Poderíamos colocar a anotação `@Service` para indicar que é um serviço, uma validação. Mas vamos usar a anotação `@Component` que é para componentes genéricos. Porque às vezes temos uma classe que não é nem uma classe de configuração, nem um _controller_ e nem uma _service_. Então podemos colocar o `@Component` para indicar ao Spring que essa classe é um componente genérico e ele carregá-la na inicialização do projeto.

Podia ser o @`Service` também, vou deixar o @`Component` para mostrar algo novo para vocês.

Vamos inserir `@Component` em todas as classes de validação.

```java
@Component
public class ValidadorHorarioAntecedencia implements ValidadorAgendamentoDeConsulta
```

Agora, com o `@Component` o Spring vai reconhecer essas classes e conseguiremos injetar o `repository`.

Podemos colocar `@Autowired` nas classes que têm o _repository_ como atributo, para o Spring injetar o _repository_ automaticamente. A `ValidadorMedicoAtivo` ficará assim, por exemplo:

```java
@Component
public class ValidadorMedicoAtivo implements ValidadorAgendamentoDeConsulta {

    @Autowired
    private MedicoRepository repository;

    // código omitido
}
```

Pronto! Na interface não precisa colocar anotação nenhuma porque o Spring carrega ela automaticamente.

## Injetar validadores na classe _service_

Para injetar esses validadores na classe _service_, a classe `AgendadeConsultas`, usaremos um esquema do Spring que vai facilitar a nossa vida.

Você poderia pensar que precisaríamos injetar cada um dos validadores, da mesma forma que estamos injetando os _repositories_. Mas esse é o problema que queremos evitar, não queremos declarar um por um. Então vamos fazer um truque que o Spring nos permite fazer.

No código de `AgendadeConsultas`, vamos declarar um atributo, vamos anotá-lo com `@Autowired`, mas esse atributo será declarado como um `List` do `java.util` e, dentro do List, declararemos a interface `ValidadorAgendamentoDeConsulta` e chamaremos esse atributo de `validadores`.

```swift
@Autowired
private ConsultaRepository consultaRepository;

@Autowired
private MedicoRepository medicoRepository;

@Autowired
private PacienteRepository pacienteRepository;

@Autowired
private List<ValidadorAgendamentoDeConsulta> validadores;
```

Pronto! O Spring vai, automaticamente, identificar que estamos injetando uma lista e vai procurar todas as classes que implementam a interface `ValidadorAgendamentoDeConsulta`. Então, não importa a quantidade de validadores, com isso o Spring vai injetar um por um. É muito mais prático fazer dessa forma.

Agora, no método `agendar()`, antes de criar as variáveis do paciente e do médico, vamos pegar essa lista de `validadores` e percorrê-la com um `forEach(v -> v.validar(dados))`.

```csharp
if (dados.idMedico() != null && !medicoRepository.existsById(dados.idMedico())) {
    throw new ValidacaoException("Id do médico informado não existe!");
}

validadores.forEach(v -> v.validar(dados));

var paciente = pacienteRepository.getReferenceById(dados.idPaciente());
var medico = escolherMedico(dados);
if (medico == null) {
    throw new ValidacaoException("Não existe médico disponível nessa data!");
}
```

Dessa forma conseguimos injetar todos os validadores e o código está bastante flexível.

Se quisermos excluir um validador, basta apagar a classe desse validador que queremos apagar. Não precisa mexer na classe `AgendadeConsultas`, a lista simplesmente ficará com uma classe a menos.

Perceba como o código ficou flexível. Se surgirem novas validações, se alterarmos uma validação ou se uma validação deixar de existir, não precisaremos mexer na classe _service_.

## _Strategy_

O que acabamos de aplicar é um padrão de projeto chamado "Strategy". Só não é exatamente um _Strategy_ porque a ideia do _Strategy_ é ter várias classes implementando uma estratégia, mas utilizaríamos apenas uma das estratégias.

Aqui não estamos usando só uma das estratégias, estamos chamando todas.

## Princípios do SOLID

Mas o que interessa aqui é que nesse código estamos aplicando, de uma vez, três princípios do SOLID, que é uma lista com cinco princípios de boas práticas de programação orientada a objetos.

Estamos aplicando os seguintes princípios do SOLID:

- **Single Responsibility Principle** (Princípio da responsabilidade única): porque cada classe de validação tem apenas uma responsabilidade.
- **Open-Closed Principle** (Princípio aberto-fechado): na classe _service_, `AgendadeConsultas`, porque ela está fechada para modificação, não precisamos mexer nela. Mas ela está aberta para extensão, conseguimos adicionar novos validadores apenas criando as classes implementando a interface.
- **Dependency Inversion Principle** (Princípio da inversão de dependência): porque nossa classe _service_ depende de uma abstração, que é a interface, não depende dos validadores, das implementações especificamente. O módulo de alto nível, a _service_, não depende dos módulos de baixo nível, que são os validadores.

Com isso ganhamos um código fácil de entender, fácil de dar manutenção, fácil de estender e de testar com testes automatizados.

Finalizamos a funcionalidade, já tem todas as regras de negócio implementadas. Mas será que está funcionando? No próximo vídeo começaremos a fazer os testes para simular cada uma dessas validações no **Insomnia** e verificar se está funcionando conforme o esperado.


-----------------------------------------------------------------------
# Para saber mais: princípios SOLID
**SOLID** é uma sigla que representa cinco princípios de programação:

- **S[](https://cursos.alura.com.br/course/spring-boot-3-documente-teste-prepare-api-deploy/task/122586)**ingle Responsibility Principle (Princípio da Responsabilidade Única)
- **O[](https://cursos.alura.com.br/course/spring-boot-3-documente-teste-prepare-api-deploy/task/122586)**pen-Closed Principle (Princípio Aberto-Fechado)
- **L[](https://cursos.alura.com.br/course/spring-boot-3-documente-teste-prepare-api-deploy/task/122586)**iskov Substitution Principle (Princípio da Substituição de Liskov)
- **I[](https://cursos.alura.com.br/course/spring-boot-3-documente-teste-prepare-api-deploy/task/122586)**nterface Segregation Principle (Princípio da Segregação de Interface)
- **D[](https://cursos.alura.com.br/course/spring-boot-3-documente-teste-prepare-api-deploy/task/122586)**ependency Inversion Principle (Princípio da Inversão de Dependência)

Cada princípio representa uma boa prática de programação, que quando aplicadas facilita muito a sua manutenção e extensão. Tais princípios foram criados por Robert Martin, conhecido como _Uncle Bob_, em seu artigo [**Design Principles and Design Patterns**](http://staff.cs.utu.fi/~jounsmed/doos_06/material/DesignPrinciplesAndPatterns.pdf).

Estes dois episódios do podcast Hipsters.Tech foram dedicados ao tema SOLID:

- [Hipsters #129 - Práticas de Orientação a Objetos](https://cursos.alura.com.br/extra/hipsterstech/praticas-de-orientacao-a-objetos-hipsters-129-a453)
    
- [Hipsters #219 - SOLID: Código bom e bonito](https://cursos.alura.com.br/extra/hipsterstech/solid-codigo-bom-e-bonito-hipsters-ponto-tech-219-a649)

-----------------------------------------------------------------------
# Testando o agendamento
## Transcrição

Já implementamos a funcionalidade de agendamento de consultas, usando a classe _service_ e os princípios SOLID.

Mas ainda não testamos. Agora é a hora de testar, vamos usar no **Insomnia** para descobrir se está tudo funcionando como esperado.

No Insomnia, vamos disparar uma requisição para fazer agendamento de consulta.

> POST [http://localhost:8080/consultas](http://localhost:8080/consultas)

```bash
{
    "idPaciente": 1,
    "idMedico": 1,
    "data": "2023-10-10T10:00,
}
```

Deu erro e apareceu uma mensagem dizendo que não conseguiu se conectar ao servidor. Talvez tenha acontecido algum problema no projeto e ele tenha parado. Vamos verificar no terminal “Run ApiApplication” do projeto.

Ele está mostrando que tem alguma consulta com problema.

```python
from Medico m
where
m.id = :id
```

Vamos verificar os _repositories_ para localizar esse erro. Começaremos pelo `MedicoRepository`.

A última consulta que fizemos foi a `findAtivoById`

```python
@Query ("""
    select m.ativo
    from Medico m
    where
    m.id = :id
    """)
    Boolean findAtivoById(Long id Medico);
}
```

Foi até bom acontecer esse problema para eu mostrar algo importante para vocês. Essa consulta está com `m.id = :id`. Esse `:id` o Spring Data assume que é o parâmetro que está vindo no método.

Mas no meu método, o parâmetro não está como `id`, eu deixei `idMedico`. Deu esse problema, não bateu o nome do parâmetro na query com o nome do parâmetro no método e aí causa esse erro.

O nome do parâmetro deve ser `id` assim como está na query:

```python
    @Query("""
            select m.ativo
            from Medico m
            where
            m.id = :id
            """)
    Boolean findAtivoById(Long id);
}
```

Vamos salvar e verificar o código do arquivo `PacienteRepository`. Ele está com o mesmo problema, no `findAtivoById`. Em vez de `idPaciente` deixaremos apenas `id`.

Corrigiremos o mesmo erro no `PacienteRepository`.

Vamos salvar o projeto e acompanhar a reinicialização do projeto na aba "Run".

A princípio, iniciou a aplicação normalmente.

Vamos voltar ao Insomnia e disparar novamente a requisição para agendar consulta.

> POST [http://localhost:8080/consultas](http://localhost:8080/consultas)

```bash
{
    "idPaciente": 1,
    "idMedico": 1,
    "data": "2023-10-10T10:00,
}
```

Foi retornado um _403 Forbidden_. Talvez tenha acontecido alguma _exception_, vamos verificar na aba "Run ApiApplication".

Deu a seguinte _exception_:

> java.lang.RuntimeException: Token JWT inválido ou expirado!

Isso aconteceu porque já faz algum tempo que fiz o login. Acho que são cerca de duas horas que o token do login vale. Vamos efetuar login novamente. No Insomnia, clique em "Efetuar login" e vamos disparar a requisição.

> POST [http://localhost:8080/login](http://localhost:8080/login)

```perl
{
    "login": "ana.souza@voll.med",
    "senha": "123456",

}
```

Ele exibiu um novo token aleatório, que vamos copiar para colar na aba "Bearer" da requisição "Agendar Consultas". Vamos apagar o token anterior e colar esse novo token no campo "Token".

Em seguida vamos disparar a requisição para agendar consulta, clicaremos em "Send". Agora ele retornou _200 OK_, mas está devolvendo as informações como nulas.

```json
{
    "id": null,
    "idMedico": null,
    "idPaciente": null,
    "data": null,
}
```

Isso está acontecendo porque não mexemos no _controller_. O _controller_ continua com o `return new` passando os parâmetros como nulo. Vamos abrir o pacote de _controllers_ e vamos no `ConsultaController` para arrumar isso.

No return do `ResponseEntity` estamos passando `new DadosDetalhamentoConsulta`, passa tudo está sendo passado como nulo. Não devemos mais passar essas informações nulas, devemos receber o objeto de agendamento que foi criado.

Lá na classe `AgendaDeConsultas` o método `agendar()` está `void`. Vamos tirar esse `void` e inserir o objeto `DadosDetalhamentoConsulta`. E lá no fim do método `agendar()` colocaremos `return new DadosDetalhamentoConsulta()` passando como parâmetro o objeto `consulta`.

```typescript
public DadosDetalhamentoConsulta agendar(DadosAgendamentoConsulta dados) {
    if (!pacienteRepository.existsById(dados.idPaciente())) {
        throw new ValidacaoException("Id do paciente informado não existe!");
    }

    if (dados.idMedico() != null && !medicoRepository.existsById(dados.idMedico())) {
        throw new ValidacaoException("Id do médico informado não existe!");
    }

    validadores.forEach(v -> v.validar(dados));

    var paciente = pacienteRepository.getReferenceById(dados.idPaciente());
    var medico = escolherMedico(dados);
    if (medico == null) {
        throw new ValidacaoException("Não existe médico disponível nessa data!");
    }

    var consulta = new Consulta(null, medico, paciente, dados.data(), null);
    consultaRepository.save(consulta);

    return new DadosDetalhamentoConsulta(consulta);
}
```

Vai dar um erro em "consulta", porque ainda não existe esse construtor, vamos usar o atalho "Alt + Enter" para criar o construtor que recebe o objeto `consulta` e chamamos o `this(consulta.getId(), consulta.getMedico().getId(), consulta.getPaciente().getId(), consulta.getData())`:

```scss
package med.voll.api.domain.consulta;

import java.time.LocalDateTime;

public record DadosDetalhamentoConsulta(Long id, Long idMedico, Long idPaciente, LocalDateTime data) {
    public DadosDetalhamentoConsulta(Consulta consulta) {
        this(consulta.getId(), consulta.getMedico().getId(), consulta.getPaciente().getId(), consulta.getData());
    }
}
```

Agora temos um DTO com os dados sendo devolvidos corretamente.

Em `ConsultaController`, o método `agendar()` devolve o DTO. Vamos guardar o DTO em uma variável e no `ResponseEntity.ok` passaremos o DTO, que foi devolvido pela `service`.

```typescript
@PostMapping
@Transactional
public ResponseEntity agendar(@RequestBody @Valid DadosAgendamentoConsulta dados) {
    var dto = agenda.agendar(dados);
    return ResponseEntity.ok(dto);
}
```

Pronto! Fizemos as correções. Agora podemos testar cada uma das validações no Insomnia.

Na requisição de agendar consulta, vamos testar o envio de um paciente que não existe no banco de dados:

> POST [http://localhost:8080/consultas](http://localhost:8080/consultas)

```json
{
    "idPaciente": 88888,
    "idMedico": 1,
    "data": "2023-10-10T10:00"
}
```

Ao enviar a requisição, ele devolveu o código _403 Forbidden_. Não era para devolver 403. Voltando ao terminal da IDE podemos ver que ele está enviando a _exception_ `ValidacaoException` "Id do paciente informado não existe". Mas não está aparecendo para o usuário porque ainda não inserimos essa validação na classe que faz o tratamento das _exceptions_ Vamos corrigir isso.

No pacote "exception" vamos acessar a classe `TratadorDeErros` e criar um novo método para `ValidacaoException`:

```java
@ExceptionHandler(ValidacaoException.class)
public ResponseEntity tratarErroRegraDeNegocio(ValidacaoException ex) {
    return ResponseEntity.badRequest().body(ex.getMessage());
}
```

Então, se acontecer um erro de regra de negócio, queremos devolver 400 _Bad Request_, e no corpo queremos mandar a mensagem de erro, `body(ex.getMessage()`. Está feito o tratamento para a _exception_.

Vamos voltar ao Insomnia e reenviar a requisição POST para agendar consulta de um paciente sem id no nosso banco de dados.

> POST [http://localhost:8080/consultas](http://localhost:8080/consultas)

```json
{
    "idPaciente": 88888,
    "idMedico": 1,
    "data": "2023-10-10T10:00"
}
```

Agora funcionou corretamente. Devolveu o código _400 Bad Request_ e no corpo a mensagem "Id do paciente informado não existe!".

Se passarmos um `idMedico` que não existe ele exibe a mensagem "Id do médico informado não existe!". Como esperado.

Agora podemos colocar um paciente que foi excluído, ao enviar a requisição ele exibe a mensagem "Consulta não pode ser agendada com paciente excluído". E, caso seja inserido um médico que foi excluído, ele exibirá a mensagem ""Consulta não pode ser agendada com médico excluído".

Vamos testar mais uma regra, podemos tentar agendar uma consulta em um domingo ou fora do horário de funcionamento. Ele vai exibir a mensagem: "Consulta fora do horário de funcionamento da clínica".

Podemos verificar no cartão do Trello quais são as outras regras de negócio e testar se as validações de agendamento e as mensagens de erro estão funcionando corretamente.

Ao tentarmos passar uma consulta sem médico, apenas com a especialidade, houve um erro. No terminal do IntelliJ apareceu a mensagem:

> Column 'medico_id' cannot be null

E ele tentou salvar uma consulta com um médico que não existe. Ele não deveria ter tentado salvar a consulta no banco de dados. Vamos verificar o código da classe `AgendaDeConsultas`.

Faltou um detalhe importante na lógica de escolher um médico aleatório. Faltou uma verificação. Estamos verificando se está vindo o id do médico. Se tem, consultamos esse médico no banco de dados. Se não tem, verificamos se a especialidade está sendo escolhida e, se está sendo escolhida, buscamos um médico que está livre naquela data.

Mas e se não tiver nenhum médico livre na data escolhida? Faltou esse cenário. Nesse caso, o `return medicoRepository.escolherMedicoAleatorioLivreNaData` vai devolver nulo.

Então, se essa consulta devolver nulo, é porque não tem nenhum médico livre nessa data e a consulta não pode ser realizada.

Na linha em que estamos escolhendo um médico precisamos inserir um `if` para inserir a mensagem "Não existe médico disponível nessa data!".

```csharp
var paciente = pacienteRepository.getReferenceById(dados.idPaciente());
var medico = escolherMedico(dados);
if (medico == null) {
    throw new ValidacaoException("Não existe médico disponível nessa data!");
}
```

Por isso é importante fazer os testes. Já inserimos a validação que faltava. Agora, ao fazer uma requisição por especialidade, está funcionando corretamente.

Neste vídeo testamos todos os cenários e corrigimos alguns bugs no código.

Agora sim, finalizamos a funcionalidade de agendamento de consultas. No Trello, podemos mover o cartão "Agendamento de consultas" da coluna DOING para a coluna DONE.

na coluna TO DO ainda temos o cartão da funcionalidade de cancelamento de consultas. Vamos deixar essa como desafio para vocês, pois é bem parecida com agendamento de consultas.

Na sequência, veremos outras coisas que precisamos colocar no projeto além das funcionalidades. Como, por exemplo, documentação e testes automatizados.

-----------------------------------------------------------------------
# Documentando com SpringDoc
## Transcrição

Já implementamos todas as funcionalidades do projeto, mas há alguns recursos importantes que ainda precisamos aprender, e alguns exigirão mudanças no código.

No Insomnia aberto, usamos a ferramenta para fazermos testes da API, já que é uma API Rest em que só temos a parte do _back-end_ sem a interface gráfica da tela. Então precisamos simular as requisições para sabermos se tudo está funcionando como o esperado.'

Já conseguimos criar todas as requisições para fazermos simulações e testarmos as funcionalidades do projeto. Isso foi possível porque sabemos como nossa API funciona, quais são as URLs, os métodos HTTP, o JSON, quais são os formatos, quais campos são obrigatórios ou não, as respostas e etc.

Portanto, conseguimos implementar os testes porque conhecemos bem a API. Porém, o cliente dela, o time que vai desenvolver o aplicativo _mobile_ e a parte de _front-end_, não necessariamente conhece esses detalhes.

Então, a única forma de saberem como irão integrar com nossa API é através do acesso ao código-fonte, mas nosso projeto esta usando Java com Spring Boot, e não necessariamente essas pessoas terão conhecimento dessas tecnologias.

O ideal seria disponibilizarmos uma documentação para que os times possam ler e entender como o _back-end_ funciona para construírem suas soluções integradas corretamente.

Não faremos isso manualmente para encaminharmos como um PDF, por exemplo, pois é trabalhoso e, se tivermos alguma alteração na API, teríamos que fazer atualizações constantes no documento.

Ou seja, nossa ideia é usar alguma ferramenta que faça isso de forma **automatizada**, e existem diversas delas que conseguem ler o código da aplicação do _back-end_ para disponibilizarmos para os times de _front-end_ e _mobile_, os quais ainda podem usar automatizações na integração.

Em nosso caso, como estamos usando Java com Spring Boot, teremos que usar uma ferramenta compatível, que será a **SpringDoc**.

No navegador, faremos uma busca por "springdoc" para pesquisarmos a biblioteca e entendermos como funciona. Como resultado, encontraremos a [documentação do SpringDoc neste link](https://springdoc.org/).

Na página, teremos explicações sobre o que é, como funciona e como aplicar a biblioteca no projeto. Na parte de "_Introduction_" ou introdução, teremos mais informações sobre as tecnologias envolvidas que suporta, contendo uma parte destacada por um alerta de "_important_":

> For spring-boot v3 support, make sure you use [springdoc-openapi v2](https://springdoc.org/v2/)

Ou seja, se estivermos usando o `spring-boot` na versão 3, é recomendado usar a versão 2 do `springdoc-openapi`, que é nosso caso.

Clicando no link de [`springdoc-openapi v2` aqui](https://springdoc.org/v2/), teremos a documentação de acordo com a versão correta que precisaremos.

Mais adiante, teremos a parte de "_Getting Started_" ou "Dando início" em português, em que temos as orientações para usar a biblioteca, começando pelo _download_ dela no projeto com o seguinte código da dependência do `maven`:

```xml
<dependency>
  <groupId>org.springdoc</groupId>
  <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
  <version>2.0.2</version>
</dependency>
```

Copiaremos o bloco e adicionaremos ao nosso projeto.

Abrindo o IntelliJ, abriremos o arquivo `pom.xml` e iremos até a última dependência que é a do `java-jwt` para colar o código em seguida antes do fechamento de `</dependencies>`.

```javascript
//código omitido

<dependency>
    <groupId>com.auth0</groupId>
    <artifactId>java-jwt</artifactId>
    <version>4.2.1</version>
</dependency>

<dependency>
    <groupId>org.springdoc</groupId>
    <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
        <version>2.0.2</version>
</dependency>

//código omitido
```

Salvaremos e teremos baixado a biblioteca.

Toda vez que formos incluir uma nova, é interessante pararmos o projeto clicando no ícone de "pausar" representado por um quadrado vermelho no canto superior direito da tela, para depois clicarmos na aba central de "Maven" na extremidade direita.

Expandindo-a, selecionaremos "Dependencies" e, em seguida, no canto superior esquerdo dessa aba, clicaremos no ícone de "reload" representado por duas setas circulares para recarregarmos as dependências e vermos se baixou corretamente no final da lista.

Para usarmos a biblioteca, voltaremos à documentação e, logo após o bloco de código, ela nos diz que só de instalarmos a dependência no projeto, serão criados dois endereços na API:

> [http://server:port/context-path/swagger-ui.html](http://server:port/context-path/swagger-ui.html)

> [http://server:port/context-path/v3/api-docs](http://server:port/context-path/v3/api-docs)

O primeiro é uma documentação em uma página web que podemos navegar e fazer testes, parecido com o que fazemos no Insomnia.

A segunda URL gera um JSON com a documentação, e podemos usar ferramentas que automatizam a criação do cliente dessa API baseado nesse JSON.

Porém, como estamos usando o Spring Security, por padrão, ele bloqueia todas as URLs que temos no projeto, e precisaremos estar _logades_ para acessá-las, exceto a URL de _login_.

Neste caso, queremos que ambas as URLs sejam liberadas e públicas sem precisar _logar_. Faremos essa configuração no projeto.

Abrindo o IntelliJ, fecharemos o `pom.xml` e abriremos "src > main > java" e, no pacote `med.voll.api`, acessaremos "infra > security" e abriremos a classe `SecurityConfigurations.java` contendo as configurações de segurança do projeto.

No método `securityFilterChain()` onde configuramos as URLs do projeto, encontraremos a linha de `requestMatchers()` com `.permitAll()` que libera a URL de _login_.

A copiarem os, abriremos uma nova linha abaixo e colocaremos os dois endereços, retirando o método `HttpMethod.POST` dos parênteses da cópia, pois neste caso a URL será para qualquer metodo, nao precisaremos filtrar por este.

Trocaremos a URL para `/v3/api-docs` seguido de `/**` com o subendereços que também precisam ser liberados. Depois que fecharmos as aspas da _string_, colocaremos outra na mesma linha com a segunda URL `"/swagger-ui.html"` na documentação.

Também há um outro endereço do `swagger`, que é a página HTML que possui alguns CSS e JavaScript que precisam ser baixados para carregar a página corretamente.

Então escreveremos `"/swagger-ui/**"` para o que estiver após este endereço ser liberado.

```scss
//código omitido

@Bean
public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
    return http.csrf().disable()
        .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
        .and().authorizeHttpRequests()
        .requestMatchers(HttpMethod.POST, "/login").permitAll()
        .requestMatchers("/v3/api-docs/**", "/swagger-ui.html", "/swagger-ui/**").permitAll()
        .anyRequest().authenticated()
        .and().addFilterBefore(securityFilter, UsernamePasswordAuthenticationFilter.class)
        .build();
}
//código omitido
```

Desta forma, iremos salvar e teremos os três endereços que precisaremos deixar como público para acessarmos a documentação gerada pelo SpringDoc.

Executaremos o projeto clicando no ícone de "_play_" representado por um triângulo verde no canto superior direito da tela, e veremos se algum erro aparecerá.

Tendo inicializado corretamente, acessaremos a documentação diretamente pelo _browser_. No navegador, abriremos uma nova aba , acessaremos nosso endereço do projeto "localhost:8080/v3/api-docs" para vermos o retorno.

Receberemos um JSON que explica todos os endereços _endpoints_ da nossa API. No tópico chamado `paths:` na lista lateral esquerda, teremos cada um deles.

"Por baixo dos panos", a biblioteca e as classes _controllers_, os métodos e todas as informações para fazer um JSON que detalha as funcionalidades.

Essa documentação da API pode ser usada pelos times e clientes para automatizar a geração do código que a consumirá.

Em uma nova aba do navegador, acessaremos "localhost:8080/swagger-ui/index.html" e abriremos a versão _web_ como um site que representa a API.

É a mesma coisa que o JSON mas em uma página HTML mais agradável e organizada, de forma que mais pessoas possam compreender mais facilmente.

Todos os _controllers_ aparecem listados e poderemos expandir os tópicos para exibirmos os parâmetros, como o de pacientes.

No botão do canto superior direito do tópico chamado "Try Out", conseguiremos "disparar" uma requisição para testarmos a API sem o Insomnia ou o Postman, apenas usando o Swagger que é essa ferramenta feita para testar uma API REST.

Quando "disparamos" a requisição, teremos o retorno e um erro 403, afinal estamos tentando disparar para o "/pacientes" e precisamos fazer o _login_ para isso.

Indo até o `aoutenticacao-controller`, o expandiremos e teremos a requisição POST para o _login_ clicando em "Try Out". No JSON, o `"login":` é o `ana.souzavoll.med` com a `"senha": 123456`.

Ao dispararmos essa requisição, teremos o código 200 com o valor do `"token":`. Iremos copiá-lo e iremos "disparar" a requisição para listarmos os pacientes.

Porém, não há o mesmo campo que havia no Insomnia para dizer que a requisição levava um cabeçalho do tipo _bearer_, afinal não configuramos isso no Swagger.

Isso e outros aspectos da página são personalizáveis.

A seguir, aprenderemos a colocar o cabeçalho com o _token_ para conseguirmos simular as requisições de segurança que precisamos.

-----------------------------------------------------------------------
# Atualização do SpringDoc


Caso você esteja utilizando as novas versões do Spring Boot, será necessário atualizar a versão da biblioteca Spring Doc para a versão 2.6.0.

Atualize no `pom.xml` a versão da dependência, de 2.0.2 para 2.6.0:

```xml
<dependency>
    <groupId>org.springdoc</groupId>
    <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
    <version>2.6.0</version>
</dependency>
```

E a partir da versão **3.4.0** do Spring Boot, a versão compatível do SpringDoc é a 2.7.0:

```xml
<dependency>
    <groupId>org.springdoc</groupId>
    <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
    <version>2.7.0</version>
</dependency>
```
-----------------------------------------------------------------------
# Para saber mais: OpenAPI Initiative

A documentação é algo muito importante em um projeto, principalmente se ele for uma API Rest, pois nesse caso podemos ter vários clientes que vão precisar se comunicar com ela, necessitando então de uma documentação que os ensinem como realizar essa comunicação de maneira correta.

Por muito tempo não existia um formato padrão de se documentar uma API Rest, até que em 2010 surgiu um projeto conhecido como **Swagger**, cujo objetivo era ser uma especificação _open source_ para design de APIs Rest. Depois de um tempo, foram desenvolvidas algumas ferramentas para auxiliar pessoas desenvolvedoras a implementar, visualizar e testar suas APIs, como o _Swagger UI_, _Swagger Editor_ e _Swagger Codegen_, tornando-se assim muito popular e utilizado ao redor do mundo.

Em 2015, o Swagger foi comprado pela empresa **SmartBear Software**, que doou a parte da especificação para a fundação Linux. Por sua vez, a fundação renomeou o projeto para **OpenAPI**. Após isso, foi criada a **OpenAPI Initiative**, uma organização focada no desenvolvimento e evolução da especificação OpenAPI de maneira aberta e transparente.

A OpenAPI é hoje a especificação mais utilizada, e também a principal, para documentar uma API Rest. A documentação segue um padrão que pode ser descrito no formato yaml ou JSON, facilitando a criação de ferramentas que consigam ler tais arquivos e automatizar a criação de documentações, bem como a geração de códigos para consumo de uma API.

Você pode obter mais detalhes no [site oficial da OpenAPI Initiative](https://www.openapis.org/).

-----------------------------------------------------------------------
# JWT na documentação
## Transcrição

Já geramos a documentação, mas ainda não conseguimos "disparar" a requisição enviando o cabeçalho com o _token_ JWT.

Podemos fazer isso com uma configuração adicional, já que por padrão não poderemos informar esse campo.

No item [12.34 da documentação do SpringDoc neste link](https://springdoc.org/#how-do-i-add-authorization-header-in-requests), teremos a explicação de como adicionar cabeçalho de autorização às requisições.

Deveremos criar um `@Bean` com a configuração e anotar os métodos e _controllers_ que queremos proteger com o cabeçalho _bearer_.

Criaremos uma classe de configuração de estrutura que receberá o código fornecido.

No IntelliJ, abriremos o pacote de "Infra" e criaremos um subpacote usando o atalho "Alt + Insert" para escolhermos a opção de "New Package" e nomearmos como "springdoc".

Neste novo pacote, criaremos uma nova classe Java chamada "SpringDocConfigurations" para conter as configurações do SpringDoc.

```kotlin
package med.voll.api.infra.springdoc;

public class SpingDocConfigurations {
}
```

É uma classe Java desconhecida, então não conseguiremos carregá-la.

Criaremos uma notação `@Configuration`, para deixarmos claro que a classe fará configurações. Dentro, colaremos o código que copiamos da documentação.

```typescript
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpingDocConfigurations {

    @Bean
     public OpenAPI customOpenAPI() {
         return new OpenAPI()
                        .components(new Components()
                            .addSecuritySchemes("bearer-key",
                            new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")));
    }
}
```

Este método está expondo o objeto `@Bean` do tipo `OpenAPI` que será carregado pelo SpringDoc e seguirá as configurações definidas.

Após instanciar `OpenAPI`, chamamos o método que configura componentes contendo `.addSecuritySchemes()` passando o parâmetro `"bearer-key"` e falando que é do protocolo HTTP do esquema `"bearer"` no formato `"JWT"`.

Portanto, é uma configuração de acordo com a biblioteca, contendo um cabeçalho para passarmos a chave do _token_. Porém, ainda não falamos quais _controllers_ precisamos passar também.

De volta à documentação, veremos que há a `@Operation()` em que vamos ate a operação onde queremos restringir e colocamos a anotação `@SecurityRequirement(name = "bearer-key")`.

A copiaremos e retornaremos ao IntelliJ para colocarmos a anotação nos _controllers_.

Abrindo o pacote de controladores, acessaremos `PacienteController.java` e a colocaremos acima de um método para torná-lo restrito.

Caso todos sejam, para evitarmos muita repetição em cada um, poderemos colocar a anotação acima da classe para que todos os métodos sejam considerados com ela e que precisam do `"bearer-key"`.

No caso do `PacienteController`, todos os métodos devem ter autenticação.

```less
//código omitido

@RestController
@RequestMapping("pacientes")
@SecurityRequirement(name = "bearer-key")
public class PacienteController {

//código omitido
}
```

Faremos a mesma coisa com o `MedicoController`.

```less
//código omitido

@RestController
@RequestMapping("medicos")
@SecurityRequirement(name = "bearer-key")
public class MedicoController {

//código omitido
}
```

Também para o `ConsultaController`.

```less
//código omitido

@RestController
@RequestMapping("consultas")
@SecurityRequirement(name = "bearer-key")
public class ConsultaController {

//código omitido
}
```

Não faremos no `AutenticationController.java` porque não tem _token_, afinal é o controlador para _logar_.

Também deixaremos o `HelloControler` publico porque é só um exemplo.

No `ConsultaController`, a anotação `@SecurityRequirement()` que colocamos possui o parâmetro `name = "bearer-key"`. Devemos **ter cuidado** pois é a mesma que esta na classe de configuração do SpringDoc.

Portanto, devem ser iguais para evitarmos erros na geração de cabeçalhos.

Salvaremos, reiniciaremos o DevTools e retornaremos ao Swagger no navegador. Atualizaremos com "F5" e notaremos que, para cada uma das requisições de `paciente-controller`, aparecerá um ícone de cadeado para representar a configuração de segurança.

Se clicarmos nele à direita das linhas, abriremos uma janela de diálogo com o campo de valor para configurarmos o cabeçalho e o _token_ de segurança. Bastará colocá-lo em "Value" e clicar em "Authorize" ou "Autorizar".

Isso já deixará o _token_ de segurança salvo para quando a requisição for "disparada".

Fecharemos esse _popup_ e iremos "disparar" a requisição de _login_ novamente para testarmos.

Notaremos que, em `autenticacao-controller` não há o ícone de cadeado porque não há o cabeçalho no _token_. "Dispararemos" novamente a requisição de _login_ clicando em "Try Out".

Passaremos `"ana.souza@voll.med"` e a senha `123456` que já temos cadastrado. Clicando no botão azul de "Execute", iremos executar e "disparar" a requisição.

Copiaremos o valor do _token_ que aparece no corpo da resposta e colaremos no ícone de cadeado de "/pacientes" em `paciente-controller`.

Também poderemos clicar no botão de "Authorize" no canto superior direito acima de `paciente-controller`, antes de todas as requisições.

Preenchendo e salvando o campo "value", iremos salvar o _token_ e, na requisição GET de "/pacientes", clicaremos em "Try Out" e não precisaremos mais preencher o _token_, pois já está salvo e será enviado automaticamente pelo Swagger.

Testaremos novamente "disparando" a requisição e teremos um erro 403 novamente.

No IntelliJ, identificaremos que o problema está nos parâmetros da paginação que ainda não trocamos, escrevendo vinte registros:

```json
{
"page": 0,
"size": 20
}
```

Clicando em "Execute", veremos que devolverá o coidgo 200 com todos os pacientes cadastrados no banco de dados.

Portanto, teremos conseguido "disparar" requisição para fazer essa listagem. Testaremos excluindo o "/pacientes/{id}" clicando em "Try Out". Preenchendo a descrição com "3", teremos o código 204 indicando que a requisição foi processada com sucesso.

Não precisamos colocar o cabeçalho e o token em todas as requisições, bastará ver no botão de "Authorize". Há inclusive o botão de "logout", e se clicarmos nele, iremos parar de criar o cabeçalho e deveríamos bloquear as URLs restritas.

Então já conseguimos personalizar o SpringDoc em nosso projeto para termos um cabeçalho de autorização. Há outras personalizações que poderíamos fazer além dessa.

Documentar a API Rest é muito importante para clientes saberem como conectar ao _back-end_ com suas URLs e parâmetros.

Disponibilizamos o JSON com as informações e a página HTML usando a ferramenta Swagger que se integra automaticamente ao SpringDoc, gerando o site que podemos usar para fazermos testes de API ao invés do Insomnia.

A seguir, estudaremos outros recursos.


-----------------------------------------------------------------------
# Para saber mais: personalizando a documentação
Vimos no vídeo anterior que é possível personalizar a documentação gerada pelo SpringDoc para a inclusão do token de autenticação. Além do token, podemos incluir outras informações na documentação que fazem parte da especificação OpenAPI, como, por exemplo, a descrição da API, informações de contato e de sua licença de uso.

Tais configurações devem ser feitas no objeto `OpenAPI`, que foi configurado na classe `SpringDocConfigurations` de nosso projeto:

```java
@Bean
public OpenAPI customOpenAPI() {
    return new OpenAPI()
            .components(new Components()
                    .addSecuritySchemes("bearer-key",
                            new SecurityScheme()
                                    .type(SecurityScheme.Type.HTTP)
                                    .scheme("bearer")
                                    .bearerFormat("JWT")))
                    .info(new Info()
                            .title("Voll.med API")
                            .description("API Rest da aplicação Voll.med, contendo as funcionalidades de CRUD de médicos e de pacientes, além de agendamento e cancelamento de consultas")
                            .contact(new Contact()
                                    .name("Time Backend")
                                    .email("backend@voll.med"))
                    .license(new License()
                            .name("Apache 2.0")
                            .url("http://voll.med/api/licenca")));
}
```

Usando os imports:

```kotlin
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
```

No código anterior, repare que após a configuração do token JWT foram adicionadas as informações da API. Ao entrar novamente na página do Swagger UI, tais informações serão exibidas, conforme demonstrado na imagem a seguir:

![alt text: Página do Swagger Ui exibindo as informações da Voll.med API, onde se lê a mensagem “API Rest da aplicação Voll.med, contendo as funcionalidades de CRUD de médicos e de pacientes, além de agendamento e cancelamento de consultas.”](https://cdn3.gnarususercontent.com.br/2771-spring-boot/imagem2.png)

Para saber mais detalhes sobre quais informações podem ser configuradas na documentação da API, consulte a [especificação OpenAPI](https://spec.openapis.org/oas/latest.html#schema) no site oficial da iniciativa.

-----------------------------------------------------------------------
Testes com Spring Boot

## Transcrição

Já implementamos a documentação. Agora, outro assunto importante diz respeito aos testes. Anteriormente, entendemos que é possível fazer os testes da API pela própria interface do Swagger, além de usar o Insomnia ou outra ferramenta de testes de API.

Mas estes testes são predominantemente manuais: precisamos entrar na ferramenta, configurá-los, dispará-los e analisar os resultados. É importante também fazer os **testes automatizados**.

O foco deste curso não é ensinar o que são os testes automatizados, os tipos de teste, como fazer testes com Java usando a biblioteca JUnit e o Mockito. Nosso foco é na parte do Spring Boot.

Por isso, trouxemos algumas discussões.

### Testes automatizados com Spring Boot

Como podemos escrever testes automatizados para classes e componentes que usam os recursos do Spring Boot?

Se analisarmos o nosso projeto, temos a seguinte estrutura de pacotes:

- med.voll.api
    - controller
        - AutenticacaoController
        - ConsultaController
        - HelloController
        - MedicoController
        - PacienteController
    - domain
        - consulta
            - validacoes
                - AgendaDeConsultas
                - Consulta
                - ConsultaRepository
                - DadosAgendamentoConsulta
                - DadosDetalhamentoConsulta
        - endereco
        - medico
        - paciente
        - usuario
            - ValidacaoException
    - infra
        - exception
            - TratadorDeErros
        - security
            - DadosTokenJWT
            - SecurityConfigurations
            - SecurityFilter
            - TokenService
        - springdoc
            - SpringDocConfigurations
    - ApiApplication

Encontramos diversos tipos de classes aqui: os controllers, o pacote de domínio com entidades JPA, os _repositories_, as classes de validação de consulta, os DTOs e o pacote com configurações de infraestrutura do projeto (tratamento de erro e configurações de segurança). Perceba que o projeto está crescendo.

Mas devemos testar todas as classes e os métodos do projeto? Não. A ideia é entendermos o que é importante de ser testado. A parte crítica do sistema são as regras de negócio que se encontram nas validações, nos algoritmos e nos cálculos essenciais para o projeto.

No nosso caso, seria a funcionalidade de consulta. Por isso, o pacote "validacoes" é um bom candidato a testes. Todas as classes que implementamos em aulas anteriores são boas para testarmos, pois elas contêm as regras de negócio da aplicação.

Elas são essencialmente classes Java que usam componentes do Spring, mas conseguimos fazer testes de unidade com o JUnit e usando o Mockito.

Não será esse o foco do curso. Dedicaremos tempo a aspectos mais específicos do Spring Boot, especialmente as classes Controller e Repository.

### O que testaremos neste curso?

Focaremos na classe **Controller**, que representa a nossa **API**. É nele que mapeamos as requisições do nosso projeto (endpoints). É onde tentamos configurar a requisição HTTP, o verbo do protocolo HTTP, os parâmetros esperados etc.

Também é onde estão as validações do BIN validation (campos obrigatórios, tamanho mínimo e máximo, por exemplo). A lógica disparada, o código HTTP devolvido e o JSON devolvido na resposta também estão lá.

Por isso, essa parte do nosso projeto é o ponto de entrada da API. Toda requisição feita por clientes da API chega primeiro às classes Controller. É onde configuramos os códigos com as regras de tudo o que chega e sai da API. Aprenderemos a fazer testes de uma classe Controller.

Temos também as interfaces **Repository**, com a integração ao banco de dados. Neste curso, estamos usando um Spring Data JPA. Com ela, só criamos uma interface herdando a interface do Spring e os métodos do CRUD já são implementados.

Não precisamos testar nada disso: o próprio Spring já testou e garante que esteja tudo funcionando. Nosso foco, então, serão as **Queries**, usadas para fazer consultas. É importante testar esses métodos para garantir que escrevemos o código corretamente e que o resultado alcançado é o esperado.

Portanto, estes são os dois tipos de componentes que aprenderemos a testar: Controller e Repository. Usaremos os recursos do Spring para escrever testes voltados a esses componentes.

Claro que é importante testar as regras de negócio. Porém, como elas não dizem tanto respeito à parte do Spring Boot, deixaremos essa parte de fora. Disponibilizaremos o projeto final com todos os testes implementados para consulta.

Na sequência, testaremos os nossos Repositories e, em seguida, os Controllers.


-----------------------------------------------------------------------
# Configurando o banco de testes

## Transcrição

Um dos testes que faremos é o de interfaces **Repository**.

Precisamos escrever um teste automatizado e, no caso do Java, a biblioteca padrão é o **JUnit**. A primeira ação lógica a se fazer é adicionar o JUnit ao projeto como uma dependência.

Com o IntelliJ aberto, abriremos o arquivo "pom.xml". Se repararmos nas dependências do projeto, temos as do Spring Boot, do Lombok, do MySQL, do Flyway, mas não a do JUnit. A verdade é que não precisamos adicionar essa dependência, pois ela já está embutida no projeto.

Lá no primeiro curso, quando criamos o projeto no site do **Spring Initializr**, ele adicionou automaticamente a seguinte dependência ao nosso projeto:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-test</artifactId>
    <scope>test</scope>
</dependency>
```

Essa dependência já inclui:

- JUnit
- Mockito;
- Hamcrest;
- AssertJ.

O Mockito é uma biblioteca para fazer Mocks, enquanto o Hamcrest e o AssertJ são bibliotecas para deixar o código de assertivas do JUnit mais simples. Assim, não precisamos nos preocupar com adicionar o JUnit ao projeto.

Agora, abriremos o menu Project à esquerda e acessaremos: "src > main > java > med.voll.api > domain > medico > MedicoRepository".

Ele tem os seguintes métodos: `findAllByAtivoTrue`, `escolherMedicoAleatorioLivreNaData` e `findAtivoById`. Destes, queremos testar aqueles que têm consultas mais complexas.

No método `findAllByAtivoTrue`, usamos o padrão de nomenclatura do Spring Data e, por isso, o próprio Spring Data gera a Query para nós.

Quando escrevemos um método nesse padrão de nomenclatura, o Spring já faz uma validação para verificar se, por exemplo, existe um parâmetro chamado `Ativo` e se ele é booleano. Por isso, não precisamos testar esse método.

O último método, `findAtivoById`, poderia ser testado, pois estamos passando uma Query personalizada. No entanto, é um método tão simples que dispensa o teste.

Já o método `escolherMedicoAleatorioLivreNaData` é um bom candidato a testes, pois se trata de um método mais complexo: ele usa filtros, tem um _subselect_ e é importante para a aplicação. É ele quem seleciona um médico livre na data e horário escolhido pela pessoa usuária quando esta agenda uma consulta.

Por isso, seria interessante criarmos um teste para a nossa interface MedicoRepository e escrever cenários de teste para esse método `escolherMedicoAleatorioLivreNaData`.

Faremos isso selecionando o método desejado e utilizando o atalho "ALT + Insert". Das opções que surgirem na tela, selecionaremos a opção "_Test_".

Uma nova janela se abrirá. Lá, teremos o nome da nova classe de testes seguindo o padrão do JUnit ("MedicoRepositoryTest"). O IntelliJ já inserirá essa classe no pacote "src > test > java", específico para classes de teste automatizado.

Logo abaixo, a janela pede para confirmarmos o método que queremos testar (abaixo de "_Generate test methods for:_"), clicaremos na caixa de diálogo ao lado do método `escolherMedicoAleatorioLivreNaData` e selecionaremos o botão "OK".

Está criada a nossa classe de teste. Expandindo o menu Project, repare que a pasta foi criada em "src > test > java > med.voll.api > domain medico".

Se você explorou o projeto do curso, deve ter reparado que, ao criá-lo com o Spring Initializr, ele até cria uma classe de exemplo de testes automatizados chamada "ApiApplicationTests". Podemos apagá-la, pois ela não será usada.

Para testar uma classe Repository, usaremos alguns recursos do Spring Boot voltados a testes automatizados. Já que queremos testar um Repository, precisamos inserir a anotação `@DataJpaTest` nela.

> A anotação @DataJpaTest é utilizada para testar uma interface Repository.

Ao inserir essa anotação, o Spring já subirá o contexto e carregará as configurações de persistência do nosso projeto. Podemos rodar essa classe de teste para ver o que acontece. Faremos isso clicando com o botão direito sobre a anotação `@DataJpaTest` e escolherendo a opção "_Run 'MedicoRepositoryTest'_".

A aba "Run" foi aberta na parte inferior do IntelliJ e, do lado esquerdo da interface, vemos que a classe "_MedicoRepositoryTest_" foi colocada para rodar e, dentro dela, o método `escolherMedicoAleatorioLivreNaData`.

Ao lado do nome da classe e do método, há um pequeno círculo vermelho com um ponto de exclamação dentro. Isso indica que o teste falhou. Na parte central, podemos observar mais detalhes da falha.

Em meio aos detalhes do erro, podemos notar que a falha aconteceu na hora de substituir o DataSource com um banco de dados embutido para testes.

Em seguida, ele dá uma sugestão: se quisermos testar usando um banco de dados embutido, precisamos adicioná-lo como uma dependência do projeto.

Toda vez que fizermos um teste que acessa o banco de dados, temos duas abordagens possíveis para usar. Por padrão, o Spring não usará o mesmo banco de dados da aplicação, mas um banco de dados _in-memory_, ou seja, um banco embutido (_embedded_). Este pode ser o H2, o Derby ou qualquer outro banco de dados embutido em memória.

Foi por isso que o teste falhou: o Spring Boot procurou e não encontrou uma dependência no banco de dados em memória. Assim, ele lança uma _exception_.

Por que é interessante usarmos um banco de dados in-memory? A **vantagem** é que ele é mais rápido, pois roda em memória em vez de ser em disco, como um banco de dados tradicional (o MySQL, por exemplo).

Já a desvantagem é que usamos bancos de dados distintos para o projeto e para o teste. Pode ser que o teste funcione no H2, por exemplo, mas o projeto apresente algum erro. Isso acontece porque usamos um banco de dados distinto.

No nosso caso, podemos solicitar que o Spring não use o banco de dados em memória, mas o próprio banco de dados da aplicação. Isso resultará em um teste que seja o mais fiel possível ao nosso ambiente. Usaremos essa opção. A desvantagem dele é que o teste será um pouco mais lento, ainda que mais fidedigno.

Para usar essa abordagem, precisamos inserir a anotação `@AutoConfigureTestDatabase()`. Como parâmetro, escreveremos `replace =` e pressionaremos "CTRL + Espaço" para receber as sugestões automáticas. Uma delas é a "Replace.NONE". Escolheremos esta pressionando o "Enter" e veremos que o parâmetro mudou para `replace = AutoConfigureTestDatabase.Replace.NONE`

Com isso, estamos indicando que queremos fazer uma configuração do banco de dados de teste e pedindo para não substituir as configurações do banco de dados pelas do banco em memória.

Feita a substituição, tentaremos rodar o teste novamente para ver se o erro persiste. Após clicar com o botão direito do mouse e selecionar "_Run 'MedicoRepositoryTest'_", observaremos que o teste foi concluído com sucesso.

Porém, o teste foi bem-sucedido porque o método `escolherMedicoAleatorioLivreNaData` está vazio.

Essa será a opção usada no curso. Lembrando que não existe uma alternativa correta ou melhor que a outra: ambas têm vantagens e desvantagens.

Eu prefiro usar o banco de dados real para ficar mais próximo do cenário em que a aplicação irá funcionar, embora o teste demore um pouco mais para ser executado. Afinal, depois de pronta, a aplicação não usará um banco de dados em memória.

No entanto, teremos outro problema: o nosso banco de dados já tem muitos registros cadastrados. Isso pode interferir no teste automatizado. O ideal é que usemos o mesmo banco (MySQL), mas com outro _database_ exclusivo para os testes.

Com isso, os dados que já temos no ambiente de desenvolvimento não impactarão os dados usados para os testes automatizados.

Para executar essa mudança, acessaremos "src > main > java > resources > application.properties". Este é o application properties que queremos usar no ambiente de desenvolvimento, mas queremos outra configuração para o ambiente de testes.

Para isso, duplicaremos este arquivo clicando em "application.properties" e pressionando o atalho "CTRL + C", seguido de "CTRL + V". Em seguida, renomearemos a cópia para "application-test.properties".

Podemos ter vários arquivos de propriedades e o "-test" funciona como se fosse um perfil (_profile_). Assim, "application.properties" continua sendo o arquivo padrão e "application-test.properties" serve só para usarmos no ambiente de teste.

Abriremos o arquivo "-test" e apagaremos todas as propriedades, com exceção da primeira, que corresponde à URL do banco de dados. Nela, modificaremos apenas o nome do _database_. Em vez de ser "vollmed_api", será "vollmed_api_test".

Todas as outras propriedades (login, usuário etc.) serão herdadas automaticamente de "application.properties". Esse é o comportamento padrão do Spring. A única propriedade sobrescrita foi a URL, as demais permanecem iguais.

Agora, voltaremos para a classe de testes. Lá, precisamos indicar ao Spring que, ao rodar o teste, queremos que ele carregue o "application-test.properties". Do contrário, ele não carregará automaticamente.

Para isso, inseriremos mais uma anotação: `@ActiveProfiles("test")`. Dentro dos parênteses, reproduziremos o que vem depois do traço (-) no nome do arquivo. Neste caso, apenas `"test"`.

Rodaremos o teste mais uma vez para verificar se teremos algum problema. Após rodar o projeto, obteremos um novo erro. Se clicarmos no teste que falhou, concluiremos que o arquivo "vollmed_api_test" foi lido, mas não foi encontrado um banco de dados no MySQL com esse nome.

Precisamos criar este _database_. Abriremos o Terminal e entraremos no MySQL, digitaremos a senha e usaremos o comando "create database vollmed_api_test;". Em seguida, pressionaremos a tecla "Enter" e o banco de dados será criado.

Não precisamos criar as tabelas, pois ele rodará as mesmas migrations neste banco de dados de teste. Podemos sair do MySQL e rodar o teste novamente clicando com o botão direito e pressionando "_Run 'MedicoRepositoryTest'_".

Observaremos que o teste foi realizado com sucesso. Com isso, temos todas as configurações corretas e conseguimos escrever os cenários de teste, atividade que faremos no próximo vídeo.


-----------------------------------------------------------------------
# Para saber mais: testes com in-memory database
Como citado no vídeo anterior, podemos realizar os testes de interfaces _repository_ utilizando um banco de dados em memória, como o **H2**, ao invés de utilizar o mesmo banco de dados da aplicação.

Caso você queira utilizar essa estratégia de executar os testes com um banco de dados em memória, será necessário incluir o H2 no projeto, adicionando a seguinte dependência no arquivo `pom.xml`:

```xml
<dependency>
  <groupId>com.h2database</groupId>
  <artifactId>h2</artifactId>
  <scope>test</scope>
</dependency>
```

E também deve remover as anotações `@AutoConfigureTestDatabase` e `@ActiveProfiles` na classe de teste, deixando-a apenas com a anotação `@DataJpaTest`:

```java
@DataJpaTest
class MedicoRepositoryTest {

  //resto do código permanece igual

}
```

Você também pode **apagar** o arquivo **application-test.properties**, pois o Spring Boot realiza as configurações de `url`, `username` e `password` do banco de dados H2 de maneira automática.

-----------------------------------------------------------------------
# Testando o repository
## Transcrição

Já implementamos a infraestrutura do nosso teste do Repository. Agora, já temos tudo configurado: orientamos o Spring de que, quando o teste for executado, ele não deve usar o banco de dados _in-memory_, mas o mesmo banco da aplicação. A única diferença é que ele não usará o mesmo _database_. Com isso, ele usará um banco de dados exclusivo para os testes.

Queremos fazer o teste no Repository, fazendo a chamada para o método `escolherMedicoAleatorioLivreNaData()`. No entanto, existem vários cenários possíveis para testar o método:

- Não haver nenhum médico disponível cadastrado no banco de dados;
- Haver médicos disponíveis no horário e data, mas de outra especialidade;
- Haver um médico da especialidade disponível;
- Haver um médico da especialidade ocupado;
- … e assim por diante.

Ou seja, os cenários possíveis são muitos. Assim, teremos um método para cada cenário. Tendo isso em mente, renomearemos o método `escolherMedicoAleatorioLivreNaData()` para `escolherMedicoAleatorioLivreNaDataCenario1()`. Os próximos métodos corresponderão ao cenário 2, cenário 3 e assim por diante.

Mas o que significa "Cenário 1"? Isso não passa nenhuma mensagem para quem lê o código, a não ser para a pessoa que o escreveu. Por isso, para deixá-lo mais claro, usaremos um recurso do JUnit.

Na linha imediatamente acima do método, logo abaixo da anotação `@Test`, escreveremos outra anotação: `@DisplayName()`. Dentro dos parênteses, inseriremos uma `string`, que nos permitirá descrever mais detalhadamente o método, pois nos permitirá dar espaço entre as palavras e inserir um texto mais longo.

O Cenário 1 corresponderá ao caso em que temos um médico da especialidade cadastrado no banco de dados, mas ele não está livre no dia e horário escolhido pela pessoa usuária. Neste caso, esse profissional não deve ser devolvido pelo método `escolherMedicoAleatorioNaData()`. O resultado, portanto, deve ser nulo.

Por isso, escreveremos o seguinte dentro da `string`: `"Deveria devolver null quando unico medico cadastrado nao esta disponivel na data"`.

Agora, escreveremos o método em si. No fundo, o que precisamos fazer é pegar o Repository e chamar o método que desejamos testar. Mas como fazemos para acessar o Repository de dentro do teste?

Para isso, usaremos os recursos do próprio Spring: como a classe está anotada com `@DataJpaTest`, o Spring subirá o contexto da aplicação e, com isso, conseguimos injetar objetos dentro da classe de teste.

Assim, declararemos um atributo do tipo `MedicoRepository`, chamando-o de `medicoRepository`, e, logo acima dele, inseriremos a anotação `@Autowired`, usada para fazer a injeção de dependências em todo o projeto.

No fim das contas, o nosso teste tem que fazer a chamada para o `medicoRepository.escolherMedicoAleatorioLivreNaData()`. O retorno dessa chamada será guardado na variável `medicoLivre`.

Quando chamarmos este método para este cenário, o retorno deve ser nulo. Por isso, faremos a assertiva logo abaixo: `assertThat(meidcoLivre).isNull()`. O IntelliJ nos indica que não encontrou o `assertThat`. Colocaremos o cursor sobre ele e pressionaremos "ALT + Enter".

Em seguida, selecionaremos a opção "_Import static method_". Aparecerá uma lista de métodos `assertThat` para importar. Escolheremos a opção que vem do pacote "**org.assertJ.core.api**", vindo da classe "**Assertions.assertThat**".

Por enquanto, ele nem está compilando, pois o método `escolherMedicoAleatorioLivreNaData()` precisa de dois parâmetros: a especialidade e a data. Como especialidade, passaremos o parâmetro `Especialidade.CARDIOLOGIA`.

Quanto à data, não podemos pegar a data atual para ser parâmetro do método, pois cada vez que o teste rodar, teremos um dia diferente e, consequentemente, o comportamento do teste também será distinto.

Por isso, criaremos uma variável chamada `proximaSegundaAs10`. Na linha de cima, definiremos essa variável como `var proximaSegundaAs10 = LocalDate.now(). with(TemporalAdjusters.next(DayofWeek.MONDAY))`. Com isso, a próxima segunda-feira é calculada com base na data atual. Em seguida, passamos a hora usando o `.atTime(10, 0)`, indicando que a hora é 10 horas da manhã.

```typescript
@Test
@DisplayName("Deveria devolver null quando unico medico cadastrado nao esta disponivel na data")
void escolherMedicoAleatorioLivreNaDataCenario1() {
    var proximaSegundaAs10 = LocalDate.now()
                    .with(TemporalAdjusters.next(DayOfWeek.MONDAY))
                    .atTime(10, 0);
     var medicoLivre = medicoRepository.escolherMedicoAleatorioLivreNaData(Especialidade.CARDIOLOGIA, proximaSegundaAs10);
     assertThat(medicoLivre).isNull();
```

Poderíamos rodar o teste agora, mas como fica o banco de dados? Anteriormente, definimos que que o banco usado será o mesmo da aplicação, mas com um _database_ específico para os testes. O Flyway roda as migrations e cria todas as tabelas normalmente no banco de testes, mas este está vazio.

Essa é outra desvantagem desse tipo de teste automatizado: todas as informações que precisam estar previamente cadastradas no banco de dados devem ser feitas manualmente.

Assim, antes de fazer a chamada para o método `escolherMedicoAleatorioLivreNaData()`, precisaremos cadastrar um médico, um paciente e uma consulta no banco de dados, pois são essas as informações necessárias para esse cenário.

```csharp
// Trecho de código suprimido

var medico =
var paciente =
var consulta =

// Trecho de código suprimido
```

No entanto, precisamos de um método para cadastrar cada uma dessas informações (médico, paciente e consulta). Poderíamos injetar o `pacienteRepository` e o `consultaRepository` na classe, mas também é possível usar outra abordagem: usar o Entity Manager da própria JPA.

```java
@Autowired
private TestEntityManager em;
```

Criaremos um novo atributo anotado com `@Autowired` e usaremos o `TestEntityManager`, usado especificamente para testes automatizados. Em seguida, usaremos o Entity Manager para salvar o médico, o paciente e a consulta.

Uma boa prática é organizar o código de teste com **métodos privados**. Assim, não deixamos o cenário de testes muito longo. Além disso, essas informações precisarão ser usadas em outros cenários de teste. Logo, os métodos privados contêm informações reutilizáveis.

```typescript
private void cadastrarConsulta(Medico medico, Paciente paciente, LocalDateTime data) {
    em.persist(new Consulta(null, medico, paciente, data));
}

private Medico cadastrarMedico(String nome, String email, String crm, Especialidade especialidade) {
    var medico = new Medico(dadosMedico(nome, email, crm, especialidade));
    em.persist(medico);
    return medico;
}

private Paciente cadastrarPaciente(String nome, String email, String cpf) {
    var paciente = new Paciente(dadosPaciente(nome, email, cpf));
    em.persist(paciente);
    return paciente;
}

private DadosCadastroMedico dadosMedico(String nome, String email, String crm, Especialidade especialidade) {
    return new DadosCadastroMedico(
            nome,
            email,
            "61999999999",
            crm,
            especialidade,
            dadosEndereco()
    );
}

private DadosCadastroPaciente dadosPaciente(String nome, String email, String cpf) {
    return new DadosCadastroPaciente(
            nome,
            email,
            "61999999999",
            cpf,
            dadosEndereco()
    );
}

private DadosEndereco dadosEndereco() {
    return new DadosEndereco(
            "rua xpto",
            "bairro",
            "00000000",
            "Brasilia",
            "DF",
            null,
            null
    );
}
```

Os métodos acima servem para criar os DTOs que representam o médico, o paciente e a consulta, além de métodos para salvá-los no banco de dados usando o Entity Manager.

Voltando ao cenário de teste, chamaremos `cadastrarMedico` na linha `var medico =`. Teremos que passar um nome (`"Medico"`), um e-mail (`"medico@voll.med"`), um CRM (`"123456"`) e a especialidade do médico (`Especialidade.CARDIOLOGIA`).

Faremos algo semelhante com o paciente: chamaremos o método `cadastrarPaciente`, com um nome (`"Paciente"`), um e-mail (`paciente@email.com`) e um CPF (`00000000000`).

Por fim, chamaremos o método para cadastrar a consulta (`cadastrarConsulta`). Os parâmetros são o médico e o paciente que acabamos de cadastrar. A data é a próxima segunda-feira, às 10h da manhã (`proximaSegundaAs10`).

```swift
var medico = cadastrarMedico("Medico", "medico@voll.med", "123456", Especialidade.CARDIOLOGIA);
var paciente = cadastrarPaciente("Paciente", "paciente@email.com", "00000000000");
cadastrarConsulta(medico, paciente, proximaSegundaAs10);
```

Com isso, fizemos as chamadas e cadastramos tudo no banco de dados. Não precisamos guardar o `consulta` em uma variável, então podemos excluir o `var consulta =` que estava presente no código anteriormente.

Terminamos assim o primeiro cenário de teste. Essa parte é mais extensa porque exige toda a configuração e a criação de métodos privados que serão reaproveitados nos próximos testes. No entanto, o processo será mais rápido do segundo cenário em diante.

Agora, executaremos o teste. Podemos fazer isso clicando em um ícone em forma de seta verde que aparece na lateral esquerda da interface, ao lado da linha que define a assinatura do método (linha 35). A segunda opção é clicando com o botão direito do mouse sobre a classe e selecionando "_Run_".

Perceba pelo Console que ele sobe o servidor e o Spring. Além disso, o `insert` do médico, do paciente e da consulta foram feitos. Em seguida, chamamos o método para fazer a consulta de um médico aleatório livre naquele horário e o teste foi realizado com sucesso. Então, essa consulta devolveu um número.

Um fator importante em testes de Repository: todos os registros que inserimos serão apagados ao fim da execução do método para que um método de teste não interfira nos demais. Assim, cada método de teste roda de maneira isolada.

Esse é o comportamento padrão do Spring: com o término de um teste, ele faz o _rollback_ automaticamente. Assim, quando um novo teste rodar, o banco de dados estará zerado.

Criado o primeiro cenário de teste, fica mais fácil criar os demais. Agora, faremos o cenário `"Deveria devolver medico quando ele estiver disponível na data"`. Nesse cenário, temos um médico cadastrado, mas ele está livre para fazer a consulta. Podemos manter a mesma data (`proximaSegundaAs10`).

Criaremos um médico no banco de dados. Porém, não precisamos cadastrar paciente nem consulta. Podemos apagar as duas linhas que dizem respeito a elas.

Já o `assert` desse cenário não deve ser nulo, em vez disso, substituiremos o `.isNull()` por `isEqualTo(medico)`, ou seja, deve ser igual ao médico cadastrado anteriormente.

O médico está cadastrado e será guardado em uma variável. Quando fizermos a consulta para escolher o médico livre aleatoriamente, é o `medicoLivre` que deve vir como resultado, já que é o único livre na data.

```typescript
@Test
@DisplayName("Deveria devolver medico quando ele estiver disponivel na data")
void escolherMedicoAleatorioLivreNaDataCenario2() {
     var proximaSegundaAs10 = LocalDate.now()
                    .with(TemporalAdjusters.next(DayOfWeek.MONDAY))
                    .atTime(10, 0);
    var medico = cadastrarMedico("Medico", "medico@voll.med", "123456", Especialidade.CARDIOLOGIA);

    var medicoLivre = medicoRepository.escolherMedicoAleatorioLivreNaData(Especialidade.CARDIOLOGIA, proximaSegundaAs10);
    assertThat(medicoLivre).isEqualTo(medico);
}
```

Percebeu como é rápido criar os demais cenários? Agora, clicaremos com o botão direito na classe e selecionaremos "_Run_" para rodar o teste. Ao fim do processo, observaremos que o teste foi realizado com sucesso.

Os métodos de teste geralmente são divididos em três blocos: uma primeira parte chamada de "**given**" ou "**arrange**", uma segunda parte chamada "**when**" ou "**act**" e, por fim, "**then**" ou "**assert**".

Elas servem para indicar que "dado que" temos tais dados, "quando" dispararmos alguma ação, "este" é o resultado esperado. Estas são as três partes de um teste: aquela em que cadastramos as informações, a em que executamos a ação que desejamos testar e aquela em que verificamos se o resultado é o esperado.

Feito isso, conseguimos finalizar o nosso teste do Repository. Por enquanto, estamos testando só um método, o `escolherMedicoAleatorioLivreNaData()`. Testamos só dois cenários, mas existem outros. Esse será o seu desafio: implementar os próximos cenários possíveis.

Com isso, aprendemos a fazer o teste automatizado de uma interface Repository do Spring, usando o Spring Boot, as anotações de teste do Spring e a estratégia de usar o mesmo banco de dados da aplicação com um _dabatase_ distinto.

Na sequência, aprenderemos a testar os Controllers para fazer o teste da API.

-----------------------------------------------------------------------
# Testando erro 400
## Transcrição

Já criamos o teste da interface Repository. O próximo componente que vamos aprender a testar no curso é o **Controller**, outro tipo de classe que costumamos utilizar em projetos com o Spring Boot.

É uma classe importante a ser testada, pois o Controller representa a interface de entrada na nossa API, ou seja, todas as requisições feitas por clientes na API passam pelo Controller.

O objetivo dele é chamar as classes que vão executar as regras de negócio, a persistência, e devolver algum resultado para clientes. Precisamos garantir que essa chamada e esse retorno (o JSON, o código HTTP) estão funcionando conforme o esperado.

# Testando erro 400

Com o projeto aberto, veja que temos várias classes Controller, sendo uma delas `ConsultaController`, contendo somente o método para fazer o agendamento de consultas. É esse método que testaremos utilizando o Spring Boot.

```kotlin
@RequestMapping("consultas")
@SecurityRequirement(name = "bearer-key")
public class ConsultaController {

    @Autowired
    private AgendaDeConsultas agenda;

    @PostMapping
    @Transactional
    public ResponseEntity agendar(@RequestBody @Valid DadosAgendamentoConsulta dados) {
        var dto = agenda.agendar(dados);
        return ResponseEntity.ok(dto);
    }

}
```

Com o método `agendar()` selecionado, vamos utilizar o atalho "Alt + Insert" para abrir a janela "_Generate_". Escolheremos a penúltima opção "_Test_..." e será aberta uma tela para confirmar as informações do teste que será criado. Com tudo preenchido corretamente, clicamos em "OK" para criar a classe `ConsultaControllerTest` em "test > java", no pacote "Controller":

```java
package med.voll.api.controller;

import static org.junit.jupiter.api.Assertions.*;

class ConsultaControllerTest {

}
```

Feito isso, **como testar um Controller**?

Lembre-se de que não se trata mais de um Repository, então não vamos mais utilizar a notação `@DataJpaTest`, e sim a `@SpringBootTest` em cima da classe. Essa é a notação utilizada quando queremos subir o contexto completo do Spring para fazer a simulação da nossa classe Controller.

```java
package med.voll.api.controller;

import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ConsultaControllerTest {

}
```

Agora, o esquema é o mesmo de antes: queremos testar o método `agendar()`, então vamos começar criando um método de teste: `void agendar_cenario1()`. Acima do método, colocamos a notação `@Test` seguida da notação `@DisplayName` para descrever melhor o cenário de teste.

> Existem vários cenários de teste possíveis; o que incluímos no código abaixo será o primeiro deles.

```less
// Trecho de código suprimido

@SpringBootTest
class ConsultaControllerTest {

    @Test
    @DisplayName()
    void agendar_cenario1() {
    
    }

}
```

## Cenário de teste

A nossa API está usando _Bean Validation_, então se chega uma requisição com dados inválidos, ela deve devolver o código **400**. Queremos que esse seja o nosso cenário de teste, então definimos isso na notação `@DisplayName`:

```less
// Trecho de código suprimido

    @Test
    @DisplayName("Deveria devolver codigo http 400 quando informacoes estao invalidas")
    void agendar_cenario1() {
    
    }

}
```

Feito isso, surge a seguinte questão:

> **Como iremos chamar o Controller?** Será parecido com o teste do Repository? Precisaremos declarar um atributo `Controller` e fazer a injeção de dependências? Chamar diretamente o método `agendar()`?

Nesse caso, há algumas diferenças. No teste do Controller, não injetamos o Controller. Lembre-se de que ele é chamado quando cai uma requisição na nossa API, ou seja, quando disparamos uma requisição do navegador, do _Insomnia_, ou de alguma ferramenta que irá chamar a API.

Dito isso, o processo será relativamente parecido: precisaremos simular uma requisição na nossa API.

Existem duas estratégias possíveis para escrever esse teste:

1. Podemos de fato subir um servidor web e disparar uma requisição real, utilizando a classe **RestTemplate**;
    
2. Ou podemos fazer um teste de unidade utilizando o **mock**. Nesse caso, não subimos um servidor de verdade; nós simulamos uma requisição e avaliamos como o Controller irá reagir, isto é, como ele irá receber a requisição e o que será devolvido.
    

A primeira abordagem, e também a mais cara, é o **teste de integração**, em que vamos disparar uma requisição de verdade. Como consequência, a API realmente utilizará o Repository, o Service, e acessará o banco de dados. Logo, será um teste bastante **lento** e pesado.

Na segunda abordagem, chamada **teste de unidade**, faremos um mock do Repository e do Service, pois não queremos chamá-los, uma vez que já existem testes para esses componentes. Queremos testar o Controller de maneira unitária, isolada do restante do projeto. O objetivo é apenas validar se o Controller está fazendo o que deveria ser feito, sem interferência dos outros componentes.

Temos, então, duas abordagens diferentes e não há certo ou errado! O que existem são **vantagens** e **desvantagens**.

Para esse curso, escolheremos a segunda opção: faremos um teste de unidade, pois a ideia é testar apenas o Controller de maneira isolada.

## Teste de unidade

Como disparar uma requisição para o Controller, sendo que não há uma requisição real, mas um **mock**?

Há uma classe do Spring utilizada para isso chamada `MockMvc`; vamos declará-la como atributo (`mvc`) e inserir a notação `@Autowired` acima dele. O nome é bastante óbvio: a classe `MockMvc` simula requisições http usando o padrão `mvc`.

Para conseguirmos injetar o `MockMvc` na classe `ConsultaControllerTest`, além da notação `@SpringBootTest` acima da classe, precisamos da notação `@AutoConfigureMockMvc`.

```less
// Trecho de código suprimido

@SpringBootTest
@AutoConfigureMockMvc
class ConsultaControllerTest {

    @Autowired
    private MockMvc mvc;

    @Test
    @DisplayName("Deveria devolver codigo http 400 quando informacoes estao invalidas")
    void agendar_cenario1() {
    
    }

}
```

Agora, vamos disparar a requisição: basta utilizar o `MockMvc` e declarar o método `perform()`. Esse método irá performar uma requisição na nossa API.

Entre os parênteses, teremos vários métodos estáticos, como GET, POST, PUT, DELETE. Um dos métodos que queremos chamar do nosso Controller é o `agendar()`, um método POST (`@PostMapping`). Vamos então chamar o método estático POST em `perform()`, abrir e fechar parênteses.

```less
// Trecho de código suprimido

    @Test
    @DisplayName("Deveria devolver codigo http 400 quando informacoes estao invalidas")
    void agendar_cenario1() {
        mvc.perform(post());
    }

}
```

> A princípio, haverá um erro de compilação e o POST não será encontrado. Para solucionar o problema, utilizamos o atalho "Alt + Enter" e escolhemos a opção "_Import static method..._" ("Importar método estático").
> 
> Feito isso, aparecerão três opções de importação. Importaremos a última delas, `MockMvcRequestBuilders.post` (uma vez que estamos utilizando o `MockMvc`).

No método POST, precisamos passar um parâmetro com a URL que queremos chamar, no caso, "/consultas", a mesma URL configurada no nosso Controller. Com isso, pedimos para que o `mvc` performe uma requisição via método POST para o endereço "/consultas".

```csharp
// Trecho de código suprimido

void agendar_cenario1() {
    mvc.perform(post("/consultas"));
}
```

Na sequência, queremos o retorno, pois precisamos guardar o que será devolvido. Para isso, chamamos o método `.andReturn()` para pegar o retorno, seguido do método `.getResponse()`. Guardaremos isso em uma variável chamada `response`.

```csharp
// Trecho de código suprimido

void agendar_cenario1() {
    var response = mvc.perform(post("/consultas"))
            .andReturn().getResponse();
}
```

A ideia é chamar o `response`, pois precisamos guardá-lo em algum lugar.

No entanto, houve um erro de compilação. Posicionando o cursor sobre o método `perform()`, vemos o aviso de que existe uma exceção não tratada.

Esse método pode lançar uma exceção; como não queremos fazer o tratamento dela, vamos colocar um `throws` na assinatura do método. Com o cursor posicionado sobre `perform()`, teclamos "Alt + Enter"; será sugerida como primeira opção "_Add exception to method signature_" ("Adicionar exceção à assinatura do método").

```csharp
// Trecho de código suprimido

void agendar_cenario1() throws Exception {
    var response = mvc.perform(post("/consultas"));
            .andReturn().getResponse();
}
```

Com as duas últimas linhas de código do bloco acima, conseguimos disparar uma requisição com o Controller e guardamos o `response` em uma variável.

## Assertiva

Agora, faremos a assertiva: vamos verificar se o _status code_ é o 400, pois disparamos a requisição, mas não levamos nenhum corpo nela.

A requisição está sem nenhum parâmetro, mas lembre-se que, na requisição de agendar uma consulta, o médico é opcional, enquanto o paciente e a data são obrigatórios.

Como não estamos levando nem o ID e nem a data, deveria ser retornado "**erro 400**". Primeiramente, faremos os _asserts_ disso.

Após disparar a requisição, vamos declarar o método `assertThat()` e importar o _static_ da mesma forma que fizemos anteriormente, com o atalho "Alt + Enter". Nesse caso, selecionamos a penúltima opção `Assertions.assertThat`, que vem do pacote `org.assertj.core.api`.

Entre parênteses, colocaremos `response.getStatus()` seguido de `isEqualTo()`, onde iremos passar o 400. Para fazer isso, utilizaremos a classe utilitária do Spring `HttpStatus`, do pacote `org.springframework.http`. Feito isso, acrescentamos a constante `BAD_REQUEST` seguida do método `value()`

```csharp
// Trecho de código suprimido

var response = mvc.perform(post("/consultas"));
        .andReturn().getResponse();

assertThat(response.getStatus()).isEqualTo(HttpStatus.BAD_REQUEST.value());
```

Dessa forma, será retornado o código **400**.

O bloco de código acima é o método utilizado para testar o código 400: primeiro, é disparada uma requisição para o endereço "/consultas" via método POST, sem levar nenhum corpo; na sequência, jogamos o resultado (`.andReturn()`) e o `getResponse()` em uma variável e verificamos se o status do `response` é 400, pois nesse cenário, esse é o erro que deve acontecer.

Finalizado o nosso teste, podemos rodá-lo clicando com o botão direito sobre a classe `ConsultaControllerTest` e selecionando a opção "_Run_". Perceba que o Spring sobe o servidor, mas não é disparada uma requisição de verdade, e sim um mock.

Nesse caso, o meu teste falhou: temos a informação de que era esperado o erro 400, mas foi retornado o erro 403.

```yaml
org.opentest4j.AssertionFailedError:
expected: 400
 but was: 403
Expected :400
Actual   :403
```

Isso acontece devido ao _Spring Security_. Para fazer o agendamento pela URL, precisamos estar logados, e não fizemos isso nesse teste.

Você pode argumentar o seguinte: nesse teste, não estamos testando segurança, autenticação e autorização. Dito isso, vamos considerar que foi feito o login, para testar a chamada da API independentemente de estarmos ou não logados.

#### Como informar à Spring que a autenticação deve ser ignorada?

Acima do método, além das notações `@Test` e `@DisplayName`, colocaremos uma terceira notação do Spring: `@WithMockUser`.

```java
// Trecho de código suprimido

@Test
@DisplayName("Deveria devolver codigo http 400 quando informacoes estao invalidas")
@WithMockUser
void agendar_cenario1() throws Exception {
    var response = mvc.perform(post("/consultas"));
            .andReturn().getResponse();

    assertThat(response.getStatus()).isEqualTo(HttpStatus.BAD_REQUEST.value());
}
```

Essa notação serve para indicar ao Spring que deve ser feito o mock de uma pessoa usuária, considerando para o Spring Security que estamos logados ao executar o teste.

> Caso queira chamar um método com autenticação, mas sem passar a pessoa usuária e fazer um teste de segurança, use essa notação para que o Spring simule um login.

Feito isso, salvamos e rodamos novamente conforme fizemos antes, e o erro 400 será retornado.

# Conclusão

Implementamos um cenário de teste, porém, esse foi o cenário mais fácil, onde não precisamos lidar com o JSON. Nós não passamos um JSON na requisição e nem verificamos um JSON na resposta. O teste do erro 400 é bastante tranquilo!

E se quisermos testar o cenário correto, onde passamos o JSON, temos o ID do médico, do paciente, a data, para verificar se o JSON devolvido está correto?

**Na sequência aprenderemos a fazer esse teste!**


-----------------------------------------------------------------------
# Testando código 200
## Transcrição

Já criamos o cenário do erro 400, e agora simularemos o do **código 200** devolvido pela API quando fazemos o agendamento, enviamos o JSON com as informações corretas e o recebemos de volta com o detalhamento.

Em `ConsultaControllerTest.java` em que já temos o primeiro cenário `@Test`, bastará copiarmos e colarmos em seguida para fazermos as alterações dos próximos cenários.

Primeiro, renomearemos o método de agendamento para `agendar_cenario2()` e o conteúdo de `@DisplayName()` para `"Deveria devolver código http 200 quando informações estão válidas"`.

Já o `assertThat()` com `response.getStatus()` não será mais `BAD_REQUEST`, e sim `OK` para devolver o código 200. Porém, neste método, precisaremos levar um JSON válido.

Para isso, o `.perform()` recebe como parâmetro `post()` em que passaremos `.content()` para levarmos o JSON. Poderemos escrever via _string_ fazendo o desenho manualmente, o que não é recomendável porque é muito trabalhoso, ou poderemos usar uma classe do Spring para tornarmos a criação do JSON mais fácil.

Antes disso, precisaremos chamar o `.contentType()` para levarmos o cabeçalho HTTP que indica o envio de dados no formato JSON. Isso era feito automaticamente no Insomnia, mas aqui teremos que fazer manualmente. Dentro dos parâmetros, passaremos como parâmetro a classe `MediaType` do Spring que vem do pacote `org.springframework.http`, seguido de `.APPLICATION_JSON`.

Injetaremos mais uma classe utilitária além de `MockMvc` chamada `private JacksonTester<>` que possui os _generics_ com o tipo de objeto que irá trabalhar. Em nosso caso, deverá ser do mesmo tipo `DadosAgendamentoConsulta` recebido no método `agendar()` do `ConsultaController`.

Copiaremos essa classe e a adicionaremos dentro do _generics_ de `JacksonTester<>`. Em seguida, chamaremos o atributo `dadosAgendamentoConsultaJson`.

Duplicaremos esse atributo porque precisaremos de dois JSONs, o que chega na API e o que é devolvido por ela. Nesse segundo, o que chegará será o _generics_ `DadosDetalhamentoConsulta` e o atributo será `dadosDetalhamentoConsultaJson`.

```swift
//trecho de código suprimido

class ConsultaControllerTest {

    @Autowired
    private MockMvc mvc;
    
    @Autowired
    private JacksonTester<DadosAgendamentoConsulta> dadosAgendamentoConsultaJson;

    @Autowired
    private JacksonTester<DadosDetalhamentoConsulta> dadosDetalhamentoConsultaJson;

//trecho de código suprimido

}
```

Se voltarmos ao `ConsultaController.java`, bastará observarmos que o método `agendar()` recebe o `DadosAgendamentoConsulta` mas devolve outro `dto`, que é o `DadosDetalhamentoConsulta`.

Portanto, em nosso teste, deveremos ter os dois `JacksonTester<>` para simularmos o JSON de entrada e o de saída que é devolvido.

De volta ao nosso teste, dentro de `.content()`, passaremos `dadosAgendamentoConsultaJson` com `.write()` recebendo o objeto `new DadosAgendamentoConsulta`, onde passaremos a identificação de um médico e um paciente, como `2l` e `5l` por exemplo.

Também precisaremos passar uma data e a especialidade. Traremos para as variáveis antes de `response`, em que `var data` será igual a `LocalDateTime.now()`.

A data pode ser atual porque estamos chamando o _controller_ diretamente, então não faremos validação, apenas mudaremos o horário com `.plusHours(1)` para adicionarmos uma hora a mais, esclarecendo que é uma data no futuro.

Em uma nova linha seguinte, criaremos a `var especialidade` sendo igual a `Especialidade.CARDIOLOGIA` por exemplo.

No momento de instanciarmos `DadosAgendamentoConsulta`, passaremos os `id`s do médico, do paciente, a `data` e a `especialidade`.

Porém, não poderemos passar `.write()` direto para `.content()`, pois bis devolve outro tipo de objeto. Portanto, logo após seu parêntese de fechamento, chamaremos `.getJson()` para converter para uma _string_ JSON.

O objeto do `JacksonTester<>` pega o que passamos como parâmetro e converte para o JSON no formato _string_ sem precisarmos criar manualmente.

```java
// Trecho de código suprimido

@Test
@DisplayName("Deveria devolver codigo http 200 quando informações estão validas")
@WithMockUser
void agendar_cenario2() throws Exception {
    var data = LocalDateTime.now().plusHours(1);
    var especialidade = Especialidade.CARDIOLOGIA;
    var response = mvc
        .perform(
            post("/consultas")
                .contentType(MediaType.APPLICATION_JSON)
                .content(dadosAgendamentoConsultaJson.write(
                    new DadosAgendamentoConsulta(2l, 5l, data, especialidade)
                ).getJson())
        )
        .andReturn().getResponse);

    assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
}
```

Já fizemos a requisição, levamos o cabeçalho `contentType()` e o JSON criado pelo `JacksonTester<>`.

Nas assertivas `assertThat()`, estamos apenas verificando se o código HTTP está vindo como 200. Mas além disso, deveremos checar se o JSON que está vindo é o que estamos esperando.

Criaremos uma variável `jsonEsperado` sendo igual a `dadosDetalhamentoConsultaJson` com `.write()` recebendo como parâmetro o `new DadosDetalhamentoConsulta()`.

Essa classe receberá um objeto do tipo `Consulta` ou as identificações da consulta, do médico, do paciente e da data.

O `id` da consulta, como não chamaremos banco de dados, não receberemos um identificador certo, então a princípio passaremos nulo.

Já a identificação do médico deverá ser o `2l`, do paciente `5l`, seguida da mesma `data`. Após a criação do objeto, aplicaremos `.getJson()` para devolvermos um JSON.

Na linha seguinte, chamaremos o `assertThat()` contendo `response.getContentAsString()` para termos o conteúdo como _string_. Depois, aplicaremos `isEqualTo(jsonEsperado)`.

```csharp
// Trecho de código suprimido

assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
var jsonEsperado = dadosDetalhamentoConsultaJson.write(
        new DadosDetalhamentoConsulta(null, 2l, 5l, data))
        .getJson();

assertThat(response.getContentAsString()).isEqualTo(jsonEsperado);
```

Rodaremos esse teste e aguardaremos acabar a execução.

Teremos um erro indicando que o `Jacksontester<>` não foi encontrado, pois para podermos injetá-lo, é preciso ter uma outra anotação em cima da classe chamada `@AutoConfigureJsonTesters`.

```less
//trecho de código suprimido

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureJsonTesters
class ConsultaControllerTest {

//trecho de código suprimido

}
```

Rodando novamente, não teremos um erro porém o teste irá falhar.

Fez o `select` do banco de dados e disparou a consulta, mas não é isso que queríamos, pois queremos acessar somente o _controller_ de maneira isolada, e por isso falhou.

Faltou indicarmos ao Spring que não use o banco de dados de verdade. Em `ConsultaController.java`, veremos que está injetando a classe `AgendaDeConsultas` que está acessando o _database_.

Para pedirmos um _mock_ deste objeto, voltaremos à classe de teste e declararemos mais um atributo `private AgendaDeConsultas agendaDeConsultas` e, em cima dele, colocaremos a anotação `@MockBean`.

Com isso, diremos ao Spring que, quando precisar injetar este objeto no _controller_, deve aplicar o _mock_, e não injetar uma `agendaDeConsultas` de verdade.

```swift
//trecho de código suprimido

class ConsultaControllerTest {

    @Autowired
    private MockMvc mvc;
    
    @Autowired
    private JacksonTester<DadosAgendamentoConsulta> dadosAgendamentoConsultaJson;

    @Autowired
    private JacksonTester<DadosDetalhamentoConsulta> dadosDetalhamentoConsultaJson;
    
    @MockBean
    private AgendaDeConsultas agendaDeConsultas;

//trecho de código suprimido

}
```

Salvaremos e rodaremos o teste novamente.

Veremos que não disparou o `select` e não foi ao banco de dados, porém o teste falhou de novo. O retorno diz que o JSON devolvido deveria ser a identificação nula, a do médio `2` e a do paciente `5`, além da data atual, mas o que chegou foi um JSON vazo `""`. Então, por algum motivo, não devolveu nada, ou seja, veio o código `200` mas o corpo chegou vazio.

Isso aconteceu porque, em nosso _controller_, chamamos a `agenda.agendar()`, mas nosso `agenda` é um _mock_, que por padrão devolve nulo.

Então, nosso `dto` está nulo, e no momento de fazermos a conversão, esse `dto` devolvido pelo Spring é `null`.

É um _mock_ mas precisaremos simular dizendo que, quando o método `agendar()` for disparado, devolveremos as informações `dados`.

Para fazermos essa configuração, voltaremos ao arquivo de teste e, antes de dispararmos a requisição de fato, usaremos o `Mockito`, que é a biblioteca de _mocks_ que o Spring usa por "debaixo dos panos".

Após `var especialidade` e antes de `var response`, chamaremos os métodos `when()` e faremos o `import` automático da biblioteca. Então, quando o `agendaDeConsultas.agendar()` for chamado, teremos o `thenReturn()` para retornarmos o `new DadosDetalhamentoConsulta()` esperado.

Mais adiante, em `jsonEsperado`, recortaremos a linha de `new DadosDetalhamentoConsulta()` e escreveremos `dadosDetalhamento`, a qual será passada no `thenReturn()`.

Em seguida, jogaremos isso em uma nova variável chamada `dadosDetahamento` sendo igual a `new DadosDetalhamentoConsulta()` com `null, 2l, 5l, data`.

No `when()`, o conteúdo de `.thenReturn()` será apenas `dadosDetalhamento`.

Portanto, quando a `agenda` que é o _mock_ tiver o método `.agendar()` chamado, não importará o parâmetro para devolver os dados.

Com isso, iremos disparar a requisição e, por fim, verificaremos se o JSON devolvido é igual ao objeto esperado.

```java
// Trecho de código suprimido

@Test
@DisplayName("Deveria devolver codigo http 200 quando informações estão validas")
@WithMockUser
void agendar_cenario2() throws Exception {
    var data = LocalDateTime.now().plusHours(1);
    var especialidade = Especialidade.CARDIOLOGIA;

    var dadosDetalhamento = new DadosDetalhamentoConsulta(null, 2l, 5l, data);
    when(agendaDeConsultas.agendar(any())).thenReturn(dadosDetalhamento);

    var response = mvc
        .perform(
            post("/consultas")
                .contentType(MediaType.APPLICATION_JSON)
                .content(dadosAgendamentoConsultaJson.write(
                    new DadosAgendamentoConsulta(2l, 5l, data, especialidade)
                ).getJson())
        )
        .andReturn().getResponse();

    assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
    
    var jsonEsperado = dadosDetalhamentoConsultaJson.write(
        dadosDetalhamento
    ).getJson();

    assertThat(response.getContentAsString()).isEqualTo(jsonEsperado);
}
```

Rodaremos o teste e conseguiremos passá-lo com sucesso.

Já conseguimos acessar este segundo cenário, mas se tivermos outros, a ideia seria a mesma copiando, colando e adaptando para os demais.

Estamos rodando todos os testes de maneira isolada, mas para rodarmos todos os que existem no projeto, abriremos o menu lateral com a lista de arquivos à esquerda, clicaremos em "src > test > java" com o botão direito do mouse, e escolheremos a opção "Run 'all Tests'".

Desta forma, rodaremos todos os testes de todos os pacotes. No momento, temos quatro métodos de teste e todos estão passando corretamente, ou seja, na API está devolvendo o resultado esperado e as consultas dos objetos esperados.

Mas o ideal é que haja um teste para cada cenário possível.

Nesta aula, aprendemos a fazer testes de unidade usando JUnit, os recursos do SpringBoot, Mockito e AssertJ para facilitar a escrita das assertivas para fazermos testes automatizados no projeto com Spring dos componentes.

A seguir, conheceremos outros recursos do _framework_ que poderemos utilizar.


-----------------------------------------------------------------------
Build com Maven

## Transcrição

Já implementamos testes automatizados e vamos considerar que terminamos o projeto. Ao terminar o projeto completo ou parte dele, queremos disponibilizá-lo no ar. Surge, então, a seguinte questão:

> **Como disponibilizar um projeto?**

# _Build_ do projeto

Até então, executávamos o projeto apenas localmente, no próprio computador onde rodamos a aplicação, o banco de dados e os testes. No entanto, para disponibilizar esse projeto, precisamos hospedá-lo em algum servidor, seja ele interno da empresa ou algum serviço na nuvem, como o _Amazon_, o _Google Cloud_ e o _Azure_.

A ideia é gerar o _build_ do nosso projeto e disponibilizá-lo para ser executado em algum servidor. Além disso, precisaremos fazer alguns **ajustes** na nossa aplicação antes de hospedá-la.

O principal ajuste a ser feito está relacionado ao **banco de dados**. As configurações do banco de dados da nossa aplicação ficam no arquivo `application.properties`; vamos abri-lo em "src > main > resources".

```ini
spring.datasource.url=jdbc:mysql://localhost/vollmed_api
spring.datasource.username=root
spring.datasource.password=root

spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true

server.error.include-stacktrace=never

api.security.token.secret=${JWT_SECRET:12345678}
```

> Nessa pasta, além do `application.properties`, temos o `application-test.properties`, configurado apenas para sobrescrever o banco de dados da aplicação durante a execução dos testes.
> 
> ```ini
> spring.datasource.url=jdbc:mysql://localhost/vollmed_api_test
> ```

Em `application.properties`, temos as configurações do banco de dados que apontam para "localhost". Com isso, dizemos para o Spring que o banco de dados está rodando na própria máquina e a _database_ se chama "vollmed_api"; a pessoa usuária do banco de dados é "root"; e a senha do banco de dados é "root".

Essas são as configurações **fixas** do banco de dados, porém, elas funcionam apenas localmente. Pode ser que no servidor onde vamos disponibilizar o projeto, o banco de dados fique em outro computador, ou seja, pode ser que existam dois servidores: um para onde ficará a aplicação; e outro para onde ficará o banco de dados.

Logo, o endereço não será "localhost". Queremos **flexibilizar** essas configurações, tanto do endereço do banco de dados quanto da pessoa usuária e da senha, para que possamos sobrescrever, isto é, trocar os parâmetros no ambiente de produção.

Uma das formas de fazer isso é aplicando o conceito de **ambientes**, de **_profiles_**, conforme fizemos para os testes.

> O teste está em outro arquivo (`application-test.properties`). Para o ambiente de produção, podemos criar um terceiro arquivo separado.

## Arquivo `application-prod.properties`

Para criar esse arquivo, vamos selecionar o `application.properties` no painel "_Project_" à esquerda e teclar "Ctrl + C" para copiar. Será aberta uma janela para renomearmos o arquivo; vamos chamá-lo de `application-prod.properties`. Feito isso, teclamos "Enter" para finalizar a ação.

> "Prod" é uma abreviação de "_production_" (**ambiente de produção**).

O carregamento desses arquivos funciona da seguinte maneira: o Spring sempre carrega todas as propriedades do `application.properties`, e se o mandarmos considerar que estamos no ambiente de produção, ele também carrega as propriedades de `application-prod.properties`.

Nesse arquivo, vamos apenas sobrescrever as propriedades desejadas. As que quisermos reaproveitar, não precisam ser duplicadas: deixamos no próprio arquivo `application.properties`.

No caso, queremos sobrescrever a URL do banco de dados, a pessoa usuária, e a senha, além das duas propriedades seguintes: `show-sql` e `format_sql`. Em um ambiente de produção, não queremos gerar log de SQL, então vamos definir essas propriedades como "false".

> A propriedade _stacktrace_ permanecerá como "never" e o _secret_ também não sofrerá alterações, então podemos apagar essas duas linhas de código; elas serão lidas do `application.properties`.

```ini
spring.datasource.url=jdbc:mysql://localhost/vollmed_api
spring.datasource.username=root
spring.datasource.password=root

spring.jpa.show-sql=false
spring.jpa.properties.hibernate.format_sql=false
```

Feito isso, como passar a pessoa usuária, a senha do banco de dados, e a URL do banco de dados? Ainda não sabemos quais serão as propriedades e não é interessante deixar isso fixo no código.

> Essa inclusive é uma **prática de segurança**: não devemos expor senhas e outros aspectos de segurança no código fonte da aplicação.

Para resolver esse problema, costumamos usar **variáveis de ambiente**. Nesse caso, a ideia é a seguinte: na propriedade `spring.datasource.url`, vamos digitar `$`, abrir chaves, e passar dentro delas o nome da variável de ambiente (`DATASOURCE_URL`), semelhante ao que fizemos com o _secret_ do JSON Web Token. Faremos o mesmo nas outras duas propriedades, porém na primeira temos a variável `DATASOURCE_USERNAME` e na segunda `DATASOURCE_PASSWORD`.

```ini
spring.datasource.url=${DATASOURCE_URL}
spring.datasource.username=${DATASOURCE_USERNAME}
spring.datasource.password=${DATASOURCE_PASSWORD}

spring.jpa.show-sql=false
spring.jpa.properties.hibernate.format_sql=false
```

Com isso, o Spring sabe que essas três propriedades referenciam variáveis de ambiente. A ideia é que ele procure essas variáveis em um sistema operacional ou em um parâmetro, quando formos executar a aplicação (mais adiante aprenderemos a fazer isso), e substitua nessas propriedades o valor atribuído a elas.

Assim, conseguimos ter mais um arquivo _properties_ exclusivo para o ambiente de produção e sobrescrever apenas o que quisermos. O restante continuará sendo puxado de `application.properties`.

Dessa forma, configuramos nosso banco de dados no ambiente de produção via variáveis de ambiente. Essa é a boa prática!

Agora, fica a seguinte pergunta:

> Uma vez configurado e finalizado o projeto, como gerar o executável dessa aplicação e enviá-lo para ser executado no servidor, seja ele um ambiente _cloud_ ou interno da empresa?

Lembre-se que o nosso projeto está utilizando o **Maven**. Além de gerenciar as dependências do projeto, o Maven serve para gerar o build, isto é, para empacotá-lo.

Podemos fazer isso pelo **IntelliJ**. Primeiramente, vamos abrir a aba "Maven" no canto superior direito do software (onde sempre víamos o campo "_Dependencies_" ao mexer em uma dependência).

Além desse campo, há um pacote chamado "_Plugins_" e a pasta "**_Lifecycle_**" ("Ciclo de vida"). Nesta última, estão todas as fases para as quais o Maven dá suporte, entre elas a fase `package`. Essa é a fase que chamamos no Maven para que ele gere o pacote do nosso projeto, de modo que seja possível executar a aplicação.

Vamos clicar sobre `package` com o botão direito e selecionar a primeira opção, "_Run Maven Build_" ("Executar compilação do Maven"), para rodar o build com esse objetivo específico.

Feito isso, será aberta a aba "_Run_" e o log será gerado. Para empacotar o projeto, é necessário:

- Compilar o código-fonte da aplicação;
- Compilar as classes de teste;
- E executar os testes automatizados.

Se todos os testes estiverem passando corretamente, gera-se o empacotamento. Caso algum teste esteja falhando, é interrompida a execução e não é gerado o pacote da nossa aplicação.

> Logo, o Maven considera que só queremos gerar o build se todos os testes estiverem corretos.

Feito isso, ao final do log, temos a informação de que o build do projeto foi gerado com sucesso e o tempo que o Maven levou para fazer isso.

```css
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time:  8.232 s
```

Nesse momento, temos um arquivo `.jar` do Java para conter o nosso projeto executável. Esse projeto fica em uma pasta criada pelo Maven chamada "target":

```bash
[INFO] Building jar: /home/rodrigo/Desktop/api/target/api-0.0.1-SNAPSHOT.jar
```

Agora, vamos minimizar a aba "Run" e retornar à aba "_Project_" à esquerda. No diretório raiz do nosso projeto API, está a pasta "target"; ao expandi-la, encontramos o arquivo `api-0.0.1-SNAPSHOT.jar`. Esse é o arquivo executável, isto é, o build da nossa aplicação.

> É esse arquivo `.jar` que vamos copiar, transferir para o servidor, e executar a aplicação.

A nomenclatura é definida por padrão, lida do nosso `pom.xml`, correspondendo ao nome do artefato ("api") e à versão _default_ ("0.0.1-SNAPSHOT"), visto que não inserimos nenhuma versão. No entanto, podemos personalizá-la.

# Conclusão

Com isso, aprendemos a gerar o build e empacotar o nosso projeto via Maven no IntelliJ. Além disso, criamos o arquivo `application-prod.properties` para ter as propriedades que serão executadas no ambiente de produção.

Resta a seguinte dúvida:

> Gerado o arquivo `.jar`, como executá-lo no servidor onde faremos o _deploy_, onde vamos colocar a aplicação para rodar em produção?

**Na sequência te respondo isso!**


-----------------------------------------------------------------------
# Executando via terminal
## Transcrição

No vídeo anterior, geramos o build do projeto e o arquivo `.jar` da nossa aplicação. Temos o arquivo `application-prod.properties` no ambiente de produção e as variáveis de ambiente (URL, login e senha do banco de dados) para o _datasource_.

Mas **como rodar o projeto em outro computador**, em um servidor onde quero disponibilizar e fazer o _deploy_ da aplicação?

> Veremos uma **simulação** de como seria o deploy, pois foge do escopo do curso fazê-lo de fato, afinal, ele varia. Se quisermos fazer o deploy na _Amazon_, devemos seguir o processo da plataforma; no _Azure_, o processo é outro; no _Google Cloud_, igualmente.
> 
> Todas as plataformas têm suas configurações e seu jeito específico de trabalhar. Dito isso, a ideia é analisar apenas uma simulação do passo a passo, independentemente de servidor.

# Executando via terminal

Iniciamos com o arquivo `api-0.0.1-SNAPSHOT.jar`. No servidor, copiaríamos esse arquivo, o colocaríamos nele de alguma forma, e o executaríamos via linha de comando, rodando o mesmo comando utilizado para rodar uma aplicação Java, por se tratar de um arquivo `.jar`.

Vamos simular isso no terminal, que pode ser o _prompt_ do seu sistema operacional ou o próprio IntelliJ para facilitar o processo.

No diretório do meu projeto em específico, vemos que ele está na pasta "api" do meu Desktop. Daremos um `ls target` para listar os comandos no diretório **target**.

> Caso esteja no _Windows_, o comando é **dir** em vez de **ls**.

Feito isso, teremos no terminal o arquivo `api-0.0.1-SNAPSHOT.jar`, o executável da nossa aplicação.

```ruby
rodrigo@alura:~Desktop/api$
rodrigo@alura:~Desktop/api$
rodrigo@alura:~Desktop/api$  ls  target/
api-0.0.1-SNAPSHOT.jar           classes            generated-test-sources  maven-status      test-classes
api-0.0.1-SNAPSHOT.jar.original  generated-sources  maven-archiver          surefire-reports
rodrigo@alura:~Desktop/api$
```

#### Como rodar o projeto?

Para fazer isso, basta utilizar o comando **java**. A única coisa que precisamos ter instalada no servidor onde vamos rodar a aplicação é o **Java** na **versão 17**, utilizada nesse curso.

Com o Java instalado, digitamos `java -version` para exibir essas informações no terminal:

```java
// Trecho suprimido

rodrigo@alura:~Desktop/api$  ls  target/
api-0.0.1-SNAPSHOT.jar           classes            generated-test-sources  maven-status      test-classes
api-0.0.1-SNAPSHOT.jar.original  generated-sources  maven-archiver          surefire-reports
rodrigo@alura:~Desktop/api$ java -version
openjdk version "17.0.5" 2022-10-18
OpenJDK Runtime Environment (build 17.0.5+8-Ubuntu-2ubuntu122.04, mixed mode, sharing)
rodrigo@alura:~Desktop/api$
```

O comando para rodar o projeto é composto pelo comando **java**, pelo parâmetro **-jar**, e pelo **caminho do arquivo**:

```bash
java -jar target/api-0.0.1-SNAPSHOT.jar
```

Esse é o comando utilizado para rodar arquivos `.jar`.

> Para incluir o caminho do arquivo, você pode digitar "api" e utilizar a tecla "Tab" para completar automaticamente o nome do arquivo.

```java
// Trecho suprimido

rodrigo@alura:~Desktop/api$ java -version
openjdk version "17.0.5" 2022-10-18
OpenJDK Runtime Environment (build 17.0.5+8-Ubuntu-2ubuntu122.04, mixed mode, sharing)
rodrigo@alura:~Desktop/api$ java -jar target/api-0.0.1-SNAPSHOT.jar
```

Em seguida, teclamos "Enter" para executar. A princípio, a aplicação é inicializada, mas vamos observar o início do log, abaixo da _splash screen_ do Spring. Nas primeiras linhas, temos a mensagem de que a aplicação está sendo iniciada ("_Starting ApiApplication_"), e na segunda linha, temos informações sobre o _profile_.

Não há nenhum profile ativo, logo, será usado o profile "default", ou seja, o Spring irá ler apenas o arquivo `application.properties`.

No entanto, queremos que seja lido o arquivo `application-prod.properties`. Como fazer com que, ao rodar o projeto pela linha de comando, seja considerado "prod" como profile ativo?

Vou parar a aplicação e pressionar seta para cima para listar o último comando. Agora, antes do parâmetro -jar, vamos passar outro parâmetro: `-Dspring.profiles.active=prod`.

```ruby
rodrigo@alura:~/Desktop/api$ ^C
rodrigo@alura:~/Desktop/api$ java -Dspring.profiles.active=prod -jar target/api-0.0.1-SNAPSHOT.jar
```

Assim, passamos o profile ativo no momento de rodar o projeto: basta passar o parâmetro **-D** e o nome do parâmetro que o Spring espera (`spring.profiles.active=prod`). Após o nome do profile, que no meu caso é "prod", vem o parâmetro -jar seguido do caminho do arquivo `.jar`.

Em seguida, vamos teclar "Enter" e rodar novamente. Porém, ocorrerá um erro. Se formos ao início do log, veremos as mensagens de que a aplicação está sendo inicializada e que o profile "prod" está ativo (_The following 1 profile is active: "prod"_).

No entanto, lembre-se de que, no arquivo `application-prod.properties`, dissemos que o URL, o login e a senha do banco de dados deveriam ser puxados de **variáveis de ambiente**. Elas não foram encontradas no sistema operacional, por isso houve uma _Exception_.

> No log, haverá uma mensagem de que não foi possível carregar a parte de _repository_ e de persistência, pois a URL não foi identificada; ela deve ser iniciada com "jdbc", mas por enquanto está sendo utilizado `${}`.
> 
> ```csharp
> Caused by: java.lang.IllegalArgumentException: URL must start with 'jdbc'
> ```

Dito isso, **como passar as variáveis de ambiente?** Da mesma forma que passamos o parâmetro do profile! Com o projeto parado, pressionamos seta para cima e digitaremos o seguinte comando:

```ini
-DDATASOURCE_URL=jdbc:mysql://localhost/vollmed_api`
```

Antes do parâmetro -jar, inserimos novamente o parâmetro -D, substituindo as três variáveis de ambiente. Em cada parâmetro, substituímos uma variável, então primeiramente temos `-DDATASOURCE_URL=`, seguido do endereço do servidor de banco de dados, que pode ser a própria máquina ou o IP de outra máquina.

> Para simular, utilizei o "localhost", pois o banco está no meu próprio computador.

```bash
java -Dspring.profiles.active=prod -DDATASOURCE_URL=jdbc:mysql://localhost/vollmed_api -jar target/api-0.0.1-SNAPSHOT.jar
```

Passamos então a variável da **URL**. Faremos o mesmo processo para as variáveis **USERNAME** e **PASSWORD**. Trata-se das mesmas variáveis configuradas no arquivo `application-prod.properties`.

```bash
java -Dspring.profiles.active=prod -DDATASOURCE_URL=jdbc:mysql://localhost/vollmed_api -DDATASOURCE_USERNAME=root -DDATASOURCE_PASSWORD=root -jar target/api-0.0.1-SNAPSHOT.jar
```

É dessa forma que executamos nosso projeto no servidor, independentemente de qual ele seja: copiamos o arquivo `.jar` e rodamos o comando `java -D`, passando o "prod" em profile, as três variáveis de ambiente (URL, login e senha do banco de dados), e o caminho do `.jar`.

Teclando "Enter", a princípio irá rodar normalmente, ou seja, houve a conexão com o banco de dados local e o projeto foi inicializado em 4 segundos. Retornando ao início do log, vemos que foi lido o profile "prod", isto é, as propriedades desse arquivo.

#### Vamos testar?

No navegador, entraremos na documentação do _Swagger_:

> [http://localhost:8080/swagger-ui.html](http://localhost:8080/swagger-ui.html)

A documentação foi carregada, então o projeto inicializou corretamente.

Perceba que não rodei o projeto pelo IntelliJ, mas pelo terminal (embora ele esteja dentro do IntelliJ). Simulamos como se estivéssemos em um ambiente de produção, então não rodamos o projeto pelo ícone de _play_.

Esse é o processo que deve ser executado no servidor para rodar um projeto com o Spring Boot, independentemente de o servidor utilizado ser um _cloud_ ou interno da empresa:

> Geramos o build de um arquivo `.jar` e, para executá-lo, basta rodar via linha de comando pelo terminal com o comando **java**. Em seguida, passamos as variáveis de ambiente e o profile que queremos executar.

**Simples, não é?!**

No servidor, precisamos de apenas uma coisa instalada: o Java versão 17. Caso queira, uma alternativa é utilizar o _Docker_, mas será necessário configurar o arquivo `Dockerfile` no projeto e ter o Docker instalado no servidor; ele criará um _container_ com o java e todas as dependências do projeto.

# Conclusão

Conforme dito anteriormente, nossa ideia era mostrar como funciona o **processo**, e não realizar o deploy propriamente dito, afinal, cada ambiente cloud, cada servidor, funciona de um jeito diferente.

Na Alura, temos cursos de _AWS_, de _Azure_, de _Google Cloud_, caso tenha interesse em aprender a usar esses servidores. Posteriormente, você pode utilizar esse projeto para tentar fazer o deploy no servidor.

> **Observação:** o banco de dados não necessariamente estará rodando dentro do mesmo servidor. Pode ser que você configure em outro servidor; nesse caso, a URL do banco de dados não seria "localhost" como no exemplo exibido anteriormente, mas sim o endereço IP do servidor onde você instalou uma SQL.
> 
> Nas variáveis USERNAME e PASSWORD, provavelmente não usaríamos "root" e "root", pois é uma senha insegura. O ideal é gerar _username_ e senha aleatórios, então passaríamos os parâmetros conforme a instalação do servidor onde está rodando o MySQL.

Com isso, aprendemos:

- A gerar o build de uma aplicação com o Spring Boot, utilizando o Maven e gerando o arquivo `.jar`;
- E a simular o processo de deploy, rodando via linha de comando e passando variáveis de ambiente.

Espero que você tenha aprendido e gostado do curso! Na sequência, continuaremos com algumas considerações finais.

-----------------------------------------------------------------------
# Para saber mais: build com arquivo .war
Projetos que utilizam o Spring Boot geralmente utilizam o formato **jar** para o empacotamento da aplicação, conforme foi demonstrado ao longo desta aula. Entretanto, o Spring Boot fornece suporte para o empacotamento da aplicação via formato **war**, que era bastante utilizado em aplicações Java antigamente.

Caso você queira que o build do projeto empacote a aplicação em um arquivo no formato war, vai precisar realizar as seguintes alterações:

1) Adicionar a tag `<packaging>war</packaging>` no arquivo `pom.xml` do projeto, devendo essa tag ser filha da tag raiz `<project>`:

```xml
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>3.0.0</version>
    <relativePath/> <!-- lookup parent from repository -->
  </parent>
  <groupId>med.voll</groupId>
  <artifactId>api</artifactId>
  <version>0.0.1-SNAPSHOT</version>
  <name>api</name>

  <packaging>war</packaging>
```

2) Ainda no arquivo `pom.xml`, adicionar a seguinte dependência:

```xml
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-tomcat</artifactId>
  <scope>provided</scope>
</dependency>
```

3) Alterar a classe _main_ do projeto (`ApiApplication`) para herdar da classe `SpringBootServletInitializer`, bem como sobrescrever o método `configure`:

```java
@SpringBootApplication
public class ApiApplication extends SpringBootServletInitializer {

  @Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
    return application.sources(ApiApplication.class);
  }

  public static void main(String[] args) {
    SpringApplication.run(ApiApplication.class, args);
  }

}
```

Pronto! Agora, ao realizar o build do projeto, será gerado um arquivo com a extensão `.war` dentro do diretório `target`, ao invés do arquivo com a extensão `.jar`.


-----------------------------------------------------------------------
# Para saber mais: GraalVM Native Image

Uma das novidades de mais destaque da versão 3 do Spring Boot é o suporte a imagens nativas, algo que reduz, de maneira muito significativa, o consumo de memória e o tempo de inicialização de uma aplicação, sendo que alguns outros frameworks concorrentes do Spring Boot, como Micronaut e Quarkus, já forneciam suporte a esse recurso.

Na realidade até era possível gerar imagens nativas em aplicações com Spring Boot antes da versão 3, mas para isso se fazia necessário a utilização de um projeto chamado **Spring Native**, que adicionava suporte a isso. Com a chegada da versão 3 do Spring Boot, tal projeto não é mais necessário.

## Native Image

Imagem nativa é uma tecnologia utilizada para compilar uma aplicação Java, incluindo todas as suas dependências, gerando um arquivo binário executável que pode ser executado diretamente no sistema operacional, sem a necessidade de se utilizar a JVM. Mesmo sem executar numa JVM, a aplicação também contará com os recursos dela, como gerenciamento de memória, garbage collector e controle de execução de threads.

Para saber mais detalhes sobre a tecnologia de imagens nativas acesse a documentação no site: [https://www.graalvm.org/native-image](https://www.graalvm.org/native-image)

## Native Image com Spring Boot 3

Uma maneira bem simples de gerar uma imagem nativa da aplicação é utilizando um plugin do Maven, que deve ser incluído no arquivo `pom.xml`:

```xml
<plugin>
  <groupId>org.graalvm.buildtools</groupId>
  <artifactId>native-maven-plugin</artifactId>
</plugin>
```

Pronto! Essa é a única alteração necessária no projeto. Após isso, a geração da imagem deve ser feita via terminal, com o seguinte comando Maven sendo executado no diretório raiz do projeto:

```bash
./mvnw -Pnative native:compile
```

O comando anterior pode levar vários minutos para finalizar sua execução, sendo totalmente normal essa demora.

Atenção! Para executar o comando anterior e gerar a imagem nativa do projeto, é necessário que você tenha instalado em seu computador o [GraalVM](https://www.graalvm.org/) (máquina virtual Java com suporte ao recurso de Native Image) em uma versão igual ou superior a 22.3.

Após o comando anterior finalizar, será gerado no terminal um log como o seguinte:

```lua
Top 10 packages in code area:           Top 10 object types in image heap:
   3,32MB jdk.proxy4                      19,44MB byte[] for embedded resources
   1,70MB sun.security.ssl                16,01MB byte[] for code metadata
   1,18MB java.util                        8,91MB java.lang.Class
 936,28KB java.lang.invoke                 6,74MB java.lang.String
 794,65KB com.mysql.cj.jdbc                6,51MB byte[] for java.lang.String
 724,02KB com.sun.crypto.provider          4,89MB byte[] for general heap data
 650,46KB org.hibernate.dialect            3,07MB c.o.s.c.h.DynamicHubCompanion
 566,00KB org.hibernate.dialect.function   2,40MB byte[] for reflection metadata
 563,59KB com.oracle.svm.core.code         1,30MB java.lang.String[]
 544,48KB org.apache.catalina.core         1,25MB c.o.s.c.h.DynamicHu~onMetadata
  61,46MB for 1482 more packages           9,74MB for 6281 more object types
--------------------------------------------------------------------------------
    9,7s (5,7% of total time) in 77 GCs | Peak RSS: 8,03GB | CPU load: 7,27
--------------------------------------------------------------------------------
Produced artifacts:
 /home/rodrigo/Desktop/api/target/api (executable)
 /home/rodrigo/Desktop/api/target/api.build_artifacts.txt (txt)
================================================================================
Finished generating 'api' in 2m 50s.
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time:  03:03 min
[INFO] Finished at: 2023-01-17T12:13:04-03:00
[INFO] ------------------------------------------------------------------------
```

A imagem nativa é gerada no diretório **target**, juntamente com o arquivo .jar da aplicação, como um arquivo executável de nome **api**, conforme demonstrado na imagem a seguir:

![alt text: Lista de arquivos e diretórios localizados dentro do diretório target do projeto, estando entre eles o arquivo da imagem nativa, cujo nome é **api**](https://cdn3.gnarususercontent.com.br/2771-spring-boot/imagem3.png)

Diferente do arquivo .jar, que é executado pela JVM via comando `java -jar`, a imagem nativa é um arquivo binário e deve ser executada diretamente pelo terminal:

```bash
target/api
```

Ao rodar o comando anterior será gerado o log de inicialização da aplicação, que ao final exibe o tempo que levou para a aplicação inicializar:

```sql
INFO 127815 --- [restartedMain] med.voll.api.ApiApplication : Started ApiApplication in 0.3 seconds (process running for 0.304)
```

Repare que a aplicação levou menos de meio segundo para inicializar, algo realmente impressionante, pois quando a executamos pela JVM, via arquivo .jar, esse tempo sobe para algo em torno de 5 segundos.

Para saber mais detalhes sobre a geração de uma imagem nativa com Spring Boot 3 acesse a documentação no site:

- [GraalVM Native Image Support](https://docs.spring.io/spring-boot/docs/current/reference/html/native-image.html)


-----------------------------------------------------------------------

# Resumo

## Transcrição

Chegamos ao final de mais um curso na Alura, onde aprendemos a usar o _Spring Boot_ com mais alguns recursos. Se você chegou até aqui, te parabenizo por ter acompanhado todo esse treinamento e aprendido novos recursos desse framework incrível no mundo Java!

**Vamos recapitular o que vimos ao longo do treinamento?**

# Aula 1

Começamos com um projeto que havia sido terminado nos dois últimos cursos de Spring Boot e aprendemos algumas funcionalidades a mais.

Aprendemos a implementar, por exemplo, as funcionalidades de agendamento e cancelamento de consultas. No caso, demonstramos o agendamento de consultas e deixamos o cancelamento como desafio.

Além disso:

- Entendemos como implementar regras de negócio na aplicação;
- Aprendemos a utilizar uma classe Service e fazer uso dela no controller;
- E descobrimos como fazer a implementação de algoritmo com regras de negócio, com fluxo de execução.

# Aula 2

Em seguida, aprendemos a fazer o isolamento de validações sem que a classe Service ficasse grande demais, utilizando o esquema de validadores que conseguimos injetar por polimorfismo com interface e `List`.

Com isso, aplicamos um padrão de projeto e princípios do SOLID, para deixar nosso código fácil de entender e, principalmente, de fazer manutenção.

Aprendemos, então, a fazer esse tipo de implementação de regras de negócio em uma aplicação Java com o Spring Boot.

# Aula 3

Depois, nos aprofundamos na parte de documentação de uma API. Adicionamos ao projeto o `SpringDoc`, uma das bibliotecas que dão suporte para gerar a documentação e projetos Java com o Spring Boot.

Também aprendemos a acessar a interface gráfica gerada pelo [_Swagger_](https://swagger.io/). Nós entendemos:

- Como funciona a interface do software;
- Como simular requisições para a nossa API;
- Como colocar o cabeçalho do _JSON Web Token_ para as requisições que precisam de autenticação;
- E como fazer com que esses cabeçalhos apareçam na documentação do Swagger.

A partir disso, geramos uma documentação muito útil para as pessoas clientes da nossa API. Com ela, os times responsáveis pelo desenvolvimento do aplicativo mobile e pela aplicação front-end saberão como funciona a API, quais são as URLs, os parâmetros, os códigos HTTP, de modo que consigam testar e simular requisições, além de desenvolver projetos conectando à nossa API da maneira correta.

# Aula 4

Na sequência, aprendemos sobre testes automatizados. Nesse curso, focamos nos testes de componentes do Spring: _Repository_ e _Controller_.

Para isso, criamos um teste `MedicoRepositoryTeste` no diretório "src > test > java", aplicando a estratégia de usar um banco de dados real (no caso, o MySQL) com uma _database_ separada para a escrita dos testes automatizados.

Nós aprendemos a fazer essa configuração por Spring; a usar o esquema de _profile_; e criamos o arquivo `application.properties` específico para o teste, permitindo o uso de outra database sem que os dados de desenvolvimento afetem o resultado dos testes.

Além disso, aprendemos a escrever o código que simula esses cenários de testes no nosso Repository, cuja consulta era mais complexa. Aprendemos então:

- A preparar os dados;
- A fazer o insert das informações necessárias;
- A fazer as chamadas do repository;
- E a verificar se o comportamento está conforme o esperado.

Depois, aprendemos a testar uma classe Controller. Para isso, aplicamos a estratégia de realizar um teste de unidade, isto é, de maneira isolada, utilizando o _mock_ para simular o Repository, o Service, e os demais serviços.

> Nesse caso, não fizemos um teste de integração, onde de fato será chamado o controller, uma requisição HTTP, e o repository para acessar o banco de dados.

Aprendemos a escrever esse tipo de teste utilizando um `MockMvc` e a classe utilitária `JacksonTester` no Spring, para facilitar o processo de validar JSONs pela nossa API. Após isso, fizemos alguns cenários de teste.

# Aula 5

Na última aula, aprendemos a gerar o _build_ da nossa aplicação via _Maven_, gerando um arquivo `.jar` na pasta "target > test-classes".

Também aprendemos a criar outro arquivo de _properties_ para um ambiente de produção, utilizando variáveis de ambiente para não expor dados sensíveis na aplicação.

Por fim, aprendemos a executar o projeto, simulando um _deploy_ em um ambiente de produção. Entendemos os comandos e parâmetros necessários para rodar a nossa aplicação e passar um profile e as variáveis de ambiente pelo terminal.

# Conclusão

Com isso, encerramos os nossos treinamentos de Spring Boot.

> Nós aprendemos a:
> 
> - Criar uma API do zero com o Spring usando o [_Spring Initializr_](https://start.spring.io/);
> - Implementar nossas primeiras funcionalidades, um controller, um repository;
> - Usar o _Flyway_;
> - Fazer o CRUD da nossa aplicação;
> - Fazer a validação com o [_Bean Validation_](https://beanvalidation.org/);
> - Usar as _migrations_ para controlar o histórico de evolução do banco de dados;
> - Aplicar testes automatizados.

Vimos diversos recursos ao longo dos 3 cursos da formação, e com isso, completamos a nossa jornada com o Spring Boot!

Obviamente, não vimos tudo do software. Ainda há vários outros recursos e módulos, mas nesse ponto, você já tem uma boa base de conhecimento, sabe como funciona, compreende o básico utilizado no dia a dia, e é capaz de seguir estudando pelas documentações.

https://cursos.alura.com.br/course/spring-boot-3-documente-teste-prepare-api-deploy/task/122060

