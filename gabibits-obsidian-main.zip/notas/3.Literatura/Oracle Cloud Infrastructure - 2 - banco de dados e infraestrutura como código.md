---
type: "10"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
  - "#oracle"
  - "#OCI"
  - "#cloud"
fonte_curso: https://cursos.alura.com.br/formacao-oracle-cloud-infraestructure-one
Url_video_curso: 
OCI: https://cdn3.gnarususercontent.com.br/oracle-one-alumni/OCI%20-%20Cartilha.pdf
w3schools:
---

Tópico:: #oracle #infrastructure #database #oci #cloud

- Compreenda conceitos de bancos de dados na nuvem
- Aprenda a criar e configurar um compute para hospedar uma aplicação NodeJS
- Hospede um site estático no Object Storage da Oracle Cloud
- Realize a implantação de infraestruturas como código na Oracle Cloud
-----------------------------------------------------------------------
## Aulas

## Aulas

- [](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/section/13797/tasks)
    
    [Bancos de dados na OCI](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/section/13797/tasks) [Ver primeiro vídeo](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105748)
    
    0 / 8
    
    17min
    
    - Apresentação
    - Bancos de dados na OCI
    - Escolhendo banco de dados
    - Criando um banco autônomo
    - Faça como eu fiz: prepare o banco para Doguito
    - Para saber mais: bancos de dados Oracle
    - Para saber mais Bancos de Dados Não Relacionais na OCI
    - O que aprendemos?
- [
    
    Conectando API e banco de dados
    
    0 / 9
    
    39min
    
    ](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/section/13798/tasks)
    
    - Projeto da aula anterior
    - Conhecendo o Doguito API
    - Implantando uma API na OCI
    - Faça como eu fiz: executar o Doguito API na OCI
    - Testando o Doguito API
    - Faça como eu fiz: testando a API REST do Doguito
    - Para saber mais: tecnologias do Doguito
    - Permitindo o acesso à aplicação
    - O que aprendemos?
- [
    
    Armazenamento
    
    0 / 9
    
    40min
    
    ](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/section/13799/tasks)
    
    - Projeto da aula anterior
    - Armazenamento na OCI
    - Doguito no Object Storage
    - Faça como eu fiz: servindo o site estático do Doguito
    - SSL no Load Balancer
    - Faça como eu fiz: Doguito API com SSL
    - Para saber mais: Object Storage na OCI
    - Tipo de armazenamento adequado
    - O que aprendemos?
- [
    
    Infraestrutura como código
    
    0 / 8
    
    38min
    
    ](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/section/13800/tasks)
    
    - Projeto da aula anterior
    - O que é infra como código
    - O gerenciador de recursos
    - Nossa primeira IAC
    - Faça como eu fiz: infraestrutura a partir do código
    - Para saber mais: automatizando a infraestrutura
    - Vantagens da IAC
    - O que aprendemos?
- [
    
    Infra do Doguito como código
    
    0 / 9
    
    34min
    
    ](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/section/13801/tasks)
    
    - Projeto da aula anterior
    - Configurando a stack do Doguito
    - Faça como eu fiz: Doguito como código
    - Implantando stack na OCI
    - Faça como eu fiz: implantando o Doguito como código
    - Para saber mais: Terraform
    - Implantando recursos como código
    - O que aprendemos?
    - Conclusão

-----------------------------------------------------------------------
# 01Apresentação

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105748

## Transcrição

Olá, bem-vindo à segunda parte do nosso treinamento sobre Oracle Cloud. Para que você possa acompanhá-lo, é necessário que já tenha realizado a primeira parte, o [curso de Oracle Cloud Infrastructure: implantação de uma aplicação na nuvem](https://cursos.alura.com.br/course/oracle-cloud-infrastructure-aplicacao-nuvem), em que aprendemos os conceitos básicos de OCI.

Naquele primeiro treinamento, implantamos uma rede virtual através do menu da OCI, na lateral esquerda, na área "Rede". Em seguida, criamos as instâncias de computação através no menu "Computação". E nossa última tarefa foi a criação de um _load balancer_, também na área "Rede", para permitir que nossa aplicação escale horizontalmente.

Agora, vamos continuar nossa missão de implantar o Doguito Pet Shop a partir de onde paramos. Inicialmente, precisamos definir como realizar o **armazenamento dos dados dinâmicos** do Doguito, o que será feito através de um banco de dados. No menu lateral da OCI, temos as opções "Oracle Database" e "Banco de Dados". Vamos estudar os **diferentes tipos de bancos de dados oferecidos pela OCI** e verificar qual melhor se encaixa em nossas necessidades.

Em seguida, veremos também as opções de armazenamento à nossa disposição, no menu lateral da OCI, em "Armazenamento" — ou "_Storage_, caso esteja usando a ferramenta em inglês. Analisaremos as características desses armazenamentos, suas peculiaridades, casos de uso, assim como as possibilidades de uso pela nossa própria aplicação, o Doguito.

Por fim, praticamente toda implementação de ambiente _cloud_ deve ter algum mecanismo de **automação e reprodutibilidade** para que possamos versionar e implantar com bastante segurança nossa infraestrutura, evitando procedimentos manuais que são bastante propensos a erros. Com esse objetivo, aprenderemos a usar o gerenciador de recursos, que podemos encontrar no menu da OCI na área "Serviços de Desenvolvedor".

Vamos implementar a infraestrutura do Doguito como código através de **_scripts_** **Terraform**.

Espero que você esteja bastante animado para começar esse curso, porque temos bastante a fazer. Vamos lá!

-----------------------------------------------------------------------
# 02Bancos de dados na OCI

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105749

## Transcrição

Olá. Nesta aula, veremos quais os tipos de serviços de banco de dados que a OCI oferece. Clicando no ícone do menu da OCI (no canto superior esquerdo da tela), teremos duas divisões que nos interessam: "Oracle Database" e "Bancos de Dados".

Num primeiro momento, vamos explorar a aba "Oracle Database". Dentro dela, selecionaremos a opção "Bare Metal, VM e Exadata". Em seguida, clicaremos no botão "Criar Sistema de BD" — ainda não faremos a criação, vamos entrar apenas para analisar seu conteúdo.

Nessa nova página, há uma série de campos a serem preenchidos com informações básicas do sistema. Por enquanto, vamos examinar os três **tipos de forma** que podemos selecionar.

A primeira opção é "Máquina Virtual" (ou _Virtual Machine_, se estiver navegando em inglês), que nos dá a oportunidade de um provisionamento muito rápido. Nesse caso, o próprio sistema da Oracle gerenciará o volume de dados. A segunda opção é "Bare Metal", que significa que teremos um servidor físico dedicado, resultando numa melhor performance. A terceira opção é o "Exadata", direcionado para sistemas com grande volume de transações. Ele consegue suportar até 2.5 _petabytes_ de dados, com altíssima performance, ou seja, é interessante para grandes clientes, grandes casos de uso.

Vamos voltar ao menu da OCI e selecionar "Oracle Database > Autonomous Database". Em português, bancos de dados autônomos. Em seguida, clicaremos no botão "Criar Autonomous Database". Dessa vez, vamos analisar alguns tipos de carga de trabalho e os tipos de implantação disponíveis.

Esses bancos de dados autônomos utilizam aprendizagem de máquina para otimização do processo de segurança, _back-up_, atualizações e outras atividades rotineiras que tradicionalmente são feitas pelos administradores de bancos de dados.

Nessa categoria de bancos de dados autônomos, há uma divisão. O "Data Warehouse" serve para fazer análise de dados para grandes volumes de informações. Já "Processamento de Transações" (ATP) é mais operacional, para transações executadas muito rapidamente. Ou seja, o primeiro é mais voltado para volumes e o segundo, para transações. De forma oculta, esses bancos de dados utilizam Exadata — mas, no caso, a própria OCI faz esse gerenciamento.

Quanto aos tipos de implantação, temos duas opções. Com a "Infraestrutura Compartilhada", seremos responsáveis por gerenciar somente o banco de dados autônomo, enquanto a OCI gerenciará a implantação dos dados em si. Com a "Infraestrutura Dedicada", teremos o uso exclusivo do _hardware_ e do Exadata, resultando numa performance mais alta.

Os bancos de dados autônomos são ditos **_self-driving_**, porque todo gerenciamento da infraestrutura, incluindo a monitoração e otimização, é automatizada. Eles também são ditos **_self-securing_**, significando que esses bancos possuem recursos automáticos que protegem contra ataques externos, usuários maliciosos internos, entre outras questões. Por fim, os bancos de dados autônoms também são ditos **_self-repairing_**, o que quer dizer que os bancos se previnem automaticamente de quaisquer indisponibilidades que possam ocorrer.

Desse modo, na aba "Oracle Database", vimos as opções de "Bare Metal, VM e Exadata" e "Autonomous Database". Esses bancos variam em questões de performance, de necessidade de gerenciamento e também de custo — em geral, quanto mais dedicada for a máquina, maior a tarifa de operação.

Além dessas opções, na aba "Bancos de Dados" no menu da OCI, temos como alternativas "MySQL" e "Oracle NoSQL Database". O MySQL será fornecido como um serviço totalmente gerenciado pela OCI e suportado pelo próprio time do MySQL que trabalha na Oracle. Já o NoSQL Database suportará cargas sob demanda, trabalho com tabelas JSON e dados do tipo chave-valor. Além disso, ele tem garantia de transações com latência inferior a 10 milissegundos — algo bem interessante.

Voltando a "Oracle Database > Autonomous Database" e clicando novamente no botão "Criar Autonomous Database", temos o "APEX" que servirá para aplicações de baixo código (ou _low code_), também com gerenciamento automático. E, por fim, temos o "JSON" que deixamos por último porque é justamente com o qual vamos trabalhar nesse curso — ele é um banco de dados NoSQL que incluiremos na nossa aplicação Doguito Pet Shop.

Focaremos no JSON porque nossa aplicação é feita em Node, que trabalha muito bem essa junção entre NoSQL e JSON, facilitando nossa programação.

-----------------------------------------------------------------------
# 04Criando um banco autônomo

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105750

## Transcrição

Para o caso do Doguito, vamos utilizar o banco de dados no formato JSON, uma API bastante amigável, fácil para desenvolvermos.

Então, vamos criar nosso banco de dados. Partindo da primeira tela da OCI, acessaremos o menu e clicaremos em "Oracle Database > Autonomous Database" e pressionaremos o botão "Criar Autonomous Database".

Na nova tela, vamos fornecer alguns dados. Primeiramente, selecionaremos o compartimento de desenvolvimento. Em seguida, vamos definir "DOGUITODB" tanto como nome de exibição quanto o nome do banco de dados. No tipo de carga de trabalho, vamos selecionar o JSON — criado para desenvolvimento de aplicativos baseados em JSON, APIs de documento amigáveis para o desenvolvedor e armazenamento JSON nativo. Quanto ao tipo de implantação, escolheremos a infraestrutura compartilhada, que é o que temos disponível na nossa conta _free trial_.

Os próximos dados são as configurações do banco de dados. De início, vamos ativar a opção _Always Free_ e seremos informados de que: "Se o seu Always Free Autonomous Database ficar sem atividade por 7 dias consecutivos, o banco de dados será interrompido automaticamente. Seus dados serão preservados e você poderá reiniciar o banco de dados para continuar utilizando-o. Se o banco de dados ficar parado por 3 meses, ele será recuperado".

No campo "Versão do banco de dados", podemos manter o número padrão, que é a versão 19 da Oracle. A contagem de OCPUs e o volume de armazenamento têm valores travados.

O próximo ponto importante é escolher a senha do usuário. Para fins didáticos, vamos colocar uma senha bem simples, "Doguito12345". Num cenário real, utilizaríamos uma senha mais elaborada, mais segura.

Em seguida, em tipo de acesso à rede, selecionaremos "Acesso seguro de todos os lugares", que permite que usuários com credenciais do banco de dados acessem o banco de dados pela internet. Essa opção nos obriga a fazer um TLS mútuo (_mutual TLS_), que é interessante, pois poderemos conectar até a nossa máquina local com o próprio sistema da Oracle, desde que tenhamos esse certificado instalado. Isso implica um passo a mais no processo, mas não é muito complicado.

A seguir, vamos manter a licença incluída. Não é preciso preencher o campo de e-mail para contato. Na parte inferior esquerda, temos a possibilidade de definir configurações mais avançadas, por ora não vamos explorar essa parte. Podemos clicar no botão "Criar Autonomous Database".

Seremos direcionados a outra página em que veremos o _status_ de provisionamento, à esquerda. Inicialmente, teremos um quadrado amarelo com o texto "PROVISIONANDO"; após alguns segundos, o _status_ será alterado para "DISPONÍVEL", com um quadrado verde.

> Para avançar, é preciso permitir as janelas _pop-ups_. Caso estejam bloqueadas no seu navegador, basta clicar no ícone de _pop-up_ à direita da barra de endereço e conceder a permissão para o site da Oracle.

Com o banco provisionado, vamos clicar em "Ações do Banco de Dados". Uma nova aba será aberta e veremos uma variedade de operações disponíveis, como importação de dados, SQL, gráficos etc. No momento, estamos interessados na opção JSON, para gerenciar nosso banco de dados de documentos JSON.

Entrando nessa opção, vamos clicar em "Criar Coleção". No caso de banco de dados NoSQL baseados em JSON, **coleções** são análogas às tabelas dos bancos de dados convencionais relacionais. Então, criaremos uma coleção com nome "clientes" (note que há um exemplo de dados, porém não é editável) e, em seguida, clicaremos no botão "Criar" ao fim da página.

Está criada a nossa coleção "clientes", como podemos verificar no painel à esquerda. A partir desse momento, já conseguimos incluir dados, pressionando o ícone de "Novo Documento JSON", no topo da página:

```perl
{
    "nome": "Paulo",
    "email": "paulo@gmail.com"
}
```

Após clicar em "Criar", no painel inferior podemos confirmar os documentos gerados. Vamos criar mais um documento JSON:

```perl
{
    "nome": "Tiago",
    "email": "tiago@gmail.com"
}
```

Novamente, podemos verificar a listagem de entidades criadas.

À direita dessa lista, há algumas operações à disposição. A primeira delas é a opção de editar, vamos testá-la modificando o último documento criado:

```perl
{
    "nome": "Tiago Lage",
    "email": "tiago@gmail.com"
}
```

Além disso, por essa interface podemos clonar, exportar e excluir as entidades. A título de exemplo, vamos apagar o documento referente ao cliente "Tiago Lage". Note que, ao clicar na opção de exclusão, será mostrado o ID da entidade em questão.

Nesse vídeo, criamos o nosso banco de dados e já conseguimos fazer algumas manipulações, operando em algumas entidades. Na próxima aula, vamos conectar uma aplicação, porque ficar mexendo no banco de dados diretamente pela interface _web_ não é muito interessante — imagine se tivéssemos centenas ou milhares de usuários! De qualquer modo, podemos entrar, visualizar e fazer operações básicas.

-----------------------------------------------------------------------
# 06Para saber mais: bancos de dados Oracle

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105786

A Oracle desenvolve um dos bancos de dados mais utilizados no meio corporativo do mundo. Desta forma, é de se esperar que a Oracle Cloud disponibilize muitos tipos de recursos de bancos de dados adequados às diversas necessidades de seus clientes. Este video detalha as características técnicas de cada uma das opções de bancos de dados da Oracle Cloud e é recomendável assisti-lo se você já é um administrador de bancos de dados ou se tem um contato mais profundo com a área:

https://youtu.be/F4-sxIsnbKI

O conteúdo em video pode apresentar alguns tópicos desatualizados, por isso, todos os detalhes sobre a utilização de Bancos de Dados na OCI podem ser também encontrados na documentação oficial na seção “Gerenciamento de Dados”, através dos links [https://docs.oracle.com/pt-br/iaas/Content/home.htm](https://docs.oracle.com/pt-br/iaas/Content/home.htm) e [https://docs.oracle.com/es-ww/iaas/Content/home.htm](https://docs.oracle.com/es-ww/iaas/Content/home.htm).

-----------------------------------------------------------------------
# 07Para saber mais Bancos de Dados Não Relacionais na OCI

Além das soluções tradicionais de bancos de dados relacionais, também está disponível na OCI a Oracle Database API para MongoDB.

Com esta API, os desenvolvedores podem usar as ferramentas e drivers de código aberto do MongoDB conectados a um Oracle Autonomous JSON Database mantendo os benefícios de um banco de dados autônomo juntamente com uma API de banco de dados Não Relacional.

Como a API é compatível com o Mongo DB, frequentemente, pouca ou nenhuma alteração é necessária no código nos aplicativos existentes – basta alterar a string de conexão.

A lista de linguagens de programação recomendadas inclui C, C#, Go, Java, Node.js, Ruby, entre outras.

O passo a passo de como utilizar o Oracle Database API para MongoDB encontra-se disponível neste [link](https://docs.oracle.com/en/cloud/paas/autonomous-database/adbsa/mongo-using-oracle-database-api-mongodb.html)

-----------------------------------------------------------------------
# 02Conhecendo o Doguito API

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105751

## Transcrição

Com o nosso banco de dados criado, é hora de conectar nossa aplicação a ele para que possa consumir os dados disponibilizados nesse banco. O código da aplicação em si é fornecido na plataforma da Alura, você pode baixá-lo no tópico anterior a este vídeo. A seguir, vamos abrir o código no VS Code e dar uma olhada nele.

Trata-se do projeto **Doguito API**. Nossa aplicação está dividida entre a parte de _front-end_ e a de _back-end_. O Doguito API, escrito em Node.js, é a parte de **_back-end_**, ou seja, é ele que fará as operações relativas ao banco de dados, como a persistência e captura de informações. Toda comunicação será feita por meio do Doguito API.

Primeiramente, vamos abrir o arquivo `package.json`. Toda aplicação Node.js tem um arquivo central chamado `package.json` que descreve as dependências. Nesse caso, temos:

```json
// código anterior omitido

"dependencies": {
    "body-parser": "^1.19.2",
    "cookie-parser": "~1.4.4",
    "cors": "^2.8.5",
    "debug": "~2.6.9",
    "ejs": "~2.6.1",
    "express": "~4.16.1",
    "express-async-handler": "^1.2.0",
    "http-errors": "~1.6.3",
    "morgan": "~1.9.1",
    "oracledb": "^5.3.0"
  }

// código posterior omitido
```

No caso,`body-parser`, `cookie-parser`, `cors`, `debug`, `ejs`, `express` são dependências comuns de uma aplicação Express.js — nossa aplicação é escrita em **Node com o _framework_ Express**. No momento, a dependência que nos interessa é a `oracledb`, ou seja, o banco de dados da Oracle.

É neste arquivo que começa nossa aplicação. Na linha 6 do `package.json`, constatamos que para rodar essa aplicação será executado o comando `node ./bin/www` (ou `npm start`). Portanto, no painel à esquerda, vamos em "bin > www".

Analisando esse outro arquivo, compreendemos que a aplicação é iniciada e será feito um `require` nas dependências dela. Nas linhas seguintes, veremos que tanto a porta do ambiente quanto a porta 3000 podem ser selecionadas. O servidor será criado e diversas outras operações e alterações administrativas serão realizadas. A parte mais importante é a importação de `app`, na linha 7. Logo, vamos ao arquivo `app.js`.

Esse arquivo especificará onde estão as _views_ (as telas da aplicação), além de determinar que a aplicação permite a utilização através de `cors`, ou seja, requisições entre domínios são autorizadas. Ademais, será usado o Express como biblioteca e o bodyParser para processar o corpo das requisições, possuindo também um diretório de conteúdo público (`public`).

Nas linhas 27 e 28, notamos os **roteamentos** da aplicação. Assim, temos uma rota para a raiz e outra para clientes, onde se concentrará a maior parte do nosso trabalho nesse curso:

```php
app.use('/', indexRouter);
app.use('/clientes', clientesRouter);
```

Mais abaixo, podemos verificar a forma como erros serão tratados e, partir da linha 46, vemos um serviço chamado `ClienteService`. Quando a aplicação inicia, o `ClienteService`é iniciado e disponibilizado no contexto da aplicação, sob o próprio nome "clienteService". Por outro lado, quando a aplicação vai sair, é chamado o comando `closePool()`, encerrando o _pool_ de conexões com o banco de dados.

Então, vamos analisar o que o `ClienteService` faz, indo até "services > cliente-service.js". Quando iniciado, ele coleta algumas informações do ambiente: nome do usuário (`DB_USER`), senha do usuário (`DB_PASSWORD`) e a URL de conexão (`CONNECT_STRING`). Esses são os parâmetros de comunicação com o banco de dados:

```javascript
// código anterior omitido

    static async init() {
        console.log(`process.env.DB_USER: ${process.env.DB_USER}`);
        console.log(`process.env.DB_PASSWORD: ${process.env.DB_PASSWORD}`);
        console.log(`process.env.CONNECT_STRING: ${process.env.CONNECT_STRING}`);

        console.log('Criando pool de conexões...')
        await oracledb.createPool({
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            connectString: process.env.CONNECT_STRING,
        });
        console.log('Pool de conexões criado.')
        return new ClienteService();
    }

// código posterior omitido
```

Além disso, da linha 18 a 22, ele cria o _pool_ de conexões. Em geral, trabalhamos com _pool_ de conexões porque não é recomendado fazer uma conexão a cada requisição recebida do cliente. O _pool_ permite um melhor gerenciamento, fazendo com que conexões possam ser reaproveitadas. Ao criar esse _pool_, são passadas informações de usuário, senha e URL de conexão.

Por fim, será retornada um `ClienteService` (linha 24).

Mais abaixo, temos uma série de operações interessantes. A primeira delas é o `getAll()`, que retornará todos os clientes. Vamos analisar esta operação:

```javascript
    async getAll() {
        let connection;
        const result = [];

        try {
            connection = await oracledb.getConnection();

            const soda = connection.getSodaDatabase();
            const clienteCollection = await soda.createCollection(CLIENTES_COLLECTION);
            let clientes = await clienteCollection.find().getDocuments();
            clientes.forEach((element) => {
                result.push({
                    id: element.key,
                    createdOn: element.createdOn,
                    lastModified: element.lastModified,
                    ...element.getContent(),
                });
            });
        } catch (err) {
            console.error(err);
        } finally {
            if (connection) {
                try {
                    await connection.close();
                }
                catch (err) {
                    console.error(err);
                }
            }
        }
        return result;
    }
```

A princípio, é criada uma variável chamada `connection`, que fará uma conexão com `oracledb`, ou seja, se conectará com o banco de dados. Depois, será criado o `.getSodaDatabase()`, o principal elemento de comunicação com banco de dados JSON.

Em seguida, temos `.createCollection()` que tentará criar uma coleção, mas caso ela já exista, retornará a própria coleção existente. Ele utiliza uma constante chamada `CLIENTES_COLLECTION` que aponta para `'clientes'`. Anteriormente, quando criamos o Autonomous Database JSON, geramos uma coleção dentro dele chamada justamente `'clientes'` — este é o ponto de ligação.

Nosso código seleciona essa coleção, chama o método `.find()` e pega todos os documentos (`getDocuments()`) — seria o mesmo que consultar todos os registros numa base de dados relacional. Para cada um desses documentos, será incluído um objeto JSON com ID, data de criação, data da última modificação e o conteúdo em si.

Caso ocorra algum erro, será exibido uma mensagem por meio do `console.error(err)` e, finalmente, a conexão será fechada.

Além do `getAll()`, temos outras operações. Se quisermos buscar pelo ID, usaremos o `getById(clienteId)`, cuja principal diferença é encontrada na linha 68, em que passamos o `key` com o ID do documento desejado.

Também temos a operação `save(cliente)` com a qual salvamos um novo cliente. Trata-se de uma persistência. Este método recebe um cliente que será passado como parâmetro em `.insertOneAndGet()`.

Em seguida, temos o `update(id, cliente)` que recebe um ID e um cliente e, após o `.find()`, aplica o método `.replaceOneAndGet()` que atualizará o elemento. O `deleteById()` fará a remoção a partir do ID informado, chamando o método `.remove()`. E, por fim, `.closePool()` será chamado no encerramento do sistema.

Tudo isso está ligado às URLs do sistema pelo sistema de rotas, que podemos encontrar em "routes > clientes.js". Nesse arquivo, veremos, por exemplo, que se for feita uma chamada do tipo GET para a URL base`/`, será chamado o método `getAll()` na instância de `CLIENTE_SERVICE`:

```csharp
// Lista todos os clientes
router.get('/', asyncHandler(async (req, res) => {
  res.send(await res.app.get(CLIENTE_SERVICE).getAll());
}));
```

Se quisermos detalhar pelo ID, será chamado o método `getById()`:

```csharp
// Detalha um cliente
router.get('/:id', asyncHandler(async (req, res) => {
    res.send(await res.app.get(CLIENTE_SERVICE).getById(req.params.id));
}));
```

Se chamarmos um POST na URL `/`, será chamado o método `save()`:

```less
// Insere um cliente
router.post('/', asyncHandler(async (req, res) => {
  res.status(201).send(await res.app.get(CLIENTE_SERVICE).save(req.body));
}));
```

Se fizermos um PUT, será o método `update()`:

```less
// Altera um cliente
router.put('/:id', asyncHandler(async (req, res) => {
  res.status(200).send(await res.app.get(CLIENTE_SERVICE).update(req.params.id, req.body));
}));
```

Se fizermos um DELETE, será chamado o método `deleteById()`:

```csharp
// Exclui um cliente
router.delete('/:id', asyncHandler(async (req, res) => {
  const deleted = await res.app.get(CLIENTE_SERVICE).deleteById(req.params.id);
  res.status(deleted.count == 1 ? 204 : 404).end();
}));
```

Portanto, este é o código do Doguito API. Lembrando que ele já está pronto, estamos apenas observando seu conteúdo para termos uma ideia de como tudo funciona. Você pode continuar explorando a aplicação para descobrir mais.

Vale lembrar que quando nossa aplicação estiver em execução, ao acessar a porta 3000, veremos a página _index_. Se colocarmos `/clientes` ao final do endereço, teremos como retorno a lista de clientes.

Ademais, você pode explorar [o site do Node.js](https://nodejs.org/en/), [o site do Express](https://expressjs.com/pt-br/) e [a documentação da biblioteca SODA (_Simple Oracle Document Access_)](https://docs.oracle.com/en/database/oracle/simple-oracle-document-access/nodejs/), que são ferramentas utilizadas nesse projeto.

Na próxima aula, vamos baixar essa aplicação no servidor que já está em execução e fazer a ligação com o nosso banco de dados


-----------------------------------------------------------------------
# 03Implantando uma API na OCI

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105752

## Transcrição

Uma vez que compreendemos quais tipos de bancos de dados a OCI oferece, fizemos a criação do nosso _Autonomous Database_ JSON e entendemos as características do Doguito API, é hora de instalarmos e colocarmos o Doguito API para ser executado nas instâncias de _compute_ que já temos.

Na interface inicial da OCI, no menu, vamos clicar em "Computação > Instâncias". Num primeiro momento, vamos colocar o Doguito API em uma instância só, portanto vamos selecionar a `dps-vm1`. Nessa página, teremos várias informações, em especial o **endereço IP público**, que usaremos em breve.

Clicaremos no ícone à direita da barra superior para abrir o Cloud Shell. Para acessar a máquina, vamos copiar o endereço IP público (no meu caso, é 132.226.245.137) e utilizá-lo no comando `ssh` seguido do caminho para o arquivo `.ssh`, da seguinte forma: `ssh opc@132.226.245.137 -i .ssh/cloudshellkey`. Assim, estaremos na máquina.

A seguir, colocaremos o código do Doguito API nessa máquina por meio do comando `git clone https://github.com/alura-cursos/doguito-api.git`, clonando o repositório do Doguito API. Você pode confirmar a URL no material disponibilizado na plataforma.

Vamos nos deparar com um problema: "comando git não encontrado" — ainda não temos o **Git** instalado nessa máquina. Então, executaremos o comando `sudo dnf install git` e confirmaremos a operação digitando "_yes_". O processo de instalação pode demorar alguns segundos.

Com o Git instalado, podemos repetir o comando `git clone https://github.com/alura-cursos/doguito-api.git` e, em seguida, listaremos os diretórios (com `ls`) para nos certificar de que o projeto foi clonado.

Vamos acessar o projeto (`cd doguito-api/`) e instalar as dependências, utilizando o comando `npm install`. Novamente, teremos um erro: "comando npm não encontrado" — precisamos também instalar o **NPM** e o pacote do **Node**. Faremos isso através do comando `sudo dnf install @nodejs:16` (ou seja, a versão 16). Essa ação requer uma confirmação, digitaremos "y".

Concluída a instalação, vamos repetir o comando `npm install`. Dessa vez, o comando é bem-sucedido. Por serem muitas dependências, esse processo pode ser um pouco demorado.

Com as dependências instaladas, agora podemos executar o `npm start`. Vamos nos deparar com mais um erro, seremos informados de que não foi encontrada a biblioteca cliente do banco de dados Oracle — em outras palavras, precisamos instalar mais alguns _softwares_. Basicamente, faltam duas bibliotecas adicionais. A primeira será instalada com `sudo dnf install oracle-instantclient-release-e18` e a outra com `sudo dnf install oracle-instantclient-basic`.

Feitas essas instalações, tentaremos executar nosso projeto mais uma vez, com `npm start`. Vamos obter outro erro: falta a senha, o nome de usuário, a _connection string_. Essa série de problemas ocorre porque, agora que fizemos todas as instalações necessárias, falta fazer a comunicação, de fato, com a instância do banco de dados.

Para tanto, no menu da OCI, vamos até "Oracle Database > Autonomous Database". Em seguida, acessaremos o DOGUITODB e clicaremos no botão "Conexão do BD" no topo da página. Nessa nova aba, teremos a opção de fazer o _download_ da _wallet_, que contém os arquivos necessários para fazermos o **_mutual TLS_**. O _mutual TLS_ é semelhante ao HTTPS, porém ele reconhecerá tanto um lado como o outro, um lado autenticará o outro (ou seja, é mútuo). Então, basta clicar no botão "Fazer o download da wallet", criar uma senha (podemos usar "Doguito12345" de novo) e baixar.

O próximo passo é colocar esse arquivo na instância. Primeiramente, no Cloud Shell, vamos deslogar da _virtual machine_ utilizando o comando `exit`. A seguir, acessaremos o menu no canto esquerdo superior do Cloud Shell e selecionaremos a opção "Fazer upload". Vamos arrastar o arquivo `Wallet_DOGUITODB.zip` do nosso computador para a área de _upload_ e clicar em "Fazer Upload".

Dessa forma, fizemos o _upload_ para o Cloud Shell, mas o arquivo ainda não está na máquina virtual! Para realizar essa transferência, utilizaremos o comando `scp`, parecido com o `ssh`, porém usado para **cópias**. Então, indicaremos o arquivo da chave, o arquivo a ser copiado, o local para onde copiaremos e a pasta-destino: `scp -i .ssh/cloudshellkey Wallet_DOGUITODB.zip opc@132.226.245.137:/home/opc`. Lembre-se de usar o IP público da sua própria instância.

Feitas essas operações, novamente faremos o _login_ via `ssh` na nossa máquina virtual e, ao fazer a listagem, veremos a `Wallet_DOGUITODB.zip` junto do `doguito-api`. A _wallet_ está na instância.

Agora, precisamos transferir esse arquivo `.zip` para uma pasta específica da própria Oracle: `sudo cp Wallet_*.zip /usr/lib/oracle/21/client64/lib/network/admin`. Arquivo copiado, vamos descompactá-lo no destino, com o comando `sudo sh -c 'cd /usr/lib/oracle/21/client64/lib/network/admin && unzip -B Wallet_*.zip`. Assim, os arquivos serão extraídos.

Se voltarmos à pasta do `doguito-api` e tentarmos executar o `npm start`, notaremos que o usuário, a senha e a _string_ de conexão continuam indefinidos. Vamos definir essas variáveis por meio do comando `export`. Logo, `export DB_USER=ADMIN` e `export DB_PASSWORD=Doguito12345`. Quanto à _string_ de conexão, ela estará localizada no arquivo `tnsnames.ora`. Outra opção é ir até "Oracle Database > Autonomous Database", acessar o DOGUITODB, clicar no botão "Conexão do BD" e copiar um dos nomes TNS. No Cloud Shell, vamos executar `export CONNECT_STRING=doguitodb_high`.

Mais uma vez, vamos tentar iniciar o serviço e, dessa vez, o processo será bem-sucedido! Serviço criado e em execução, veremos os _logs_ das conexões no Shell.

O próximo passo é fazer a conexão via URL no navegador. No menu da OCI, vamos até "Computação > Instâncias" e copiar o IP público de `dps-vm1`. Numa nova aba do navegador, vamos colar esse endereço e adicionar a porta 3000 ao final — `:3000`. Entretanto, a conexão não será concluída.

Anteriormente, quando criamos a instância, foram necessários mais dois passos além desses. O primeiro é liberar a porta 3000 no próprio _firewall_ da máquina. Vamos deixar nosso servidor rodando na porta 3000 mesmo, porque é o _default_ do Express, para não entrar em colisão com o HTPD. Então, vamos liberar a porta 3000 com o comando `sudo firewall-cmd --permanent --add-port=3000/tcp` e dar um _reload_ com `sudo firewall-cmd --reload`.

Além disso, temos que incluir a porta 3000 no roteamento da VCN. No menu da OCI, vamos em "Rede > Redes Virtuais na Nuvem". Acessaremos a VCN1, entraremos na VCN pública "Public Subnet-VCN1" e, em seguida, clicaremos na lista de segurança "Default Security List for VCN1". Constataremos que a porta 80 está liberada.

Vamos criar uma nova regra de entrada. O CIDR de origem será 0.0.0.0/0, o mais amplo de todos. Manteremos o intervalo de portas de origem como "Todos" e definiremos intervalos de portas de destino como 3000. Regra adicionada, vamos rodar o `npm start` mais uma vez.

Agora, conseguimos nos conectar via URL do navegador na porta 3000! Se adicionarmos `/clientes` ao final do endereço, veremos a lista de clientes atual.

Para confirmar, no menu da OCI, podemos ir a "Oracle Database > Autonomous Database", entrar no DOGUITODB, clicar em "Ações do Banco de Dados", selecionar JSON e verificar a mesma lista de entidades no painel inferior.

Podemos editar e salvar a entidade referente ao cliente Paulo:

```perl
{
    "nome": "Paulo Teste",
    "email": "paulo@gmail.com"
}
```

Recarregando a tela `/clientes`, teremos a lista atualizada, com "Paulo Teste".

Assim, conseguimos levantar nosso projeto Doguito API e nos comunicar com o banco de dados. Até a próxima aula!


-----------------------------------------------------------------------
# 04Faça como eu fiz: executar o Doguito API na OCI

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105789


Aprendemos como implantar uma aplicação Node.JS na infraestrutura da OCI. Clonamos o repositório git da aplicação na instância, em seguida instalamos o Node JS, os drivers de bancos de dados e por fim liberamos o firewall e a regra de entrada para que a aplicação ficasse acessível.

Chegou a hora de você praticar o que aprendeu e executar o Doguito API na OCI. Para ter acesso aos códigos, você pode acessar o link do repositório no [GitHub](https://github.com/alura-cursos/doguito-api)!

-----------------------------------------------------------------------
# 05Testando o Doguito API

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105762

## Transcrição

Agora que estamos com a aplicação implantada no servidor, vamos fazer alguns testes de operações: **listar**, **detalhar**, **incluir**, **alterar** e **excluir** dados. Checaremos se tudo está devidamente funcionando.

Existem várias ferramentas distintas para fazer esses tipos de testes, até mesmo na própria linha de comando, usando o Curl. No caso, optamos por um _plugin_ de navegador chamado **Boomerang**, que é mais visual. Para instalá-lo, basta procurar "Boomerang - SOAP & REST Client" na loja do seu navegador Microsoft Edge ou Google Chrome.

Com o _plugin_ instalado, vamos clicar no botão "Quick Request" e informar a URL, ou seja, o IP público da máquina virtual seguido da porta e `/clientes`. Essa ferramenta requer que indiquemos o protocolo também (HTTP), então no meu caso o endereço será `http://132.226.245.137:3000/clientes`. Pressionando o botão "SEND", temos o retorno esperado no painel à direita.

Vamos tentar ver os detalhes do cliente Paulo a partir do seu ID. Ao final da URL, adicionamos uma barra (`/`) seguida do ID. Clicando em "SEND", obtemos os detalhes desejados.

A seguir, na interface da OCI, vamos encerrar o Cloud Shell e a conexão para ver o que acontece. Voltando ao Boomerang, vamos tentar listar os clientes mais uma vez: `http://132.226.245.137:3000/clientes`. Dessa vez, temos um erro.

Em realidade, ainda falta um passo após a instalação da aplicação. Precisamos deixá-la rodando como um **serviço** do Linux para que ela não fique dependente de ser "startada" por uma pessoa e evitar que ela "caia" com o encerramento do Cloud Shell. Além disso, é interessante que seja colocada com um serviço para, quando a instância for iniciada, ele seja levantado junto.

Vamos voltar à OCI e abrir o Cloud Shell, para fazer mais uma alteração no projeto. Primeiro, vamos nos conectar usando o IP público da instância, no meu caso: `ssh opc@132.226.245.137 -i .ssh/cloudshellkey`. Em seguida, entraremos no projeto Doguito (`cd doguito-api/`). Há um arquivo chamado `doguito-api.service`. Para alterá-lo, temos duas opções de editores, o **VI (ou Vim)** e o **Nano**.

Com o comando `vim doguito-api.service`, vamos editá-lo usando o Vim, que não é muito intuitivo, mas resolverá nossos problemas. Para entrar no modo de edição, pressionaremos a tecla "I". Vamos modificar a senha (`DB_PASSWORD`) para "Doguito12345" e a _string_ de conexão para "doguitodb_high". Para salvar e sair, pressionaremos a tecla "Esc" e, em seguida, digitamos `:wq` — _write and quit_.

Para realizar a mesma operação com o Nano, basta usar `nano doguito-api.service`. Fazer alterações nesse editor é um pouco mais fácil, depois pressionamos "Ctrl + O" para escrever e "Ctrl + X" para sair.

Para conferir que as modificações foram salvas, podemos executar `cat doguito-api.service`:

```ini
# https://docs.oracle.com/en/learn/use_systemd/index.html#introduction
# https://oracle-base.com/articles/linux/linux-services-systemd#creating-linux-services
# https://nodesource.com/blog/running-your-node-js-app-with-systemd-part-1/

[Unit]
Description=Doguito API Service
After=network.target

[Service]
Environment="DB_USER=ADMIN"
Environment="DB_PASSWORD=Doguito12345"
Environment="CONNECT_STRING=doguitodb_high"
Type=simple
User=opc
ExecStart=/usr/bin/node /home/opc/doguito-api/bin/www
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

A seguir, vamos copiar esse arquivo para a pasta do `systemd`, rodando o comando `sudo cp doguito-api.service /lib/systemd/system`. Em seguida, daremos um _reload_ no _daemon_ do `systemd`, para que ele note o novo serviço disponível — `sudo systemctl daemon-reload`.

Feita essa operação, vamos checar o _status_ do `doguito-api.service` com o comando `sudo systemctl status doguito-api.service`. Veremos que está inativo. Se tentarmos enviar uma requisição no Boomerang, ainda não funcionará. Para resolver esse problema, vamos executar o `sudo systemctl start doguito-api.service`. Agora, nos _status_, consta como "_active (running)_". Pressionando o botão "SEND" no Boomerang, voltamos a ter um retorno apropriado.

Assim, temos um controle fácil sobre o serviço. A qualquer momento, podemos ver o _status_ (`sudo systemctl status doguito-api.service`), parar o serviço (`sudo systemctl stop doguito-api.service`) e reiniciá-lo (`sudo systemctl start doguito-api.service`).

Além disso, um bom procedimento que podemos realizar é fazer com que o serviço se inicie automaticamente junto do sistema operacional, com o comando `sudo systemctl enable doguito-api.service`. Tudo funcionando, podemos mandar requisições pelo Boomerang sem problemas.

Para confirmarmos, vamos executar o `exit` e encerrar o terminal Cloud Shell. Pressionando o botão "SEND" no Boomerang, verificamos que o serviço continua funcionando. Resta realizarmos os testes que tínhamos começado no início desse vídeo.

Para fazer a **listagem**, vamos mandar um GET para a URL `http://132.226.245.137:3000/clientes`. Teremos como retorno um objeto do tipo **_array_**.

Para fazer o **detalhamento**, basta acrescentar `/` e o ID do usuário. Diferentemente do anterior, o retorno é um objeto só. Se colocarmos um ID que não existe, o retorno será 404, o código de erro HTTP de "não encontrado".

A seguir, **criaremos** uma entidade. Vamos alternar do método GET para o POST, na caixa de seleção à esquerda da URL que informamos. Logo abaixo, há uma barra com as opções "BODY", "HEADERS", "QUERY STRINGS", "AUTH" e "ASSERTION". Marcaremos o "BODY" como conteúdo do tipo "JSON" e, na área de código, informaremos o objeto:

```perl
{
    "nome": "Tiago",
    "email":"tiago@gmail.com"
}
```

Note que não informamos o ID, pois ele será atribuído automaticamente.

Na aba "HEADERS", informaremos que tipo de conteúdo estamos mandando. Vamos clicar no botão "Add Header" na parte inferior direita e preencher os campos "Name" e "Value" com "Content-Type" e "application/json", respectivamente. Podemos clicar no botão "SEND" para enviar a requisição para a URL, sem ID.

Para confirmar que a entidade foi criada, vamos voltar para o método GET e pressionar "SEND". Perceberemos que agora há duas instâncias. Na própria interface _web_ do gerenciador de banco de dados, ao pressionar o _play_ novamente, teremos duas instâncias também: Tiago e Paulo.

Agora, temos a opção de fazer o detalhamento do usuário Tiago, usando seu ID.

Assim, já testamos a **criação**, a **listagem** e o **detalhamento**. Em seguida, vamos fazer a **alteração** de dados. Para tanto, mudaremos para o método PUT e manteremos a URL com o ID do usuário Tiago. Na área de código, vamos modificar o e-mail do usuário:

```perl
{
    "nome": "Tiago",
    "email": "tiago@outlook.com"
}
```

Pressionaremos "SEND" e, em seguida, vamos conferir na interface _web_ que as informações do usuário foram devidamente alteradas.

A última operação é a **exclusão**. Colocaremos o método DELETE e, com a mesma URL, clicaremos em "SEND". Teremos um resultado 204, sem conteúdo, como esperado. Se realizarmos a listagem mais uma vez, notaremos que Tiago não existe mais.

Nesse vídeo, conseguimos avançar em dois passos importantes. Em primeiro lugar, conseguimos rodar nossa aplicação como um serviço do sistema operacional. Agora, toda vez que a máquina for iniciada, o serviço já ficará ativo, não mais vinculado ao Cloud Shell. Depois, realizamos as operações básicas do **CRUD** (_create, read, update, delete_). Recomendo bastante o uso desse _plugin_ de navegador, pois facilitará os testes de envio de requisições, mas o comando `curl` da linha de comando também é uma opção para quem tem mais familiaridade.

Até a próxima aula!


-----------------------------------------------------------------------
# 06Faça como eu fiz: testando a API REST do Doguito

Testamos a API REST do Doguito utilizando um plugin de navegador. Existem várias opções de plugins de navegadores, mas utilizamos o Boomerang, que está disponível nos links abaixo:

- [Chrome](https://chrome.google.com/webstore/detail/boomerang-soap-rest-clien/eipdnjedkpcnlmmdfdkgfpljanehloah?hl=pt-BR)
- [Edge](https://microsoftedge.microsoft.com/addons/detail/boomerang-soap-rest-c/bhmdjpobkcdcompmlhiigoidknlgghfo)

Se você usa o Firefox, uma opção é o [RESTClient](https://addons.mozilla.org/pt-BR/firefox/addon/restclient/).

Porém, vimos que a execução do Doguito está sendo realizada de forma manual, o que não é ideal, uma vez que se a instância for reiniciada ou ocorrer algum problema, o Doguito não será executado de novo. Para evitar este problema, convertemos o Doguito em um serviço do Systemd.

Agora é com você, faça os ajustes recomendados e teste o Doguito API com um cliente REST. Se tiver alguma dificuldade, use o fórum para conversar com outras pessoas sobre sua dúvida!

-----------------------------------------------------------------------
# 07Para saber mais: tecnologias do Doguito

Nossa aplicação de exemplo que será implantada na Oracle Cloud é desenvolvida utilizando JavaScript, NodeJS e o framework Express. Para o nosso curso não será necessário conhecimento profundo de desenvolvimento de aplicações usando estas tecnologias, pois focaremos mais na infraestrutura de implantação.

No entanto, caso você se interesse por esta pilha tecnológica ou queira se aprofundar mais nos assuntos, recomendo dar uma olhada na [Formação Node.js com Express](https://www.alura.com.br/formacao-node-js-express) que também está disponível aqui na plataforma Alura.


-----------------------------------------------------------------------
# 09O que aprendemos?

## Nessa aula, você aprendeu:

- Que o Doguito API é uma aplicação que expõe uma API REST escrita em JavaScript utilizando o framework Express.js e que é executada pelo Node.js;
- Que é necessário instalar o git para clonar nosso projeto para a instância, além de ser necessário instalar o Node para executar o Doguito API e outros drivers de bancos de dados específicos da Oracle;
- Que fazemos o download da Wallet de conexão do banco de dados para que nossa instância possa acessar o DOGUITODB;
- Que podemos criar um serviço do systemd para que a aplicação do Doguito API inicie automaticamente com nossa instância;
- Que é necessário liberar o acesso à porta 3000 no firewall da instância e criar uma regra de acesso na lista de segurança da rede virtual para que possamos acessar o Doguito API;
- Que podemos utilizar um cliente REST como o Boomerang para acessar nossa API do Doguito.


-----------------------------------------------------------------------
# 01Projeto da aula anterior

Para esta aula usaremos alguns arquivos que estarão disponibilizados para download neste [link](https://cdn3.gnarususercontent.com.br/2487-oracle-cloud-infrastructure-dados-infraestrutura-codigo/05/doguito-site-object-storage.zip).

-----------------------------------------------------------------------
# 02Armazenamento na OCI

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105753

## Transcrição

Olá, tudo bem? Chegou o momento de entendermos um pouco melhor como fazer o armazenamento de arquivos dentro da OCI. Você pode estar se perguntando: não basta criar uma instância de _compute_ e salvar os arquivos? Sim, esta é uma possibilidade, porém ela torna o gerenciamento bastante complicado. Por isso, neste vídeo, vamos aprender sobre algumas opções bem mais avançadas para **gerenciamento de arquivos** dentro da OCI. Essas opções estão no menu da OCI, no tópico "Armazenamento" (em inglês, _Storage_).

Para escolhermos qual tipo de armazenamento é mais conveniente para nosso projeto, precisamos compreender as **características dos dados** que pretendemos armazenar, por exemplo, se é uma informação persistente ou não (ou seja, se é necessário fazer _back-up_ ou se poderá ser descartada).

Além disso, é interessante conhecer o **tipo de dados** que será armazenado, se é um banco de dados, um arquivo de vídeo ou de áudio, uma fotografia ou um texto etc.

Ademais, o **tipo de performance** também é importante: precisamos de um armazenamento mais rápido ou pode ser um pouco mais lento? É preciso pesar as necessidades, visto que uma melhor performance está diretamente ligada a um maior custo.

Também devemos pensar na **capacidade de armazenamento**, quantos _gigabytes_ precisaremos.

Outros pontos importantes para considerar antes de escolher o tipo de armazenamento são quantas **operações de _input_ e _output_** serão necessárias para nossos arquivos e qual **taxa de transferência** (velocidade de transferência de dados) queremos.

Mais um passo relevante é a **durabilidade**, que define quantas cópias dos dados vamos manter. Nesse cenário, a persistência significa armazenar os dados de forma segura, e a durabilidade refere-se à quantidade de cópias — caso uma delas apresente algum problema, temos outra por segurança.

A **forma de conectividade** com a instância de dados também é importante. Podemos definir, por exemplo, se preferimos uma conectividade como um HD local ou como um armazenamento de rede. Quanto aos **protocolos**, temos opções como bloco, _file_ ou HTTP.

É essencial analisarmos esses requisitos para decidir qual tipo de _storage_ utilizar.

O primeiro tipo de armazenamento disponibilizado pela OCI é o **NVMe**, que basicamente é uma instância de um HD dentro do _data center_, ligada fisicamente ao servidor — semelhante aos nossos computadores locais, nas nossas casas, com o HD ligado fisicamente à máquina. Na OCI, esse HD é um SSD de altíssima performance, destinado a ser utilizado por aplicações mais sensíveis e que necessitam de uma performance muito alta.

A segunda opção, o **armazenamento em blocos**, seria como se pegássemos esse HD que está fisicamente na máquina e o movêssemos para outra máquina dentro do mesmo _data center_, de modo que seria um HD num **servidor dedicado**, não mais ligado fisicamente à máquina. A vantagem desse tipo de _storage_ é que podemos ter a persistência e a durabilidade independentes do _compute_ ao qual o HD estava ligado inicialmente, há uma maior flexibilidade. Separando o HD da máquina, ela tem total controle sobre a partição criada (formatação, particionamento, montagem do _file system_ etc).

Observando no menu da OCI, abaixo do tópico de "Armazenamento em Blocos" em que temos todo o controle sobre a partição que estará em outra unidade de rede, temos a opção de **armazenamento de arquivos** (_file storage_). Trata-se de uma alternativa semelhante à anterior, dado que o armazenamento estará em outra instância no mesmo _data center_, porém o _file storage_ pode ser compartilhado entre duas instâncias de _compute_. Então, por exemplo, se temos duas instâncias de _compute_ que precisam usar os mesmos arquivos, o armazenamento de arquivos permite esse compartilhamento (o que não é possível no armazenamento em bloco). Assim, todas as instâncias com acesso a esse armazenamento de arquivos podem ler e escrever. Nesse caso, o nível de gerenciamento que a máquina tem é sobre arquivos e diretórios, não gerenciamos partições — apenas montamos o _file system_ e a instância estará pronta para uso. Ou seja, está em um nível um pouco mais alto de abstração.

Por fim, o elemento de maior nível de abstração é o **_object storage_**, destinado justamente ao armazenamento para _web_, no qual armazenamos fotos, vídeos, arquivos de _log_, arquivos de texto. A vantagem dele é ser acessível através de HTTP, ou seja, não é um ponto de montagem como as duas opções anteriores, não é necessário montar o _file system_.

O _object storage_ pode nos servir para simplificar o Doguito, em especial a parte do _front-end_. Podemos implantar no _object storage_ nossos arquivos `.html`, `.css` e `.js` que farão depois a comunicação com a API. Ele é uma plataforma de armazenamento de alta performance, direcionado para o uso pela internet. Os dados são gerenciados como objetos, ideal para dados não-estruturados — diferente, por exemplo, de um banco de dados relacional. Então, para arquivos em geral (como textos, fotos e vídeos) o _object storage_ é um tipo de armazenamento bem adequado. O acesso ao conteúdo pode ser público ou privado, além de outros recursos mais avançados.

A seguir, vamos ver alguns casos de uso do _object storage_. Como foi comentado anteriormente, ele pode ser utilizado para dados estruturados e semi-estruturados, Big Data, Analytics, servidor de _back-up_ e os arquivos serão salvos como objetos.

No menu da OCI, vamos em "Armazenamento > Serviços Object Storage and Archive Storage" para criar um _object storage_. Na nova página, clicaremos no botão "Criar Bucket". Mais adiante, veremos detalhes dessa criação; por ora, apenas pressionaremos o botão "Criar" ao final da página, sem modificar nada. Agora, os conteúdos já podem ser armazenados como objetos.

Objetos são elementos compostos por uma chave (nome do arquivo) e um valor (conteúdo do arquivo). Além disso, eles também podem ter alguns metadados customizados. Os objetos serão armazenados no que chamamos **_buckets_** que, por sua vez, têm nome único.

É interessante apontar que é utilizada a **estrutura de arquivos plana**, ou seja, como se fosse um HD com todos os arquivos na raiz. Apesar disso, temos como "imitar" uma estrutura de pastas e, ao visualizá-a, constataremos que as pastas serão prefixos dos arquivos. Em resumo, usa-se a estrutura plana, mas conseguimos "imitar" uma estrutura de pastas. Veremos isso mais adiante.

Ademais, há o conceito de _namespace_, que é um contêiner de nível superior para todos esses _buckets_ e que também possui um nome único.

A seguir, vamos entrar no _bucket_ que acabamos de criar, clicando sobre seu nome. Descendo um pouco a página, na área "Objetos", pressionaremos o botão "Fazer upload". Vamos subir um arquivo bem básico, somente a título de exemplo: basta arrastar o arquivo `favicon.ico` e clicar em "Fazer upload" na parte inferior da tela. Na sequência, podemos clicar no botão "Fechar", também na parte inferior.

Feito o _upload_, vamos exibir os detalhes desse novo objeto. Podemos copiar a URL onde ele está disponível e, numa nova aba do navegador, acessá-la. Note que o caminho dessa URL é composta por várias divisões: a região onde estamos, o _namespace_, o _bucket_ que criamos e, por fim, o objeto.

Observando o conteúdo da página, veremos uma mensagem de que o _bucket_ não foi encontrado, explicando que ou ele não existe nesse _namespace_, ou não temos autorização para acessá-lo. Obtemos esse resultado porque esse _bucket_, por padrão, tem a visibilidade privada. Voltando à página de informação do _bucket_, na parte superior, clicaremos no botão "Editar Visibilidade" e alterar para a opção "Público". Em seguida, podemos voltar à aba anterior e recarregá-la. Dessa vez, conseguiremos acessar a imagem.

Desse modo, já que conseguimos colocar um arquivo de ícone, bem simples, talvez possamos subir todo o nosso _front-end_! É esse processo que realizaremos na próxima aula: subir um site estático no _object storage_.


-----------------------------------------------------------------------
# 03Doguito no Object Storage

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105754

## Transcrição

Nosso próximo objetivo é **implantar o _front-end_** do Doguito Pet Shop em um _object storage_. O _front-end_ é composto por arquivos **estáticos**, como `.html`, `.css`, `.js` e imagens, que são armazenados no servidor e retornados em sua forma nativa, sem nenhum tipo de processamento.

No menu da OCI, vamos em "Armazenamento > Serviços Object Storage and Archive Storage" e pressionaremos o botão "Criar Bucket" para criar uma área de armazenamento, como se fosse uma pasta. Daremos um nome para esse _bucket_, vamos chamá-lo de "site".

Em seguida, temos várias opções — desta vez, vamos analisá-la com mais calma. A primeira configuração é relativa à **camada de armazenamento padrão** e nela temos níveis, por exemplo, padrão e arquivo compactado.

O **nível padrão** (_standard_, em inglês) define que todos os dados recuperados sejam retornados de forma instantânea. Ele é bastante consistente: cada vez que as informações forem atualizadas, sempre serão retornadas cópias mais recentes.

Há também o **acesso infrequente**, para dados críticos que não têm acesso instantâneo, por exemplo, arquivos de _back-up_. Nessa categoria de armazenamento, os dados devem ser guardados por, no mínimo, 31 dias. A principal vantagem desse nível é ser 60% mais barato que o armazenamento padrão, portanto, dependendo da velocidade que precisamos e do tempo pelo qual armazenaremos os dados, faremos uma escolha que vai interferir no custo — optar pela opção mais rápida torna seu sistema mais caro. No caso do armazenamento infrequente, a taxa cobrada é aquela de quando se faz a recuperação dos dados.

O último nível é o de **arquivo**, direcionado para dados que não precisamos imediatamente, que funciona como se fosse um armazenamento mais antigo (que chamávamos armazenamento em fita), porém na Cloud há mais recursos. O tempo mínimo de retenção dos arquivos é de 90 dias. Nesse caso, há um processo de restauração dos arquivos (que demora, no mínimo, uma hora) e, em seguida, podemos fazer o _download_.

Por ora, deixaremos no "Padrão".

Ademais, existe uma _feature_ interessante chamada **_auto-tiering_**, que observa nossos arquivos e faz a movimentação entre as camadas _standard_ e _infrequent access_, conforme o uso. Em outras palavras, se guardamos um arquivo no _standard_ porém não o acessamos por um tempo, ele será automaticamente movido para um nível mais barato de armazenamento; caso voltemos a usá-lo, ele retornará ao nível _standard_. Essa é uma ótima maneira, (automática e sem custos adicionais) de otimizar e reduzir o custo de utilização do _storage_. Para ativar essa _feature_, vamos selecionar "Ativar Armazenamento Automático em Camadas".

Em seguida, temos a opção de ativar o **controle de versão de objetos**. Dessa forma, os dados sempre serão versionados automaticamente, em vez de serem substituídos — quando enviarmos um arquivo com o mesmo nome, ele será versionado, de modo que podemos recuperá-lo posteriormente. Não vamos selecionar essa opção agora.

A **encriptação** dos dados também é importante, visto que a nuvem pode ter dados bastante sensíveis. No nosso _bucket_, os dados sempre são encriptados automaticamente e, no caso, nem sequer temos a opção de **não** encriptá-los. Vamos manter a primeira opção selecionada.

Essas configurações bastam, podemos pressionar no botão "Criar" ao final da aba. Em seguida, entraremos nesse _bucket_, clicando sobre seu nome, e subiremos os arquivos. Para este próximo passo, é necessário que você faça o _download_ e descompacte o arquivo `doguito-site-object-storage.zip`, disponibilizado no próximo tópico desta aula.

Na área "Objetos" desta página, vamos clicar no botão "Fazer Upload", arrastar o arquivo `index.html` para a área de _upload_ e pressionar "Fazer Upload". Esse processo deve ser bem rápido. Em seguida, vamos repetir esse processo com o arquivo `favicon.ico`.

Agora, faremos o _upload_ de arquivos que estão dentro de pastas. Na pasta que descompactamos, existe um diretório chamado `css`, portanto vamos **preencher o campo "Prefixo do Nome do Objeto" com "css/"**, arrastar o arquivo `styles.css` para a área de _upload_ e clicar em "Fazer Upload".

Depois, faremos o mesmo para `images`: o prefixo será "images/" e subiremos o arquivo `doguitoadm.svg`. Perceba que, na área "Objetos" da página, a estrutura de pastas está sendo montada. Por fim, faremos o _upload_ do arquivo `scripts.js`, na pasta `js` (ou seja, usaremos o prefixo "js/").

Pronto, já podemos acessar os arquivos. À direita do nome `index.html`, podemos clicar para exibir os detalhes, copiar o caminho do URL e abrir em uma nova aba do navegador. A princípio, obtemos um erro relativo à autorização de acesso (o mesmo que vimos em uma aula anterior). Basta editarmos a visibilidade, tornando o _bucket_ público.

Ao tentar abrir aquela URL mais uma vez, a página inicial será carregada (o _front-end_ está funcionando), porém surgirá uma mensagem do navegador. Note que os clientes não estão listados na página. Precisamos apontar qual o endereço do nosso servidor de API. Para tanto, em nosso computador, vamos editar o arquivo `scripts.js`. Você pode usar o seu editor de preferência; caso não tenha nenhum, o Bloco de Notas será suficiente.

Abrindo o arquivo, na segunda linha, veremos `'http://???:3000/clientes'` — precisamos substituir essas interrogações pelo IP da nossa instância. No menu da OCI, vamos em "Computação > Instâncias" e copiaremos o IP público da `dps-vm1`, que é onde subimos o Doguito. Podemos abrir em outra aba, acessando a porta 3000, para nos certificar de que está funcionando. Em seguida, vamos substituir as interrogações por esse IP e salvar o arquivo.

Agora, é necessário substituir o arquivo `scripts.js` no _object storage_. No menu da OCI, vamos em "Armazenamento > Buckets" e entraremos em "site". Vamos excluir o arquivo `scripts.js` existente e fazer o _upload_ do arquivo atualizado, usando o prefixo "js/".

Vamos tentar acessar o `index.html` de novo. Veremos que a lista de clientes ainda não foi carregada e, desta vez, a mensagem é diferente: falha ao fazer o _fetch_.

No navegador, pressionaremos a tecla "F12" para abrir o console de desenvolvedor. Podemos consultar a aba "Console" e pressionar a tecla "F5" para recarregar a página. Veremos um aviso de que essa página `index.html` foi carregada com HTTPS, porém fez uma requisição para um conteúdo inseguro em HTTP (o `/clientes` da API) e foi bloqueado. Este conteúdo deve ser carregado por HTTPS também.

Em outras palavras, o site abriu — o HTML, o CSS, o JS e as imagens carregaram normalmente —, entretanto, no momento em que esse _front-end_ tentou se comunicar com o _back-end_ ocorreu um problema. O _front-end_ foi carregado sobre HTTPS, um protocolo seguro, e por esse motivo não podemos fazer requisições AJAX para um site inseguro, via HTTP. O navegador vai bloquear. Então, apesar de termos conseguido carregar o _front-end_ do Doguito corretamente, ainda não conseguimos fazer a comunicação com o servidor de _back-end_. Vamos corrigir essa questão na próxima aula!


-----------------------------------------------------------------------
# 04Faça como eu fiz: servindo o site estático do Doguito

Aprendemos a criar um bucket público de um Object Storage que nos permitiu servir o site estático do Doguito, ou seja, arquivos HTML, CSS e JavaScript de forma muito simples e prática.

É a sua vez de fazer o mesmo! Para isso, será necessário baixar o [arquivo do curso](https://cdn3.gnarususercontent.com.br/2487-oracle-cloud-infrastructure-dados-infraestrutura-codigo/05/doguito-site-object-storage.zip) “doguito-site-object-storage.zip” em zip, criar um bucket e fazer o upload dos arquivos.

-----------------------------------------------------------------------
# 05SSL no Load Balancer

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105755

## Transcrição

Terminamos nossa última aula com um problema: carregamos os arquivos estáticos do _front-end_ (HTML, CSS, JS) do Doguito através do _object storage_, que serve esse conteúdo por meio do protocolo HTTPS. No entanto, o nosso _back-end_ (nossa API) é servido através do protocolo HTTP e o navegador não permite que, a partir de uma página com HTTPS, faça requisições HTTP. A seguir, descobriremos como resolver essa questão.

Teremos que colocar um **certificado HTTPS** e o primeiro passo é criá-lo. Para tanto, no Cloud Shell, vamos executar o comando `openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -sha256 days 365` para criar um certificado com o algoritmo `sha256` válido por 365 dias. Este certificado é autoassinado e não tem muito valor. Em geral, emitimos por uma **entidade certificadora** para, de fato, ter melhor validade. Mas, no nosso caso, este serve.

Será pedida uma senha, podemos colocar "doguito", e na sequência teríamos que preencher mais algumas informações. No nosso contexto, podemos deixar tudo em branco e só apertar a tecla "Enter" até finalizar. Rodando o `ls` no diretório, veremos que foram criados os arquivos `cert.pen` e `key.pen`.

Agora, veremos como criar esse acesso HTTPS. Poderíamos entrar no servidor que está servindo na porta 3000 e configurá-lo para HTTPS, no entanto, no dia a dia, a terminação do HTTPS é feita no _load balancer_. Portanto, para já nos acostumarmos com cenários reais, vamos ativar o HTTPS no _load balancer_. A requisição chegará ao _load balancer_ em HTTPS e, em seguida, fluir em HTTP para a nossa máquina virtual em execução.

No menu da OCI, vamos em "Rede > Balanceadores de carga", onde já temos um _load balancer_ configurado — vamos acessá-lo. A primeira alteração será importar o certificado na aba "Certificados": selecionaremos a opção "Certificado Gerenciado pelo Balanceador de Carga" e clicaremos no botão "Adicionar Certificado". Colocaremos o nome "doguito-cert".

Precisamos arrastar o arquivo para fazer _upload_, porém ele está no Cloud Shell, então, no canto esquerdo superior desse console, vamos clicar em "Fazer download" e informar o nome do arquivo `cert.pen` e repetir o processo com `key.pen`. Em seguida, basta arrastar o arquivo `cert.pen` para a área de _upload_ do "certificado SSL", depois selecionar a opção "Especificar Chave Privada" e arrastar o arquivo `key.pen` para a área de _upload_ de "Chave Privada". Abaixo dessa área, teremos que informar a senha "doguito". Por fim, clicamos em "Adicionar Certificado" ao final da página. Haverá uma mensagem de confirmação.

Na aba "Certificados", podemos verificar o certificado disponível. Às vezes, ele pode demorar um pouco para ser carregado. Além disso, não podemos nos esquecer de selecionar a opção "Certificado Gerenciado pelo Balanceador de Carga".

Agora, é necessário fazer um ajuste no _load balancer_ para que ele também aceite conexões HTTPS. Neste momento, se copiarmos o IP público do balanceador de carga, o abrirmos em uma nova aba do navegador e adicionarmos `https://` ao início da URL, a página não será carregada. Vamos resolver essa questão a seguir.

Na aba "Listeners", veremos que já temos um _listener_ para a porta 80. Vamos criar mais um, clicando no botão "Criar Listener". Daremos o nome "listener-https", especificaremos o protocolo como "HTTPS" e manteremos a porta 443. A seguir, vamos selecionar "Certificado Gerenciado pelo Balanceador de Carga" e automaticamente o `doguito-cert` será escolhido. Depois, vamos definir o conjunto de _back-end_ para o qual o tráfego deve ser direcionado (só há uma opção) e finalmente clicaremos no botão "Criar Listener" ao final da página. Haverá uma mensagem de confirmação. Na aba "Listeners", podemos verificar o novo _listener_ disponível.

Vamos tentar novamente acessar o IP público do _load balancer_ com o certificado HTTPS. Ainda não está funcionando, porque configuramos nossa VCN para aceitar entrada de tráfego na parte pública somente da porta 80. No menu da OCI, em "Rede > Redes Virtuais na Nuvem", vamos entrar na VCN1 e ajustá-la. Na área "Listas e Segurança", entraremos em "Default Security List for VCN1" e clicaremos no botão "Adicionar Regras de Entrada". No campo "CIDR de Origem", colocaremos 0.0.0.0/0. Quanto à porta de destino, definiremos 443.

Após fazer a ativação, vamos recarregar a aba com o IP público do _load balancer_. Aparecerá uma mensagem: "Sua conexão não é privada". Como fomos nós mesmos que emitimos o certificado, é necessário autorizarmos o _browser_. Clicaremos no botão "Avançado" e permitiremos que ele continue.

Conseguimos acessar, porém, se adicionarmos `/clientes` ao final da URL, haverá um erro "Not Found" (não encontrado). Isso acontece porque a página Doguito Petshop Server 1 (e Doguito Petshop Server 2) é exibida pelo serviço do Apache, na porta 80, ou seja, todo tráfego de entrada chegando no _load balancer_ é redirecionado para a porta 80. Precisamos redirecionar para a porta 3000, onde está a API do Doguito.

No menu da OCI, entraremos em "Rede > Balanceadores de Carga" e acessaremos o nosso _load balancer_. Em seguida, em "Conjuntos de Backend", vamos entrar na única opção que temos e, na aba "Backends", veremos que há dois _backends_ registrados — um de final 173 e o outro 77. Ambos direcionados para a porta 80.

Nós instalamos o Node em apenas uma das instâncias, a `dps-vm1`, cujo IP termina em 173. Então, por ora, vamos excluir do balanceador de carga a instância de final 77. Basta selecioná-la e, no menu "Ações", clicar em "Excluir".

Feito esse procedimento, no _backend_ restante, precisamos mudar a porta 80. Com ele selecionado, no menu "Ações" clicaremos em "Editar Porta" e definiremos a porta 3000, que é onde está rodando o Node.

Agora, vamos acessar o IP do balanceador de carga e conseguiremos ver a página do Doguito API, com o protocolo HTTPS. Se adicionarmos `/clientes` ao final da URL, será retornada a lista de clientes. Portanto, é este IP do _load balancer_ que usaremos, devemos atualizar essa URL no arquivo `scripts.js`.

Na interface da OCI, no _bucket_ "site", vamos apagar o arquivo `scripts.js`. Em nosso computador, vamos abrir o `scripts.js` e, na segunda linha, alterar o caminho da URL para conferir com o IP do _load balancer_, com protocolo HTTPS e final `/clientes`. Salvaremos o arquivo e faremos o _upload_ novamente, para a pasta `js.`.

Acessando mais uma vez o _front-end_, desta vez a lista de clientes será carregada. A comunicação entre o _front-end_ e o _back-end_ foi bem-sucedida. Uma vez que o _back-end_ também está em HTTPS, o _browser_ não bloqueou a comunicação.

-----------------------------------------------------------------------
# 06Faça como eu fiz: Doguito API com SSL


Vimos que para que nosso front-end possa se comunicar com a API é necessário que ambos utilizem protocolo HTTPS. Dessa forma, precisamos de um meio para acessar a API do Doguito via HTTPS.

A forma mais comum de fazer isso é um certificado HTTPS no balanceador de cargas, então é necessário criar um certificado, importá-lo no balanceador e em seguida incluir um listener para a porta 443 no balanceador. Por fim, fazemos ajustes para que as requisições do balanceador sejam direcionadas para o back-end na porta 3000.

Ajustado esse primeiro passo, em seguida devemos alterar o arquivo scripts.js, que passará a apontar para o IP público do balanceador de cargas e utilizar o protocolo HTTPS. Agora é sua vez de fazer a ativação.

-----------------------------------------------------------------------
# 07Para saber mais: Object Storage na OCI

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105797


Object Storage é um conceito novo que tem se popularizado em diversos fornecedores de Cloud. Isso se deve à sua facilidade de criação e baixa necessidade de manutenção. Seus usos podem variar desde a utilização para upload de conteúdo de usuários até mesmo persistência de configuração das aplicações. Para saber um pouco mais se Object Storagm, assista a este video da Oracle que explica muitas características do Object Storage:

O conteúdo em video pode apresentar alguns tópicos desatualizados, por isso, todos os detalhes sobre a utilização de Armazenamento na OCI podem ser também encontrados na documentação oficial na seção “Armazenamento”, através dos links [https://docs.oracle.com/pt-br/iaas/Content/home.htm](https://docs.oracle.com/pt-br/iaas/Content/home.htm) e [https://docs.oracle.com/es-ww/iaas/Content/home.htm](https://docs.oracle.com/es-ww/iaas/Content/home.htm).

-----------------------------------------------------------------------
# 08Tipo de armazenamento adequado

A OCI oferece diversos tipos de armazenamento para cada caso de uso e necessidade. Quando criamos uma instância, ela está associada a um volume de inicialização que possui a imagem do sistema operacional para realizar o boot. Caso essa instância necessite expandir seu armazenamento ou caso desejarmos manter arquivos que serão preservados mesmo se a instância for destruída, devemos utilizar um tipo de armazenamento específico para isso.

Selecione a alternativa que corresponde ao armazenamento mais adequado neste caso.

Volume em blocos.

Alternativa correta. 
O serviço de volume de blocos permite provisionar e gerenciar dinamicamente volumes de armazenamento em bloco como se fossem uma unidade de disco rígido comum. Você também pode desconectar um volume e anexá-lo a outra instância sem perda de dados. Esta é a opção mais adequada para expandir a capacidade de armazenamento de uma instância.


-----------------------------------------------------------------------
# 09O que aprendemos?


## Nessa aula, você aprendeu:

- Que a OCI oferece diversos tipos de armazenamento para sua aplicação, como o armazenamento em blocos, armazenamento de arquivos e o Object Storage. Cada categoria apresenta diversas características de performance e durabilidade, devendo ser avaliadas as necessidades específicas de cada caso de uso;
- Que o Object Storage permite acesso HTTPS direto aos recursos, a partir da definição de um namespace e de um bucket;
- Que podemos utilizar o Object Storage para armazenar e servir o front-end do Doguito Petshop, sendo uma forma simplificada para servir um site via HTTPS;
- Que quando o front-end é servido em HTTPS é necessário que o backend também seja servido em HTTPS para que o navegador aceite realizar requisições AJAX entre os domínios.

-----------------------------------------------------------------------
# 01Projeto da aula anterior


Para esta aula usaremos alguns arquivos que estarão disponibilizados para download neste [link](https://cdn3.gnarususercontent.com.br/2487-oracle-cloud-infrastructure-dados-infraestrutura-codigo/04/2022-03-15%2002.19.44%20-orm-dps.zip).

-----------------------------------------------------------------------
# 02O que é infra como código

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105756

## Transcrição

Para entendermos o conceito de infraestrutura como código, primeiro temos que compreender o histórico de desenvolvimento das aplicações e como ele evoluiu com o tempo.

Inicialmente, tínhamos aplicações que chamávamos de **monolito** — até hoje há quem siga essa filosofia, essa estratégia. Em aplicações monolíticas, todas as funcionalidades estão empacotadas juntas, como um grande programa executável. Assim, temos a parte de usuários, de produtos, de vendas dentro de uma única unidade.

Com o passar do tempo e com a necessidade de escalar as aplicações, percebeu-se que existem algumas desvantagens no uso desse modelo. Quando um componente falha, por exemplo, todo o pacote falha. Se tivermos um problema na compilação ou execução da parte de usuários, o aplicativo inteiro deixa de funcionar.

Já para escalar a aplicação, no modelo monolítico, é necessário escalar todas as funcionalidades. Se temos um número de usuários maior e queremos replicar a aplicação, teríamos que replicá-la como um todo (usuário, produtos, vendas), mesmo que a necessidade seja em apenas um dos módulos. Esse processo seria um desperdício de recursos.

Além disso, para construirmos e implantarmos a aplicação no modelo de monolito, todo o pacote deve ser implantado. Assim, quanto maior for a aplicação (pois ao longo do desenvolvimento inserimos mais e mais recursos), mais difícil fica essa implantação.

Outra questão é relativa à linguagem de desenvolvimento. Como a aplicação é um grande monolito, todo o pacote deve ser escrito em uma mesma linguagem de programação. Por exemplo, se utilizamos Java para codar a parte de usuários, somos obrigados a usar Java para produtos e vendas também. Atualmente, com o aumento da diversidade de tecnologias, muitas vezes existe uma linguagem mais apropriada para cada um desses módulos, mas no modelo monolítico temos essa restrição.

Por causa de todas essas desvantagens, surgiu a **arquitetura de microsserviços**, em que cada microsserviço possui uma tarefa simples. Então, por exemplo, a parte de usuários ficará responsável somente por processos relacionados a usuário (cadastrar, listar, excluir usuários etc); a parte de produtos trabalhará apenas com produtos (cadastrar, alterar, excluir produtos etc) e assim por diante. Ou seja, em vez de ter uma única aplicação, um monolito, teremos várias aplicações pequenas, cada qual realizando um pequeno serviço, um microsserviço.

Os microsserviços se comunicam através de um protocolo leve, como uma API REST. Ademais, cada funcionalidade pode ser escalada de forma independente. Por exemplo: se sabemos que, na Black Friday, teremos maior pressão sobre o módulo de vendas, podemos levantar novas instâncias somente desse módulo, para atender mais usuários. No modelo monolítico, seria necessário escalar toda a aplicação, gerando desperdício de recursos.

Outra característica notável dos microsserviços é que são desacoplados, permitindo que a aplicação mantenha a disponibilidade mesmo que ocorra uma falha em um dos seus componentes. Supondo que haja um problema no cadastramento de usuário, que a comunicação com o banco de dados esteja comprometida, o resto da aplicação (como cadastramento de produtos ou realização de vendas) permanece funcionando, pois são desacoplados.

Existem ainda muitos outros benefícios e, por causa disso, a arquitetura de microsserviços tem evoluído rapidamente e tem sido adotada amplamente pelas empresas.

Entretanto, surgem também alguns desafios. Uma vez que não implantaremos somente um monolito, mas, sim, **várias** aplicações (o que gera mais trabalho), há um aumento da complexidade geral do sistema, por isso, precisamos ter em mente algumas considerações.

Por exemplo, trabalhando nesse modelo de microsserviços, em geral, temos lidar com **infraestrutura como código**, em que tratamos os recursos de infraestrutura (disponibilidade do disco rígido, quantidade de CPUs, entre outros) como um código escrito. Então, teremos algum tipo de programa ou documento digital que descreverá a infraestrutura.

A vantagem é que, da mesma forma que podemos versionar um sistema em desenvolvimento, temos a opção de fazer o mesmo com a infraestrutura. Como a descrevemos de forma digital, podemos replicá-la e implantá-la automaticamente por meio de uma ferramenta que realize esse processo por nós, sem a necessidade de irmos à interface e escolhermos as configurações uma a uma. Simplesmente aplicamos um código-fonte que descreve essa infraestrutura e ela será montada. Esse recurso também facilita o compartilhamento do documento descritivo com outros times, caso precisem de uma referência.

A **utilização de contêineres**, como Docker e Kubernetes, é outro ponto interessante dos microsserviços, em especial a questão de portabilidade. Um mesmo contêiner pode ser implantado em várias infraestruturas diferentes, na própria máquina do desenvolvedor ou num ambiente de _cloud_, facilitando a adoção da filosofia de DevOps.

Em outras palavras, para uma mesma infraestrutura, um mesmo sistema operacional, rodamos o Docker e nele colocamos várias aplicações, que podem ser os microsserviços.

Outro item importante desse modelo é o **API Gateway**. Os microsserviços precisam se comunicar entre si e também com o mundo externo, então é essencial considerarmos a questão de segurança. Anteriormente, trabalhamos com _gateways_ durante a criação da VCN: um para se comunicar com a internet, outro para serviços. Nesse caso, criaremos um _gateway_ para comunicar os microsserviços e fazer reforços de políticas de segurança.

Existem mais pontos importantes relativos aos microsserviços, mas de modo geral, no que tange a adoção das empresas, esses três pontos são os mais destacados: implantação de infraestrutura como código, conteinerização das aplicações e o API gateway.

No menu da OCI, no item "Serviços ao Desenvolvedor", podemos ver o que a OCI pode oferecer para facilitar a nossa jornada de desenvolvimento. Temos opções como "Gerenciamento de Recursos" que trabalha a infraestrutura como código; "Funções", que lida com a parte de Serverless, caso nosso objetivo seja trabalhar sem um servidor, com o Lambda; "Contêineres e Artefatos", onde encontramos o Container Engine for Kubernetes (OKE) e funcionalidade de registros de contêineres e artefatos (nossos binários); e, por fim, "Gerenciamento de API", que inclui os API Gateways, gerenciando a parte de comunicação entre nossos microsserviços e a internet.

Com essas ferramentas à nossa disposição, nosso caminho para trabalhar com microsserviços e uma arquitetura mais desacoplável e mais escaláveis se torna muito mais simples.

-----------------------------------------------------------------------
# 03O gerenciador de recursos

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105757

## Transcrição

Nas aulas passadas, criamos uma instância do Doguito API. Vamos acessá-la. No menu da OCI, em "Computação > Instâncias", vamos copiar o IP público da `dps-vm1` e colá-lo em uma nova aba do navegador, acrescentando a porta 3000. Também podemos acessar a lista de clientes, adicionando `/clientes` ao final da URL.

Fizemos a configuração e a instalação do Node, do Git e do próprio código-fonte do Doguito apenas na instância `dps-vm1`. Será que conseguiríamos, de cor, fazer todos esses passos de novo na `dps-vm2`? Podemos até tentar, mas há uma chance de esquecermos um passo ou realizá-lo de forma errada. Para evitar esse problema, nosso próximo será **converter a infraestrutura do Doguito API para código**, de forma que seja facilmente replicável. Assim, poderemos criar mais de uma instância do Doguito API de modo simples, em vez de fazer esse processo manualmente. No caso, faremos apenas duas instâncias, mas num cenário real poderiam ser dezenas e ficaria praticamente inviável!

Além disso, imagine que a aplicação fez muito sucesso, temos 50 instâncias do Doguito Pet Shop e estamos trabalhando com uma versão específica do Node. Em dado momento, o Doguito é atualizado e passa a utilizar uma nova versão do Node. Nesse caso, teríamos que atualizar cada máquina manualmente! Esse processo é muito propenso a falhas.

Para converter a infraestrutura do Doguito para código, utilizaremos um recurso da OCI chamado "Gerenciador de Recursos". No menu da OCI, vamos em "Serviços ao Desenvolvedor > Gerenciador de Recursos".

O gerenciador de recursos nos auxiliará a tratar a infraestrutura do Doguito como código e também na instalação, configuração e gerenciamento de novos recursos, sempre usando a **metodologia da infraestrutura como código**. O gerenciador de recursos, em realidade, é um serviço gerenciado do Terraform.

O [**Terraform**](https://www.terraform.io/) é uma aplicação que funciona de modo independente da OCI e é a ferramenta que, de fato, fará a implementação da infraestrutura como código. A ideia é justamente **descrevermos os componentes da nossa infraestrutura usando uma sintaxe e uma definição de alto nível**. Não é necessário escrever detalhe por detalhe, basicamente vamos descrever o que queremos e o próprio sistema cuida de fazer a implantação.

Esse processo permite que tenhamos um projeto arquitetural, como se fosse a planta de uma casa (no caso, da nossa infraestrutura), que pode ser versionada e gerenciada semelhante a um código-fonte. Ademais, podemos criar de forma simples a nossa pilha de infraestrutura de _software_, sem precisar realizar processos manuais e decorar o passo a passo.

Na prática, para fazer essa conversão, precisamos seguir um fluxo na OCI. O primeiro é passo é criar os **arquivos de configuração** e fazer o _upload_ de um **pacote de configurações**, que são os códigos escritos no padrão do Terraform. Em seguida, criaremos uma **pilha (_stack_, em inglês)** e rodar as ações do Terraform sobre ela.

O nosso código Terraform pode estar num determinado Git, em uma pasta, em um _bucket_ do _object storage_ (como fizemos com o site estático), em um compartimento, pode ser um _template_ ou até um arquivo `.zip`. A partir desse arquivo, geramos uma pilha (no gerenciamento de recursos) que definirá um conjunto de recursos de _cloud_ dentro do compartimento do Doguito. Em seguida, executaremos os **_jobs_**, que são um conjunto de comandos Terraform que podem ser executados em uma pilha. Esses _jobs_ são os comandos padrões do Terraform, como **_plan_**, **_apply_** e, eventualmente quando não precisarmos mais desses recursos, o **_destroy_**, para liberá-los.

Após executar essas ações, será gerado um **arquivo de estado** Terraform, gerenciado de forma segura pelo próprio gerenciador de recursos. Ele será usado pelo Terraform e garantirá que haja uma única fonte da verdade para o estado atual da infraestrutura — o arquivo especificará o que foi criado, qual a versão dos _softwares_ instalados, quais passos foram seguidos e assim em diante. Essa é uma das principais vantagens do Terraform em relação a fazer as operações manualmente. Desta última forma, podemos esquecer de alguns detalhes, enquanto o Terraform consegue manter esse arquivo de estado com todas as informações necessárias.

De forma bastante resumida, vimos que o gerenciador de recursos é um serviço gerenciado pelo Terraform que nos auxiliar muito na implantação da infraestrutura do Doguito como código.


-----------------------------------------------------------------------
# 04Nossa primeira IAC

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105758

## Transcrição

Chegou a hora de começarmos a transformar o Doguito em uma **infraestrutura como código (IaC)**. Para começar, precisamos fazer o _download_ do arquivo chamado `orm-dps.zip`, no tópico "Projeto da aula anterior". Trata-se de uma infraestrutura básica, pronta para fazermos testes. Num primeiro momento, vamos levantar essa infraestrutura simples para testar, depois repetiremos o processo com o Doguito.

No menu da OCI, vamos em "Serviços ao Desenvolvedor > Gerenciador de Recursos > Visão Geral". Na área "Conceitos Básicos", clicaremos em "Criar uma Pilha" (_stack_, em inglês). No topo da página, veremos uma **definição do conceito de pilha** e, mais abaixo, serão apresentadas diversas opções de configuração. Vamos manter "Minha configuração" selecionado.

Em "Origem da configuração do Terraform", escolheremos "Arquivo .zip" e arrastaremos o arquivo `orm-dps.zip` para a área de _upload_. Mais abaixo, podemos manter o nome padrão e nos certificar de que o compartimento escolhido é "Desenvolvimento". Quanto à versão do Terraform, vamos defini-la como 0.14.x, a versão compatível com esse arquivo. Em seguida, clicaremos no botão "Próximo", no canto esquerdo inferior da página.

Agora, temos algumas variáveis configuráveis na hora da criação da pilha, como a largura mínima e máxima do _load balancer_, que manteremos como 10. Em "Compute Shape", por termos uma conta gratuita, precisamos selecionar "VM.Standard.E2.1.Micro".

Em "SSH Key Configuration", vamos escolher a opção "Colar Chaves SSH". Acessaremos o Cloud Shell e consultaremos a chave pública por meio do comando `cat .ssh/cloudshellkey.pub`. Vamos copiá-la e, em seguida, colá-la no campo "SSH Public Key".

Mais abaixo nessa página, temos a área "Virtual Cloud Network Configuration", onde podemos definir o nome da VCN, a barra de endereço da VCN e o nome da _subnet_ — vamos manter tudo como está, no padrão. Por fim, clicaremos no botão "Próximo", ao final da página.

Por enquanto, **não** vamos selecionar a opção "Executar Aplicação" (que seria o `apply`). Basta clicar em "Criar", no canto esquerdo inferior da tela.

A criação da pilha é um processo rápido, feito imediatamente. À esquerda, já consta o quadrado verde com a legenda "Ativo". Vamos seguir para o próximo passo: **planejar**.

Clicaremos no botão "Planejar" no topo da tela. Deixaremos o nome padrão, sem modificá-lo, e selecionaremos "Planejar" ao final da página. Esse procedimento é um pouco mais demorado. Assim como os demais componentes, o quadrado laranja à esquerda (com a legenda "Em andamento") demonstra que ainda está em processamento. Nesse meio tempo, vamos explorar as configurações dentro de `orm-dps.zip`.

Descompactando e abrindo a pasta, veremos uma série de arquivos da OCI, no formato Terraform. Eles descrevem nossa infraestrutura. Em um editor de textos — no caso, estou usando o Visual Studio Code, você pode usar outro de sua preferência ou até mesmo o Bloco de Notas —, vamos abrir o arquivo `compute.tf`. Nele veremos a descrição dos _computes_, por exemplo: na linha 9, temos o nome do primeiro _compute_ ("Web-Server-01"); na linha 14, sabemos a qual placa de rede ele vai se conectar ("primaryvnic"); e, na linha 23, consta a chave SSH (`var.ssh_public_key`). Nas linhas 32, 37 e 46 encontraremos o nome, a placa de rede e a chave SSH do segundo _compute_.

> Na Alura, temos um curso específico sobre Terraform, caso seja de seu interesse entender mais a fundo o conteúdo desses arquivos de configuração.

A seguir, vamos abrir o arquivo `loadBalancer.tf`, que descreve a configuração do balanceador de carga. Na linha 3, temos o nome do _load balancer_. Nas linhas 10 e 11, podemos visualizar as definições de largura de banda. Das linhas 15 a 24, dispomos de detalhes relativos ao _health check_, na porta 80. Na linha 27, descobrimos que o algoritmo de balanceamento usado será o Round Robin. Nas linhas 36 e 46, respectivamente, sabemos a porta que será direcionada para a máquina 1 e a máquina 2. A partir da linha 49, temos a descrição dos _listeners_ e assim por diante. Basicamente, são as configurações que fizemos em tela.

Por fim, vamos explorar o arquivo `network.tf`, responsável pela configuração da rede. A partir da linha 8, temos a descrição do _internet gateway_, que terá um _label_. Na sequência, veremos a tabela de roteamento público (_Public Route Table_). Entre as linhas 27 e 36, há configurações da sub-rede, incluindo a faixa de endereços dessa _subnet_. A partir da linha 38, temos a criação e descrição da _security list_, bem como regras de entrada, e assim por diante.

Além desses três arquivos, temos o `output.tf` que definirá a saída, ou seja, finalizando a execução do comando `apply`, o `output.tf` determina que seja exibido o endereço de IP do _load balancer_, através do qual acessaremos as máquinas.

Ademais, há o comando de inicialização da _cloud_ (`cloud-init.yaml`) que especifica quais pacotes precisam ser instalados, qual repositório Yum deve ser acessado e quais são os comandos disponíveis:

```less
# Linhas 14 a 20 do arquivo cloud-init.yaml

runcmd:
  - [sh, -c, echo "<html>Web Server IP `hostname --ip-address`</html>" > /var/www/html/index.html]
  - [firewall-offline-cmd, --add-service=https]
  - [firewall-offline-cmd, --add-service=http]
  - [systemctl, enable, httpd]
  - [systemctl, start, httpd]
  - [systemctl, restart, firewalld]
```

Por exemplo, na linha 15, temos um comando que criará um arquivo `index.html` em cada uma das instâncias de _compute_, selecionando o endereço de IP da instância e "jogando" o arquivo `/var/www/html/index.html`. Na linha 16 e 17, serão adicionados os serviços de HTTPS e HTTP no _firewall_. Na linha 18 e 19, o serviço `httpd` será ativado e iniciado. Por fim, na linha 20, o _firewall_ é reiniciado para que ele reconheça as novas configurações.

Temos as configurações de `datasources.tf` que define a origem de algumas informações importantes. Além disso, há o arquivo `schema.yaml` que basicamente nos informa sobre as variáveis que podemos alterar quando criamos a instalação. A partir da linha 73, por exemplo, temos a possibilidade de escolher a _shape_ da máquina que utilizaremos. Já da linha 92 até o final do arquivo, dispomos dos campos em que informamos a chave SSH.

Por fim, no arquivo `variables.tf`, são criadas algumas variáveis que serão utilizadas dentro dos próprios arquivos do Terraform.

Ótimo, já conhecemos o conteúdo dos arquivos, podemos voltar à OCI e verificar que o nosso _plan job_ foi executado com sucesso. O quadrado à esquerda está verde, com a legenda "Bem-sucedido". Mais abaixo nessa página, na área "Logs", podemos consultar uma série de informações. Algumas delas foram obtidas durante esse processo de planejamento das atividades que serão executadas; outras serão obtidas após a execução do `apply`, por exemplo, o próprio IP.

Voltando aos detalhes da pilha, falta apenas fazermos o comando `apply` (aplicar). Vamos clicar no botão "Aplicar", em seguida, em "Aplicar" novamente, no final da página. O processo do `apply` é mais demorado, pode levar alguns minutos.

No nosso caso, o processo de `apply` falhou. O quadrado à esquerda ficou vermelho, com a legenda "Com falha". Para descobrirmos o problema, vamos consultar o _log_ mais abaixo nesta página.

Encontraremos o seguinte aviso: "**_Error: 400-LimitExceeded_**". O limite de instâncias e do _load balancer_ foram excedidos. Isso ocorre porque a nossa conta é gratuita, portanto possui uma limitação da quantidade de recursos que podemos alocar. Como já temos um servidor e um _load balancer_ alocados, o `apply` não foi aceito. Então, precisaremos destruir o serviço que fizemos antecipadamente, mas não se preocupe, depois será bem mais fácil de refazermos.

A **destruição de elementos** deve obedecer uma sequência para que dê certo; do contrário, a exclusão dos recursos será recusada. Primeiramente, vamos excluir o _load balancer_.

No menu da OCI, vamos em "Rede > Balanceamento de Carga". À direita do nome do _load balancer_, vamos expandir o menu de opções e selecionar "Encerrar". Haverá uma mensagem de confirmação, podemos clicar em "Encerrar" mais uma vez e o _status_ mudará para "Excluindo". Devemos esperar até que o processo seja concluído — podemos recarregar a página algumas vezes — e, assim que o balanceador de carga desaparecer da tela, a exclusão foi realizada com sucesso e podemos seguir para o próximo passo.

Agora, excluiremos as instâncias de _compute_. No menu, em "Computação > Instâncias", começaremos apagando a `dps-vm1`. Na linha referente à `dps-vm1`, à direita, vamos expandir as opções e pressionar "Encerrar". Haverá uma mensagem de confirmação, é muito importante marcar o _checkbox_ "Excluir permanentemente o volume de inicialização anexado", pois existe também um limite nesses volumes e, caso não façamos essa exclusão agora, posteriormente precisaremos apagá-los manualmente. Em seguida, podemos clicar em "Encerrar Instância".

Repetiremos essa sequência para a `dps-vm2` e, assim como o _load balancer_, esperaremos alguns instantes até que as instâncias estejam definitivamente encerradas, antes de proceder para os próximos passos.

Em seguida, apagaremos nossa rede virtual, em "Rede > Redes Virtuais na Nuvem". Começando pela VCN1, vamos expandir as opções e clicar em "Encerrar". Na mensagem de confirmação, pressionaremos "Encerrar" novamente e, finalizado o processo, vamos repeti-lo com a VCN2.

Com o _load balancer_, as instâncias e as redes virtuais encerradas, vamos voltar a "Serviços ao Desenvolvedor > Gerenciador de Recursos > Pilhas" e acessar a nossa pilha, para tentar fazer o `apply` mais uma vez. Vamos clicar em "Aplicar", depois, em "Aplicar" ao final da página, e esperar o processamento, que pode demorar alguns minutos.

Dessa vez, veremos o quadrado à esquerda verde, com a legenda "Bem-sucedido", indicando que deu tudo certo. Podemos consultar o _log_ para verificar tudo que foi criado e, ao final do _log_, teremos o endereço de IP do _load balancer_, como especificamos no arquivo `output.tf`.

Na sequência, vamos confirmar a criação de todos os recursos. No menu da OCI, em "Rede > Balanceador de Carga", veremos que existe um novo _load balancer_, "Demo-Web-LB". A integridade geral estará marcada como crítica porque o balanceador ainda não conseguiu validar os _back-ends_, mas em pouco tempo isso será resolvido automaticamente.

Já em "Computação > Instâncias", vamos constatar que dois novos _computes_ foram criados: "Web-Server-01" e "Web-Server-02", cada qual com um IP público e outro privado. Note que as máquinas demoram cerca de 5 minutos para subir, então, se copiarmos o IP público e tentarmos abrir em uma nova aba do navegador, talvez a página não carregue de imediato.

Passados esses 5 minutos, conseguiremos fazer o acesso pelo IP público das instâncias. Uma vez bem-sucedido, podemos voltar à página de detalhes do balanceador de carga e observar que está ativo e com a integridade OK. Além disso, podemos copiar o IP público do _load balancer_ e acessá-lo no navegador. Pressionando a tecla F5, teremos o efeito do Round Robin, em que os servidores internos são alternados.

Desse modo, conseguimos fazer um teste da utilização da infraestrutura como código, para entendermos o processo de implantação. Na nossa próxima aula, vamos adaptar o projeto do Doguito para executar na nossa infraestrutura.


-----------------------------------------------------------------------
# 05Faça como eu fiz: infraestrutura a partir do código

Realizamos a criação de nossa primeira infraestrutura a partir do código utilizando o gerenciador de recursos da OCI.

Inicialmente foi necessário remover os recursos já utilizados para não ultrapassar os limites de uso da conta free tier.

Realizamos então a remoção do balanceador de cargas, das duas instâncias de computação e da rede virtual.

Em seguida, já conseguimos implantar nossa primeira infraestrutura como código com o arquivo “orm-dps.zip”, que tem uma infraestrutura básica de balanceador de carga, rede virtual e duas instâncias.

Siga os passos realizados no vídeo para implantar a infraestrutura como código e se tiver problemas, acione o fórum do curso para obter o auxílio, bons estudos!


-----------------------------------------------------------------------
# 06Para saber mais: automatizando a infraestrutura

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105806

A infraestrutura necessária para a execução de nossas aplicações tem se tornado cada vez mais complexa. Além disso, também temos o conceito de infraestrutura elástica, que consiste em adequar nossa infraestrutura implantada ao volume de trabalho de um determinado momento. Para isso, surge a necessidade de automatização de implantação, que deve deixar de ser um processo manual para ser um processo automático e reproduzível.

Como vimos, o Resource Manager da OCI é nosso aliado nesta tarefa, e este video traz muitas informações complementares para aprofundarmos nosso conhecimento sobre o Resource Manager:

https://youtu.be/btnRgK36LnE

O conteúdo em video pode apresentar alguns tópicos desatualizados, por isso, todos os detalhes sobre a utilização do Resource Manager na OCI podem ser também encontrados na documentação oficial através dos links [https://docs.oracle.com/pt-br/iaas/Content/ResourceManager/home.htm#top](https://docs.oracle.com/pt-br/iaas/Content/ResourceManager/home.htm#top) e [https://docs.oracle.com/es-ww/iaas/Content/ResourceManager/home.htm#top](https://docs.oracle.com/es-ww/iaas/Content/ResourceManager/home.htm#top).

-----------------------------------------------------------------------
# 07Vantagens da IAC


Infraestrutura como código é uma abordagem muito adotada atualmente, em especial quando se utilizam práticas de DevOps nas organizações. Isso porque há vantagens reais nesta forma de gerenciamento e provisionamento em comparação à implantação manual de infraestruturas, Marque as alternativas com as opções que correspondem aos benefícios da IAC.

Selecione 3 alternativas
Reprodutibilidade da infraestrutura.

Alternativa correta. O código que representa uma infraestrutura pode ser novamente executado um número indefinido de vezes tornando a infraestrutura facilmente reproduzível.

Controle de versão da infraestrutura.

Alternativa correta. Com a infraestrutura como código, o código que representa a infraestrutura pode ser versionado utilizando as ferramentas convencionais de versionamento como o Git.

Automatização do provisionamento.

Alternativa correta. A principal vantagem de se utilizar infraestrutura como código é a automatização do provisionamento, eliminando praticamente todo o processo manual e passível de erro de implantação de infraestrutura.


-----------------------------------------------------------------------
# 08O que aprendemos?

## Nessa aula, você aprendeu:

- Que as aplicações têm evoluído sua arquitetura de construção de monolitos para microsserviços;
- Que a utilização de microsserviços acelera a necessidade de se trabalhar com automatização de provisionamento de infraestrutura e infraestrutura como código;
- Que a OCI disponibiliza diversas soluções de suporte ao desenvolvimento através da opção “Serviços ao Desenvolvedor”, por exemplo: Kubernetes, Registro de Artefatos, Gateway de API e Gerenciamento de Recursos (IaaS);
- Que o Gerenciador de Recursos é um serviço do Terraform e permite a definição de infraestruturas como código, colaborando para que a infraestrutura possa ser facilmente replicada e versionada.


-----------------------------------------------------------------------
# 01Projeto da aula anterior

Para esta aula usaremos alguns códigos que estarão disponibilizados para a consulta no [GitHub](https://github.com/alura-cursos/doguito-site-orm).



-----------------------------------------------------------------------
# 02Configurando a stack do Doguito

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105759

## Transcrição

Neste momento, estamos com aquela pilha básica de exemplo implantada na OCI. Podemos acessar o menu da OCI, entrar em "Serviços ao Desenvolvedor > Gerenciador de Recursos > Pilhas" e ver a pilha devidamente implantada e ativa. A seguir, faremos **ajustes para rodar o Doguito**.

Na conta gratuita, temos uma limitação de quantidade de máquinas que podemos executar simultaneamente, portanto será necessário destruir essa pilha para implantar o Doguito. Na página de detalhes da pilha, vamos clicar no botão "Destruir" e confirmar, pressionando "Destruir" novamente ao final da página. O quadrado à esquerda ficará laranja, enquanto essa ação é executada.

Nesse meio-tempo, vamos começar os ajustes nos arquivos do Terraform para configurar a execução do Doguito. Precisaremos do `doguito-site.service` e do `orm-dps.zip` (compartilhados na plataforma). Vamos descompactar o arquivo `.zip`, renomear a pasta resultante para "orm-dps-v2" e abri-la no VS Code ou seu editor de texto de preferência — o Bloco de Notas também é uma opção. A seguir, vamos efetuar algumas adaptações nos arquivos para que a nossa versão do Doguito funcione adequadamente.

De início, acessaremos `compute.tf` e faremos algumas alterações para deixar o conteúdo um pouco mais semântico. A primeira modificação será **definir um nome mais significativo** para a primeira instância: na linha 6, substituiremos "web-01" por "dps-server-01", repetindo o processo na linha 9 (o `display_name`):

```csharp
# código anterior omitido

resource "oci_core_instance" "dps-server-01" {
  availability_domain = data.oci_identity_availability_domains.ADs.availability_domains[var.AD -1]["name"]
  compartment_id      = var.compartment_ocid
  display_name        = "dps-server-01"
  shape               = var.instance_shape

# código posterior omitido
```

Nas linhas 29 e 32, vamos alterar o nome e o `display_name` da segunda instância para "dps-server-02":

```csharp
# código anterior omitido

 resource "oci_core_instance" "dps-server-02" {
   availability_domain = data.oci_identity_availability_domains.ADs.availability_domains[var.AD -1]["name"]
   compartment_id      = var.compartment_ocid
   display_name        = "dps-server-02"
   shape               = var.instance_shape

# código posterior omitido
```

O arquivo `compute.tf` está pronto. Em seguida, vamos abrir o `loadBalancer.tf` e alterá-lo conforme a necessidade. Começaremos definindo um nome mais semântico para o balanceador de carga: na linha 3, em lugar de "Demo-Web-LB", colocaremos "DPS-LB" — ou seja, **D*_oguito *_P**et **S*_hop *_L**oad **B**alancer:

```csharp
resource "oci_load_balancer" Load_Balancer {
  compartment_id = var.compartment_ocid
  display_name = "DPS-LB"
  shape          = "flexible"
  subnet_ids = [
    oci_core_subnet.subnet.id,
  ]
  shape_details {
      #Required
      maximum_bandwidth_in_mbps = var.load_balancer_max_band
      minimum_bandwidth_in_mbps = var.load_balancer_min_band
    }
}

# código posterior omitido
```

Nesse trecho, temos também algumas configurações de largura de banda. A próxima alteração é relativa à porta do `health_checker` que, no momento, está testando na porta 80. Como levantamos o Doguito na porta 3000, mudaremos de 80 para 3000, na linha 17. Assim, o funcionamento do servidor será checado.

Mais abaixo nesse arquivo, a partir da linha 29, ajustaremos os _back-ends_. Podemos manter os nomes "dps-vm1" e "dps-vm2", porém vamos direcionar o tráfego para a porta 3000, onde o Doguito será executado: nas linhas 36 e 46, substituiremos 80 por 3000.

Ademais, precisamos mudar os `ip_address` para corresponder com o novo nome das instâncias de _compute_. Na linha 34, definiremos `ip_address = oci_core_instance.dps-server-01.private_ip` e, na linha 44, `ip_address = oci_core_instance.dps-server-02.private_ip`:

```bash
# código anterior omitido

resource "oci_load_balancer_backend" dps-vm1 {
  backendset_name  = oci_load_balancer_backend_set.web-servers-backend.name
  backup           = "false"
  drain            = "false"
  load_balancer_id = oci_load_balancer.Load_Balancer.id
  ip_address       = oci_core_instance.dps-server-01.private_ip
  offline          = "false"
  port             = "3000"
  weight           = "1"
}
resource "oci_load_balancer_backend" dps-vm2 {
  backendset_name  = oci_load_balancer_backend_set.web-servers-backend.name
  backup           = "false"
  drain            = "false"
  load_balancer_id = oci_load_balancer.Load_Balancer.id
  ip_address       = oci_core_instance.dps-server-02.private_ip
  offline          = "false"
  port             = "3000"
  weight           = "1"
}

# código posterior omitido
```

Quanto ao _listener_ (linhas 49 a 63), não precisamos modificá-lo — vamos mantê-lo na porta HTTP 80, pois a porta HTTP de entrada é a 80 e internamente o fluxo será direcionado para a porta 3000.

O próximo arquivo que alteraremos é o `network.tf`. Da linha 48 a 56, temos uma regra de _ingress_ que permite o acesso na porta 80, que chegará ao _load balancer_. Da linha 58 a 67, consta outra regra de _ingress_, desta vez na porta 22, para fazer o acesso via SSH nas máquinas. A seguir, vamos **incluir mais uma regra, na porta 3000**:

```python
# código anterior omitido

  ingress_security_rules {
    protocol = "6"
    source   = "0.0.0.0/0"

    tcp_options {
      min = 80
      max = 80
    }
  }

  ingress_security_rules {
    protocol = "6"
    source   = "0.0.0.0/0"

    tcp_options {
      min = 22
      max = 22
    }
  }

  ingress_security_rules {
    protocol = "6"
    source   = "0.0.0.0/0"

    tcp_options {
      min = 3000
      max = 3000
    }
  }
```

Em resumo, modificamos alguns detalhes dos arquivos `compute.tf`, `loadBalancer.tf` e `network.tf`. São esses todos os ajustes necessários nos **arquivos Terraform**.

Agora, a principal mudança será no arquivo `cloud-init.yaml`. Os arquivos de Terraform servem para criar os recursos da OCI, já o `cloud-init.yaml` contém uma **série de comandos que serão executados quando a instância for levantada**, ou seja, da primeira vez em que o _compute_ for executado.

Assim sendo, vamos abrir o `cloud-init.yaml` e ajustá-lo à nossa maneira. A princípio, focaremos nos `packages`. Em vez do `httpd`(o Apache), utilizaremos o Git: na linha 12, vamos comandar a instalação do pacote do Git. Na sequência, realizaremos a instalação do Node:

```markdown
packages:
  - git
  - nodejs
```

Anteriormente, quando levantamos a máquina, instalamos alguns _softwares_ de conexão com o banco de dados. A seguir, vamos repetir esses processos: o primeiro pacote a ser instalado é o `oracle-instantclient-release-el8`, que servirá para nos comunicarmos com o banco de dados JSON da Oracle. O segundo é o `oracle-instantclient-basic`:

```markdown
runcmd:
  - [dnf, -y, install, oracle-instantclient-release-el8]
  - [dnf, -y, install, oracle-instantclient-basic]

  - [sh, -c, echo "<html>Web Server IP `hostname --ip-address`</html>" > /var/www/html/index.html]
  - [firewall-offline-cmd, --add-service=https]
  - [firewall-offline-cmd, --add-service=http]
  - [systemctl, enable, httpd]
  - [systemctl, start, httpd]
  - [systemctl, restart, firewalld]
```

Note que alguns pacotes são instalados em `packages` e outros podemos rodar em `runcmd`. No caso, `dnf` comanda a instalação do pacote e `-y` faz a confirmação, depois temos `install`, que é o comando de instalação e, por fim, o pacote desejado.

A seguir, vamos clonar o projeto do Doguito nessa máquina, por meio do `git clone`:

```markdown
runcmd:
  - [dnf, -y, install, oracle-instantclient-release-el8]
  - [dnf, -y, install, oracle-instantclient-basic]
  - [git, -C, /home/opc, clone, https://github.com/tiagolpadua/doguito-site-orm.git]

  - [sh, -c, echo "<html>Web Server IP `hostname --ip-address`</html>" > /var/www/html/index.html]
  - [firewall-offline-cmd, --add-service=https]
  - [firewall-offline-cmd, --add-service=http]
  - [systemctl, enable, httpd]
  - [systemctl, start, httpd]
  - [systemctl, restart, firewalld]
```

Por partes: o `-C` serve para indicar a pasta onde queremos clonar (`/home/opc`), `clone` executa o comando de clonagem em si e, por fim, temos o endereço do repositório.

Em seguida, precisamos acessar a pasta onde será feito o clone do Doguito e rodar o `npm install`, para que as dependências sejam instaladas:

```markdown
runcmd:
  - [dnf, -y, install, oracle-instantclient-release-el8]
  - [dnf, -y, install, oracle-instantclient-basic]
  - [git, -C, /home/opc, clone, https://github.com/tiagolpadua/doguito-site-orm.git]
  - [bash, -c, 'cd /home/opc/doguito-site-orm && npm install']

  - [sh, -c, echo "<html>Web Server IP `hostname --ip-address`</html>" > /var/www/html/index.html]
  - [firewall-offline-cmd, --add-service=https]
  - [firewall-offline-cmd, --add-service=http]
  - [systemctl, enable, httpd]
  - [systemctl, start, httpd]
  - [systemctl, restart, firewalld]
```

Vale lembrar que todos esses comandos serão executados somente quando a máquina for levantada da primeira vez. Para que o Doguito continue em execução, caso a máquina reinicie ou ocorra algo nesse sentido, colocaremos um _service_. Entre os arquivos disponibilizados na plataforma, você terá o `doguito-site.service`, que é um _template_ de um serviço que utilizaremos.

Portanto, no arquivo `cloud-init.yaml`, precisamos descobrir uma maneira de acessar o `doguito-site.service` para instalá-lo na instância. Para tanto, usaremos o serviço de armazenamento da OCI. Entrando em "Armazenamento > Buckets", clicaremos em "Criar Bucket". Daremos o nome "internal" e pressionaremos "Criar" ao final da página. Acessando o _bucket_, vamos editar a visibilidade. Por motivos didáticos, deixaremos o _bucket_ com acesso público, mas em casos reais o ideal é que seja privado.

A seguir, na área "Objetos", vamos fazer o _upload_ do arquivo `doguito-site.service` — não há necessidade de preencher o campo de prefixo. À direita do objeto, podemos exibir os detalhes e **copiar a URL do arquivo**.

Voltando ao nosso projeto, no arquivo `cloud-init.yaml`, utilizaremos o comando `wget` para colocar o `doguito-site.service` na máquina, fazendo uso da URL que acabamos de copiar:

```bash
runcmd:
  - [dnf, -y, install, oracle-instantclient-release-el8]
  - [dnf, -y, install, oracle-instantclient-basic]
  - [git, -C, /home/opc, clone, https://github.com/tiagolpadua/doguito-site-orm.git]
  - [bash, -c, 'cd /home/opc/doguito-site-orm && npm install']

  - [wget, https://objectstorage.us-phoenix-1.oraclecloud.com/n/axnv318jdswe/b/internal/o/doguito-site.service, -P, /lib/systemd/system]

  - [sh, -c, echo "<html>Web Server IP `hostname --ip-address`</html>" > /var/www/html/index.html]
  - [firewall-offline-cmd, --add-service=https]
  - [firewall-offline-cmd, --add-service=http]
  - [systemctl, enable, httpd]
  - [systemctl, start, httpd]
  - [systemctl, restart, firewalld]
```

Note que a URL varia de acordo com o usuário, com o _namespace_, ou seja, você deve usar o endereço do URL que consta nos detalhes do **seu** objeto `doguito-site.service`. Dessa forma, rodaremos o comando `wget` e faremos o _download_ do serviço em `/lib/systemd/system`.

Por fim, precisamos reiniciar (`reload`), depois ativar e inicializar o `doguito-site.service` (`enable` e `start`). São os mesmos comandos que realizamos anteriormente, porém desta vez estamos na infraestrutura como código:

```markdown
runcmd:
  - [dnf, -y, install, oracle-instantclient-release-el8]
  - [dnf, -y, install, oracle-instantclient-basic]
  - [git, -C, /home/opc, clone, https://github.com/tiagolpadua/doguito-site-orm.git]
  - [bash, -c, 'cd /home/opc/doguito-site-orm && npm install']

  - [wget, https://objectstorage.us-phoenix-1.oraclecloud.com/n/axnv318jdswe/b/internal/o/doguito-site.service, -P, /lib/systemd/system]
  - [systemctl, daemon-reload]
  - [systemctl, enable, doguito-site.service]
  - [systemctl, start, doguito-site.service]

  - [sh, -c, echo "<html>Web Server IP `hostname --ip-address`</html>" > /var/www/html/index.html]
  - [firewall-offline-cmd, --add-service=https]
  - [firewall-offline-cmd, --add-service=http]
  - [systemctl, enable, httpd]
  - [systemctl, start, httpd]
  - [systemctl, restart, firewalld]
```

Assim, as configurações do _service_ estão prontas, vamos prosseguir.

A linha em que fazemos o `echo` com o `index.html` não é mais necessária, podemos apagá-la. Além disso, a ativação dos serviços HTTP e HTTPS do _firewall_ também não nos servem mais, pois teremos uma porta específica. Vamos remover essas linhas e adicionar a porta com o comando `firewall-offline-cmd, --add-port=3000/tcp`:

```markdown
runcmd:
  - [dnf, -y, install, oracle-instantclient-release-el8]
  - [dnf, -y, install, oracle-instantclient-basic]
  - [git, -C, /home/opc, clone, https://github.com/tiagolpadua/doguito-site-orm.git]
  - [bash, -c, 'cd /home/opc/doguito-site-orm && npm install']

  - [wget, https://objectstorage.us-phoenix-1.oraclecloud.com/n/axnv318jdswe/b/internal/o/doguito-site.service, -P, /lib/systemd/system]
  - [systemctl, daemon-reload]
  - [systemctl, enable, doguito-site.service]
  - [systemctl, start, doguito-site.service]
  - [firewall-offline-cmd, --add-port=3000/tcp]

  - [systemctl, enable, httpd]
  - [systemctl, start, httpd]
  - [systemctl, restart, firewalld]
```

Também não usaremos o `httpd`, então tiraremos os comandos de ativação e inicialização:

```bash
runcmd:
  - [dnf, -y, install, oracle-instantclient-release-el8]
  - [dnf, -y, install, oracle-instantclient-basic]
  - [git, -C, /home/opc, clone, https://github.com/tiagolpadua/doguito-site-orm.git]
  - [bash, -c, 'cd /home/opc/doguito-site-orm && npm install']

  - [wget, https://objectstorage.us-phoenix-1.oraclecloud.com/n/axnv318jdswe/b/internal/o/doguito-site.service, -P, /lib/systemd/system]
  - [systemctl, daemon-reload]
  - [systemctl, enable, doguito-site.service]
  - [systemctl, start, doguito-site.service]
  - [firewall-offline-cmd, --add-port=3000/tcp]
  - [systemctl, restart, firewalld]
```

Na última linha, mantemos o `restart` do _firewall_. Desse modo, do comando `wget` em diante temos o _service_ configurado.

Falta ainda um item importante. Anteriormente, quando subimos o Doguito Pet Shop, baixamos um arquivo de _wallet_ que contém as configurações de conexão com o banco de dados. Logo, vamos seguir uma estratégia semelhante ao que fizemos com o arquivo `doguito-site.service`: armazenaremos o arquivo de _wallet_ no _bucket_ "internal".

Caso você não tenha o arquivo da _wallet_ no seu computador, você pode baixá-lo indo em "Oracle Database > Autonomous JSON Database", acessando "DOGUITODB", clicando no botão "Conexão do BD" e pressionando "Fazer download da wallet". Na sequência, vamos movê-lo para nosso _object storage_.

No menu da OCI, vamos acessar o _bucket_ "internal" e fazer o _upload_ do `Wallet_DOGUITODB.zip`. Depois, exibiremos os detalhes desse novo objeto, copiaremos o caminho do URL e, de volta ao arquivo `cloud-init.yaml`, construiremos o comando `wget` com essa URL:

```bash
runcmd:
  - [dnf, -y, install, oracle-instantclient-release-el8]
  - [dnf, -y, install, oracle-instantclient-basic]
  - [git, -C, /home/opc, clone, https://github.com/tiagolpadua/doguito-site-orm.git]
  - [bash, -c, 'cd /home/opc/doguito-site-orm && npm install']

  - [wget, https://objectstorage.us-phoenix-1.oraclecloud.com/n/axnv318jdswe/b/internal/o/Wallet_DOGUITODB.zip, -P, /usr/lib/oracle/21/client64/lib/network/admin]

  - [wget, https://objectstorage.us-phoenix-1.oraclecloud.com/n/axnv318jdswe/b/internal/o/doguito-site.service, -P, /lib/systemd/system]
  - [systemctl, daemon-reload]
  - [systemctl, enable, doguito-site.service]
  - [systemctl, start, doguito-site.service]
  - [firewall-offline-cmd, --add-port=3000/tcp]
  - [systemctl, restart, firewalld]
```

Lembrando que esse caminho é distinto para cada usuário, é essencial que você use a URL que você mesmo copiou. Assim, baixaremos o arquivo de _wallet_ compactado para `/usr/lib/oracle/21/client64/lib/network/admin`. O próximo passo é entrar no local de _download_ e descompactar a _wallet_ (`unzip`):

```bash
runcmd:
  - [dnf, -y, install, oracle-instantclient-release-el8]
  - [dnf, -y, install, oracle-instantclient-basic]
  - [git, -C, /home/opc, clone, https://github.com/tiagolpadua/doguito-site-orm.git]
  - [bash, -c, 'cd /home/opc/doguito-site-orm && npm install']

  - [wget, https://objectstorage.us-phoenix-1.oraclecloud.com/n/axnv318jdswe/b/internal/o/Wallet_DOGUITODB.zip, -P, /usr/lib/oracle/21/client64/lib/network/admin]
  - [sudo, sh, -c, 'cd /usr/lib/oracle/21/client64/lib/network/admin/ && unzip -B Wallet_*.zip']

  - [wget, https://objectstorage.us-phoenix-1.oraclecloud.com/n/axnv318jdswe/b/internal/o/doguito-site.service, -P, /lib/systemd/system]
  - [systemctl, daemon-reload]
  - [systemctl, enable, doguito-site.service]
  - [systemctl, start, doguito-site.service]
  - [firewall-offline-cmd, --add-port=3000/tcp]
  - [systemctl, restart, firewalld]
```

Finalmente, nossas configurações estão prontas, vamos salvar todas essas modificações. Em seguida, vamos zipar a pasta `orm-dps-v2`. Este é nosso arquivo de _stack_, pronto com as configurações do Terraform.

Na próxima aula, vamos subir essa _stack_ na OCI.


-----------------------------------------------------------------------
# 03Faça como eu fiz: Doguito como código

Está pronto para criar uma pilha customizada para implantar o Doguito de maneira extremamente simples e prática?

Bom, serão necessários alguns passos, são eles:

- Ajustar o arquivo “compute.tf” customizando o nome das instâncias;
- Ajustar o arquivo loadbalancer.tf customizando o nome do balanceador de cargas e as portas de conexão;
- Ajustar o arquivo “network.tf” incluindo uma regra de ingress para a porta 3000;
- Criar um novo bucket chamado internal e faça o upload dos arquivos “doguito-site.service” e “Wallet_DOGUITODB.zip”;
- Alterar o “arquivo cloud-init.yaml” instalando o git, o Node.js e os drivers de conexão com o banco de dados Oracle. Inserir um comando no arquivo para fazer o download e configurar o service do Doguito, além de fazer o download da Wallet e descompactá-la no local adequado, liberando a porta 3000 no firewall;

Por fim, temos que compactar novamente o arquivo “orm-dps-vm2” em um arquivo zip que será utilizado para inicializar a pilha do Doguito. Vamos lá?

Não deixe de entrar em contato com outras pessoas no fórum da Alura caso tenha alguma dúvida ou dificuldade com a atividade!

-----------------------------------------------------------------------
# 04Implantando stack na OCI

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105760

## Transcrição

Agora que criamos e configuramos os arquivos do Doguito, vamos subir uma _stack_. No menu da OCI, vamos em "Serviços ao Desenvolvedor > Gerenciador de Recursos > Pilhas".

No início do vídeo anterior, comandamos a destruição daquela pilha básica para testes e, com esse processo finalizado, podemos excluí-la da nossa lista, para não gerar confusão. Basta expandir as opções à direita do seu nome, clicar em "Excluir" e confirmar a ação.

Além disso, em "Computação > Instâncias", verificaremos que não há nenhuma instância ativa no momento.

Voltando à área de Pilhas, faremos o _upload_ da nossa nova _stack_, clicando no botão "Criar Pilha". Em "Origem da configuração do Terraform", vamos selecionar a opção "Arquivo .zip" e, em seguida, arrastar o `orm-dps-v2.zip` para a área de _upload_. Mais abaixo, vamos escolher a versão 0.14.x do Terraform e clicar em "Próximo".

Em "SSH Key Configuration", selecionaremos "Colar Chaves SSH". Vamos acessar o Cloud Shell e, a partir da raiz, executaremos o comando `cat ~/.ssh/cloudshellkey.pub` para pegar a parte pública da chave. Basta copiar o retorno e colar no campo "SSH Public Key". Podemos manter o resto das configurações com os valores _default_ e clicar em "Próximo", ao final da página. Em seguida, pressionaremos "Criar". Veremos o quadrado verde à esquerda com a legenda "Ativo", indicando que a pilha foi criada.

A seguir, vamos clicar no botão "Planejar". A princípio, teremos à esquerda um quadrado laranja com legenda "Aceito", enquanto é feita a verificação dos arquivos. Após alguns segundos, o quadrado ficará verde com a legenda "Bem-sucedido" e teremos o _logs_ da execução.

Voltando aos detalhes da pilha, podemos clicar em "Aplicar", depois em "Aplicar" mais uma vez para confirmar. Novamente, teremos um quadrado laranja, enquanto a ação é processada. Esse passo demora vários minutos, nesse meio-tempo daremos uma olhada em algumas informações interessantes dessa página.

Vamos observar o _log_ (ele pode demorar alguns segundos para carregar, depois do início da execução). Nele, podemos verificar que estamos selecionando a última versão do _template_ da OCI, por exemplo. Em seguida, podemos acompanhar a criação dos componentes: primeiro, é criada a sub-rede; depois o _load balancer_ e temos a informação do tempo que esse processo levou (no meu caso, foram 45 segundos); e, na sequência, serão gerados os _back-end servers_.

Ao final, o processo será bem-sucedido e podemos ir a "Computação > Instâncias" e verificar que temos duas máquinas em execução. Vamos copiar o IP público de uma delas e tentar acessá-la **na porta 3000**, em uma nova aba do navegador. Notaremos que ainda não está funcionando, porque a instância foi levantada, mas os _softwares_ ainda não foram instalados.

Existe uma forma de acompanhar o processo de execução da instância. Para tanto, precisamos do IP público da máquina — no meu caso, é 140.238.238.46. No Cloud Shell, vamos rodar o comando `ssh opc@140.238.238.46 -i ~/.ssh/cloudshellkey`. Digitaremos "_yes_" para confirmar e nos conectar à instância. Após fazer o _login_, podemos acompanhar os processos de instalação da máquina por meio do comando `tail -f /var/log/cloud-init-output.log`.

Esses processos são aqueles comandos que configuramos no vídeo anterior, de instalação do Node e do Git, por exemplo, que ocorrem na primeira inicialização da máquina. A depender do consumo de recursos, esse procedimento pode demorar de 5 a 10 minutos. Caso ocorra algum problema, ele será exibido nesse _log_ também.

Haverá uma primeira verificação, depois ocorrerá a instalação do Node, do NPM e do Git. Em seguida, serão instalados os _drivers_ da própria Oracle, inclusive o relativo à conexão com banco de dados. Depois, o `doguito-site-orm` será clonado. Note que, nesse repositório, juntamos a parte estática e a parte da API no mesmo projeto, devido a nossa limitação na quantidade de máquinas. Na sequência, será executado o `npm install` e serão baixados o `doguito-site.service` e o arquivo de _wallet_. Ao final, receberemos uma mensagem de que a configuração do `cloud-init` foi concluída.

Agora, vamos copiar o IP público de uma das máquinas e acessá-la na porta 3000, em uma nova aba no navegador. Desta vez, estará funcionando. Podemos testar a outra instância, também estará tudo em ordem.

Nosso acesso, de fato, ocorrerá pelo _load balancer_, portanto, vamos até "Rede > Balanceadores de Carga". A integridade geral do balanceador deve estar OK, se tivéssemos acessado mais cedo estaria marcado como "Falha". Entraremos no "DPS-LB", em seguida clicaremos em "Conjuntos de Backend" na lateral esquerda. Vamos acessar "web-servers-backend" e pressionar "Backends" na lateral esquerda, novamente. Assim, podemos consultar que eles estão apontando corretamente para a porta 3000.

Voltando aos detalhes do _load balancer_, copiaremos o IP público dele e o acessaremos (sem a porta 3000) em outra aba no navegador, confirmando que está funcionando corretamente.

A seguir, vamos testar. Na página do Doguito, clicaremos em "Novo Cliente" e cadastraremos o usuário "Tiago", com o e-mail "tiago@alura.com.br". Voltando para a lista de clientes, podemos verificar o cadastro realizado com sucesso.

Como última confirmação, vamos ao menu da OCI, em "Oracle Database > Autonomous JSON Database". Acessaremos o DOGUITODB, clicaremos em "Console de Serviço" e veremos toda a atividade, indicando que está tudo funcionando conforme esperado.

Nos detalhes do DOGUITODB, podemos clicar em "Ações do BD", selecionar "JSON" e verificar o dado que acabamos de salvar persistido no banco de dados.

Desse modo, nosso sistema Doguito Pet Shop está rodando corretamente, tanto a parte de _front-end_ quanto a de _back-end_, na porta 3000. Além disso, o balanceador de carga está fazendo sua função de distribuição entre as instâncias. Conseguimos fazer todas as configurações do início ao fim.


-----------------------------------------------------------------------
# 05Faça como eu fiz: implantando o Doguito como código

Temos o arquivo “orm-dps-v2.zip” e agora é hora de implantá-lo como uma pilha na OCI. Para isso utiliozamos a opção de Serviços ao Desenvolvedor e o Gerenciador de Recursos.

O processo será muito semelhante ao que fizemos anteriormente, mas utilizaremos o arquivo “orm-dps-v2.zip” que acabamos de gerar para subir uma pilha customizada para o Doguito.

Vamos lá? Espero que tudo dê certo e sua pilha seja implantada com sucesso, mas se tiver algum problema, você pode conversar com outros colegas no fórum e até responder as dúvidas que souber.


-----------------------------------------------------------------------
# 06Para saber mais: Terraform

Neste treinamento nosso foco é no aprendizado de utilização da Oracle Cloud para casos práticos, no entanto, você deve ter visto que falamos sobre várias ferramentas auxiliares que podemos usar para trabalhar em uma Cloud.

O Resource Manager da OCI é uma destas ferramentas e que internamente utiliza scripts Terraform para automatizar a implantação de infraestrutura.

Se você se interessou pelo Terraform e quer aprender mais sobre ele, dê uma olhada no [curso sobre Terraform](https://www.alura.com.br/curso-online-terraform) que temos disponível na plataforma da Alura.


-----------------------------------------------------------------------
# 07Implantando recursos como código

Para facilitar a implantação do Doguito e permitir que esta implantação seja versionada e facilmente evoluída, utilizamos a funcionalidade da OCI chamada **gerenciador de recursos**. Ele nos possibilita criar uma nova pilha que pode definir determinados tipos de recursos computacionais.

Selecione as alternativas que correspondem a esses recursos.

Instâncias de computação.

Alternativa correta. As instâncias de computação podem ser configuradas como parte de uma pilha no arquivo compute.tf.

Balanceadores de carga.

Alternativa correta. Os balanceadores de carga podem ser configurados como parte de uma pilha no arquivo loadbalancer.tf.

Gateways.

Alternativa correta. Os gateways podem ser configurados como parte de uma pilha no arquivo network.tf.


-----------------------------------------------------------------------
# 08O que aprendemos?


## Nessa aula, você aprendeu:

- Que podemos customizar os arquivos Terraform para criar diversos tipos de recursos computacionais de uma pilha de implantação;
- Que utilizamos o arquivo cloud-init.yaml para customizar a instalação de softwares diversos nas instâncias computacionais criadas a partir de uma pilha;
- Que usamos o Armazenamento de Objetos para guardar arquivos de configuração que serão utilizados na implantação de nossas pilhas de recursos.

-----------------------------------------------------------------------
# 09Conclusão

https://cursos.alura.com.br/course/oracle-cloud-infrastructure-dados-infraestrutura-codigo/task/105761

## Transcrição

Chegamos à conclusão do nosso curso!

Nossos principais objetivos eram **conhecer as características da OCI** e aplicar esses conhecimentos na implantação o Doguito Pet Shop num ambiente de _cloud_.

Nossa primeira tarefa era realizar a conexão do Doguito com uma base de dados. Analisamos as alternativas disponibilizadas pela OCI e optamos pela utilização do **banco de dados autônomos baseado em JSON**, por sua simplicidade e facilidade de uso.

A seguir, estudamos o funcionamento do Doguito para conectá-lo a esse banco de dados. Percebemos trata-se de uma **aplicação NodeJS, escrita em JavaScript e que utiliza o _framework_ ExpressJS**, fornecendo uma API para acessarmos as funcionalidades do Doguito. Com base nesse conhecimento, implantamos o Doguito na OCI e configuramos sua conexão com o banco.

Entretanto, ao testar, notamos que o Doguito não era iniciado automaticamente com a máquina virtual. Como solução, configuramos nossa aplicação como um **serviço** do próprio sistema operacional.

Em seguida, o colocamos no **_load balancer_** e o acessamos pelo navegador, diretamente na API. Visto que era mais interessante implantar uma interface para navegar pelas funcionalidades, analisamos as possibilidades de **armazenamento** e escolhemos o **_object storage_** para servir nosso site estático de uma maneira bem simples. Houve, no entanto, um problema de comunicação com a API, porque o _object storage_ roda em SSL por _default_, diferente do Doguito não estava utilizando o SSL. Por isso, configuramos o SSL no _load balancer_.

Por fim, visando converter o Doguito para um modelo DevOps, mais moderno e avançado, utilizamos a metodologia da **infraestrutura como código**. Começamos implantando uma estrutura básica de testes e, depois, ajustamos os _scripts_ do Terraform para que o Doguito se tornasse facilmente implantado e versionado, sem precisarmos realizar comandos manuais repetitivos. Basta subirmos a _stack_ atualizada e a OCI implantará os componentes da maneira esperada.

Espero que você tenha gostado deste treinamento, preparado com bastante dedicação pela equipe da Alura. Até mais e bons estudos!







