---
type: "9"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
fonte_curso: https://cursos.alura.com.br/course/spring-ai-integre-aplicacao-spring-openai
---

Tópico:: #Java #JPA #Spring_Boot #chatgpt #claude #IA #Inteligencia_Artifical 

- Desenvolva uma aplicação Java integrada com a API da OpenAI
- Utilize o Spring AI para integrar uma aplicação Java com a API da OpenAI
- Aprenda boas práticas de engenharia de prompts para otimizar as interações com a IA
- Diferencie e escolha entre os modelos de GPT disponíveis na API da OpenAI
- Faça a gestão de custos relacionados ao uso de tokens
- Implemente a contagem de tokens para estimar custos
- Trate erros e use boas práticas ao se conectar com APIs externas

-----------------------------------------------------------------------
## Aulas

- [](https://cursos.alura.com.br/course/spring-ai-integre-aplicacao-spring-openai/section/21281/tasks)
    
    [Spring AI](https://cursos.alura.com.br/course/spring-ai-integre-aplicacao-spring-openai/section/21281/tasks) [Ver primeiro vídeo](https://cursos.alura.com.br/course/spring-ai-integre-aplicacao-spring-openai/task/170398)
    
    0 / 10
    
    36min
    
    - Apresentação
    - Preparando o ambiente: ferramentas
    - Preparando o ambiente: cadastro na OpenAI
    - Criando um projeto com Spring AI
    - Integração com a API da OpenAI
    - API Key e variáveis de ambiente
    - Para saber mais: cuidados com a chave da API
    - Análise de sentimentos
    - Faça como eu fiz: primeira integração com a API da OpenAI
    - O que aprendemos?
- [
    
    Prompt Engineering
    
    0 / 9
    
    27min
    
    ](https://cursos.alura.com.br/course/spring-ai-integre-aplicacao-spring-openai/section/21282/tasks)
    
    - Projeto da aula anterior
    - Playground e parâmetros
    - Para saber mais: parâmetros da API
    - Categorizador de produtos
    - Prompt Engineering
    - Para saber mais: estratégias de Prompt Engineering
    - Dominando a arte do Prompt Engineering
    - Faça como eu fiz: prompt engineering na categorização de produtos
    - O que aprendemos?
- [
    
    Modelos e custos
    
    0 / 10
    
    28min
    
    ](https://cursos.alura.com.br/course/spring-ai-integre-aplicacao-spring-openai/section/21283/tasks)
    
    - Projeto da aula anterior
    - Diferença entre modelos
    - Para saber mais: tokens
    - Para saber mais: processamento em lote
    - Alterando modelos programaticamente
    - Para saber mais: injeção dinâmica do modelo
    - Contagem de tokens
    - Escolhendo o modelo apropriado
    - Faça como eu fiz: modelos dinâmicos no código
    - O que aprendemos?
- [
    
    Tratamento de erros
    
    0 / 7
    
    18min
    
    ](https://cursos.alura.com.br/course/spring-ai-integre-aplicacao-spring-openai/section/21284/tasks)
    
    - Projeto da aula anterior
    - Possíveis erros da API
    - Parâmetros de retry
    - Gerando logs
    - Monitoramento e logging
    - Faça como eu fiz: registrando logs das requisições
    - O que aprendemos?
- [
    
    Flexibilidade do Spring AI
    
    0 / 9
    
    24min
    
    ](https://cursos.alura.com.br/course/spring-ai-integre-aplicacao-spring-openai/section/21285/tasks)
    
    - Projeto da aula anterior
    - Modelo multimodal
    - Integrando com outras APIs
    - Criatividade com modelo multimodal
    - Faça como eu fiz: gerando imagens com a OpenAI
    - Projeto final do curso
    - Referências
    - O que aprendemos?
    - Conclusão

-----------------------------------------------------------------------
## Nesta aula, você aprendeu:

- Como utilizar o Spring AI para integrar uma aplicação Java com a API da OpenAI;
- Como iniciar um projeto Spring AI, via Spring Initializr, adicionando dependências necessárias;
- Como criar um controller REST para processar requisições GET e mapear URLs;
- Como utilizar a classe `ChatClient` para disparar requisições à API da OpenAI;
- A importância de configurar corretamente a chave de API da OpenAI no arquivo `application.properties`, via variáveis de ambiente;
- A importância de garantir que arquivos de configuração sensíveis do IntelliJ estejam no `.gitignore` ao utilizar controle de versão.
-----------------------------------------------------------------------
## Nesta aula, você aprendeu:

- A utilizar o Playground da OpenAI para testar interações com a API;
- Configurar parâmetros de geração de texto, como temperatura;
- Transferir configurações do Playground para o código;
- Ajustar o campo "System" no Playground para definir o comportamento do gerador de texto;
- Implementar uma funcionalidade de categorização de produtos no projeto;
- Especificar claramente instruções para a inteligência artificial por meio de prompt engineering.

-----------------------------------------------------------------------
## Nesta aula, você aprendeu:

- A importância de escolher corretamente o modelo GPT adequado para a aplicação, considerando custos e capacidades técnicas;
- Navegar pela documentação da OpenAI para compreender características e limitações dos modelos;
- Alterar o modelo utilizado na API da OpenAI programaticamente usando o método `.withModel` e definir configurações padrão com `.defaultOptions`;
- Configurar parâmetros globais no arquivo `application.properties` do spring Boot;
- Como a quantidade de tokens influencia no custo de uso da API e a importância de estimativas precisas;
- Utilizar a biblioteca Jtokkit em Java para contar tokens antes de fazer chamadas à API.

-----------------------------------------------------------------------
## Nesta aula, você aprendeu:

- Erros comuns ao chamar a API da OpenAI e suas implicações;
- Tratamento automático de erros no Spring Boot e personalizações possíveis;
- Propriedades de retentativa do Spring AI e sua configuração no `application.properties`;
- Importância da geração de logs e uso de `Advisors` para registrar requisições e respostas;
- Cuidados com a exposição de dados sensíveis nos logs.

-----------------------------------------------------------------------
## Nesta aula, você aprendeu:

- O conceito de multimodalidade nas APIs de IA, incluindo a geração de texto, imagens, áudios e vídeos;
- Integrar a API da OpenAI para geração de imagens em um projeto Spring;
- Criar e estruturar um controller para manipular a geração de imagens no Spring Boot;
- Configurar parâmetros personalizados para imagens usando o `ImageOptionsBuilder`;
- Trocar provedores de IA genérica alterando dependências no arquivo `pom.xml`;
- Ajustar configurações específicas no arquivo `application.properties` para novos provedores de IA;
- A importância de usar classes genéricas do Spring para um código desacoplado e flexível.

-----------------------------------------------------------------------
## O que vamos aprender?

Neste curso, entenderemos como funciona a integração utilizando o _**Spring AI**_, módulo do Spring para **integração em uma aplicação Java**.

Aprenderemos a criar um **projeto** utilizando o **Spring** — famoso _framework_ do mundo Java — com um **módulo AI**, que consegue se conectar e **integrar** com diversos provedores de inteligência artificial generativa, como o _Amazon Bedrock_ ou a _OpenAI_, que possui o famoso _ChatGPT_.

Provavelmente, você já utiliza o **ChatGPT** ou o _**Gemini**_ do _Google_ para gerar **textos e imagens**, e deseja integrar esses recursos em aplicações. Faremos isso com Java e Spring AI.

Para isso, criaremos um projeto com o Spring AI, entenderemos como ele funciona, e aprenderemos a escrever um código usando as **classes do Spring** para **integrar com as APIs** de maneira flexível, permitindo trocar o provedor ou a plataforma de maneira simples, sem reescrever toda a aplicação.

Utilizaremos a **inteligência artificial**, principalmente, para **geração de textos e imagens**, e descobriremos como fazer isso usando o módulo do Spring AI.

Também aprenderemos técnicas como _**prompt engineering**_ (ou **Engenharia de Prompt**) para melhorar os prompts que nossa aplicação envia ao integrar com a API, obtendo respostas mais assertivas e próximas do esperado.

Além disso, entenderemos como o Spring lida com **erros de integração** e APIs externas fora do ar, evitando a necessidade de tratamento manual nos códigos Java. Utilizaremos bastante as **documentações** do [Spring AI](https://docs.spring.io/spring-ai/reference/) e da [OpenAI](https://platform.openai.com/docs/overview) para entender esses recursos e funcionalidades.

## Quais são os requisitos?

Para melhor aproveitamento do curso, é necessário ter conhecimentos em **Java** e _**Spring Boot**_. Na plataforma da Alura, oferecemos formações para aprender Java e Spring Boot, pois, neste curso, utilizaremos essas ferramentas, mas não as ensinaremos do zero.

Também é importante conhecer **API REST**, pois desenvolveremos uma API REST que se comunicará com outra API REST. Portanto, é necessário entender o que é:

> - API;
> - Requisição;
> - Resposta;
> - Protocolo;
> - Verbos HTTP;
> - Cabeçalhos;
> - Entre outros.

Por fim, devemos saber o que é uma **inteligência artificial generativa**. Embora uma das etapas do curso seja nos integrarmos a essas ferramentas, não explicaremos do zero o que é o ChatGPT ou a ideia de IA generativa. Na plataforma, temos cursos que ensinam essa base sobre IA generativa.

Esses são os pré-requisitos para acompanhar o curso sem dificuldades.

## Conclusão

Esperamos que você goste do curso e aproveite o módulo do Spring para **tornar o código Java mais simples** ao integrar com APIs de inteligência artificial generativa. Focaremos na **OpenAI**, mas o Spring suporta dezenas de ferramentas e provedores, sendo fácil trocar de um para outro.

> Em caso de dúvidas, utilize nosso [fórum](https://cursos.alura.com.br/forum/categoria-inteligencia-artificial/todos) ou participe da [comunidade no _Discord_](https://cursos.alura.com.br/dashboard).

Ao final do curso, lembre-se de deixar sua **avaliação**, pois os feedbacks são essenciais para sempre melhorarmos nossos conteúdos. **Nos encontramos na primeira aula!**


-----------------------------------------------------------------------
# 02Preparando o ambiente: ferramentas
## IDE

O [IntelliJ](https://www.jetbrains.com/pt-br/idea/download) será utilizado como IDE para desenvolvimento do projeto.

## Java

O projeto do curso utiliza o [Java na versão 21](https://www.oracle.com/java/technologies/javase/jdk21-archive-downloads.html).

> Obs: atente-se aos **pré-requisitos** para se certificar de que já possui os conhecimentos necessários para acompanhar este curso sem dificuldades.

Recomendamos que você tenha experiência com o Playground da OpenAI e Spring Boot ou ter feito os seguintes cursos:

- [ChatGPT: desvendando a IA em conversas e suas aplicações](https://cursos.alura.com.br/course/chatgpt-desvendando-ia-conversas-aplicacoes)
- [IA: explorando o potencial da inteligência artificial generativa](https://cursos.alura.com.br/course/ia-explorando-potencial-inteligencia-artificial-generativa)
- [Spring Boot 3: desenvolva uma API Rest em Java](https://cursos.alura.com.br/course/spring-boot-3-desenvolva-api-rest-java)



-----------------------------------------------------------------------
# 03Preparando o ambiente: cadastro na OpenAI

Ao longo do curso vamos escrever uma aplicação Java que se integra com a API da OpenAI, disparando requisições para as funcionalidades de geração de textos e imagens via inteligência artificial generativa. Para que você consiga realizar os mesmos procedimentos que serão demonstrados no curso, será necessário a criação de uma conta na OpenAI, caso você ainda não tenha criado.

A criação da conta na OpenAI é um processo simples, mas requer atenção a detalhes para garantir que você possa acessar todos os recursos oferecidos, como a utilização da API. Para criar sua conta, siga o passo a passo abaixo:

## Passo 1: Acesso ao site da OpenAI

Abra algum navegador de sua preferência e acesse o [site da OpenAI developer platform](https://platform.openai.com/).

## Passo 2: Criação da conta

1. Na página inicial do site, clique no botão "Sign Up", que geralmente fica localizado no canto superior direito da página.
2. Na página de criação de conta, você tem a opção de se cadastrar com seu endereço de e-mail ou via integração com sua conta do Google/Microsoft/Apple.
    - **E-mail:** Digite seu e-mail e clique em "Continue". Siga as instruções para definir uma senha e confirmar seu e-mail.
    - **Google/Microsoft/Apple:** Clique no botão correspondente e siga as instruções para se autenticar com sua conta.

## Passo 3: Confirmação de e-mail

Se você se cadastrou via e-mail, acesse sua caixa de entrada e procure pelo e-mail de verificação enviado pela OpenAI, para clicar no link de confirmação (obs: o e-mail pode chegar em sua caixa de spam).

## Passo 4: Configuração do perfil

Após a confirmação do e-mail, você será redirecionado para a página de configuração do perfil, na qual deverá preencher as informações solicitadas, como nome e sobrenome.

## Passo 5: Acessando o dashboard

Depois de configurar seu perfil, você será redirecionado para a [página do dashboard da OpenAI](https://platform.openai.com/assistants), onde você pode explorar várias opções e serviços oferecidos pela OpenAI.

## Passo 6: Cadastro de cartão de crédito

Para utilizar a API da OpenAI e acessar todos os recursos, você precisará adicionar um método de pagamento. Acesse a [página de Billing](https://platform.openai.com/settings/organization/billing/overview) e clique em "Payment Methods" para vincular o seu cartão de crédito.

Clique no botão "Add payment method" e preencha as informações do seu cartão de crédito.

## Passo 7: Adicionando crédito à sua conta

Após cadastrar o cartão de crédito, será necessário adicionar um valor para ser utilizado em sua conta. Volte para a página de Billing e clique no botão "Add to credit balance". Na pop-up que for aberta, você precisará escolher o cartão de crédito que foi cadastrado e indicar o valor que deseja adicionar à sua conta.

O valor mínimo que a OpenAI permite é de 5 dólares, algo mais do que suficiente para o que utilizaremos ao longo do curso. Esse valor será debitado de seu cartão de uma vez e ficará como crédito para ser utilizado nos serviços da plataforma, sendo descontado de acordo com o uso.

## Observações importantes

- Mantenha suas informações de login seguras;
- Considere habilitar a [autenticação multi-fator](https://platform.openai.com/settings/profile?tab=security), nas configurações de sua conta;
- Verifique regularmente a [seção de faturamento](https://platform.openai.com/settings/organization/billing/overview) para monitorar seus gastos e evitar surpresas;
- Consulte a documentação da OpenAI para entender melhor [como utilizar a API de maneira eficiente e segura](https://platform.openai.com/docs/guides/safety-best-practices).



-----------------------------------------------------------------------
# 04Criando um projeto com Spring AI

## Transcrição

Neste vídeo, vamos iniciar nosso projeto utilizando o _Spring AI_ para criar uma **aplicação _Java_** que se integra com a **API da _OpenAI_**, aproveitando recursos de inteligência artificial generativa.

## Criando um projeto com _Spring AI_

### Acessando a documentação do _Spring AI_

Começaremos com a **documentação do _Spring_** aberta, especificamente, o [módulo do Spring AI](https://spring.io/projects/spring-ai).

Esse site é a fonte de informações onde podemos entender o que é o projeto, como ele funciona, e acessar a documentação necessária para aprender a usar o módulo do Spring focado em IA.

Na página, encontramos duas abas. A primeira delas é a aba de _**overview**_ (visão geral), que explica o projeto Spring AI e suas funcionalidades, como, por exemplo:

> - O **chat**, que será a principal funcionalidade utilizada ao longo do curso;
> - Os **provedores de inteligência artificial** suportados, como _Amazon Bedrock_, _Azure OpenAI_, _Mistral AI_ e _Minimax AI_, por exemplo, sendo a OpenAI a principal que utilizaremos;
> - Os recursos de **envio de mensagens** e **geração de imagens**, com uma listagem dos provedores suportados para cada tipo de recurso;
> - Entre outras informações.

Ao final da página, há uma seção chamada "_**Getting Started**_". Após entender os recursos e provedores suportados, podemos iniciar um projeto. Para isso, são oferecidas duas opções:

> 1. Usar uma ferramenta de **linha de comando** do Spring, caso o _**Spring CLI**_ esteja instalado no computador;
> 2. Ou utilizar o site [_**Spring Initializr**_](https://start.spring.io/) para gerar o projeto através de um **formulário** em uma página HTML.

Nesse caso, optaremos pela segunda opção: utilizar o Spring Initializr.

### Utilizando o _Spring Initializr_

O Spring Initializr é um site muito conhecido, utilizado para **geração de projetos com o Spring**, principalmente, com o _**Spring Boot**_. Criaremos o projeto a partir desta opção.

O formulário é dividido em duas partes:

> - À esquerda, informações sobre **linguagem**, **projeto** e **versão**;
> - À direita, informações sobre **dependências** e **módulos** do Spring a serem adicionados.

Escolheremos o _**Maven**_ como gerenciador de _build_ e de dependências, e a linguagem será **Java**. No momento da gravação deste curso, a última versão estável do Spring Boot é a **3.3.3**.

As informações do Maven serão as seguintes:

> - _**Group:**_ `br.com.alura`
> - _**Artifact:**_ `ecomart`
> - _**Name:**_ `ecomart`
> - _**Description:**_ _Demo project for Spring Boot_
> - _**Package name:**_ `br.com.alura.ecomart`
> - _**Packaging:**_ `Jar`
> - _**Java:**_ `21`

No lado direito do formulário, adicionaremos as **dependências**. Para isso, clicamos no botão "_ADD DEPENDENCIES…_" ou utilizamos o atalho "Ctrl + B". A principal dependência será a **OpenAI**.

> **Atenção!** Devemos escolher a opção OpenAI, não a Azure OpenAI.

Além da OpenAI, adicionaremos mais duas dependências: a _**Spring Web**_, para testar funcionalidades via requisições HTTP; e a _**Spring Boot DevTools**_, para facilitar mudanças no código com publicação automática, sem necessidade de reiniciar manualmente o projeto na IDE.

Ao final, as três dependências selecionadas serão: OpenAI; Spring Web; e Spring Boot DevTools.

Após preencher todo o formulário, clicaremos no botão "_**GENERATE**_" no canto inferior esquerdo, que criará um **arquivo ZIP** (`ecomart.zip`) do projeto. Após salvá-lo na pasta de downloads do computador, podemos descompactar para acessar a pasta do projeto ("**ecomart**").

Feito isso, podemos apagar o arquivo ZIP, pois já foi descompactado. Agora, precisamos **abrir o projeto na IDE**. Nesse caso, utilizaremos o _**IntelliJ**_, recomendado para facilitar o aprendizado.

### Abrindo o projeto no _IntelliJ_

Com o IntelliJ aberto, escolheremos a opção "_Open_" para **abrir um projeto**. Em seguida, navegaremos até a pasta "Downloads" e selecionaremos a pasta do projeto "ecomart".

Na tag `dependencies` do arquivo `pom.xml`, começamos a listar as **dependências**, incluindo a Spring AI e a OpenAI (provedor escolhido para implementação no módulo de inteligência artificial do Spring AI), além do Spring Web, do DevTools, e outras configurações automáticas do Spring.

> _`pom.xml`:_

```xml
<!-- código omitido -->

<dependencies>
        <dependency>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
                <groupId>org.springframework.ai</groupId>
                <artifactId>spring-ai-openai-spring-boot-starter</artifactId>
        </dependency>

        <dependency>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-devtools</artifactId>
                <scope>runtime</scope>
                <optional>true</optional>
        </dependency>
        <dependency>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-starter-test</artifactId>
                <scope>test</scope>
        </dependency>
</dependencies>

<!-- código omitido -->
```

No diretório "_src > main > java_", a estrutura de pacotes segue as configurações feitas no site ("br.com.alura.ecomart"), onde encontramos a classe `EcomartApplication` (arquivo `EcomartApplication.java`) com o método `main()`, que usaremos para executar a aplicação.

> _`EcomartApplication.java`:_

```java
package br.com.alura.ecomart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomartApplication {

    public static void main(String[] args) {
        SpringApplication.run(EcomartApplication.class, args);
    }

}
```

> Pode haver um erro no IntelliJ se o Java não estiver configurado corretamente, mas isso pode ser ajustado. Se já tivermos rodado outros projetos Java, isso provavelmente não ocorrerá.

## Conclusão

Com o projeto criado, temos uma **aplicação Java com Spring Boot**. Se já conhecemos o Spring Boot, não há novidades, exceto pelo módulo e pela dependência do **Spring AI**.

No próximo vídeo, vamos entender **como usar o Spring AI** e **integrar com a API da OpenAI**!


-----------------------------------------------------------------------
# 05Integração com a API da OpenAI

## Transcrição

Agora que temos nosso projeto criado e importado no _IntelliJ_, podemos **implementar alguma funcionalidade** escrevendo algum código que irá usar a inteligência artificial, ou seja, que irá **se integrar com a API da _OpenAI_**. Esse será nosso objetivo neste vídeo.

## Integração com a API da _OpenAI_

Como mencionado, trabalharemos no projeto fictício de uma empresa chamada **Ecomart**, um _e-commerce_ de produtos ecológicos. Ao longo do curso, teremos alguns cenários específicos, isto é, alguns **casos de uso** de funcionalidades que precisarão utilizar **inteligência artificial generativa**.

### Gerando nomes de produtos ecológicos

Para começar, neste primeiro exemplo, precisamos **gerar nomes de produtos ecológicos**, e queremos **usar a inteligência artificial** para nos ajudar com isso.

Imagine que a pessoa que vai utilizar o sistema irá entrar em alguma tela ou funcionalidade específica, e ela precisa de **nomes criativos** para produtos. A geração de nomes criativos será feita pela IA. Portanto, o objetivo deste vídeo será escrever um código que chama a API da OpenAI e envia o pedido de 5 nomes de produtos ecológicos; como se enviássemos um _prompt_, mas **via código _Java_**.

### Criando a classe `GeradorDeProdutosController`

Começaremos com um código Java tradicional, pensando em uma **API REST**.

> Na criação do projeto, adicionamos um **módulo _web_**, justamente para testar a aplicação via **requisições HTTP** no navegador.

Com o projeto aberto no IntelliJ, **criaremos uma nova classe** que será um _**controller**_ responsável por receber a requisição, e essa classe terá o código que chama a API da OpenAI.

Com o pacote "ecomart" selecionado, usaremos o atalho "Alt + Insert" e escolheremos a opção "_**Java Class**_". Feito isso, digitaremos `controller.` para criar um subpacote com esse nome, seguido do nome da classe, que será `GeradorDeProdutosController`.

> _`GeradorDeProdutosController.java`:_

```java
package br.com.alura.ecomart.controller;

public class GeradorDeProdutosController {
}
```

### Transformando a classe em um _controller_

Para **transformar a classe em um controller**, adicionamos a anotação `@RestController` acima da declaração, visto que será um controller do tipo REST.

Além disso, usamos a anotação `@RequestMapping()`, passando entre parênteses e aspas duplas a URL que será chamada no controller quando for disparada uma requisição. Nesse caso, passaremos a URL "gerador", ou seja, se chegar uma requisição para a `/gerador`, ela cairá nesse controller.

```java
// código omitido

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("gerador")
public class GeradorDeProdutosController {
}
```

### Declarando o método `gerarProdutos()`

No controller, precisamos ter um **método** com alguma lógica que será executada na requisição.

Dito isso, no escopo de `GeradorDeProdutosController`, criaremos um método `public` que devolve uma `String`, e nomearemos esse método como `gerarProdutos()`. Por enquanto, ele não fará nada; apenas compilaremos com `return` seguido de uma _string_ vazia (`""`).

Acima do método, adicionamos `@GetMapping` para mapear o **verbo do protocolo HTTP**.

```java
// código omitido

@RestController
@RequestMapping("gerador")
public class GeradorDeProdutosController {

    @GetMapping
    public String gerarProdutos() {
        return "";
    }

}
```

### Usando o _Spring AI_ para chamar a API

Até o momento, temos a parte **web** implementada, um **controller** construído, e a **requisição _GET_** mapeada. Assim, se chegar uma requisição GET para `/gerador`, cairemos no método `gerarProdutos()`, que, no momento, devolve apenas uma string vazia. O escopo do método `gerarProdutos()` é onde faremos a **chamada para a API da OpenAI**, usando o **Spring AI**.

O Spring AI já foi adicionado ao projeto como uma das dependências, com o módulo da OpenAI. Porém, qual classe devemos chamar? Qual classe precisamos instanciar? Como fazer para integrar? Como funciona a API do Spring para se integrar com a API da OpenAI?

Retornaremos à **documentação do Spring** para descobrir.

### Acessando a documentação do _Spring AI_

Com a [documentação do Spring AI](https://spring.io/projects/spring-ai) aberta, ao final da página, encontramos a seção "_**Getting Started**_", que explica como criar o projeto. Contudo, **não há exemplo de código**.

Agora que temos o projeto criado, como proceder?

No topo da página, temos duas abas: a primeira chamada "_**OVERVIEW**_", que exploramos até o momento; e a segunda chamada "_**LEARN**_". Nessa segunda aba, encontramos as **versões** do Spring AI:

> - `1.0.0-SNAPSHOT`;
> - `1.0.0-M2`.

Nesse caso, acessaremos a versão `1.0.0-SNAPSHOT`, que é a atual no momento da gravação. À direita da versão, há um link chamado "[_Reference Doc._](https://docs.spring.io/spring-ai/reference/index.html)". É justamente isso que queremos acessar: a **documentação de referência**, para entendermos como funciona a parte do código.

Ao clicar nesse link, somos redirecionados para uma documentação com o **ponto de vista técnico** de código. Trata-se de uma documentação muito completa, com uma barra de menu lateral à esquerda contendo **categorias**, onde conseguimos encontrar o que desejamos implementar.

> A depender do que queremos implementar, encontramos seções específicas neste menu.

Nesse menu lateral esquerdo, clicaremos sobre o item "_**Spring AI API**_". Ao fazer isso, a página se expande para exibir vários sub-itens dentro dessa seção. A partir do menu, selecionaremos o primeiro item: "[_**Chat Client API**_](https://docs.spring.io/spring-ai/reference/api/chatclient.html)".

Nosso objetivo é acessar a API do Spring para fazer a **integração com o recurso de chat**, pois esse é o modo que queremos usar da inteligência artificial generativa. No momento, não queremos gerar imagens ou fazer transcrição de áudio, por exemplo; queremos apenas o modo de chat, como no ChatGPT, onde fazemos uma pergunta, a IA gera uma resposta, e retorna a resposta gerada.

Na documentação do Chat Client API, é explicado como esse modo funciona no caso do Spring, e são apresentados alguns **exemplos de código**. Com base nessa parte da documentação, aprenderemos a **escrever um código** para fazer a chamada para a API da OpenAI. Observe o exemplo abaixo:

> _Exemplo de código extraído da documentação do Spring AI, na seção "Spring AI API > Chat Client API > [Using an autoconfigured `ChatClient.Builder`](https://docs.spring.io/spring-ai/reference/api/chatclient.html#_using_an_autoconfigured_chatclient_builder)":_

```java
@RestController
class MyController {

    private final ChatClient chatClient;

    public MyController(ChatClient.Builder chatClientBuilder) {
        this.chatClient = chatClientBuilder.build();
    }

    @GetMapping("/ai")
    String generation(String userInput) {
        return this.chatClient.prompt()
            .user(userInput)
            .call()
            .content();
    }
}
```

Perceba que foi usado um exemplo semelhante ao que fizemos anteriormente, criando um **controller** e um **método**. No escopo do método, está o trecho de código que precisamos.

### Ajustando o método `gerarProdutos()`

Vamos copiar esse trecho do `return`, voltar para o IntelliJ, e substituir o `return ""` pelo que copiamos. Evidentemente, teremos um **erro de compilação**, pois o exemplo usa `return this.chatClient`. Sendo assim, precisamos ter um atributo na classe chamado `chatClient`.

Analisando o controller de exemplo da documentação, ele tem um **atributo** e um **construtor** para fazer a injeção de dependências desse atributo. Copiaremos tanto o atributo quanto o construtor e colaremos no escopo da classe `GeradorDeProdutosController`, acima da declaração do método.

Agora, precisamos apenas **fazer a importação**. Para isso, vamos pedir que o IntelliJ importe `ChatClient` e substituir o nome do controller `MyController` por `GeradorDeProdutosController`.

> _`GeradorDeProdutosController.java`:_

```java
package br.com.alura.ecomart.controller;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("gerador")
public class GeradorDeProdutosController {

    private final ChatClient chatClient;

    public GeradorDeProdutosController(ChatClient.Builder chatClientBuilder) {
        this.chatClient = chatClientBuilder.build();
    }

    @GetMapping
    public String gerarProdutos() {
        return this.chatClient.prompt()
                .user(userInput)
                .call()
                .content();
    }

}
```

Sempre que quisermos fazer uma **chamada para a API**, para o provedor de inteligência artificial que usamos neste curso (OpenAI), precisamos usar a classe `ChatClient`, que é o **cliente de chat**.

Essa classe do Spring abstrai a integração com a API, seja da OpenAI ou de qualquer provedor, para usar o recurso de chat — envio de mensagens e geração de respostas via IA generativa.

Perceba que o construtor `GeradorDeProdutosController()` não recebe como parâmetro um objeto `ChatClient`, mas sim um `ChatClient.Builder`.

No Spring, não conseguimos injetar diretamente o `ChatClient`. É necessário injetar o `Builder`, que possui um método chamado `build()`, responsável pela construção do `ChatClient`. Portanto, no construtor, injetamos `Builder` e chamamos `build()` para obter o objeto.

### Declarando a variável `pergunta`

No momento, o método `gerarProdutos()` retorna um **erro de compilação**, pois a variável `userInput` não existe. O `userInput` seria a **pergunta**, isto é, o texto.

Para corrigir isso, antes do `return` no escopo do método, vamos **declarar uma variável** (`var`) chamada `pergunta`, que será igual a uma string com o pedido "Gere 5 produtos ecológicos". Feito isso, no método `user()`, iremos substituir `userInput` pela variável local `pergunta`.

```java
// código omitido

@GetMapping
public String gerarProdutos() {
    var pergunta = "Gere 5 produtos ecologicos";

    return this.chatClient.prompt()
            .user(pergunta)
            .call()
            .content();
}

// código omitido
```

Esse é o código para fazermos a **integração com a API da OpenAI**. Note que ele é simples: temos primeiro `this.chatClient.prompt()`, seguido de `.user()` contendo a **mensagem da pessoa usuária**, `.call()` para **disparar a requisição**, e `.content()` para **obter o conteúdo da resposta**.

Isso retorna uma string com a resposta gerada pela inteligência artificial.

## Conclusão

Assim, temos o código implementado, o controller finalizado, e uma **funcionalidade** aplicada ao projeto que já conseguimos testar. Basta executar a aplicação e acessar o endereço `localhost:8080/gerador`, para chamar o método `gerarProdutos()` e retornar a string.

Para executar o projeto, acessamos o menu "_**Project**_" à esquerda, abrimos a classe `EcomartApplication` (que contém o método `main()`), clicamos no ícone de _play_, e escolhemos a opção "_Run_". Ao fazer isso, o _console_ retorna um erro, indicando que precisa de uma **chave de API** que está indefinida. Abordaremos esse detalhe importante no próximo vídeo!

-----------------------------------------------------------------------
# 06API Key e variáveis de ambiente

## Transcrição

Ao tentar executar o projeto e rodar a classe _main_, comum em projetos com _Spring Boot_, ocorreu um erro no _console_ e o projeto não foi inicializado. Vamos entender o que aconteceu e o que precisamos fazer para **continuar a integração com a API da _OpenAI_**?

## API _key_ e variáveis de ambiente

No console, na linha que contém "_Caused by_" e mostra a causa raiz da exceção, é indicado que **a chave da API da OpenAI deve ser configurada** ("_OpenAI API key must be set._").

### Adicionando uma propriedade de conexão

Até o momento, não configuramos essa chave no projeto. Nesse caso, o retorno sugere usar uma **propriedade de conexão**, fornecendo duas opções de propriedades.

Primeiramente, em projetos com **Spring Boot**, isso deve ser configurado no arquivo `application.properties`, então utilizamos a propriedade de conexão `spring.ai.openai.api-key`.

```plaintext
spring.ai.openai.api-key
```

Vamos copiar o nome dessa propriedade, minimizar o terminal, ir até "_src > main > **resources**_" no menu lateral esquerdo, e abrir o arquivo `application.properties` onde colaremos a propriedade.

> _`application.properties`:_

```vbnet
spring.application.name=ecomart

spring.ai.openai.api-key
```

Toda propriedade tem um **nome** e precisamos atribuir um **valor**. Nesse caso, temos uma questão de **segurança**: quando usamos o _ChatGPT_, fazemos _login_ no navegador, e a OpenAI identifica quem se conectou e está enviando requisições. Por outro lado, **não fizemos login no código**.

Sendo assim, ao rodar a aplicação e integrar com a API da OpenAI, como ela irá **identificar quem disparou a requisição** para registrar e cobrar? Afinal, a API é um recurso pago.

Diferente do navegador, onde fazemos login, não fornecemos um nome de usuário e senha. Nesse caso, precisamos **criar uma chave de API** na conta da OpenAI, que será utilizada para integrações.

### Criando uma chave de API

Com o navegador aberto, faremos login na conta da OpenAI e acessaremos a página "_**Dashboard**_" no menu superior à direita. Feito isso, no menu lateral esquerdo, o último item é "_**API keys**_", onde cadastramos as **chaves**. Criaremos uma **nova chave** clicando em "_Create new secret key_".

Na janela aberta, definiremos um **nome** para a chave, como `curso-4091-spring`, e clicaremos em "_Create secret key_". A chave gerada é uma string extensa que precisamos copiar para usar no código.

> **Importante!** Copie a chave neste momento, pois ao fechar a janela, não conseguimos visualizá-la novamente. Se não copiarmos, será necessário gerar uma nova.

Com a chave copiada, podemos retornar ao IntelliJ e atribuí-la à propriedade `spring.ai.openai.api-key` que acabamos de adicionar ao arquivo `application.properties`.

### Configurando uma variável de ambiente

A chave da API é uma **informação sensível** e não deve ser exposta no código. Portanto, vamos ajustar isso usando **variáveis de ambiente**. No Spring, delimitamos variáveis de ambiente com `${}`.

No `application.properties`, vamos substituir a chave pela variável `OPENAI_API_KEY`.

```ini
spring.application.name=ecomart

spring.ai.openai.api-key=${OPENAI_API_KEY}
```

> Lembre-se de **substituir variável de ambiente** pela sua própria chave gerada na OpenAI.

Agora, precisamos **configurar uma variável de ambiente**. Para isso, podemos usar o terminal para executar um comando, ou, de forma independente do sistema operacional, **configurar no IntelliJ**.

No pacote "src > main > java", clicaremos com o botão direito sobre o arquivo `EcomartApplication.java` e escolheremos a opção "_Modify Run Configuration…_". No campo "_**Environment variables**_", podemos configurar a variável `OPENAI_API_KEY` igual à chave de API.

Dessa forma, passamos a chave, mas ela não estará fixa no código (_hard coded_). Feito isso, basta aplicar as mudanças e tudo continuará funcionando normalmente, **sem expor a chave**.

> **Importante!** O IntelliJ armazena a configuração da variável de ambiente no arquivo `workspace.xml` dentro da pasta oculta "_**.idea**_". Se usarmos o _Git_ para controle de versão, é importante **não enviar essa pasta para o repositório**. No entanto, o arquivo `.gitignore` executa a função de excluir a pasta ".idea", evitando que o arquivo XML seja enviado.

### Testando o código

Após configurar, podemos executar novamente a classe `EcomartApplication`, isto é, a classe _main_. O projeto será inicializado na porta 8080, permitindo testar uma **requisição** para o controller.

No navegador, acessaremos o endereço `http://localhost:8080/gerador`, que mapeamos no controller. O método usa as classes do Spring para chamar a OpenAI, retornando uma resposta:

> Claro! Aqui estão cinco produtos ecológicos que podem ajudar a reduzir o impacto ambiental:
> 
> 1. **Sacolas Reutilizáveis**: Feitas de materiais duráveis como algodão orgânico ou poliéster reciclado, essas sacolas substituem as sacolas plásticas de uso único.
> 2. **Escovas de Dente de Bambu**: Feitas de bambu biodegradável, essas escovas são uma alternativa sustentável às escovas de plástico tradicionais.
> 3. **Canudos de Aço Inoxidável ou Bambu**: Em vez de usar canudos de plástico descartáveis, opte por canudos reutilizáveis que podem ser lavados e usados várias vezes.
> 4. **Cosméticos Naturais e Orgânicos**: Produtos de beleza que utilizam ingredientes naturais e orgânicos, evitando químicos nocivos e embalagens plásticas desnecessárias.
> 5. **Panelas e Utensílios de Cozinha de Materiais Sustentáveis**: Panelas de ferro fundido, utensílios de bambu e outros produtos de cozinha feitos de materiais ecológicos duram mais e são melhores para o meio ambiente. Esses produtos não só ajudam a reduzir o desperdício e a poluição, mas também promovem práticas de consumo mais responsáveis e sustentáveis.

A cada atualização da página, uma nova requisição é disparada, gerando **respostas variadas**.

> Claro! Aqui estão cinco produtos ecológicos que podem ajudar a reduzir o impacto ambiental:
> 
> 1. **Sacolas Reutilizáveis**: Feitas de materiais duráveis como algodão orgânico, poliéster reciclado ou juta, essas sacolas são uma alternativa sustentável às sacolas plásticas descartáveis.
> 2. **Escovas de Dentes de Bambu**: As escovas de dentes de bambu são biodegradáveis e uma excelente alternativa às escovas de dentes de plástico que demoram centenas de anos para se decompor.
> 3. **Shampoo e Condicionador em Barra**: Esses produtos eliminam a necessidade de embalagens plásticas e são frequentemente formulados com ingredientes naturais e biodegradáveis.
> 4. **Copo Reutilizável**: Feitos de materiais como aço inoxidável, vidro ou bambu, os copos reutilizáveis são ideais para substituir os copos descartáveis de café ou outras bebidas.
> 5. **Painéis Solares Portáteis**: Pequenos painéis solares que podem ser usados para carregar dispositivos eletrônicos, como smartphones e tablets, são uma excelente maneira de aproveitar a energia renovável e reduzir a dependência de fontes de energia não renováveis. Esses produtos são apenas algumas opções que podem ajudar a diminuir o impacto ambiental e promover um estilo de vida mais sustentável.

Dessa forma, conseguimos implementar a **integração com a API da OpenAI** usando o **Spring AI**.

O código na classe `GeradorDeProdutosController` é simples e fácil de entender, destacando a **simplicidade** do Spring para facilitar a integração com a API da OpenAI.

## Conclusão

Neste vídeo, conhecemos um código **simples** e **fluente** para realizar a integração com a API da OpenAI usando Spring AI. Nas próximas aulas, continuaremos explorando **recursos do Spring AI**!

-----------------------------------------------------------------------
# 07Para saber mais: cuidados com a chave da API

Uma chave de API permite a comunicação entre sua aplicação e os serviços fornecidos por uma plataforma, como a OpenAI. Ela funciona como uma **senha** que autentica e autoriza as requisições que sua aplicação dispara para a API. Portanto, proteger essa chave é extremamente importante para evitar acessos não autorizados e manter a integridade de seus projetos.

## O que é uma chave de API?

Uma chave de API é um **token** único que é fornecido por um serviço, quando você se registra para usar suas APIs. Esta chave deve ser inserida em suas requisições para autenticar sua aplicação e permitir que ela acesse os recursos da API. Sem essa chave, sua aplicação não poderá se comunicar com a API do serviço.

## Cuidados com a chave de API

Manter a chave de API segura é fundamental para proteger seus dados e garantir que apenas os aplicativos autorizados tenham acesso aos serviços que você utiliza. Listamos a seguir alguns cuidados importantes que você deve ter em relação às suas chaves de API:

1. **Segurança**
    
    - **Armazenamento seguro:** Nunca armazene sua chave de API em texto puro no código-fonte ou em locais acessíveis publicamente, como repositórios GitHub. Utilize variáveis de ambiente ou serviços de gerenciamento de segredos para manter sua chave segura.
    - **Acesso restrito:** Limite o acesso à chave somente às pessoas que realmente precisam dela. Não compartilhe sua chave em fóruns públicos ou com terceiros não confiáveis.
2. **Rotacionamento**
    
    - **Troca regular:** Crie um hábito de rotacionar suas chaves de API periodicamente. Isso minimiza o risco de uso indevido em caso de comprometimento.
    - **Processo de rotação:** Garanta que você tenha um processo bem definido para rotacionar chaves, incluindo notificações e atualizações nos ambientes de desenvolvimento e produção.
3. **Monitoramento**
    
    - **Logs de acesso:** Utilize logs para monitorar todas as requisições feitas com sua chave de API, pois essa prática pode ajudar a identificar atividades incomuns ou suspeitas.
    - **Limitação de acesso:** Se possível, configure limites de uso e restrições geográficas ou de IP para reduzir o risco de abuso.
4. **Revogação**
    
    - **Resposta rápida:** Se você suspeitar que sua chave de API foi comprometida, revogue-a imediatamente e gere uma nova. A OpenAI disponibiliza uma [interface em que você pode gerenciar e revogar suas chaves de API](https://platform.openai.com/api-keys).
    - **Investigue a causa:** Depois de revogar uma chave comprometida, investigue como o comprometimento ocorreu e tome medidas para prevenir futuros incidentes.
5. **Camadas de autenticação**
    
    - **Autenticação Multifator (MFA):** Sempre que possível, ative MFA nas contas que possuem acesso para gerar ou visualizar chaves de API, pois isso adiciona mais uma camada de segurança.
    - **Tokens temporários:** Se o serviço permitir, utilize tokens temporários que expiram após um certo período, em vez de chaves permanentes.
6. **Treinamento**
    
    - **Boas práticas:** Certifique-se de que todas as pessoas da sua equipe estejam cientes das boas práticas de segurança em relação ao uso e manuseio das chaves de API.
    - **Procedimentos:** Documente e distribua procedimentos claros sobre como gerar, utilizar, armazenar e revogar chaves de API.

Ao seguir as recomendações anteriores, você diminui consideravelmente os riscos de segurança, construindo um ambiente muito mais confiável para o desenvolvimento e operação das suas aplicações, que se integram com serviços externos via chaves de API.

-----------------------------------------------------------------------
# 02Playground e parâmetros

## Transcrição

Vamos continuar nosso curso de Spring AI!

## Revisando a Aula Anterior

Na aula anterior, aprendemos a criar o projeto e a realizar nossa primeira integração com a API da OpenAI, utilizando as classes do Spring e o módulo de inteligência artificial. Observamos que o código ficou bem organizado. Agora, vamos implementar novas funcionalidades em nosso projeto Ecomart.

No exemplo apresentado na aula anterior, configuramos uma URL `/gerador`, que, ao receber uma requisição, aciona nosso _controller_ para gerar cinco produtos ecológicos aleatórios. A inteligência artificial realiza essa geração e o resultado é exibido no navegador. Tudo está funcionando corretamente. Agora, vamos explorar um caso de uso diferente: a necessidade da Ecomart de classificar produtos.

## Explorando a API da OpenAI

Antes de partir para o código e implementar essa nova funcionalidade, precisamos entender detalhadamente como a API da OpenAI funciona internamente, como ela realiza essa geração e se temos algum controle sobre isso.

Poderíamos consultar a documentação do Spring e alterar parâmetros diretamente no código, mas existe um recurso mais interessante que facilita esse processo: o Playground. Trata-se de uma área para testes e simulações, onde podemos ajustar parâmetros diretamente na interface web da OpenAI.

## Utilizando o Playground

Vamos abrir a aba do navegador onde estamos logados na conta da OpenAI. Na aula anterior, mostramos como gerar a chave da API. No menu superior, há um item chamado Playground. Ao clicar nele, somos levados a essa ferramenta, que é um espaço para experimentação e simulação diretamente no navegador.

Após encontrar os parâmetros adequados para nosso objetivo, levaremos esses parâmetros para o código. Testar aqui antes de partir para o código torna o processo mais produtivo e facilita a determinação das configurações que atendem nosso caso de uso específico.

No Playground, a interface se assemelha ao chat GPT, mas com muitos parâmetros adicionais. O chat GPT utiliza a inteligência artificial da OpenAI, mas permite alterar apenas a versão do modelo (GPT-4 ou GPT-3), pois já vem pré-configurado. No caso de uma API que consumimos, queremos personalizar ao máximo. Aqui, temos acesso a muitos parâmetros não disponíveis no chat GPT.

Na tela, há um formulário central onde podemos enviar perguntas. Digitaremos a mensagem "gere cinco produtos ecológicos" e clicaremos no botão verde "Run" para executar. O processo de geração de texto ocorre conforme a pergunta enviada, semelhante ao uso direto do chat GPT. No entanto, à direita da página, há vários parâmetros que podemos ajustar para controlar a geração do texto. Aqui reside nossa flexibilidade, permitindo modificar a geração para se adequar ao nosso cenário de uso.

## Ajustando Parâmetros no Playground

Um dos principais parâmetros é a temperatura, que vem com o valor padrão de 1. Podemos ajustá-la usando um _slider_. Se aumentarmos para 1.5, por exemplo, e rodarmos a geração novamente, podemos observar mudanças na forma de escrita. Ao clicar em "Run", a geração começa, mas pode apresentar palavras aleatórias em vários idiomas, fugindo do contexto desejado.

Isso ocorre porque aumentamos a temperatura, que controla o quão criativa a resposta deve ser. A geração de texto é baseada em probabilidade de palavras, e aumentar a temperatura faz com que palavras menos prováveis sejam escolhidas, aumentando a criatividade, mas também o risco de resultados indesejados. Quando são gerados resultados que fogem do contexto e parecem não fazer sentido, ocorre o que chamamos de **alucinação de IA**.

No nosso caso, 1.5 foi um valor muito alto. Quando ajustamos para 1.2 e pedimos novamente a geração de cinco produtos, a geração ocorre sem problemas, com menor criatividade e risco de erro. Podemos testar diferentes valores, como 1.1, para ajustar conforme necessário.

Além da temperatura, podemos controlar o número de _tokens_, que explicaremos mais adiante no curso. Disponibilizaremos, também, uma atividade "Para Saber Mais" que explora outros parâmetros. O importante é que o Playground permite testes e simulações até encontrarmos os valores ideais para nossa aplicação. Com os parâmetros ajustados, levamos essas configurações para o código. No nosso caso, deixaremos a temperatura em 1.0.

## Próximos Passos

Precisamos, agora, saber como transferir esses parâmetros para o código, mas isso será abordado no próximo vídeo. Até lá!



-----------------------------------------------------------------------
# 03Para saber mais: parâmetros da API

A API da OpenAI possui diversos parâmetros disponíveis que podem ser ajustados para obter os resultados desejados em suas aplicações. Esses parâmetros influenciam o comportamento do modelo e a qualidade das respostas geradas. Veja a seguir os principais parâmetros e como eles funcionam:

## Temperature

- **Definição:** O parâmetro `Temperature` controla a aleatoriedade das respostas geradas pelo modelo.
- **Intervalo de valores:** 0.0 a 2.0
- **Descrição:** Valores mais baixos, como 0.5 ou 0.6, fazem com que o modelo produza respostas mais determinísticas e focadas, reduzindo a criatividade. Já valores mais altos, como 1.2 ou 1.5, aumentam a criatividade e a diversidade das respostas, mas também podem introduzir mais incoerência.
- **Uso:** Use um valor baixo para tarefas que requerem respostas precisas e coerentes, como explicações técnicas. Use `temperature` alta para tarefas criativas, como escrita de histórias.

## Max Tokens

- **Definição:** O parâmetro `Maximum Tokens` define o número máximo de tokens (palavras ou partes de palavras) na resposta gerada pelo modelo.
- **Intervalo:** Depende do modelo utilizado. Normalmente tem um limite de 4096 ou 16384.
- **Descrição:** Este parâmetro limita o comprimento da resposta. Por exemplo, se for definido como 50, a resposta não ultrapassará 50 tokens.
- **Uso:** Ajuste de acordo com a necessidade da aplicação. Para respostas curtas e diretas, use um valor menor. Para respostas detalhadas, use um valor maior.

## TopP

- **Definição:** O parâmetro `TopP`, também conhecido como núcleo de amostragem, controla a diversidade através da restrição do conjunto de candidatos para a próxima palavra.
- **Intervalo:** 0.0 a 1.0
- **Descrição:** Com `TopP` de 0.9, o modelo considera apenas os 90% dos candidatos mais prováveis (com base na sua probabilidade cumulativa) para a próxima palavra. Isso pode tornar as respostas mais variadas e menos previsíveis.
- **Uso:** Use em conjunto com `temperature` para ajustar a criatividade e diversidade das respostas. Valores mais altos podem gerar respostas mais variadas.

## Frequency penalty

- **Definição:** O parâmetro `Frequency penalty` aplica uma penalidade a palavras que já apareceram na resposta.
- **Intervalo:** 0.0 a 2.0
- **Descrição:** Valores positivos reduzem a probabilidade de repetir as mesmas palavras, incentivando a diversidade lexical. Valores negativos podem aumentar a probabilidade de repetição.
- **Uso:** Utilize um valor alto quando quiser respostas com menor repetição de palavras, sendo útil em situações que requerem maior variação lexical.

## Presence penalty

- **Definição:** O parâmetro `Presence penalty` penaliza a presença de determinadas palavras na resposta.
- **Intervalo:** 0.0 a 2.0
- **Descrição:** Similar ao `Frequency penalty` mas com foco na presença de palavras, não apenas na frequência. Valores altos desencorajam a inclusão de palavras presentes em contextos anteriores, enquanto valores baixos incentivam essa inclusão.
- **Uso:** Ajuste para controlar a inclusão de certas palavras na resposta, mantendo ou alterando o contexto de forma mais flexível.

## Stop sequences

- **Definição:** O parâmetro `Stop sequences` define uma ou mais sequências de caracteres que, ao serem encontradas, fazem com que o modelo interrompa a geração de texto.
- **Descrição:** Pode ser uma string única ou uma lista de strings. Quando uma dessas sequências aparece na resposta gerada, a geração de texto é interrompida.
- **Uso:** Use para delimitar respostas e evitar saídas excessivamente longas ou fora de contexto. Por exemplo, em um chatbot, você pode definir sequências de parada para garantir que o modelo responda de maneira concisa.

Entender e ajustar os parâmetros da API da OpenAI permite que você obtenha respostas mais alinhadas às necessidades de sua aplicação, seja ela técnica, criativa ou conversacional. Experimente diferentes combinações de parâmetros para descobrir quais configurações funcionam melhor para seu caso de uso específico.

-----------------------------------------------------------------------
# 04Categorizador de produtos

## Transcrição

Agora que compreendemos o funcionamento do Playground e os parâmetros da OpenAI, podemos avançar para a próxima funcionalidade, ajustando os parâmetros conforme nosso caso de uso específico!

## Resetando o Playground

Com a tela do Playground aberta, simularemos a funcionalidade que será traduzida para código. Podemos limpar todas as mensagens geradas clicando no ícone de vassoura, o que apagará todas as mensagens.

## Campo System no Playground

Além dos parâmetros à direita, na parte central inferior, há o campo onde digitamos a mensagem. Na parte superior, existe um campo denominado _System_, onde configuramos o comportamento do gerador de texto ou ferramenta de chat. Podemos deixar algo pré-configurado para que, sempre que enviarmos uma mensagem no campo do usuário, essa configuração de sistema seja considerada. Isso será útil.

## Testando a Funcionalidade no Playground

A próxima funcionalidade que desenvolveremos será a categorização de produtos. Imagine que, em nosso e-commerce, temos diversos produtos e queremos categorizá-los. Indicaremos o nome do produto e ele deverá nos informar a qual categoria pertence. Eventualmente, precisaremos alterar a categorização dos produtos, e podemos utilizar a inteligência artificial para automatizar e facilitar esse processo.

Para isso, configuraremos a seguinte mensagem no campo _System_: "Você é um categorizador de produtos." No campo do usuário, enviaremos o nome de um produto, como "escova de dentes". Antes de executar, ajustaremos a temperatura para 0.85, pois queremos que o categorizador seja conservador e restrito, sem muita criatividade.

Após configurar a mensagem do sistema e a temperatura, enviaremos "escova de dentes" no campo do usuário e clicaremos em executar. A resposta que recebemos é:

> Categoria: Cuidados Pessoais > Higiene Bucal > Escovas de Dentes.

Ou seja, nos informou a categoria de cuidados pessoais, com subcategorias como higiene bucal e escova de dentes. Isso demonstra que, ao enviar "escova de dentes", o sistema já sabia que deveria categorizar graças ao campo _System_. Com a temperatura em 0.85, ele categorizou corretamente, sem informações adicionais.

Vamos testar com outro produto, como "sacola reutilizável". A resposta dessa vez é:

> Categoria: Casa e Cozinha > Organização e Armazenamento > Sacolas Reutilizáveis

Está funcionando perfeitamente!

## Implementando em Java com Spring AI

Agora, queremos implementar essa funcionalidade em nosso código Java, utilizando Spring AI. Vamos simular esse cenário no código.

No IntelliJ, criaremos uma nova classe _controller_ para não misturar com o gerador. No diretório `src/main/java`, dentro do pacote `controller`, copiaremos a classe `GeradorDeProdutos` e a renomearemos para `CategorizadorDeProdutosController`. Esta será nossa nova classe para categorizar produtos.

Agora, faremos as adaptações necessárias. A URL não será mais `/gerador`, mas sim `/categorizador`. O gerador chamará o `GeradorController`, enquanto o categorizador chamará o `CategorizadorController`. Precisaremos do `ChatClient`, do construtor e de um método anotado com `@GetMapping`. Renomearemos o método para `categorizar`.

## Simulando a Categorização no Código

Simularemos o que fizemos no Playground. Teremos duas variáveis: `system`, com o texto `"Você é um categorizador de produtos"`, e `pergunta`, com a mensagem do usuário, como `"Escova de dentes"`.

```typescript
@GetMapping
public String categorizar() {
    var system = "Você é um categorizador de produtos";
    var pergunta = "Escova de dentes";

    return this.chatClient.prompt()
        .user(pergunta)
        .call()
        .content();
}
```

Precisamos adaptar a chamada, pois atualmente estamos passando apenas a pergunta do usuário. Precisamos passar o _system_ e o parâmetro de temperatura, o que é simples com as classes do Spring AI.

Antes de passar a mensagem do usuário, chamaremos o método `.system` e passaremos a variável `system`. Para configurar o sistema, basta chamar o método `.system`.

Recapitulando: no `chatClient`, começaremos um novo `.prompt`, passaremos o sistema (`.system(system)`) e a pergunta do usuário (`.user(pergunta)`), e chamaremos `.call()` para obter o conteúdo da resposta gerada pela IA (`.content()`).

```typescript
@GetMapping
public String categorizar() {
    var system = "Você é um categorizador de produtos";
    var pergunta = "Escova de dentes";

    return this.chatClient.prompt()
        .system(system)
        .user(pergunta)
        .call()
        .content();
}
```

## Ajustando Parâmetros da API

Para ajustar os parâmetros da API, como a temperatura, após a mensagem do usuário, chamaremos o método `.options()`, que recebe as opções de parâmetros. Como existem vários parâmetros, utilizaremos a classe `ChatOptionsBuilder` para construá-lo.

Depois, chamaremos o método `.builder()` para construir o objeto e, antes de chamar `.build()`, configuraremos os parâmetros com métodos como `.withTemperature()`, passando `0.85f`. No Java, precisamos adicionar `f` para indicar que é um _float_.

```typescript
@GetMapping
public String categorizar() {
    var system = "Você é um categorizador de produtos";
    var pergunta = "Escova de dentes";

    return this.chatClient.prompt()
        .system(system)
        .user(pergunta)
        .options(ChatOptionsBuilder.builder()
                .withTemperature(0.85f)
                .build())
        .call()
        .content();
}
```

Implementamos a nova funcionalidade. Para torná-la mais interessante, podemos receber a pergunta como parâmetro, em vez de deixá-la fixa no código. Então vamos remover a linha `var pergunta = "Escova de dentes";` e, no método `categorizar`, receberemos `String produto`, permitindo chamar a URL `/categorizador` e passar o parâmetro na barra de endereços. Além disso, `.user()` receberá `produto` e não `pergunta`.

Assim, testamos de maneira dinâmica, sem fixar um único produto no código.

```typescript
@GetMapping
public String categorizar(String produto) {
    var system = "Você é um categorizador de produtos";
        
    return this.chatClient.prompt()
        .system(system)
        .user(produto)
        .options(ChatOptionsBuilder.builder()
                .withTemperature(0.85f)
                .build())
        .call()
        .content();
}
```

## Testando no Navegador

Vamos testar no navegador.

Reiniciamos o projeto e, ao acessar [localhost:8080/categorizador?produto=Celular](http://localhost:8080/categorizador?produto=Celular), o sistema retornará:

> Categoria principal: Eletrônicos Subcategorias possíveis: 1. Smartphones 2. Telefones básicos 3. Acessórios para celular 4. Peças de reposição para celular Se houver mais especificações ou características do produto, posso ajudar a categorizá-lo de forma ainda mais detalhada.

Ao testar com "Escova de dentes" e "Sacola reutilizavel", ele também retorna as categorias corretas.

[localhost:8080/categorizador?produto=Escova de dentes](http://localhost:8080/categorizador?produto=Escova%20de%20dentes)

> Categoria: Higiene Pessoal.

[localhost:8080/categorizador?produto=Sacola reutilizavel](http://localhost:8080/categorizador?produto=Sacola%20reutilizavel)

> Categoria: Casa e Jardim > Organização e Armazenamento > Sacolas Reutilizáveis

## Conclusão e Próximos Passos

A integração está funcionando, e o código permanece simples, configurando parâmetros como no Playground. Porém, observamos que a resposta não está padronizada, apresentando subcategorias diferentes. Vamos melhorar essa padronização nos próximos vídeos!

-----------------------------------------------------------------------
# 05Prompt Engineering

## Transcrição

Implementamos nosso categorizador de produtos, utilizando recursos para alterar parâmetros, como a temperatura, e tornar nosso código dinâmico, permitindo informar o nome do produto pela URL no navegador.

No entanto, como mencionado anteriormente, a resposta não está padronizada, resultando em formatos distintos. Isso não é ideal, pois desejamos controlar a resposta devolvida pela inteligência artificial. Embora ela gere respostas de maneiras variadas, podemos tentar controlar para que a resposta seja o mais próxima possível do esperado na aplicação. Esse será o foco deste vídeo!

## Ajustando o Parâmetro de Sistema

Atualmente, no método `categorizar()`, o parâmetro do sistema está configurado apenas como `"Você é um categorizador de produtos"`. Isso está muito genérico e abstrato. O problema é que não especificamos como a resposta deveria ser ou se há uma lista pré-determinada de categorias. O ideal é sermos o mais específicos possível para que a IA considere isso e gere uma resposta próxima do resultado esperado. Vamos ajustar esse campo de sistema.

A string de `system` estava como `"Você é um categorizador de produtos"`, e agora vamos complementar dizendo: `"e deve responder apenas o nome da categoria do produto informado"`.

```typescript
@GetMapping
public String categorizar(String produto) {
    var system = "Você é um categorizador de produtos e deve responder apenas o nome da categoria do produto informado";
        
    return this.chatClient.prompt()
        .system(system)
        .user(produto)
        .options(ChatOptionsBuilder.builder()
                .withTemperature(0.85f)
                .build())
        .call()
        .content();
}
```

Dessa forma, fomos mais específicos, indicando que o sistema deve responder apenas o nome da categoria do produto informado. Isso deixa claro o resultado esperado.

## Testando as Alterações

Vamos reiniciar e testar no navegador enviando a requisição anterior para categorizar "sacola reutilizável".

[localhost:8080/categorizador?produto=Sacola reutilizavel](http://localhost:8080/categorizador?produto=Sacola%20reutilizavel)

> Acessórios ecológicos

Agora, está mais próximo do desejado. Ao testar com "Escova de dentes", recebemos "higiene pessoal". O comportamento mudou, respeitando o que foi pré-determinado.

## Refinando o Prompt

Voltando ao código, a dica é ser o mais específico possível. Podemos complementar, padronizar a resposta, ser explícitos no formato desejado e fornecer exemplos. Vamos utilizar uma string detalhada, usando o recurso de _TextBlock_ do Java. Então, o texto entre três aspas duplas, ajustando a formatação e a indentação.

O texto é:

> Você é um categorizador de produtos e deve responder apenas o nome da categoria do produto informado
> 
> Escolha uma categoria dentra a lista abaixo:
> 
> 1. Higiene pessoal
>     
> 2. Eletronicos
>     
> 3. Esportes
>     
> 4. Outros
>     
> 
> exemplo de uso:
> 
> Pergunta: Bola de futebol
> 
> Resposta: Esportes

O código ficará assim:

```python
@GetMapping
public String categorizar(String produto) {
    var system = """
    Você é um categorizador de produtos e deve responder apenas o nome da categoria do produto informado
        
    Escolha uma categoria dentro da lista abaixo:
    1. Higiene pessoal
    2. Eletrônicos
    3. Esportes
    4. Outros
        
    ###### exemplo de uso:
        
    Pergunta: Bola de futebol
    Resposta: Esportes
    """;
    
    return this.chatClient.prompt()
        .system(system)
        .user(produto)
        .options(ChatOptionsBuilder.builder()
                .withTemperature(0.85f)
                .build())
        .call()
        .content();
}
```

## Testando o Novo Prompt

Na loja, temos apenas essas quatro categorias (higiene pessoal, eletrônicos, esporte e outros), então excluímos outras. Ao final, incluímos um exemplo de pergunta e resposta, uma boa prática ao usar inteligência artificial, sendo específico para obter respostas próximas do esperado.

Vamos salvar, reiniciar e testar no navegador.

Enviamos a requisição "Escova de dentes" e recebemos "higiene pessoal". Ao enviar "canudo de aço", recebemos "outros". Está funcionando corretamente!

## Conclusão e Engenharia de Prompt

Essa prática é chamada de _Prompt Engineering_ (engenharia de prompt), que envolve padronizar o parâmetro de entrada, tratamento, saída, formato e exemplos. Existem técnicas para controlar as interações com a IA generativa, permitindo maior controle sobre as respostas. Neste curso, incluímos um "Para Saber Mais" com um link para a documentação da OpenAI, explicando boas práticas e técnicas de _Prompt Engineering_.

## Próximos Passos

Com a funcionalidade de categorização concluída, na próxima aula, abordaremos novos exemplos e funcionalidades do projeto.

-----------------------------------------------------------------------
# 06Para saber mais: estratégias de Prompt Engineering

rompt engineering é um conjunto de técnicas e estratégias utilizadas para otimizar a interação com modelos de linguagem, como o GPT-4o da OpenAI. Ao construir prompts eficazes, você pode direcionar o comportamento do modelo e obter respostas mais relevantes e precisas. A seguir listamos algumas boas práticas de prompt engineering:

- **Escreva instruções claras e diretas**: Quanto mais objetivas forem as instruções, mais preciso será o resultado. Evite ambiguidade e forneça exemplos explícitos se necessário.
    
- **Faça perguntas diretas**: Formule perguntas de maneira direta para obter respostas diretas. Por exemplo, ao invés de perguntar "O que você acha sobre o clima?", pergunte "Qual é a previsão do tempo para amanhã em Maceió?".
    
- **Forneça contexto**: Incluir contexto adicional no prompt pode ajudar o modelo a entender melhor a pergunta e a fornecer uma resposta mais precisa. Por exemplo, "Explique a teoria da relatividade como se eu fosse um estudante do ensino médio".
    
- **Use formatação estrutural**: Utilizar listas, títulos e seções pode ajudar a guiar o modelo na formatação da resposta. Por exemplo, "Liste três benefícios do exercício físico".
    
- **Defina o estilo da resposta**: Indique o tom e o estilo que você deseja na resposta. Por exemplo, "Responda de forma profissional e concisa:" ou "Escreva uma história infantil divertida sobre um dragão".
    
- **Exemplos e demonstrações**: Inclua exemplos de respostas desejadas para guiar o modelo. Por exemplo, "Aqui estão alguns exemplos de como responder a perguntas sobre tecnologia:" seguido de exemplos. Você também pode mostrar exemplos de respostas inadequadas para ajudar o modelo a entender o que evitar.
    
- **Uso de restrições e limitações**: Defina claramente os limites da resposta esperada. Por exemplo, "Forneça uma resposta com no máximo 50 palavras". Se a resposta deve ser contida dentro de um determinado escopo, especifique-o. Por exemplo, "Explique apenas os benefícios ambientais do uso de energia solar".
    

Além das recomendações anteriores, você também pode consultar a [página de Prompt Engineering](https://platform.openai.com/docs/guides/prompt-engineering) na documentação da API da OpenAI, que fornece mais dicas e estratégias para aprimorar os seus prompts.



-----------------------------------------------------------------------
# 07Dominando a arte do Prompt Engineering

A Musicfy, uma startup no ramo musical, está desenvolvendo um sistema de recomendação de músicas baseado em IA. O objetivo é que, a partir da descrição de um sentimento ou situação, a API da OpenAI sugira uma música que combine com o que foi descrito.

Na fase de desenvolvimento, a equipe se deparou com um desafio: a API, por vezes, retornava músicas muito fora do esperado ou com estilos muito distintos do que seria considerado "usual".

O código em desenvolvimento está estruturado da seguinte forma:

```java
@RestController
@RequestMapping("musicas")
public class RecomendacaoMusicalController {

    private final ChatClient chatClient;

    public RecomendacaoMusicalController(ChatClient.Builder chatClientBuilder) {
        this.chatClient = chatClientBuilder.build();
    }

    @GetMapping
    public String recomendarMusica(String sentimento) {
        var prompt = String.format("Indique uma música para o sentimento: %s", sentimento);

        return this.chatClient.prompt()
                .user(prompt)
                .call()
                .content();
    }
}
```

Considerando o contexto e o código, quais das opções abaixo representam as melhores práticas de **Prompt Engineering** e calibragem de parâmetros da API para melhorar a precisão e coerência das recomendações musicais da Musicfy?

- Alternativa correta
    
    [ ] 
    
    Adicionar exemplos concretos no prompt, como: `"triste - Someone Like You (Adele)", "feliz - Happy (Pharrell Williams)"`.
    
    Exemplos concretos no prompt ajudam a API a entender o formato de resposta desejado e o contexto da requisição, tornando as sugestões mais precisas.
    
- Alternativa correta
    
    [ ] 
    
    Implementar um sistema de feedback no qual os usuários podem avaliar as recomendações, permitindo que a IA aprenda com o tempo e refine suas sugestões.
    
    A implementação de um sistema de feedback, embora não diretamente ligado ao prompt engineering, permite que a IA aprenda com as preferências dos usuários e melhore as recomendações futuras.
    
- Alternativa correta
    
    [ ] 
    
    Aumentar o valor de `temperature` para permitir maior aleatoriedade nas respostas da API, explorando um leque maior de músicas.
    
- Alternativa correta
    
    [ ] 
    
    Manter o prompt conciso, sem informações adicionais, para evitar enviesar a resposta da API.
    
- Alternativa correta
    
    [ ] 
    
    Diminuir o valor de `top_p` para restringir as respostas da API a um conjunto menor de probabilidades.
    
    Diminuir o valor de `top_p` aumenta o foco e a coerência das respostas, limitando a aleatoriedade e privilegiando sugestões mais prováveis dentro do contexto.
    

Parabéns, você acertou!

-----------------------------------------------------------------------
# 02Diferença entre modelos

## Transcrição

Vamos continuar nossos estudos no Spring AI. Na aula anterior, aprendemos a fazer a integração com a API, utilizando parâmetros.

Retomando o assunto sobre os parâmetros da API, estamos com o site da OpenAI aberto na guia "Playground", com a opção "Chat" selecionada na aba lateral esquerda. No interior da tela principal, além dos parâmetros que ficam na aba à direita, como temperatura e número máximo de _tokens_, temos um botão para escolher o modelo do ChatGPT, na parte central, acima do campo _System_.

Durante a gravação deste curso, o modelo selecionado é o GPT 4o, o mais utilizado. No entanto, ao selecionar esse botão, expandimos uma caixa que lista todos os modelos possíveis, como o GPT 4o Mini, o 4 Turbo, o 3.5 Turbo, entre outros.

**É importante considerar qual modelo utilizar ao integrar com a API da OpenAI**. Será que o modelo padrão, o 4o, é o mais apropriado para nosso caso de uso, aplicação e objetivos? Conhecer as diferenças entre esses modelos é essencial para escolher o mais adequado, pois há várias questões relacionadas a isso.

## Conhecendo os modelos

Para entender a diferença entre os modelos, acessaremos o menu superior, no qual a guia "Playground" está selecionada. À direita desta, há um item chamado "Docs". Ao clicar nele, haverá um direcionamento para a [página de documentação da API da OpenAI](https://platform.openai.com/docs/overview).

Nessa página, no lado esquerdo, há uma aba lateral com um campo de busca na parte superior. Ao digitar "Models" nele, uma janela é exibida na parte central da tela com os resultados, onde clicaremos na opção "Models".

Com isso, haverá um direcionamento para a [página da API sobre os modelos](https://platform.openai.com/docs/models/overview), na qual entenderemos quais são eles e suas diferenças, permitindo escolher o mais apropriado para nosso cenário de uso.

Na parte central, a página possui a seção "Flagship models", com cartões explicando cada, com suas características. Mais abaixo, há a seção "Models overview" com uma tabela comparativa que destaca o 4o como o modelo mais recente no momento da gravação deste vídeo, com maior inteligência e capacidade de lidar com tarefas complexas.

A tabela também destaca que o GPT-4o mini é mais enxuto, mas ainda eficiente e mais rápido, por ser mais leve.

### Número de _tokens_

Nas seções inferiores, notaremos que **cada modelo tem um limite de _tokens_**. Na seção "GPT-4o", por exemplo, há uma tabela informando que essa versão possui uma **janela de contexto de 128 mil _tokens_**. Ou seja, o chat guarda as perguntas e respostas geradas num histórico que será levado em consideração ao gerar novas respostas, mas esse histórico tem esse limite de 128 mil _tokens_.

Já o **número máximo de _tokens_ de resposta dessa versão do GPT é de 4096 _tokens_**. Contudo, há versões diferentes do GPT-4o listadas na tabela com capacidades maiores de _tokens_. Ou seja, se a resposta gerada pela API precisar ser extensa, talvez seja necessário usar um modelo com mais capacidade de _tokens_.

Além disso, a tabela informa que **esse modelo está treinado com dados até outubro de 2023**, o que significa que perguntas sobre eventos posteriores podem não ser respondidas.

Descendo para a tabela da seção "GPT-4o mini", uma versão menor do 4o, notaremos que esse modelo também tem uma janela de 128 mil _tokens_ de contexto, um tamanho de saída de 16 mil _tokens_ e é treinado com dados até outubro de 2023. Ela é uma versão melhor do que a 3.5, além de ser **mais rápida e barata**, sendo uma opção interessante se o **custo** for uma preocupação crítica.

### Preço

Além do número de _tokens_, outra preocupação relevante é o **preço**. **Cada requisição enviada à API é registrada e cobrada**, variando conforme o modelo utilizado.

Subindo a página até a seção "Flagship models", clicaremos no link "Model pricing details", abaixo dos cartões de modelo. Ele nos levará à [página de precificação dos modelos](https://openai.com/api/pricing/).

Nessa página, a tabela referente ao modelo GPT-4o informa que esse modelo custa **5 dólares por 1 milhão de _tokens_ de entrada**. Já a tabela do 4o mini informa que ele é mais barato — custa **15 centavos de dólar por 1 milhão de _tokens_**, uma diferença significativa.

## Conclusão

Ao escolher um modelo, é importante considerar o número de _tokens_ e o preço, avaliando se o modelo mais barato atende às necessidades do projeto. Nesse âmbito, a documentação é uma fonte valiosa para entender as diferenças entre os modelos, suporte, tamanho de _tokens_ e preço.

## Próximos passos

A seguir, mostraremos como trocar o modelo no código com Spring, especificando qual modelo utilizar.

-----------------------------------------------------------------------
# 03Para saber mais: tokens

Modelos de linguagem generativa, como o GPT-4o, estão na frente da tecnologia de processamento de linguagem natural (NLP). Esses modelos são capazes de gerar texto, traduzir idiomas, escrever ensaios e até mesmo responder perguntas de maneira coerente e contextualmente relevante. Para fazer isso de forma eficaz, eles precisam processar grandes quantidades de dados textuais, e é justamente aqui que os tokens entram em cena.

Para tratar texto de maneira computacional, é necessário dividi-lo em unidades menores e mais fáceis de manipular. Porém, executar essa divisão de forma que o modelo possa entender e gerar texto sem perder o contexto ou a qualidade é um desafio. Uma forma eficaz de abordar esse problema é por meio dos tokens.

## O que são tokens?

Tokens são as unidades básicas de texto que um modelo de linguagem utiliza para processar e gerar informações. Eles são como "blocos de construção" que compõem palavras, frases e sentenças. Dependendo da implementação, um token pode ser:

- **Palavras inteiras**: Em alguns modelos, cada palavra pode ser tratada como um token;
- **Sub-palavras**: Em modelos mais avançados, palavras podem ser divididas em partes menores chamadas sub-palavras ou morfemas;
- **Caracteres individuais**: Em alguns casos, caracteres individuais de uma palavra podem ser considerados tokens, embora isso seja menos comum.

## Como tokens funcionam?

Quando você insere texto em um modelo de linguagem, o texto é primeiro tokenizado, ou seja, dividido em tokens. Esses tokens são então convertidos em números, ou vetores, que o modelo pode processar. Aqui está um exemplo prático:

1. **Entrada de texto**: "O sol está brilhando."
2. **Tokenização**:
    - "O"
    - "sol"
    - "está"
    - "brilhando"
3. **Conversão para vetores**: Cada token é convertido em uma representação numérica que o modelo pode interpretar.
4. **Processamento**: O modelo processa esses vetores para gerar a resposta desejada.
5. **Geração de texto**: A resposta do modelo é convertida de volta de vetores para tokens e, então, para texto legível.

## Importância dos tokens

Entender como os tokens funcionam é importante, pois isso pode influenciar como você utiliza as ferramentas de IA generativa. A seguir, algumas motivações para isso:

- **Limitação de comprimento**: Os modelos de linguagem têm uma limitação de quantos tokens podem processar de uma vez. Isso significa que prompts e respostas combinados não podem exceder esse limite.
- **Custo e eficiência**: O processamento de tokens é uma das bases para calcular os custos ao usar a API da OpenAI. Mais tokens significam mais processamento e, portanto, maior custo.
- **Qualidade da resposta**: A forma como o texto é tokenizado pode afetar a qualidade da resposta gerada pelo modelo. Uma tokenização eficaz preserva o significado e o contexto, resultando em respostas mais precisas e relevantes.

Para entender mais sobre tokens e seu funcionamento na API da OpenAI, acesse o [artigo sobre tokens escrito pela própria equipe da OpenAI](https://help.openai.com/en/articles/4936856-what-are-tokens-and-how-to-count-them). Além disso, a OpenAI disponibiliza uma ferramenta chamada [Tokenizer](https://platform.openai.com/tokenizer), que exemplifica de maneira visual a quantidade de tokens em determinado texto.

-----------------------------------------------------------------------
# 04Para saber mais: processamento em lote
A OpenAI oferece uma poderosa ferramenta para lidar com grandes volumes de dados de forma eficiente e econômica: a **Batch API**. Com ela, você pode processar tarefas como geração de texto, tradução e análise de sentimentos em lote, sem comprometer o desempenho ou os custos.

Enquanto algumas aplicações exigem respostas imediatas da API da OpenAI, muitas vezes você se depara com a necessidade de processar grandes conjuntos de dados que não requerem resposta em tempo real. É aí que a Batch API se destaca. Imagine, por exemplo, classificar milhares de documentos, gerar embeddings para um repositório inteiro de conteúdo ou realizar análises de sentimentos em grandes quantidades de avaliações de clientes.

Com a Batch API, em vez de enviar milhares de requisições individuais, você as agrupa em um único arquivo e envia para a API. Isso traz diversas vantagens. Primeiramente, você obtém um desconto de 50% nos custos em comparação com o envio de requisições individuais. Além disso, a Batch API possui limites de taxa de uso (rate limits) significativamente maiores, permitindo que você processe muito mais dados em um período menor.

A Batch API é compatível com diversos modelos, incluindo GPT-4, GPT-3.5-Turbo e modelos de embedding de texto. Além disso, também suporta modelos ajustados (fine-tuned), proporcionando flexibilidade para atender às suas necessidades específicas.

É importante destacar que a Batch API possui seus próprios limites de taxa de uso, separados dos limites das APIs síncronas. Cada lote pode conter até 50.000 requisições, com um arquivo de entrada de até 100 MB. A OpenAI também define um limite para o número de tokens de prompt enfileirados por modelo para processamento em lote. No entanto, não há limites para tokens de saída ou número de requisições enviadas.

Visite o [site da Batch API](https://platform.openai.com/docs/guides/batch/overview), dedicado a explicar essa funcionalidade, para conhecer mais detalhes.

-----------------------------------------------------------------------
# 05Alterando modelos programaticamente

## Transcrição

Compreendemos como funcionam os modelos e as diferenças entre eles em relação a preço, número de _tokens_, entre outras questões.

Neste vídeo, entenderemos como **trocar o modelo dinamicamente** no código da nossa aplicação que utiliza a integração com a API da OpenAI. Afinal, podemos constatar que diferentes modelos seriam melhores para diferentes necessidades.

É totalmente possível tornar essa troca dinâmica. A seguir, entenderemos como isso funciona.

## Alterando o modelo no _prompt_

Voltando ao IntelliJ, acessando o código do arquivo `CategorizadorDeProdutosController`, nos atentaremos ao último exemplo do categorizador de produtos. Em nenhum momento desse código configuramos o modelo; apenas configuramos a temperatura, a configuração do sistema, o _prompt_ da pessoa usuária e disparamos a chamada.

Para configurar o modelo utilizado, há um método entre os parâmetros de opções para trocar o modelo. No caso do Spring, há várias maneiras e locais distintos onde podemos trocar o modelo e esses parâmetros.

Podemos alterar o modelo **diretamente em um _prompt_ específico**. Entre as chaves do método `categorizar()`, temos a linha `.withTemperature()`, onde trocamos a temperatura. Podemos criar abaixo dela outra linha, na qual também podemos trocar o modelo, usando `.withModel()`.

Entre os parênteses e aspas duplas, podemos passar o nome do modelo, como `gpt-4o-mini`. Com isso, não estamos trocando o modelo para a aplicação inteira, mas sim para esse método específico.

> `CategorizadorDeProdutosController.java`:

```java
public String categorizar(String produto) {
    
    // Código omitido
    
    return this.chatClient.prompt()
            .system(system)
            .user(produto)
            .options(ChatOptionsBuilder.builder()
                    .withTemperature(0.8f)
                    .withModel("gpt-4o-mini")
                    .build())
            .call()
            .content();
}
```

Após clicar no botão "Run" da barra lateral esquerda e verificar no terminal que a aplicação foi reiniciada, testaremos essa alteração.

Voltando ao navegador, acessaremos novamente o categorizador de produtos passando "canudo de aço", por meio do endereço abaixo.

```plaintext
http://localhost:8080/categorizador?produto=Canudo%20de%20aço
```

Ao pressionar "Enter", ele retorna o texto "Higiene pessoal" na tela. Ao atualizar a página, o resultado se mantém.

Trocaremos para um produto aleatório, como "garrafa reciclável", digitando `Garrafa reciclável` em vez de `Canudo%20de%20aço` no final do endereço.

```plaintext
http://localhost:8080/categorizador?produto=Garrafa reciclável
```

Com isso, ele traz o texto "Outros". A princípio, está funcionando corretamente. Essa é uma maneira de trocar o modelo diretamente no _prompt_.

## Alterando o modelo no `ChatClient`

Se tivermos vários métodos no nosso _controller_ e quisermos usar o `gpt-4o-mini` em todos, não precisamos repetir a chamada `withModel("gpt4-o-mini")` em cada método. Podemos padronizar de uma maneira que não seja necessário repetir individualmente para cada _prompt_.

Ao invés de definir diretamente no _prompt_, podemos **definir o modelo na criação do `ChatClient`**. No construtor, podemos chamar o método `build` para criar o `ChatClient` e definir um modelo específico. Todos os _prompts_ criados com base nesse `ChatClient` usarão o mesmo modelo.

Vamos fazer essa alteração. Apagaremos o `withModel()` do método `categorizar()` e, no construtor `ChatClientBuilder`, antes de chamar o método `build()`, usaremos `.defaultOptions()`.

```java
public CategorizadorDeProdutosController(ChatClient.Builder chatClientBuilder) {
    this.chatClient = chatClientBuilder
        .defaultOptions()
        .build();
}
```

Entre seus parênteses, definimos opções padrão para o `ChatClient`. Chamaremos o `chatOptionsBuilder.builder()`, adicionaremos o `.build()`, e, antes dele, o `.withModel()`, passando o `gpt-4o-mini` entre parênteses.

```java
public CategorizadorDeProdutosController(ChatClient.Builder chatClientBuilder) {
    this.chatClient = chatClientBuilder
        .defaultOptions(ChatOptionsBuilder
                .builder()
                .withModel("gpt-4o-mini")
                .build())
        .build();
}
```

Dessa forma, todos os métodos e _prompts_ criados pelo objeto `ChatClient` usarão esse modelo.

**Essa configuração é flexível**: se tivermos 20 métodos no _controller_, todos usarão esse modelo, mas **podemos trocar esse modelo em um _prompt_ específico**. O mais específico sempre sobrescreve os mais genéricos.

Vamos testar para ver se continua funcionando. Voltando ao navegador, ao trocar o final do endereço para `Escova de dentes`, ele retorna o texto "higiene pessoal", mostrando que funciona corretamente.

```plaintext
http://localhost:8080/categorizador?produto=Escova de dentes
```

O `withModel()` é simples e fácil de usar com a API do Spring AI.

## Conhecendo o modelo padrão do Spring

Antes de definir o modelo, não havia a linha `.withModel("gpt-4o-mini")` no código, e o Spring fazia a integração com a API da OpenAI mesmo assim. Qual modelo estava sendo utilizado, se não o definimos em nenhum lugar?

O Spring tem uma **configuração padrão**. Acessando o arquivo `application.properties`, notaremos que nenhum parâmetro de modelo foi definido, apenas a chave da API. Isso significa que o Spring usa configurações padrão se não definirmos temperatura, modelo ou outras configurações.

Podemos conferir isso retornando à [documentação do Spring AI](https://docs.spring.io/spring-ai/reference/api/chatclient.html). Acessando a aba do menu lateral à esquerda, clicaremos na seção "Chat Model API" para expandir suas opções para selecionar "OpenAI".

Em seguida, no menu lateral à direita da tela, temos as subopções do OpenAi Chat. Entre elas, clicaremos em "Chat Properties".

Na área central da tela será carregada esta seção, na qual encontraremos tabelas com as propriedades do chat e seus valores padrão na coluna "Default". Na tabela da subseção "Configuration Properties", uma dessas propriedades é a `spring.ai.openai.chat.options.model`, com valor padrão `gpt-4o`.

Além disso, a propriedade de temperatura `spring.ai.openai.chat.options.temperature` define como padrão o valor 0.8.

Ou seja, se não especificarmos o modelo ou temperatura, ele usará esses valores como padrão.

## Alterando o modelo globalmente

Podemos alterar esses padrões no arquivo `application.properties`. Para alterar o modelo, colaremos o nome dela nesse arquivo, informando o novo valor padrão — nesse caso, o `gpt-4o-mini`.

> `application.properties`:

```properties
spring.ai.openai.chat.options.model=gpt-4o-mini
```

**Essa configuração é global para toda a aplicação**. Contudo, ainda podemos sobrescrevê-la no _controller_ ou diretamente em um _prompt_ específico. O mais específico sempre prevalece. O código é flexível, permitindo várias formas de configuração e sobrescrita.

> É importante ler a documentação do Spring para entender esses parâmetros e códigos.

## Conclusão

Dessa forma, conseguimos trocar o modelo de maneira programática no código da aplicação, seja via configuração no `application.properties` de maneira global, ou via código, no _prompt_ ou _Chat Client_. Assim, podemos escolher dinamicamente o modelo mais apropriado para o cenário de uso.

## Próximos passos

Na sequência, continuaremos aprendendo mais recursos e funcionalidades do Spring.

-----------------------------------------------------------------------
# 06Para saber mais: injeção dinâmica do modelo
Ao utilizar a API da OpenAI em uma aplicação Spring Boot, você pode se deparar com a necessidade de interagir com diferentes modelos, como o "gpt-4o" para tarefas mais complexas e o "gpt-4o-mini" para respostas mais rápidas e econômicas.

Definir múltiplos `ChatClients` diretamente no Controller pode tornar o código complexo e difícil de gerenciar, principalmente à medida que a aplicação cresce e novas funcionalidades são adicionadas. Imagine ter que replicar a configuração do `ChatClient` em diversos Controllers, cada um com um modelo específico.

Uma abordagem mais organizada e eficiente é criar uma classe de configuração separada, onde definimos cada `ChatClient` como um **Bean** gerenciado pelo Spring. Veja a seguir um exemplo em código de como implementar isso:

```less
@Configuration
public class ChatClientConfiguration {

    @Bean
    @Qualifier("gpt-4o-mini")
    public ChatClient gpt4oMiniChatClient(ChatClient.Builder chatClientBuilder) {
        return chatClientBuilder
            .defaultOptions(ChatOptionsBuilder
                    .builder()
                    .withModel("gpt-4o-mini")
                    .build())
            .build();
    }

    @Bean
    @Qualifier("gpt-4o")
    public ChatClient gpt4oChatClient(ChatClient.Builder chatClientBuilder) {
        return chatClientBuilder
            .defaultOptions(ChatOptionsBuilder
                    .builder()
                    .withModel("gpt-4o")
                    .build())
            .build();
    }

}
```

Com essa estrutura, centralizamos a configuração dos `ChatClients`, tornando o código mais limpo e fácil de manter. Agora, basta utilizar a anotação `@Qualifier` para injetar o `ChatClient` desejado em cada Controller. Por exemplo:

```kotlin
@RestController
@RequestMapping("gerador")
public class GeradorDeProdutosController {

    private final ChatClient chatClient;

    public GeradorDeProdutosController(@Qualifier("gpt-4o") ChatClient chatClient) {
        this.chatClient = chatClient;
    }

    // ... métodos do controller ...
}
```

```kotlin
@RestController
@RequestMapping("categorizador")
public class CategorizadorDeProdutosController {

    private final ChatClient chatClient;

    public CategorizadorDeProdutosController(@Qualifier("gpt-4o-mini") ChatClient chatClient) {
        this.chatClient = chatClient;
    }

  // ... métodos do controller ...
}
```

Dessa forma, você garante uma melhor organização do seu código e facilita a manutenção e evolução da sua aplicação Spring Boot que utiliza a API da OpenAI.

-----------------------------------------------------------------------
# 07Contagem de tokens
## Transcrição

Conforme mencionado, um dos fatores que influenciam o preço ao usar a API da OpenAI é a questão dos _tokens_. A cobrança é feita por 1 milhão de _tokens_. Portanto, uma maneira de economizar é trocar o modelo com base no número de _tokens_.

Seria interessante conseguir fazer uma **contagem ou estimativa de _tokens_** para escolher qual modelo utilizar. Se um modelo tiver uma limitação, podemos usar outro modelo, dependendo do número de _tokens_ que será utilizado.

## Baixando a biblioteca JTokkit

Por exemplo, acessando o arquivo da classe `CategorizadorDeProdutosController`, poderíamos implementar uma lógica antes de disparar a chamada para a API, fazendo uma contagem de _tokens_ de alguma forma. Se a contagem atingir um determinado valor, usamos um modelo específico; se ultrapassar, usamos outro modelo. É possível implementar esse tipo de lógica.

O Spring não possui uma classe para nos ajudar com essa contagem de _tokens_, mas existem bibliotecas que fazem isso, e utilizaremos uma delas no projeto, que pode ser integrada ao Spring.

Acessando o navegador, criaremos uma nova guia, na qual pesquisaremos no Google pela biblioteca Java chamada JTokkit.

```plaintext
jtokkit
```

Entre os resultados, acessaremos o link do [GitHub do JTokkit](https://github.com/knuddelsgmbh/jtokkit) para acessar o repositório do projeto. Trata-se de um projeto _open source_ cujo código-fonte está disponível no GitHub.

Em seu interior, ele explica que essa biblioteca é o **Java Tokenizer Kit**, um kit de tokenização para Java que, entre outras funcionalidades, realiza a contagem de _tokens_, permitindo implementar uma lógica de escolha de modelos baseada no número de _tokens_.

A documentação explica como usar a biblioteca e, na seção "Installation", como adicioná-la ao projeto. Utilizando o Maven, basta adicionar a dependência exibida no bloco de código.

```java
<dependency>
    <groupId>com.knuddels</groupId>
    <artifactId>jtokkit</artifactId>
    <version>1.1.0</version>
</dependency>
```

Vamos copiar a tag dessa dependência, voltar ao projeto no IntelliJ e acessar o arquivo `pom.xml` pelo explorador lateral esquerdo.

Dentro do arquivo, no interior da _tag_ `<dependencies>`, adicionaremos o conteúdo copiado dessa dependência, que parte do grupo `com.knuddels`.

Após adicionar a dependência, clicaremos no ícone "Load Maven Changes" no canto superior esquerdo do arquivo, ou utilizar o atalho "Ctrl + Shift + O" recarregar e baixar a dependência no projeto. Com isso, poderemos utilizar a biblioteca.

## Contando _tokens_

Voltando à documentação, na seção "JTokkit - Java Tokenizer Kit" há um exemplo de código que explica como usar a biblioteca.

Precisamos instanciar uma classe chamada `Registry`, obter o `encoding` e utilizar métodos para contagem de _tokens_. Vamos copiar as duas primeiras linhas do exemplo de código, disponíveis abaixo.

```java
EncodingRegistry registry = Encodings.newDefaultEncodingRegistry();
Encoding enc = registry.getEncoding(EncodingType.CL100K_BASE);
```

Voltando ao projeto, vamoms implementar as duas linhas copiadas na classe `CategorizadorDeProdutosController`. Para isso, abaixo das chaves de `categorizar()`, criaremos o método privado `contarTokens()` para contagem de _tokens_:

> `CategorizadorDeProdutosController.java`:

```java
public String categorizar(String produto) {

    // Código omitido
    
}

private int contarTokens() {
}
```

Esse método recebe as strings de _prompt_ `system` e `user` como parâmetro. Entre suas chaves, colaremos as duas linhas copiadas do exemplo, substituindo os tipos `EncodingRegistry` e `Encoding` por `var` locais, simplificando o código.

```java
private int contarTokens(String system, String user) {
    var registry = EncodingRegistry registry = Encodings.newDefaultEncodingRegistry();
    var enc = registry.getEncoding(EncodingType.CL100K_BASE);
}
```

Por fim, importaremos a classe necessária `Encodings`, utilizando "Alt + Enter" com o cursor em cima delas e selecionando "Import class". Isso gerará o código abaixo na lista de importações do arquivo.

```java
import com.knuddels.jtokkit.Encodings;
```

A biblioteca `Encodings` funciona chamando `Encodings.newDefaultEncodingRegistry()` na primeira linha para obter o registro de _encodings_. Na linha seguinte, a partir do `registry`, apagaremos o método `getEncoding()` e chamaremos o `getEncodingForModel()`, passando entre parênteses a classe `ModelType` e o modelo `.GPT_4O_MINI`.

```java
public int contarTokens(String system, String user) {
    var registry = Encodings.newDefaultEncodingRegistry();
    var enc = registry.getEncodingForModel(ModelType.GPT_4O_MINI);
}
```

Baseando-se no modelo informado, esse método devolverá o `Encoding`. Nessa biblioteca, o `Encoding` é a classe que realiza operações, incluindo a contagem de _tokens_.

Por fim, na linha seguinte, retornaremos o resultado da contagem de _tokens_ dos dois _prompts_.

```java
public int contarTokens(String system, String user) {
    var registry = Encodings.newDefaultEncodingRegistry();
    var enc = registry.getEncodingForModel(ModelType.GPT_4O_MINI);
    return enc.countTokens(system + user);
}
```

Embora o método esteja dentro do _controller_, o ideal é **movê-lo para uma classe separada e transformá-la em um _Bean_ injetável do Spring**, caso desejemos reutilizá-la em vários pontos. Para fins didáticos, deixaremos o método privado dentro do _controller_.

Após a criação do método `contarTokens()`, basta chamá-lo onde desejarmos realizar a contagem. Entre as chaves do método `categorizar()`, acima do `return this.chatClient.prompt()`, criaremos uma variável `var tokens` e chamaremos `contarTokens()`, passando `system` e o parâmetro `produto`, que é o _input_ da pessoa usuária.

Na próxima linha, utilizaremos um `System.out.println("QTD de tokens: " + tokens)` somente para exibir a quantidade de _tokens_:

```java
public String categorizar(String produto) {
    
    // Código omitido
    
    var tokens = contarTokens(system, produto);
    System.out.println("QTD de tokens: " + tokens);
    
    return this.chatClient.prompt()
    
    // Código omitido
}
```

Com essas duas linhas, mostramos como a contagem funciona. Nesse local do código, devemos escrever a lógica de escolha de modelo baseada no número de _tokens_. Dependendo da API e do modelo, devemos conhecer as restrições de _tokens_ e implementar a troca dinâmica de modelo.

```java
public String categorizar(String produto) {
    
    // Código omitido
    
    var tokens = contarTokens(system, produto);
    System.out.println("QTD de tokens: " + tokens);
    
    // lógica de escolha de modelo baseada no número de tokens
    
    return this.chatClient.prompt()
    
    // Código omitido
}
```

Após reiniciar a aplicação, voltaremos ao navegador no endereço do `localhost` e dispararemos uma nova requisição para o categorizador de produtos, atualizando a página com "F5".

No navegador, a requisição será disparada normalmente e nada mudará. Voltando ao console do IntelliJ, verificaremos o `System.out` com a quantidade de _tokens_ de 72 para o _input_ do sistema e da pessoa usuária.

> QTD de tokens: 72

Dependendo dos _inputs_, o número de _tokens_ pode variar.

## Conclusão

O objetivo deste vídeo foi mostrar como usar uma biblioteca para contagem de _tokens_. A biblioteca não é do Spring, mas é simples e fácil de integrar ao projeto, permitindo a troca dinâmica de modelos baseada no número de _tokens_.

## Próximos passos

A seguir, continuaremos discutindo erros e problemas que podem ocorrer ao se conectar com a API da OpenAI.


-----------------------------------------------------------------------
# 08Escolhendo o modelo apropriado
A empresa Corujas Express, especializada em entregas rápidas de documentos, está desenvolvendo um sistema que analisa contratos e sugere cláusulas adicionais de segurança, otimizando o processo para seus clientes.

A equipe decidiu utilizar a API da **HogwartsAI** (empresa fictícia), mas precisa definir qual modelo de IA é o mais indicado, equilibrando custos e performance.

A HogwartsAI oferece os seguintes modelos, com seus respectivos custos e capacidades:

|**Serviço**|**Descrição**|**Custo**|
|---|---|---|
|Weasley|O mais acessível e veloz, ideal para tarefas simples.|$0.10/1.000 tokens|
|McGonagall|Equilibrado em poder e custo. Recomendado para tarefas de complexidade moderada.|$0.60/1.000 tokens|
|Voldemort|Poderoso e versátil, indicado em soluções para desafios complexos.|$1.50/1.000 tokens|
|Dumbledore|O ápice da magia computacional, ideal para tarefas que exigem sabedoria e poder.|$4.50/1.000 tokens|

A empresa estima que os contratos possuam, em média, 800 tokens. O modelo ideal deve:

- Compreender o contexto dos contratos e gerar cláusulas de segurança relevantes e eficazes.
- Minimizar os custos operacionais, considerando o volume de contratos processados e o limite de tokens por requisição.

Diante disso, qual a solução **mais eficiente**, em termos de custo e performance?

- Alternativa correta
    
    Confiar na versatilidade do Voldemort.
    
- Alternativa correta
    
    Implementar um sistema que divide os contratos em blocos de tokens e utiliza o modelo Weasley para os primeiros 800 tokens e o modelo Dumbledore para os tokens restantes.
    
- Alternativa correta
    
    Optar pela acessibilidade do Weasley.
    
- Alternativa correta
    
    Combinar o McGonagall, para a maioria dos casos, com o Voldemort, apenas quando os contratos ultrapassam 1000 tokens.
    
    Esta solução oferece o melhor dos dois mundos: o modelo McGonagall lida com a maioria dos casos a um custo menor, e o Voldemort atua em casos mais complexos, otimizando os recursos.
    
- Alternativa correta
    
    Invocar o poder do Dumbledore, garantindo a máxima qualidade na geração de cláusulas.


-----------------------------------------------------------------------
# 02Possíveis erros da API
## Transcrição

Continuamos nossos estudos com o Spring AI.

Até o momento, não abordamos a questão dos **erros** e estamos nos conectando a uma API externa. Temos o código e a aplicação utilizando o Spring Boot e o módulo do Spring AI, mas toda essa chamada do `chatClient.prompt().call` está saindo do nosso projeto e fazendo uma requisição para um **sistema externo**, que é a API da OpenAI.

Nessa comunicação, podem ocorrer erros, e precisamos entender quais são esses erros, como a OpenAI lida com eles e como devemos tratá-los em nosso projeto.

## Verificando os possíveis erros

Consultaremos a [documentação da OpenAI](https://platform.openai.com/docs/models) para entender os possíveis erros que podem ocorrer, caso a API esteja fora do ar ou haja algum outro problema.

Estávamos com a página dos modelos aberta, e agora clicamos no campo de busca no menu à esquerda da página e digitaremos "Error".

Aparece a opção **"Error Codes"**, e ao clicarmos nela, a página carrega explicando os códigos de erro e os possíveis erros que podem ocorrer na API.

A documentação explica que, como a API utiliza o protocolo HTTP, ela devolve códigos específicos para cada tipo de situação.

Por exemplo, o erro `401` ocorre quando não enviamos a API Key, ou quando enviamos uma chave expirada ou inválida, resultando em erros de autenticação. O erro `403` pode ocorrer se houver algum bloqueio de região, e o erro `429` acontece quando ultrapassamos o limite de requisições.

Mesmo com um pagamento e um cartão de crédito cadastrado, não podemos fazer um _loop_ que dispare 5 milhões de requisições de uma vez para a API. Há um **limite**, uma cota estabelecida, e essa verificação é realizada pela API da OpenAI. Caso ultrapassemos esse limite, a API bloqueará as requisições e retornará o erro `429` nas chamadas subsequentes.

O erro `500` ocorre quando a API está fora do ar. Existem várias possibilidades de erro que podem acontecer com a API da OpenAI, e para cada uma, ela devolve um **código HTTP apropriado**.

Em nosso projeto, na integração com essa API, precisamos estar preparados para esses erros.

Às vezes, o **erro pode ser nosso**, como não controlar requisições excessivas ou esquecer de enviar a chave. Outras vezes, pode ser um problema do **servidor da OpenAI**, que pode estar fora do ar ou ter sofrido um _crash_. Precisamos implementar soluções para contornar esses problemas em nossa aplicação.

## Analisando o cenário

Retornamos ao nosso projeto para discutir a ideia central e as estratégias para lidar com **possíveis erros**. Estamos novamente com a classe `CategorizadorDeProdutosController.java`. Na linha 48, onde está o `return`, é o momento em que chamamos a API da OpenAI.

```java
// código omitido

        return this.chatClient.prompt()
                        .system(system)
                        .user(produto)
                        .options(ChatOptionsBuilder
                                        .builder()
                                        .withTemperature(0.8f)
                                        .build())
                        .call()
                        .content();
}

// código omitido
```

Temos o `chatClient.prompt()`, e passamos o sistema, o usuário e as opções antes de chamar o método `call()`. Neste método, a requisição é enviada para a API da OpenAI, e pode **ocorrer um erro**, como a API estar fora do ar no momento da execução.

Para lidar com os erros, podemos usar um `try-catch`. Colocamos o `return` dentro do `try{}` e usamos um bloco `catch` para capturar exceções. Ao capturar uma exceção, é importante entender o motivo dela. O Spring pode encapsular alguma exceção específica que nos permita acessar o código HTTP. Podemos consultar a documentação do Spring para verificar essa informação.

Além disso, é importante considerar se devemos tratar erros em todos os métodos de todos os _controllers_. Podemos utilizar um `ControllerAdvice` para isolar o tratamento de erros ao usar uma API Rest, evitando que a lógica de tratamento fique espalhada pelos controllers.

Não se trata apenas de tratar o erro. Se ocorrer um erro de **bloqueio** ou se a **API da OpenAI estiver fora do ar**, precisamos considerar a ação a ser tomada em nossa aplicação.

A requisição não será processada, mas não desejamos exibir um erro à pessoa usuária, pois pode ser um problema temporário. Assim, podemos implementar uma **pausa na aplicação** no `catch` e tentar novamente após alguns segundos.

Se ainda estiver fora do ar, aumentamos o tempo de espera e tentamos novamente, multiplicando o tempo por dois a cada tentativa.

Implementar tudo isso é trabalhoso, mas não precisamos nos preocupar, pois o próprio Spring **já possui tratamento para esses cenários**. Se ocorrer algum problema, o Spring já faz as tentativas necessárias.

## Próximo passo

No próximo vídeo, veremos a documentação do Spring para entender como ele lida com esses **tipos de problemas** e se há alguma forma de **modificar o tempo de tentativas**, considerando os padrões do Spring. Até mais!

-----------------------------------------------------------------------
# 03Parâmetros de retry
## Transcrição

Já entendemos que a API da OpenAI pode apresentar erros, ficar fora do ar ou causar bloqueios se for utilizada de maneira inadequada. Embora precisemos tratar essas situações, o Spring já cuida desse tratamento para nós. Por isso, desfizemos o `try-catch`, pois não precisamos nos preocupar com isso em nosso projeto.

## Tratamento automático de erros

O Spring, em seu módulo de inteligência artificial, já possui tratamento de erros e realiza **retentativas automaticamente** quando ocorre algum problema.

Agora, entenderemos como isso funciona e se é possível **personalizar** esse comportamento. Para isso, acessaremos a documentação do Spring. Na última visita à documentação, estávamos analisando os parâmetros do Spring para alterar o modelo por meio do `application.properties`.

Mostramos que há um parâmetro para temperatura e outros disponíveis no playground para controlar a geração das respostas. Na mesma página, se subirmos um pouco, encontramos as propriedades chamadas de _**"Retry Properties"**_, que tratam de erros e retentativas.

O Spring, por si só, tentará realizar uma nova requisição caso ocorra uma falha devido a problemas na OpenAI. Ele lista os parâmetros e seus valores padrão para essas retentativas.

Por exemplo, a propriedade `spring.ai.retry.max-attempts` define quantas tentativas serão realizadas caso uma requisição falhe, com um padrão de 10 tentativas (coluna "Default"). Se todas as 10 tentativas falharem, uma **exceção será lançada**, indicando que a API da OpenAI está fora do ar.

Outros parâmetros incluem o intervalo de tempo entre tentativas, que é de 2 segundos, e o multiplicador, que inicia em 10 segundos e multiplica esse valor por 2 a cada nova tentativa. O parâmetro máximo é 5 nesse caso. Além disso, o intervalo máximo de tempo que essas requisições podem levar é de 3 minutos, entre outras propriedades disponíveis.

## Sobrescrita de Padrões

O Spring já possui padrões, mas é possível **sobrescrevê-los**. Por exemplo, se desejarmos 20 tentativas em vez de 10, ou aumentar o intervalo de 2 segundos, podemos **personalizar** essas configurações.

## Personalizando as configurações

Para fazer isso, copiamos a propriedade `spring.ai.retry.max-attempts` e colamos no `application.properties` no IntelliJ, alterando o valor para `20`.

> `application.properties`

```cpp
// código omitido

spring.ai.retry.max-attempts=20

// código omitido
```

Assim, em nosso projeto, serão realizadas 20 tentativas.

## Ajustes no intervalo de tentativas

Se a API da OpenAI apresentar erro, o Spring tentará mais 19 vezes, totalizando 20 tentativas. Agora, vamos voltar à documentação, copiamos a propriedade `spring.ai.retry.backoff.initial-interva` e ajustamos o **intervalo para 10 segundos**.

## Configurando o intervalo máximo

Por fim, o `spring.ai.retry.backoff.max-interval`, que está configurado para 3 minutos, será alterado para 300 segundos, ou seja, 5 minutos.

> `application.properties`

```cpp
// código omitido

spring.ai.retry.max-attempts=20
spring.ai.retry.backoff.initial-interval=10
spring.ai.retry.backoff.max-interval=300

// código omitido
```

Desejamos que as novas requisições durem no máximo 5 minutos. Se, após esse tempo, a API ainda estiver fora do ar, um **erro será exibido**, indicando um problema mais crítico na API da OpenAI, e precisaremos investigar a situação.

## Importância do tratamento de erros

Este é um exemplo de como o Spring trata erros, quais propriedades podemos controlar, os valores padrão e como sobrescrevê-los, se necessário.

É importante avaliar isso em nossos projetos, pois toda requisição pode falhar. Muitas vezes, pensamos que a API estará sempre online e funcionando, mas isso nem sempre ocorre. Estamos integrando uma API externa, sobre a qual não temos controle, e ela pode ficar fora do ar, sofrer sobrecarga ou ser alvo de ataques.

Devemos preparar nossa API e projeto para lidar com essas situações. No caso do Spring AI, ele já possui **algoritmos para retentativas**, o que simplifica nosso trabalho e torna o desenvolvimento mais produtivo.

## Próximo passo

Na sequência, continuaremos discutindo outras questões relacionadas a **erros**.


-----------------------------------------------------------------------
# 04Gerando logs
## Transcrição

O Spring realiza o tratamento de erros e retentativas de forma automática. Contudo, existe uma questão importante sobre **integração** relacionada aos _**logs**_.

Até agora, não vimos informações sobre o que o Spring está fazendo internamente nem quais parâmetros ele está enviando. Apenas chamamos a API e recebemos uma string como resposta.

## Verificando os logs gerados na IDE

Ao observar o console da aplicação, notamos que não há geração de logs. Os logs disponíveis são apenas gerados quando o projeto é reiniciado. Vamos limpar o log e fazer uma requisição no navegador atualizando a página no seguinte endereço:

```perl
http://localhost:8080/categorizador?produto=Escova%20de%20dentes
```

> Higiene pessoal

Ao abrir a requisição e verificar no IntelliJ, percebemos que apenas os logs de inicialização do Spring são gerados. Se enviarmos uma nova requisição, apenas o output do sistema, referente à quantidade de tokens, é exibido.

> QTD de tokens: 72

Para obter **mais detalhes** sobre a integração e a resposta retornada, é possível gerar logs mais detalhados. Assim, conseguimos registrar informações sobre o que está sendo enviado para a API e o que está sendo devolvido por ela.

## Obtendo informações mais detalhadas

No arquivo `CategorizadorDeProdutos`, podemos registrar logs da requisição e da resposta com a API da OpenAI. Para isso, precisamos consultar a documentação do Spring.

Na documentação, no menu à esquerda do site, encontramos o item "Chat Client API", que aborda a API de chat com provedores de forma geral. Na página, no menu à direita, o último item é ["Logging"](https://docs.spring.io/spring-ai/reference/api/chatclient.html#_logging), que explica que, para registrar logs e interceptar requisições, podemos utilizar um `advisor`.

> Exemplo retirado da documentação:

```sql
ChatResponse response = ChatClient.create(chatModel).prompt()
        .advisors(new SimpleLoggerAdvisor())
        .user("Tell me a joke?")
        .call()
        .chatResponse();
```

Ao criar o `ChatClient` é preciso chamar o `advisors` passando `new SimpleLoggerAdvisor()`, e há outras classes cada uma com seu respectivo objetivo. O `advisors` funciona como um interceptador e registra logs.

O `SimpleLoggerAdvisor()` gera um _output_ no `System.out()` com informações sobre a requisição e a resposta. Copiamos a linha `.advisors(new SimpleLoggerAdvisor())` e vamos integrá-la ao nosso código do arquivo `CategorizadorDeProdutosController.java`.

Podemos fazer isso de forma genérica no `ChatClient` ou para um prompt específico. Optaremos por aplicá-lo ao prompt específico em `return this.chatClient.prompt()`. No prompt, após definir as opções e antes de chamar o `call()`, colamos o `Advisor`. Também precisamos importar o `SimpleLoggerAdvisor()`.

> `CategorizadorDeProdutosController.java`

```java
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;

// código omitido

return this.chatClient.prompt() 
    .system(system)
    .user(produto)
    .options(ChatOptionsBuilder.builder()
        .withTemperature(0.85f)
        .build())
    .advisors(new SimpleLoggerAdvisor())
    .call() 
    .content();

// código omitido
```

Dessa forma, registramos o `SimpleLoggerAdvisor`, que gerará os logs desejados.

## Exibindo os logs na IDE

Para que esses logs apareçam no console da IDE, é necessário **habilitar** uma propriedade no `application.properties`. A documentação indica que, para visualizar os logs, devemos adicionar a propriedade `logging.level.org.springframework.ai.chat.client.advisor`.

Vamos copiá-la e colá-la no `application.properties`, habilitando o log no modo `debug`.

> `application.properties`

```cpp
// código omitido

logging.level.org.springframework.ai.chat.client.advisor=DEBUG
```

Dessa forma, registraremos tudo o que ocorre na requisição e na resposta.

## Verificando os logs

Após reiniciar o projeto, limpamos o console e disparamos uma nova requisição atualizando a página no navegador para categorizar a escova de dente. Novamente, obtemos:

> Higiene pessoal

Obtemos o retorno do que a IA gerou.

No console do IntelliJ, agora aparece um texto gerado pelo `SimpleLoggerAdvisor()`, mostrando os parâmetros utilizados, como o modelo `gpt-4o-mini`, a temperatura de `0.7` e o texto do prompt.

> Retorno parcialmente transcrito:

> 2024-09-17T15:45:26.873-03:00 DEBUG 66712 --- [ecomart] [nio-8080-exec-1] o.s.a.c.c.advisor.SimpleLoggerAdvisor: request: AdvisedRequest[chatModel=OpenAiChatModel [defaultOptions=OpenAiChatOptions: {"streamUsage":false,"model":"gpt-4o-mini","temperature":0.7}], userText=Escova de dentes, systemText= Você é um categorizador de produtos e deve responder apenas o nome da categoria do produto informado
> 
> Escolha uma categoria dentre a lista abaixo:
> 
> 1. Higiene pessoal
>     
> 2. Eletronicos
>     
> 3. Esportes
>     
> 4. Outros
>     
> 
> exemplo de uso:
> 
> Pergunta: Bola de futebol
> 
> Resposta: Esportes

Além disso, são exibidas informações da API, como a quantidade de tokens (`RequestsRemaining:4999`), o limite de tokens (`tokenslimit:4000000`) e outros parâmetros retornados pela API da OpenAI.

Temos também o `content` que é justamente o que estamos capturando na resposta por ser a única informação relevante do ponto de vista da pessoa usuária (Higiene Pessoal).

## Importância de registrar logs

Registrar esses logs é fundamental para a **observabilidade**, **monitoramento** e **auditoria**. No entanto, é preciso ter cuidado ao registrar **informações sensíveis**, como dados pessoais, em ambientes de produção, pois expor essas informações nos logs não é uma boa prática.

## Próximo passo

Na próxima aula, continuaremos discutindo outros **recursos** e **funcionalidades** do Spring AI em relação à OpenAI e a outros provedores de inteligência artificial.


-----------------------------------------------------------------------
# 05Monitoramento e logging
A empresa Silver Screen Productions está expandindo seus sistemas e agora precisa armazenar os roteiros completos em um novo banco de dados. Para garantir a segurança das informações, a equipe de desenvolvimento está revisando a implementação dos logs da API, que utiliza o `SimpleLoggerAdvisor` do Spring AI.

Eles identificaram o seguinte código, responsável por registrar as interações com a API da OpenAI:

```java
return this.chatClient.prompt()
        .advisors(new SimpleLoggerAdvisor())
        .system(system)
        .user(roteiroCompleto) 
        .call()
        .content();
```

Analisando o código anterior, qual é o **risco** em potencial dessa implementação?

- Alternativa correta
    
    O método `content()` retorna o texto completo da resposta da IA, expondo o código-fonte da aplicação e as chaves de acesso.
    
- Alternativa correta
    
    O código não apresenta riscos.
    
- Alternativa correta
    
    O risco está na utilização do método `system()`, que pode expor o prompt da IA.
    
- Alternativa correta
    
    A variável `roteiroCompleto` pode conter informações confidenciais.
    
    A implementação atual registra o conteúdo completo do roteiro (`roteiroCompleto`) nos logs, o que configura um risco de segurança, pois expõe informações confidenciais.
    
- Alternativa correta
    
    A chamada `this.chatClient.prompt()` expõe a aplicação a ataques de força bruta, permitindo acesso aos roteiros armazenados.


-----------------------------------------------------------------------
# 02Modelo multimodal
## Transcrição

Vamos continuar nossos estudos com Spring AI, explorando outros recursos adicionais.

## Explorando modelo multimodal

Os provedores de inteligência artificial possuem um conceito chamado de **modelo multimodal**, o que significa que eles não se limitam apenas à geração de texto. Embora o gerador de **texto**, como o ChatGPT, seja o mais comum e utilizado, essas inteligências artificiais também conseguem gerar outros tipos de informações, como **imagens, áudios e até vídeos**.

Geralmente, essas APIs oferecem suporte para vários desses tipos de modelos, o que é chamado de multimodalidade. A OpenAI, por exemplo, oferece suporte para geração de imagens, além de outros tipos de conteúdos.

Neste vídeo, aprenderemos a usar uma integração com a API para gerar imagens. No projeto, criaremos uma nova classe `Controller` para fazer a geração de imagens.

No painel de projetos à esquerda, dentro do pacote "Controller", vamos duplicar o arquivo `CategorizadorDeProdutosController` e renomeá-lo para `GeradorDeImagensController`. Feito isso, faremos as adaptações necessárias no código.

Primeiro, em `@RequestMapping()`, a URL agora será `imagem`. Segundo, o nome do método será renomeado para `gerarImagem()`, que receberá um parâmetro chamado `prompt` do tipo `String`. Assim, vamos gerar uma imagem baseada no prompt do usuário.

Também podemos apagar todo o código da implementação anterior desse método, além do construtor e do atributo `ChatClient`. Desse modo, a classe ficará apenas com o método `gerarImagem`, recebendo o parâmetro `prompt`.

> `GeradorDeImagensController.java`:

```java
@RestController
@RequestMapping("imagem")
public class GeradorDeImagensController {

    @GetMapping
    public String gerarImagem(String prompt) {

    }
}
```

Não utilizaremos mais o modelo de gerador de texto, portanto, não usaremos a classe `ChatClient` com o método `prompt()`. Será diferente, pois outras classes lidam com a geração de imagens. Vamos consultar a documentação do Spring AI para entender como isso funciona.

Na [documentação do Spring sobre Image Model API](https://docs.spring.io/spring-ai/reference/api/imageclient.html), podemos conferir as explicações sobre o funcionamento geral, as classes existentes e os provedores suportados pelo Spring para geração de imagens, incluindo a OpenAI.

No tópico "Available Implementations", vamos clicar em "OpenAI Imagem Generation" para conferir um exemplo de como fazer a [geração de imagens usando a OpenAI](https://docs.spring.io/spring-ai/reference/api/image/openai-image.html).

Primeiro, o Spring explica sobre a configuração do projeto, as propriedades e os valores padrão. No final da página, no tópico "Runtime Options", podemos conferir um exemplo de código:

> Exemplo da documentação:

```java
ImageResponse response = openaiImageModel.call(
        new ImagePrompt("A light cream colored mini golden doodle",
        OpenAiImageOptions.builder()
                .withQuality("hd")
                .withN(4)
                .withHeight(1024)
                .withWidth(1024).build())

);
```

Perceba que não é mais o `ChatClient`, mas outras classes que seguem uma linha semelhante, chamando métodos, passando parâmetros e, em algum momento, chamando um `call()` para gerar a imagem.

Esse exemplo de código mostra apenas a classe para passar os parâmetros - o que não nos ajuda muito. Portanto, vamos montar esse código na prática.

Na classe `GeradorDeImagensController`, precisaremos declarar um atributo `private final`, cujo tipo será a classe `ImageModel`, e se chamará `imageModel`.

Usaremos o atalho "Alt + Insert" para gerar o construtor que recebe o `imageModel` como parâmetro. Também importaremos a classe `ImageModel` do Spring.

> `GeradorDeImagensController.java`:

```java
import org.springframework.ai.image.ImageModel;

@RestController
@RequestMapping("imagem")
public class GeradorDeImagemController {

    private final ImageModel imageModel;

    public GeradorDeImagemController(ImageModel imageModel) {
        this.imageModel = imageModel;
    }

    // código omitido…
}
```

O Spring consegue injetar o `ImageModel` diretamente, diferente do `ChatClient`, onde precisávamos injetar o `Builder` e criar o `ChatClient`.

> O `ImageModel` é a classe que usaremos para definir os parâmetros e fazer a chamada para a API gerar a imagem.

Agora, como implementar a chamada, disparar a requisição e armazenar a imagem gerada?

No método `gerarImagem()`, criaremos uma variável `response` que representará a **resposta da requisição**, recebendo como parâmetro o `imageModel` e o método `call()`. Ele funciona de maneira semelhante ao gerador de texto do `ChatClient`, mas recebe um parâmetro.

Como parâmetro do método `call()`, vamos instanciar o `new ImagePrompt()`, que conterá o prompt do usuário e os parâmetros para personalizar a imagem, como tamanho, altura, largura e resolução. O `ImagePrompt` recebe dois parâmetros: o `prompt`, que será a variável dinâmica digitada pela pessoa usuária; e também as `options` de personalização.

Antes dessa linha, criaremos uma variável `options` para **personalizar a imagem**. Se não passarmos `options`, ele usará o formato padrão do Spring.

Essa variável receberá `ImageOptionsBuilder.builder().build()`. Contudo, antes de chamar o `build()`, também configuraremos os parâmetros `.withHeight(1024)` e `.withWidth(1024)`. Desse modo, teremos uma imagem com 1024 de largura por 1024 de altura. Você pode definir o tamanho mais adequado para seu projeto.

Existem vários métodos para passar modelo, estilo e outros parâmetros, dependendo da API usada.

Em resumo, para fazer a **chamada da API**, usamos `imageModel.call()`, passando a _string_ `prompt` com a mensagem da pessoa usuária sobre qual imagem gerar e as opções de personalização.

A chamada do `call()` devolve um objeto `response`. O que retornaremos para o navegador será um `response.getResult().getOutput().getUrl()`. Assim, obteremos a URL da imagem gerada.

```java
import org.springframework.ai.image.ImageOptionsBuilder;
import org.springframework.ai.image.ImagePrompt;

@GetMapping
public String gerarImagem(String prompt) {
        var options = ImageOptionsBuilder
                        .builder()
                        .withHeight(1024)
                        .withWidth(1024)
                        .build();

        var response = imageModel.call(new ImagePrompt(prompt, options));
        return response.getResult().getOutput().getUrl();
}
```

Em suma, chamamos a API da OpenAI e passamos os parâmetros. Ela gera a imagem e devolve uma URL, que pode ser acessada para visualizar a imagem. Podemos salvar a URL para acessá-la em uma nova aba do navegador ou até armazená-la em um banco de dados.

Apesar de não ser mais o modo de geração de texto, o código de geração de imagem continua simples e intuitivo. Vamos testá-lo para conferir se funciona.

## Gerando imagem

A requisição `GET` para a URL `imagem` cairá no método `gerarImagem()` que espera o parâmetro `prompt` com a _string_ do que queremos gerar de imagem.

Em uma nova aba no navegador, vamos acessar `localhost:8080/imagem` seguido do parâmetro `?prompt` que será igual ao texto do pedido de geração de imagem. Seguindo no tema do projeto, vamos pedir para desenhar uma imagem de uma escova de dentes de bambu.

```bash
localhost:8080/imagem?prompt=Escova de dentes de bambu
```

Após dar "Enter", a requisição será feita e os servidores da Open AI vão gerar e devolver a _string_ com a URL para o navegador. Basta copiar a URL e colar o endereço em uma nova aba para visualizar a imagem gerada.

![Escova de dentes de bambu com cerdas em degradê do verde ao azul sobre superfície de madeira com caneca de cerâmica ao fundo.](https://cdn1.gnarususercontent.com.br/1/795715/08bc66a9-6762-403e-ab5b-ac3b029f1796.jpg)

A imagem foi gerada com as dimensões de 1024x1024, conforme configurado. Podemos fazer mais testes com outros _prompts_, caso queiramos.

No curso, estamos apenas usando a URL do navegador, mas em uma aplicação, poderíamos ter uma interface gráfica ou um formulário com campos para a pessoa usuária digitar informações. Também poderíamos gravar em um banco de dados ou salvar em um arquivo.

## Próximos passos

Com o modo de inteligência artificial do Spring, podemos integrar o projeto para gerar textos, imagens, transcrição de áudio e outros recursos.

Na sequência, exploraremos outros recursos disponíveis no módulo do Spring para integração com a API da OpenAI.



-----------------------------------------------------------------------
# 03Integrando com outras APIs
## Transcrição

Fizemos a geração de imagens, um recurso interessante que vai ao encontro da ideia de multimodalidade que os provedores de inteligência artificial oferecem. Podemos utilizar esses recursos, além do modo _chat_, que é o principal e mais utilizado.

Existem outros modelos, como geradores de imagens, áudio e vídeos, que podem ser incorporados na aplicação, se fizer sentido, para incrementá-la com outros recursos de inteligência artificial generativa.

Para finalizar o curso, há um assunto importante que gostaríamos de discutir. Observando a documentação do Spring, notamos que, no menu lateral à esquerda, na parte de geração de imagem e modelo de _chat_, estamos utilizando a OpenAI. No entanto, existem outros modelos e provedores de inteligência artificial generativa, e o Spring AI oferece suporte para esses outros modelos.

Por exemplo, ao expandir a opção "Chat model API", podemos clicar na subopção "Anthropic". Com isso, a página dessa documentação explica como utilizar o Anthropic, caso desejemos usá-lo em vez da OpenAI.

São implementações distintas, mas a ideia é a mesma: integrar-se com uma API externa para geração de textos, imagens, ou qualquer outro recurso. A mudança ocorre apenas no provedor e na implementação, mas a interface e o contrato permanecem os mesmos.

Se quisermos trocar nosso provedor de OpenAI para Anthropic, ou qualquer outro que o Spring AI suporte, qual será o impacto dessa mudança no projeto? Será necessário reescrever toda a aplicação? Essa é uma preocupação comum ao trocar de fornecedor.

Vamos analisar o código do projeto para entender onde seria o impacto.

## Trocando o provedor de IA

Voltando ao IntelliJ, no código do arquivo `GeradorDeImagensController`, observaremos especificamente a classe `ImageModel`. Ao passar o mouse sobre ela, uma caixa será exibida pelo editor, na qual perceberemos que essa classe vem do pacote do Spring, `org.springframework.ai.image`.

Essa classe não pertence à OpenAI, Anthropic ou qualquer outro provedor; é uma classe genérica do Spring.

O mesmo ocorre ao acessar o arquivo `CategorizadorDeProdutosController`, no qual utilizamos o modo de geração de _chat_ com a classe `ChatClient` e a classe `ChatOptionsBuilder`, que também se originam do pacote do Spring.

Nenhuma parte do código utiliza uma implementação específica da OpenAi. Tudo pertence à interface do Spring — portanto, **o código está genérico**. Se quisermos trocar de provedor ou ferramenta de IA generativa, não precisaremos alterar esse código, ele permanece igual. Basta assegurar que a ferramenta dê suporte ao Spring.

É possível chamar as classes diretamente no _controller_, como as da OpenAI, mas isso nos prende a uma implementação específica. A recomendação é **usar as classes do Spring sempre que possível**, pois, ao trocar de provedor, não será necessário modificar nada nessas classes.

Apenas dois locais precisam ser alterados no projeto:

- O arquivo XML, para adicionar a dependência;
- O `application.properties` para adicionar as propriedades do novo provedor.

Acessando o arquivo `pom.xml` do projeto, na parte de dependências, notaremos que a dependência de inteligência artificial adicionada é específica da OpenAI. Para mudar de provedor, basta substituir essa dependência pela do novo provedor desejado. Também é possível usar ambos, sem problemas, bastando incluir a nova dependência no projeto.

Acessando o arquivo `application.properties`, por sua vez, temos as propriedades específicas do provedor, como `spring.ai.openai.apikey` e `spring.ai.openai.chatoptionsmodel`, que são específicas da OpenAI. Se quisermos usar o Anthropic, as propriedades serão diferentes.

Apesar das propriedades terem diferenças entre provedores, elas ainda serão semelhantes. Mesmo tendo funcionalidades e comportamentos distintos, elas **seguirão o mesmo modelo de geração de texto e terão parâmetros semelhantes**.

No código principal, nas funcionalidades do projeto, não será necessário modificar nada. **Essa é a vantagem da flexibilidade do Spring.**

Desde o início, o Spring teve a preocupação de deixar o código **flexível, simples e desacoplado**, permitindo **múltiplas implementações** e **trocas fáceis**. No módulo de inteligência artificial, o Spring deixou o código totalmente flexível e genérico, possibilitando a troca de fornecedores e implementações de IA generativa de maneira simples, sem causar impacto ou exigir a reescrita do projeto inteiro.

> Convidamos você a explorar a documentação do Spring, verificar os provedores, criar uma conta em algum deles e tentar fazer essa mudança no projeto. O impacto será mínimo.
> 
> Em muitas linguagens, ao trocar de provedor, é necessário reescrever todo o código. No Spring, isso é feito de maneira simples, genérica e flexível.

## Conclusão e próximos passos

Esse é mais um recurso do Spring AI que queríamos mostrar. No próximo vídeo, faremos o fechamento do curso.


-----------------------------------------------------------------------
# 04Criatividade com modelo multimodal

A empresa Silver Screen Productions, sempre em busca de inovação, está explorando as capacidades do modelo multimodal da IA generativa. A equipe está animada com o potencial dessa tecnologia para revolucionar a forma como os filmes são concebidos e produzidos com modelos multimodais.

No entanto, durante uma reunião de brainstorm, surgiram dúvidas sobre as tarefas que esse modelo multimodal conseguiria realizar.

Considerando o contexto da produção cinematográfica e o estado atual da tecnologia multimodal, qual das alternativas abaixo descreve uma tarefa que **ultrapassa** as capacidades desse modelo?

- Alternativa correta
    
    Criar uma sinopse envolvente para um filme com base no roteiro fornecido, ajudando no marketing da produção.
    
- Alternativa correta
    
    Gerar uma sequência completa de efeitos visuais que integra personagens digitais e ambientes reais, sem intervenção humana.
    
    A geração de efeitos visuais totalmente autônoma, com alta qualidade e integração perfeita, ainda ultrapassa as capacidades dos modelos multimodais, especialmente em produções cinematográficas de ponta, que demandam supervisão humana.
    
- Alternativa correta
    
    Analisar sentimentos e emoções de personagens em um roteiro e gerar sugestões de trilha sonora apropriada para as cenas.
    
- Alternativa correta
    
    Desenvolver conceitos de figurino e maquiagem baseados em descrições de personagens no roteiro.
    
- Alternativa correta
    
    Transformar descrições complexas de cenas em animações tridimensionais, otimizando o planejamento de filmagens.

-----------------------------------------------------------------------
# 07Referências

[Documentação do Spring AI](https://docs.spring.io/spring-ai/reference/index.html) **(gratuito, inglês, documentação)**

> Site contendo a documentação do módulo AI, do Spring, detalhando a parte técnica e dando exemplos de utilização para os diferentes provedores de IA generativa.

[Documentação da API da OpenAI](https://platform.openai.com/docs/api-reference/introduction) **(gratuito, inglês, documentação)**

> Site da OpenAI que documenta o funcionamento de sua API, detalhando cada serviço oferecido e suas características técnicas.

-----------------------------------------------------------------------
# 09Conclusão
## Transcrição

Chegamos ao final de mais um curso na Alura, focado em **inteligência artificial generativa com Java**, utilizando o Spring, com o módulo Spring AI. Parabéns pro chegar até aqui! Te agradecemos por nos acompanhar ao longo deste curso.

Agora, vamos recapitular tudo o que aprendemos.

## O que aprendemos?

Primeiro, entendemos o que é o **módulo Spring AI**, para integração com **APIs de inteligência artificial generativa**, focando principalmente na geração de texto, mas também abordando a geração de imagens, vídeos, entre outros. Também exploramos a documentação para compreender como funciona esse módulo.

Criamos nosso projeto utilizando o site do **Spring Initializr** e o importamos na IDE. Como é um projeto Spring Boot, ele possui toda a estrutura de diretórios e configurações tradicionais, com a diferença de incluir a dependência da inteligência artificial generativa.

Além disso, implementamos a classe para geração de nomes de produtos e entendemos como funciona a API do Spring e como chamar a API da OpenAI via Spring. Para isso, foi preciso usar a classe `ChatClient`, injetar o `ChatClient.Builder` e, a partir dele, criar o `ChatClient`.

O código para disparar a requisição é simples `chatClient.prompt()`, passando o `user()` e o método `call()` que dispara a requisição para obter a `content()` da resposta gerada pela API. O encadeamento de métodos é simples e intuitivo. O Spring facilitou muito a integração com esse tipo de API para inteligência artificial generativa.

Depois, passamos para exemplos mais aprimorados, criando um outro _controller_ para categorização de produtos. Aprendemos a passar parâmetros, trocar o modelo do GPT que estamos utilizando e usar a ideia de _**Prompt Engineering**_ para melhorar nosso _prompt_ e ter um controle mais apurado da resposta gerada pela IA.

Também aprendemos a fazer contagem de _tokens_ usando a **biblioteca externa JTokkit**, que não é do Spring, mas que podemos integrar ao nosso projeto.

Aprendemos a **customizar parâmetros** de temperatura no **Playground da OpenAI** para fazer simulações e ajustar parâmetros para casos de uso específicos. Aprendemos a habilitar o **log com SimpleLoggerAdvisor** para gerar registros das requisições e respostas feitas com a API da OpenAI.

Finalmente, aprendemos a fazer a geração de imagens com integração com a OpenAI, usando as classes de `ImageModel`.

O Spring oferece suporte para o **modelo multimodal**, permitindo a geração de imagens, vídeos e áudios. No entanto, nem todos os recursos estão disponíveis e nem todos os provedores oferecem esses recursos. O gerador de texto é o mais comum, mas é necessário consultar a documentação do provedor e da Spring AI para conferir o suporte para os demais recursos.

Além disso, descobrimos que esse código é **flexível**, sem nada específico da OpenAI. Isso permite trocar de provedor sem alterar as classes Java. Basta trocar a dependência no `pom.xml` e as propriedades no `application.properties`.

Inclusive, aprendemos a **personalizar algumas propriedades** e a trocar alguns padrões do Spring. Também aprendemos que é uma boa prática de segurança colocar a **chave da API** em uma variável de ambiente.

Por último, discutimos sobre as facilidades do **tratamento de erros** com Spring e a possibilidade de personalizar as retentativas caso a API esteja fora do ar.

## Conclusão

Aprendemos bastante ao longo deste curso. Esperamos que você tenha gostado do Spring e deste módulo de integração com APIs, seja da OpenAI ou de qualquer outro provedor.

O foco do curso foi ensinar sobre a API do Spring e como você pode utilizar esses recursos em seus projetos para implementar funcionalidades que utilizem as capacidades de IA generativa, automatizando processos para facilitar tanto para você quanto para seus usuários.

Caso tenha alguma dúvida, pode postar no **fórum** ou na comunidade no [Discord da Alura](https://discord.gg/SK9bj7hEYD). Lembre-se de deixar sua **avaliação** no curso, pois ela é importante para entender o que foi bom e o que podemos melhorar em futuras gravações.

Nos encontramos em outros cursos da Alura. Até lá!



-----------------------------------------------------------------------
