---
type: "10"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
  - "#oracle"
  - "#OCI"
  - "#cloud"
fonte_curso: https://cursos.alura.com.br/formacao-ia-generativa-one
Url_video_curso: 
IA: https://cursos.alura.com.br/course/landing-page-ia-construindo-pagina-web-funcional
w3schools:
---

Tópico:: #Inteligencia_Artifical #IA_generativa 

#### Inteligência artificial

A inteligência artificial (IA) se tornou uma peça chave no campo da programação, revolucionando a maneira como desenvolvemos e otimizamos software. Sua capacidade de aprender e se adaptar permite automatizar tarefas repetitivas, identificar erros rapidamente e propor soluções eficientes. Além disso, a IA potencializa a criatividade dos desenvolvedores ao liberar tempo que pode ser dedicado à inovação. Ferramentas como o ChatGPT facilitam a compreensão de códigos complexos e melhoram a colaboração em projetos, tornando a programação mais acessível e eficaz.

-----------------------------------------------------------------------
A Inteligência Artificial (IA) está redefinindo os processos criativos e produtivos em diversas áreas, oferecendo ferramentas poderosas para transformar ideias em soluções práticas e inovadoras. Você aprenderá conceitos fundamentais e técnicas aplicadas de IA voltadas para a criação de **landing pages**, com ênfase no uso estratégico de prompts para desenvolver copywriting e planejar estruturas de página eficazes.

Além disso, você conhecerá o papel da IA na **automação de tarefas**, otimização de fluxos de trabalho e melhoria da produtividade. Ferramentas avançadas serão apresentadas para apoiar atividades como pesquisa de mercado, organização de insights, documentação técnica e a construção de portfólios profissionais.

-----------------------------------------------------------------------
## Faça esse curso de IA para UX & Design e:

- Entenda como melhorar o uso do prompt para a construção de um bom COPY
- Entenda como melhorar o uso do prompt para a construção de um planejamento de Landing Page
- Conheça a ferramenta FRAMER e construção seu site usando IA
- Crie uma landing page completa para adquirir leads para o seu produto ou serviço

-----------------------------------------------------------------------
## Aulas

- [](https://cursos.alura.com.br/course/landing-page-ia-construindo-pagina-web-funcional/section/17615/tasks)
    
    [Planejando a LP com IA](https://cursos.alura.com.br/course/landing-page-ia-construindo-pagina-web-funcional/section/17615/tasks) [Ver primeiro vídeo](https://cursos.alura.com.br/course/landing-page-ia-construindo-pagina-web-funcional/task/139756)
    
    0 / 8
    
    11min
    
    - Apresentação
    - Visão geral
    - Para saber mais: o que é Landing Page
    - Planejando a Landing Page
    - Para saber mais: criando um Wireframe
    - IA e Landing Page
    - Faça como eu fiz: definindo a Landing Page
    - O que aprendemos?
- [
    
    Construindo artes com IA
    
    0 / 10
    
    17min
    
    ](https://cursos.alura.com.br/course/landing-page-ia-construindo-pagina-web-funcional/section/17616/tasks)
    
    - Material da aula
    - Buscando imagens para LP
    - Material do curso
    - Recolorindo artes com IA
    - Para saber mais: Adobe FireFly
    - Criando artes com IA
    - Para saber mais: editando com Freepik
    - Artes e IA
    - Faça como eu fiz: pegando imagens
    - O que aprendemos?
- [
    
    Montando a LP com IA
    
    0 / 8
    
    21min
    
    ](https://cursos.alura.com.br/course/landing-page-ia-construindo-pagina-web-funcional/section/17617/tasks)
    
    - Montando primeiro site com IA
    - Para saber mais: prompts em IAs
    - Recolorindo artes com IA
    - Para saber mais: o Framer
    - Header e footer
    - Montando site com IA
    - Faça como eu fiz: montando sua Landing Page
    - O que aprendemos?
- [
    
    Criando o Copy
    
    0 / 8
    
    16min
    
    ](https://cursos.alura.com.br/course/landing-page-ia-construindo-pagina-web-funcional/section/17618/tasks)
    
    - Criando o copy com IA
    - Validando fontes com IA
    - Para saber mais: fontes em sites
    - Inserindo o copy no site
    - Para saber mais: organizando fontes no FRAMER
    - Texto e landing page com IA
    - Faça como eu fiz: inserindo os textos na LP
    - O que aprendemos?
- [
    
    Refinando e finalizando a LP
    
    0 / 8
    
    14min
    
    ](https://cursos.alura.com.br/course/landing-page-ia-construindo-pagina-web-funcional/section/17619/tasks)
    
    - Criando formulário para Lead
    - Para saber mais: o Mailchimp
    - Publicando a Landing Page
    - Formulários com IA
    - Faça como eu fiz: Finalizando seu site
    - O que aprendemos?
    - Conclusão
    - Créditos

-----------------------------------------------------------------------
# 01Apresentação

## Transcrição

Olá! Boas-vindas ao curso de **montagem de _landing page_ utilizando inteligência artificial** da Alura. Sou o instrutor **Luiz Lima** e vou acompanhar você ao longo deste conteúdo.

> **Audiodescrição:** Luiz se descreve como um homem moreno, de olhos, cabelos e barba pretos. O cabelo dele está amarrado para trás, pois é longo, e a barba está por fazer. Ele veste uma camisa azul e está em frente a uma parede lisa iluminada em roxo, com uma estante de livros atrás dele.

## O que vamos aprender?

Neste curso, vamos trabalhar na construção de uma landing page com o auxílio da inteligência artificial. Isso significa que vamos aprender a construir o _copy_, todo o layout do site, a publicá-lo, e o mais importante, como adquirir _leads_ por meio dele.

O melhor de tudo, é que vamos fazer isso sem precisar trabalhar com codificação, o que torna este curso extremamente relevante e abrangente.

## Para quem é este curso?

Se você é uma pessoa que deseja criar landing pages para um produto que tenha pensado ou para um produto do seu ambiente de trabalho, e não possui conhecimento em HTML e CSS, mas deseja agilizar este processo com a inteligência artificial, este curso é exatamente para você.

> Não há pré-requisitos, pois tudo será feito sem código.

Um ponto importante a mencionar é que nós vamos utilizar uma ferramenta chamada _**Framer**_. Essa é uma ferramenta um pouco mais técnica, e ao decorrer do curso traremos informações de como trabalhar com ela.

Portanto, é importante ter atenção aos **Para saber mais**, especialmente neste curso, pois eles fornecem um auxílio e uma profundidade muito maior do que trazemos nos vídeos.

Esperamos que você goste muito deste conteúdo e que seja muito útil para você no seu dia a dia de trabalho ou nas suas ideias empreendedoras.

**Um abraço e te encontramos no curso!**

-----------------------------------------------------------------------
# 02Visão geral

https://cursos.alura.com.br/course/landing-page-ia-construindo-pagina-web-funcional/task/139757

## Transcrição

Que bom que você iniciou este curso! Neste primeiro momento, vamos fazer uma **visão geral** do que iremos abordar ao longo das aulas.

### Visão geral

Vamos entender e trabalhar com o _**ChatGPT**_, a fim de criar os blocos para a nossa _landing page_ (página de destino). Vamos entender como criar esses blocos, o que será necessário e depois estruturar a landing page utilizando esses auxílios.

Após isso, buscaremos **imagens**. Afinal, trabalhar com imagens em uma landing page ou website é muito importante. Contudo, essas imagens serão geradas por inteligência artificial. Como conseguimos editar e buscar de forma eficiente? Qual prompt utilizamos para isso?

Além disso, caso seja necessário alterar essas imagens buscadas, usaremos o _**Adobe Firefly**_, um recurso de inteligência artificial da _Adobe_, que permite alterar tons em imagens de ambientes vetoriais, ou até mesmo criar novas imagens.

Entender essas ferramentas auxilia muito no seu trabalho diário, principalmente no processo de construção de uma landing page.

Após entendermos os blocos e as imagens, entraremos na ferramenta _**Framer**_. Essa será a ferramenta mais complexa do curso, com a qual vamos criar uma estrutura para nosso site por meio de um prompt. A estrutura do site se parecerá com o seguinte:

![Interface da ferramenta Framer exibindo o projeto de uma página de dicas sobre investimentos financeiros chamada "Invest Better Today". São exibidos 3 layouts: um para desktop, outro para tablet, e o último para dispositivos móveis.](https://cdn1.gnarususercontent.com.br/1/1310271/f8ccd319-e166-434b-acdd-b2304e681daa.png)

Dentro dessa estrutura, temos tudo o que precisamos para uma landing page, como a _call to action_ (chamada para ação), os textos, os depoimentos e várias outras coisas importantes para que você tenha um bom desempenho em toda essa estrutura.

Porém, isso foi feito por meio de inteligência artificial com o auxílio do manual. Portanto, criamos o site de forma rápida e sem código, com a inteligência artificial e o Framer.

Mas, evidentemente, precisamos entender essa ferramenta para alterar **cores**, **textos**, **imagens** e deixar tudo da maneira como desejamos. Tudo isso para que possamos gerar nosso _lead_ através de um formulário no site e, claro, sem código.

Quando fazemos tudo isso, precisamos entender quais **fontes** e cores utilizamos. Portanto, aprenderemos também sobre ferramentas que nos ajudam a buscar essas fontes.

Por que utilizamos estas específicas? Existem ferramentas que ajudam a visualizar isso sem precisar conhecer tipografia a fundo.

Por último, como conseguimos **gerenciar nossos leads** caso as pessoas tenham interesse e queiram enviar um e-mail para nós? Para isso, utilizaremos a ferramenta _**MailChimp**_, vinculada ao Framer. Criaremos este vínculo e conseguiremos pegar os e-mails que têm interesse em nosso produto para enviar atualizações e começar a trabalhar com os leads.

Após fazer tudo isso, **publicaremos o site** para que ele esteja acessível. Na página final, será possível cadastrar o e-mail para receber inscrições.

Todas essas informações serão abordadas com calma e com muito auxílio dos Para saber mais. O objetivo é criar a nossa landing page **funcional** e **sem códigos**, podendo adquirir leads.

Vamos começar isso no próximo vídeo. Esperamos você lá. Um abraço!

-----------------------------------------------------------------------
# 03Para saber mais: o que é Landing Page

https://cursos.alura.com.br/course/landing-page-ia-construindo-pagina-web-funcional/task/142021

Muitas vezes estamos acostumados com o termo, mas não temos uma noção bem definida sobre o que de fato é uma landing page.

**Afinal o que é?**

Uma LP nada mais é do que uma página da web criada com um propósito específico em mente, normalmente ela é usada como parte de uma estratégia de marketing digital, então quem vem do marketing está bem familiarizado com o termo. O principal propósito de uma landing page é direcionar o tráfego da web para uma ação desejada, ou seja, o que você quer que façam quando visitarem sua página, um exemplo é a conversão de visitantes em leads, clientes ou assinantes.

Existem pequenas indicações de uma boa landing page para que ela tenha sucesso neste propósito, algumas delas são por exemplo, existir um formulário para conversão, ou um CTA(Call to action) claro para que as pessoas sejam direcionadas para algum lugar. Sempre de forma bem clara e chamativa, você consegue ver bem essas características no exemplo abaixo:

![Alt - Banner de um site com o fundo azul, título descritivo a esquerda também em azul mais textos corridos menores abaixo do título e um botão de ação chamado CTA abaixo dos textos, e a direita a foto de uma mulher segurando um celular.](https://cdn3.gnarususercontent.com.br/3402-landing-page/Imagens/imagem_1.png)

Todas essas indicações de uma boa Landing Page, você consegue achar de maneira mais detalhada no curso [landingpage construindo campanha](https://cursos.alura.com.br/course/landingpage-construindo-campanha), se tem interesse em conhecer estes por menores e ter um bom aproveitamento deste nosso curso de IA, aconselho assistir ao curso.

Agora vamos colocar a mão na massa.

-----------------------------------------------------------------------
# 04Planejando a Landing Page

https://cursos.alura.com.br/course/landing-page-ia-construindo-pagina-web-funcional/task/139758

## Transcrição

Vamos nos preparar para começar a desenvolver a _**landing page**_. Esperamos que você já tenha lido o **Para saber mais** antes deste primeiro vídeo, onde explicamos os conceitos básicos da landing page e disponibilizamos o link para outro curso da Alura que explica em detalhes todas as pequenas etapas desse processo de maneira muito mais aprofundada.

Lembrando que iremos trabalhar com o auxílio de **inteligência artificial** para construir a nossa landing page da maneira mais rápida e eficiente possível.

## Planejando a _landing page_

A primeira coisa que precisamos fazer é definir os **blocos** e a **estrutura** da nossa página. Às vezes, não temos uma ideia de como iremos construir e pode parecer difícil planejar tudo isso. Assim, surge nossa primeira dica: o uso do _**ChatGPT**_.

A maneira como você escreve o prompt, apesar de um pouco delicada, auxilia bastante para entender como a sua estrutura irá funcionar. Para recapitular, analise a estrutura de uma landing page e observe que ela é composta por alguns blocos.

![Estrutura de uma página de destino chamada Trekt, composta por quatro blocos principais dispostos verticalmente. O primeiro bloco consiste no cabeçalho e no banner principal, enquanto o segundo é intitulado "Our Office", seguido do terceiro "Features" e do quarto "Benefits".](https://cdn1.gnarususercontent.com.br/1/1310271/64a4f4cc-7537-4af6-8012-692f4eab7504.png)

Temos um bloco no topo, outro no meio, um terceiro no centro, e o último na parte inferior. Esses blocos de conteúdo definem nossa estrutura e cada um deles possui informações específicas. Por exemplo, temos a informação responsável por chamar a pessoa, isto é, a _call to action_ (CTA), representada pelo banner principal e assim por diante.

O segundo bloco informa o que oferecemos, o terceiro apresenta as funcionalidades do aplicativo, e o último destaca os benefícios do aplicativo. Dessa forma, esses blocos de landing page são bem padronizados. Conseguimos planejar isso e solicitar a ajuda do ChatGPT para criá-los, pois nem sempre sabemos como fazer.

Então, vamos acessar o ChatGPT e começar a escrever o seguinte prompt:

```plaintext
Por favor, crie para mim uma estrutura de landing page com base nas boas práticas de uma landing page escritas pelo site https://popupsmart.com/blog/landing-page-statistics
```

A parte mais interessante disso é entender como trabalhar com o prompt. Quanto mais informação damos para a inteligência artificial, melhor é a resposta que ela vai te fornecer.

Nesse caso, solicitamos a construção de uma landing page. Mas o que é uma landing page? Nós entendemos um pouco o conceito, especialmente após o curso de landing page da plataforma.

No entanto, o ChatGPT entende isso? É essencial fornecer um **direcionamento** para a inteligência artificial para que ela possa nos retornar o que esperamos.

No prompt acima, foi útil buscar sites e artigos que fornecessem essas estruturas de landing page. Trouxemos um exemplo interessante, o artigo "[_12 Best Landing Page Statistics You Should Know_](https://popupsmart.com/blog/landing-page-statistics)". Portanto, copiamos este link e inserimos no ChatGPT.

Ao fazer isso, fornecemos muitas informações para o próprio ChatGPT utilizar como referência e entender em que consiste uma boa estrutura de landing page.

Podemos trazer ainda mais especificidade ao prompt, inserindo o seguinte:

```plaintext
Com 4 blocos distintos sendo eles:

- Primeiro bloco com um banner e uma chamada em texto mais uma CTA
- Segundo bloco tendo benefícios de usar o meu aplicativo
- Terceiro bloco tendo depoimentos de pessoas usuárias falando bem do meu aplicativo
- Quarto bloco tendo um formulário de cadastro

Obrigado
```

> Lembrando que **CTA** é uma sigla conhecida, portanto, o ChatGPT vai reconhecer esse termo, também conhecido como _call to action_.

Após enviar o prompt, a estrutura é imediatamente apresentada, já organizada, com uma sugestão de título para a landing page e como conseguimos trabalhar em cima disso.

> **Título da Landing Page:** Descubra o Futuro com Nosso Aplicativo Inovador!
> 
> **Primeiro Bloco: Banner e Chamada com CTA**
> 
> Imagem de destaque do seu aplicativo em ação
> 
> Texto persuasivo: "Experimente a revolução tecnológica agora!"
> 
> Chamada para ação (CTA):
> 
> - **Botão CTA 1:** "Baixe Agora" (com link para a loja de aplicativos)
> - **Botão CTA 2:** "Saiba Mais" (com link para a seção de beneficios)
> 
> **Segundo Bloco: Benefícios do Aplicativo**
> 
> Destaque os principais beneficios do seu aplicativo em pontos de destaque, usando ícones ou Imagens associadas a cada beneficio:
> 
> 1. **Eficiência Aprimorada:** Aumente sua produtividade com nossa tecnologia de ponta.
> 2. **Facilidade de Uso:** Uma interface intuitiva que todos podem dominar.
> 3. **Economize Tempo e Dinheiro:** Reduza custos e otimize seus recursos.
> 4. **Suporte 24/7**: Atendimento ao cliente pronto para ajudar a qualquer momento.
> 
> **Terceiro Bloco: Depoimentos de Usuários Satisfeitos**
> 
> Apresente depoimentos reais de usuários satisfeitos com seu aplicativo:
> 
> - "Eu não posso acreditar como esse aplicativo transformou minha vida profissional. É incrível!" - João S., São Paulo
> - "Simplesmente o melhor aplicativo que já usei. Recomendo a todos!" - Maria A., Rio de Janeiro
> - "O suporte ao cliente é excepcional. Eles realmente se importam com seus clientes!" - Pedro R., Belo Horizonte
> 
> **Quarto Bloco: Formulário de Cadastro**
> 
> Inclua um formulário de cadastro simples para coletar informações dos visitantes interessados:
> 
> **Cadastro Gratuito**
> 
> - **Nome Completo:**
> - **Endereço de E-mail:**
> - **Telefone:**
> - **Senha:**
> - **Confirme a Senha:**
> 
> Botão CTA para cadastro: "Cadastrar Agora"
> 
> **Rodapé da Página:**
> 
> - Links para as redes sociais da empresa.
> - Politica de Privacidade e Termos de Uso.
> - Informações de Contato.

Perceba que é bastante rápida a organização para a criação da sua landing page. Ao pular esta etapa, você enfrentará retrabalhos futuros, pois ao revisar a estrutura dos blocos, perceberá que faltaram alguns detalhes. Portanto, essa é a primeira parte que conseguimos elaborar.

O uso de inteligência artificial agiliza essa etapa. É essencial verificar se tudo está conforme desejado. Se estiver tudo correto, podemos seguir para a construção do material.

## Conclusão

Agora que temos essa estrutura definida para a inteligência artificial, começaremos a trabalhar de fato na construção.

**Faremos isso a partir da próxima aula!**

-----------------------------------------------------------------------
# 05Para saber mais: criando um Wireframe

Um dos métodos mais comum usado para se criar uma landing page única e direcionada é que exista o processo de construir um wireframe, um pequeno esboço de como você gostaria que sua página ficasse no final.

Porém, este processo é um pouco mais profundo e exige um conhecimento mais técnico sobre ferramentas como o FIGMA. Caso seja do seu interesse entender como usar inteligência artificial no figma para criar Wireframes, eu deixo abaixo um vídeo explicando este processo.

https://youtu.be/6VsE1bLlwLQ

Contudo, no nosso processo de trabalho durante este curso, vamos **facilitar nossa construção** e pedir para a Inteligência Artificial criar o site inteiro sem precisar passar por esta etapa, isso possui suas vantagens e desvantagens, tudo depende do que você deseja para o seu produto. Vamos lá!

-----------------------------------------------------------------------
# 06IA e Landing Page

Uma das coisas que precisamos nos ater no momento de utilizar a inteligência artificial à nosso favor é saber como perguntar de forma eficiente. Dentro das perguntas abaixo, qual é o melhor PROMPT para ajudar na construção de uma LP?

1 - Por favor, crie para mim uma estrutura de landing page igual ao site de imóveis do grupo Vila Imperial Imóveis para que eu possa usar como base para o meu site.

2 - Por favor, crie para mim uma estrutura de landing page para uma empresa de cosméticos.

3 - Por favor crie para mim uma estutura de uma landing page de uma página só que atenda os critérios de uma boa landingpage construidas pelo site [https://popupsmart.com/blog/landing-page-statistics](https://popupsmart.com/blog/landing-page-statistics), eu quero que ela tenha 4 blocos de conteúdo, um com a chamada principal e CTA, outro com informações do motivo pelo qual vale a pena se cadastrar, outra com depoimentos e a ultima com um formulario para cadastro.

4 - Crie para mim uma estrutura de landing page contendo 5 blocos de conteúdo para eu divulgar meu novo produto, cada bloco deve ter texto e botão para cta.


Pergunta 3.

Este é um ótimo modelo de pergunta, pois aqui você está definindo um site para pegar como referência, e passando sua URL na pergunta, definindo o que você tem como objetivo que são 4 blocos de conteúdo e o que você deseja em cada um dos blocos, quanto mais precisa e explicada é nossa pergunta, mais eficiente é o resultado para o que queremos resolver com IA.

-----------------------------------------------------------------------
# 08O que aprendemos?

## Nessa aula, você aprendeu:

- O que é uma landing page;
- Como usar o CHAT GPT para auxiliar na construção de uma estrutura para landing page;
- Como, se for necessário, usar o FIGMA e a IA para construir um wireframe para landing pages mais únicas.

-----------------------------------------------------------------------
# 01Material da aula

Aqui você pode baixar os COPY usadas na aula:

- [Prompt Site](https://cdn3.gnarususercontent.com.br/3402-landing-page/texto_prompt_site.txt)
- [Prompt Copy](https://cdn3.gnarususercontent.com.br/3402-landing-page/texto_para_prompt_copy.txt)

prompt
create a landing page with 4 sections for my financial app.

The first section containing an image on the right and text on the left with CTA.

The second section containing about the benefits of my app with icons and texts bellow them.

The third section containing the users review of my app. 

The last section containing one subscribe form with lettering calling for it.

The landingpage has a simple menu and footer for navigation


prompt
por favor crie um copywritting para uma landing page do meu aplicativo sobre organizaÃ§Ã£o financeira. Utilizando como referencias as boas pÃ¡ticas do site https://coschedule.com/blog/writing-great-copy

Preciso de uma copy para o banner principal chamando para baixar o aplicativo ou se registrar com um CTA

Uma copy mostrando dois benefÃ­cios do aplicativo

Uma copy para Ã¡rea de testemunhos da landingpage

Um copy chamando para se inscrever para receber atualizaÃ§Ãµes.

-----------------------------------------------------------------------
# 03Material do curso

Aqui você pode baixar as imagens usada durante o curso:

- [Imagens Landing Page](https://cdn3.gnarususercontent.com.br/3402-landing-page/imagens_landingPage.zip)


-----------------------------------------------------------------------
# 04Recolorindo artes com IA

https://cursos.alura.com.br/course/landing-page-ia-construindo-pagina-web-funcional/task/139760

## Transcrição

Escolhemos a imagem que desejamos utilizar na _landing page_!

Se quiser utilizar a mesma imagem que usei, você pode voltar ao "Para Saber Mais", onde disponibilizamos todo o material disponível. Fique à vontade para usar os mesmos materiais e criar o mesmo site, com o mesmo _template_. Após escolher o que deseja, podemos converter e trabalhar com essas imagens, mas como faremos isso?

Existe um site muito interessante chamado [_Adobe Firefly_](https://firefly.adobe.com/). Está atualmente em formato _beta_ e, por isso, ainda é gratuito e disponível para todos. Se você tem uma conta _Adobe_, é ainda melhor.

Nele, temos disponíveis algumas artes e áreas de inteligência artificial disponibilizadas pela _Adobe_. Caso queira, é possível gerar imagens através de textos, preenchimento generativo e até mesmo efeitos de texto, tudo com inteligência artificial, por meio de _prompts_ de comando.

Recomendamos que você pause este vídeo e teste algumas funções para ver se deseja usar algo deste tipo em sua _landing page_. No entanto, nosso foco agora será a seção de **recoloração generativa**. Isso porque essa área nos permite mudar a paleta de cores de um formato de uma imagem vetorial, especificamente SVG, para uma paleta diferente.

Assim que tiver a imagem que deseja alterar - no meu caso, uma imagem azul para um aplicativo financeiro que eu quero mudar para uma cor diferente - você pode ir até esta área, clicar em "Gerar" e a própria ferramenta trará para você opções de variações de cores para a sua arte vetorial. Em seguida, é preciso fazer o _upload_ da imagem SVG.

Porém, pode surgir um pequeno problema. A imagem que baixei do site _Freepik_ têm os formatos EPS e JPEG. O formato SVG é um pouco diferente e está disponível no "Para Saber Mais", mas se você quiser converter seu EPS, pode usar sites como o [_Cloud Converter_](https://cloudconvert.com/), especificamente a aba de [conversão de EPS para SVG](https://cloudconvert.com/eps-to-svg).

Nela, basta clicar em "Select File", selecionar o arquivo EPS na máquina local e clicar em "Convert" (converter). O site fará todo o processo e, depois disso, é só clicar em "Download". Com isso, temos a mesma imagem, só que no formato SVG, que é o que nós vamos utilizar.

Depois desse processo, dentro do _Adobe Firefly_, é possível fazer o _upload_ da imagem ou arrastá-la para dentro do site. A partir de agora, podemos escrever as instruções para a _Adobe_, como:

> "mude a paleta de cor para um app de finanças com a cor dominante sendo amarelo"

Depois, é só clicar em "Gerar".

O _Adobe Firefly_ pega a imagem e altera a paleta de cores da maneira que solicitamos. Assim, de uma maneira rápida, temos a alteração da imagem vetorial, sem precisar trabalhar com um software vetorial como o _Illustrator_.

Note que nos são retornados formatos pré-definidos na aba à direita, além da harmonia que podemos alterar.

Decidindo a alteração das cores, podemos optar por uma tríade, uma divisão complementar ou o que mais se adequar ao padrão e conhecimento de cores que possuímos. Se você não tem um conhecimento profundo para trabalhar com isso, experimente e veja qual lhe agrada mais.

Após selecionar a que mais nos agrada, clicamos no ícone de "Baixar", no canto superior direito da imagem em questão.

Agora que temos a imagem, o que faremos a seguir? É preciso pensar nas imagens que não encontramos no _Freepik_ e se desejamos criar algo mais único. Será que existe uma ferramenta de inteligência artificial que possamos usar para criar nossos ícones e imagens?

É isso que vamos explorar no próximo vídeo, caso você queira elementos mais únicos, ao invés de apenas pegar algo pré-definido e mudar seu padrão de cores!


-----------------------------------------------------------------------
# 05Para saber mais: Adobe FireFly

A Adobe é a empresa responsável por vários softwares gráficos, entre os mais conhecidos temos o PHOTOSHOP, o ILLUSTRATOR e o AFTER EFFECTS, acredito que você deva ter escutado ao menos o nome de um desses.

Para se manter líder de mercado, a ADOBE vem investindo forte no uso de inteligência artificial para auxiliar o dia a dia das pessoas que usam os seus produtos, principalmente designers, e dentro deste universo de Inteligência Artificial ela resolveu criar um espaço aberto para a comunidade conseguir utilizar o básico das suas ferramentas de IA, ela chamou este espaço de ADOBE FIREFLY:

![[Pasted image 20250523213624.png]]

Dentro destas ferramentas, que você pode notar pelo site que ainda estão em teste (BETA), temos algumas utilidades:

- **Texto para imagem:** Semelhante ao MIDJOURNEY, baseado em um prompt de comando podemos criar imagens usando IA.


![[Pasted image 20250523213701.png]]

- **Preenchimento Generativo:** Uma ferramenta preencher espaços vazios criando composições inteiras usando IA.

![Alt - Imagem preenchida pela inteligência artificial, duas imagens na direita uma imagem de um farol com o prompt Pássaros migrando, e na imagem da direita a inserção de imagens de forma automática com IA de uma revoada ao longe.](https://cdn3.gnarususercontent.com.br/3402-landing-page/Imagens/imagem_4.png)

- **Efeitos de texto:** Uma ferramenta que gera tipografias artísticas baseadas em prompts de comando.

![Alt - Imagem da letra A criada pela IA usando o prompt - TORRADA.](https://cdn3.gnarususercontent.com.br/3402-landing-page/Imagens/imagem_5.png)

- **Recoloração Generativa:** A ferramenta que usamos em curso, que permite recriar uma paleta de cores de uma imagem vetorial para melhor aplicá-la nos projetos.
    
- **Do 3D para imagens:** Uma ferramenta que permite pegar um modelo 3D simples, sem cor e sem finalizar e gerar uma composição completa a partir desta base. (ainda em testes).
    

![Alt - Imagem de um castelo feito em 3D sem cores e ao lado como a IA vai conseguir representar o 3D como ilustrações.](https://cdn3.gnarususercontent.com.br/3402-landing-page/Imagens/imagem_6.png)

- **Estender Imagem:** Uma ferramenta para estender imagens aumentando composições.

Essas ferramentas trazem um dinamismo muito grande para o processo de construção de composição e de design, e claro, ajuda também quem não tem a possibilidade de entrar em uma ferramenta robusta como o Illustrator para alterar os vetores. Que foi o nosso caso.

Agora que vimos um pouco mais do que esta ferramenta pode fazer, vale a pena tentar testá-la um pouco e usar quando for pertinente.

Vamos agora construir nossas ilustrações em vez de alterar as que já existem!

-----------------------------------------------------------------------
# 06Criando artes com IA

https://cursos.alura.com.br/course/landing-page-ia-construindo-pagina-web-funcional/task/139761

## Transcrição

Conseguimos pegar uma imagem vetorial de um site como o _Freepik_ e trazer para uma inteligência artificial, como o _Adobe Firefly_, para alterar suas cores sem ter nenhum conhecimento sobre _softwares_ vetoriais. Isso é importante porque nos permite alterar determinados elementos aos quais não tínhamos acesso antes.

No entanto, enfrentamos um pequeno problema. Se você quiser criar uma imagem mais específica, um ícone especialmente para sua página inicial, será mais delicado. Isso porque você estará à mercê das imagens existentes no _Freepik_.

Para isso, temos as ferramentas de geração de imagem, como o _Mid Journey_, que nos permite criar e gerar imagens através de _prompts_, semelhante ao que foi feito no chat do GPT para criar textos. Essas imagens têm aplicações específicas que às vezes podem não atender ao seu propósito. Isso porque temos um formato _flat_, um formato de ícone e as imagens geradas por IA tendem a criar ilustrações um pouco mais fantasiosas ou realistas. Portanto, muitas vezes é necessário fazer vários testes.

O _Mid Journey_ é uma das ferramentas mais robustas na geração de imagens. No entanto, é uma ferramenta paga que necessita de acesso ao Discord, por isso optamos por não trabalhar com ela. Ainda assim, é importante que você conheça essa opção, e caso seja necessário, se aprofunde um pouco nela. A _Dall-E_, criada pela mesma empresa que fez o chat GPT, é outro exemplo de ferramenta robusta que gera imagens, mas também é paga.

Para trabalhar de maneira mais tranquila no curso, voltaremos ao _Freepik_. No menu superior, vamos em "AI Images", que nos mostra imagens criadas por IA. Note que elas possuem aquele aspecto fantástico, mencionado anteriormente.

O interessante do _Freepik_ é que se trata de um banco de imagens criado pela inteligência artificial, mas também tem um menu chamado "More"(Mais). Ao clicar em "More", temos acesso a diversas opções, inclusiva uma chamada "AI Image Generator" (Gerador de Imagens AI). Ao clicá-la, somos redirecionados para um site onde conseguimos criar nossa imagem com inteligência artificial. Até então, gratuitamente, e de uma maneira um pouco mais robusta do que outras ferramentas gratuitas encontradas.

Nesta plataforma, podemos descrever o que queremos ver, além de definir um estilo específico. Essa é uma vantagem: em vez de sem estilo, podemos escolher se queremos algo semelhante a uma foto, arte digital, 3D, algo com baixa poligonalidade ou até mesmo estilos de quadrinhos e desenhos animados.

Vamos optar pelo estilo 3D, pois existem alguns elementos 3D que ficam bem interessantes, e descrever o que queremos, em inglês:

> "wallet with coin on the center"

A tradução seria "carteira com moeda no centro".

Feito isso, basta clicar em "Generate" e aguardar enquanto as imagens são geradas.

Embora seja gratuito, há um limite de imagens que você pode gerar por dia, que é 40. Ou seja, a cada dia podemos gerar 40 imagens. Portanto, não gere imagens desnecessariamente, caso você precise ter acesso, no mesmo dia, à sua ferramenta.

Obtemos alguns resultados em 3D, mas podemos mudar para outro formato e verificar o que fica mais interessante.

Entre as pesquisas realizadas por mim, os resultados de uma específica me chamaram a atenção. Foram os resultados do prompt "A wallet icon with the symbol of a coin in center of the wallet", no formato _cartoon_.

Com este resultado, analisei todas as imagens e gostei bastante de uma formada por um personagem segurando uma moeda.

Quando encontramos a imagem desejada, podemos clicá-la e ela será ampliada para visualização. À direita desta visualização, teremos a opção "Edit image", que serve para editá-la. Ao clicar nesta opção, somos direcionados para outra janela, onde também é possível fazer algumas alterações.

Não entraremos em muitos detalhes sobre essa funcionalidade, a única coisa que faremos é utilizar o recurso "Remove BG", que está no menu lateral esquerdo de edição de imagem. Utilizando esse recurso, é possível remover o _background_ da imagem. Não quero esse fundo, pois não condiz com meu website, com minha _landing page_, quero apenas o personagem. Ao clicar nesta opção, a própria inteligência artificial identifica o que seria o fundo da imagem e o remove.

Feito isso, basta clicar em "Download", no canto superior direito, selecionar o formato PNG para baixar a imagem com o fundo transparente e clicar em "Download" novamente para finalmente baixá-la.

Se quiser trabalhar com mais imagens, volte no _Freepik_, crie mais imagens, busque o que achar mais interessante e vamos começar a criar nossa _landing page_. Porém, vamos fazer isso na próxima aula. Te espero lá!


-----------------------------------------------------------------------
# 07Para saber mais: editando com Freepik

O Freepik é um site de banco de imagens, onde você pode encontrar e baixar imagens para o seu projeto. A maioria das imagens possuem uso livre comercial, basta você dedicar a imagem à pessoa que disponibilizou ela, por exemplo com um texto abaixo dela ou no seu texto alternativo.

O interessante é que agora a ferramenta também possui uma área para imagens generativas, como vimos em vídeo dentro desta aula, e o que complementa ainda mais esta ferramenta é a possibilidade de uma edição básica no painel online de edição de imagens da própria ferramenta, para entender um pouco melhor como ela funciona, vamos ver abaixo sua interface e especificações.

![Alt - Imagem da interface da área de edição da ferramenta freepik, com dois menus na esquerda contendo a letra A e letra B em verde, uma parte central com uma imagem, contendo a letra C para indicar um bloco e o menu superior com a letra D para indicar outro bloco de ferramentas.](https://cdn3.gnarususercontent.com.br/3402-landing-page/Imagens/imagem_7.png)

**A -** O bloco da esquerda, é onde vemos os principais grupos de ferramentas para a edição, podemos separar em 6 categorias:

- Edit - A imagem de um lápis que indica o espaço onde podemos editar a imagem (imagem em tela).
- Text - Um texto que indica uma ferramenta para inserir textos nas imagens.
- Elements - Imagens de formas geométricas simples que indica a ferramenta para inserir imagens e ícones para se criar uma composição.
- Photos - Para inserção de fotos na composição.
- Upload - Para você inserir arquivos do seu computador e usar na composição.
- Tools - Para você vincular a ferramenta do freepik com outras ferramentas como dropbox ou google fotos e salvar direto nas nuvens suas edições.

**B -** O bloco B é onde fica a janela que mostra as configurações do que você está selecionando no bloco A. Se você estiver com o modo edição ativado, as propriedades da janela irão apresentar propriedades de edição da imagem. Se você selecionar a ferramenta de texto, a janela B vai alterar para mostrar tudo que é possível fazer com a ferramenta texto, e assim por diante.

![Alt - Imagem da interface da área de configurações apresentando informações da ferramenta de texto.](https://cdn3.gnarususercontent.com.br/3402-landing-page/Imagens/imagem_8.png)

**C -** Esta é a área para editar as imagens, o centro do programa onde você pode ver como está ficando sua composição.

**D -** Este é o menu geral, onde podemos fazer o download da imagem, criar um novo arquivo para editar e também trabalhar com as propriedades do seu perfil dentro do FREEPIK.

A janela que mais vamos utilizar é a de edição, que apresenta pra gente ferramentas super úteis como:

![Alt - Imagem da interface da área de configurações apresentando informações da ferramenta de edição de imagem.](https://cdn3.gnarususercontent.com.br/3402-landing-page/Imagens/imagem_9.png)

**Edit image (A)** - Área da ferramenta onde podemos aplicar edições rápidas como redimensionar o tamanho do espaço que a imagem se encontra (CROP), Substituir a imagem por outra (REPLACE), Remover o fundo da imagem (REMOVE BG) e Separar o fundo da parte da frente sem apagar nenhum dos dois (SEPARATE).

**FLIP E ROTATION** - Como o nome indica, são as ferramentas para você rotacionar ou inverter a imagem.

**PRESETS** - Uma área com pré-definições de edição e efeitos onde basta você clicar e automaticamente o freepik vai editar as configurações para editar contraste, cor, saturação da imagem.

**SETTINGS** - Uma área para você fazer suas próprias edições de cores na imagem de maneira manual, ali temos configurações de cor até de desfoque.

É uma ferramenta completa porém simples. Sua maior funcionalidade é para fazer edições rápidas e conseguir pegar apenas o que deseja da imagem gerada, como por exemplo no nosso caso, onde removi o fundo para pegar apenas o ícone do personagem.

Teste os efeitos, trabalhe invertendo ou aplicando melhores contrastes na imagem para ver a potência que esta ferramenta entrega.

Agora que temos nossas imagens, vamos colocar a mão na massa e montar nossa landing page!

-----------------------------------------------------------------------
# 08Artes e IA

Pensando na nossa proposta de construção de uma landing page. Das questões abaixo, qual seria a vantagem mais significativa em utilizar inteligência artificial para gerar imagens para o site?

Personalização de imagens e personalidade da Landing Page.

O uso de inteligência artificial permite que você tenha imagens únicas para a sua landing page que não existirá em outra, mesmo você não sendo uma pessoa ilustradora para desenvolver estes elementos gráficos, pegar imagens de banco de imagens torna a possibilidade de uso em outras ferramentas muito maior, removendo a unidade da sua landing page.

-----------------------------------------------------------------------

# 09Faça como eu fiz: pegando imagens

Usando o prompt e a ferramenta de edição do freepik, busque imagens únicas que fará parte do site, e também busque imagens definidas que converse com a ideia de landing page. Modifique sua paleta de cor para que tenha unidade com a identidade do tema da landing page.


-----------------------------------------------------------------------
# 10O que aprendemos?

## Nessa aula, você aprendeu como:

- Buscar imagens gratuitas para utilizar em ambiente online;
- Como usar o ADOBE FIREFLY para editar paletas de cores inteiras em imagens vetoriais, para que elas conversem com sua identidade visual;
- Como construir imagens usando IA para poder utilizá-las no design da Landing Page.


-----------------------------------------------------------------------
# 01Montando primeiro site com IA

## Transcrição

Temos a nossa estrutura, os blocos do Criamos ChatGPT, além das imagens que vamos utilizar na _Landing Page_. Agora, precisamos construir essa _Landing Page_. Para tal, existem várias ferramentas que nos auxiliam nessa construção. Provavelmente, você conhece algumas delas, como o _Wix_, um _framework_ no qual conseguimos blocar as partes do site e colocá-lo online, semelhante ao WordPress.

Há outra ferramenta muito interessante, chamada _Framer_. Esta ferramenta, antigamente, competia com o _Figma_, pois ambas são de prototipagem. Agora, o _Framer_ tem um escopo um pouco mais complexo. Isso porque ele não só consegue publicar o seu site, de forma similar ao _Wix_, como possui essa parte de blocagem, onde conseguimos manipular e trabalhar com os elementos dentro dela. Além disso, ela conta com o auxílio de inteligência artificial.

Dedicaremos nossa terceira aula a explorar essa ferramenta. Esta será a aula mais densa, então, se você não tem tanto costume de trabalhar com construção de sites e com ferramentas de prototipagem, preste bastante atenção. Faça notas, revise o vídeo para tirar suas dúvidas e confira a seção "Para Saber Mais" para facilitar o acompanhamento.

O _Framer_ vai além do uso de inteligência artificial, auxiliando na criação das imagens e na estrutura dos blocos. Portanto, entenderemos um pouco melhor sobre a ferramenta. Para iniciarmos, [acessamos o site do _Framer_](https://www.framer.com/).

No canto superior direito do site, temos a opção de nos cadastrarmos ou, caso já esteja logado, temos a opção "_Launch_". Até mesmo, é possível criar o site, na parte central da página, utilizando inteligência artificial. Basta clicar em "_Start with AI_", e vocês perceberão que é bem rápido.

Entretanto, clicaremos em "_Launch_" para abrirmos o _Framer_, porque queremos criar um novo projeto. No momento em que abrimos o _Framer_, acessamos uma página onde está escrito "_Get Started_" (Comece) na parte superior, seguida de três cartões de opções. Inclusive, a opção do centro permite obtermos _wireframe_ que criamos no _Figma_, se você tiver acessado o "Para Saber Mais", e trabalharmos a partir dele.

Outra opção, que é a do primeiro card, permite criarmos a página com a ajuda de inteligência artificial, podemos criar algo totalmente novo desde o início dentro do _Framer_. Isso é possível porque a criação do _wireframe_ não foi colocada como pré-requisito neste curso, pois pediremos para o _Framer_ fazer isso diretamente para nós.

Do lado esquerdo da página, temos uma coluna com a visão geral das nossas bibliotecas: o que estamos trabalhando, onde estão os _templates_, o que estamos desenvolvendo. Na parte central da página, abaixo das opções de "_Get Started_, estão os arquivos recentes.

No canto superior direito da seção com os arquivos recentes, há um botão azul escrito "_New_", onde clicaremos para começarmos a construir nossa página. Este novo projeto, que iniciamos ao clicar em "_New_", é nossa _Landing Page_. Precisamos entender melhor esta ferramenta mais robusta e compreender onde estão os elementos.

A _Framer_ é muito parecida com outras ferramentas de prototipagem. No centro, temos o que chamamos de _Artboard_, que é o espaço para construir e criar os elementos. À direita, temos uma janela vertical vazia, pois é onde estarão as propriedades do objeto. Acima, temos uma barra com alguns menus e, à esquerda, temos outra janela vertical com as opções para criarmos os elementos e ver como eles estão estruturados.

Começaremos clicando em "_Insert_", no canto esquerdo do menu superior. Em seguida, clicaremos em "AI", que fica na seção "_Start_" da janela da esquerda. Fazendo isso, podemos começar a construir coisas com inteligência artificial.

Ao clicarmos em "AI", o software já abre, no centro da tela, uma janela para escrevermos nosso prompt. No _Framer_, diferentemente do ChatGPT, temos que **trabalhar em inglês**. Nós criaremos um prompt para a construção do site e da _Landing Page_, que será a versão final e que será publicada.

O interessante desta Inteligência Artificial é que ela traz uma barra na parte inferior da janela do prompt, para evidenciar o quanto estamos descrevendo o site ou a landing. Vale ressaltar que esta ferramenta não constrói sites de um nível de complexidade muito alto. Ela não terá tanta diversidade quanto a imagens ou tanta variação quanto ao ChatGPT. Se você testar várias vezes, os sites criados serão relativamente semelhantes. Entretanto, ela auxilia bastante neste processo inicial de construção do site.

Vamos começar a construir o prompt. Quanto mais escrevemos, mais ela me auxilia na definição de estar bem descrito ou não. Lembrando que nós utilizamos no ChatGPT para entender nossos blocos, por isso é importante que você os tenha construído no início do curso. Assim, mesmo sem nossos blocos, podemos voltar o ChatGPT e refletir sobre como queremos que o _Framer_ crie isso. Por exemplo, a primeira página tem um banner, um texto e um CTA. Então escreveremos o prompt:

```plaintext
Create for me one landing page with four sections. The first section have one banner on right, and on left texts and a CTA
```

> **Tradução:**
> 
> Crie para mim uma landing page com quatro seções. A primeira seção tem um banner à direita e, à esquerda, textos e uma CTA

Com esta instrução, reparamos na barra inferior que está melhorando nossa descrição. Então pause o vídeo, retorne ao ChatGPT e analise como quer construir sua landing page.

Para agilizar um pouco o processo, vou copiar o texto que já elaborei e vou colá-lo dentro do meu prompt. Fiz isso tudo apenas para adiantar o processo e não ficarmos escrevendo durante a aula.

```plaintext
create an finance app landing page with 4 sections, first section with a banner containing image on the right and text on the left with CTA, the second section containing about the benefits of my app, the third section containing the users review of my app and the last section containing one subscribe form with lettering calling for it.

The landing page has a simple menu and footer too
```

Quando terminamos de escrever, ou colamos, o text, podemos clicar em "_start_" no canto superior direito da janela do prompt. Feito isso, esperaremos a "mágica" do que o _Framer_ vai fazer.

Ele constrói todos os blocos necessários, inclusive trazendo os formatos para desktop, tablet e smartphone. Assim, temos acesso aos três formatos de site, e conseguimos ter uma landing page completa.

É bastante interessante a maneira como o _Framer_ vai construindo, porque ele estrutura bastante coisa, para que consigamos reutilizar o que ele cria e ajustar como desejamos que o nosso site funcione. Entretanto, como eu havia mencionado, não é exatamente 100%. É uma ferramenta ainda em desenvolvimento, que construiu todos os blocos para nós.

Por isso, esta aula será densa. Pois agora precisamos entender como o _Framer_ trabalha, para editarmos aspectos de nosso interesse. Existem coisas que não funcionaram muito bem, mas temos a liberdade de modificar, alterar, reeditar, para fazer com que o site funcione da maneira desejada.

Então abra o _Framer_, faça um prompt, observe como funciona e se o site está bem estruturado. Caso não tenha ficado legal, crie um novo prompt, e assim começaremos a trabalhar de forma mais adequada. A partir do próximo vídeo, começaremos a editar esses elementos.

Agora que já temos o site pronto, criado por Inteligência Artificial, aprenderemos como utilizar essa ferramenta para colocar a imagem que eu queremos, ajustar alguns blocos e começar a deixá-lo com a aparência desejada para a landing page.

-----------------------------------------------------------------------




-----------------------------------------------------------------------




-----------------------------------------------------------------------




-----------------------------------------------------------------------




-----------------------------------------------------------------------




-----------------------------------------------------------------------




-----------------------------------------------------------------------




-----------------------------------------------------------------------




-----------------------------------------------------------------------




-----------------------------------------------------------------------







