---
type: "9"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
fonte_curso: https://cursos.alura.com.br/course/mysql-procedures
Url_video_curso: https://dev.mysql.com/doc/
MySql_funcions: https://dev.mysql.com/doc/refman/8.0/en/functions.html
w3schools: https://www.w3schools.com/sql/sql_ref_mysql.asp
---

Tópico:: #MySQL #DataBase

- Saiba implementar Stored Procedures
- Use o Cursors para buscar dados
- Controle o fluxo da sua procedure
- Trate os erros corretamente
- Aplique Stored Procedures a Triggers

## Aulas

- [](https://cursos.alura.com.br/course/mysql-procedures/section/8299/tasks)
    
    [Preparando ambiente](https://cursos.alura.com.br/course/mysql-procedures/section/8299/tasks) [Ver primeiro vídeo](https://cursos.alura.com.br/course/mysql-procedures/task/56701)
    
    0 / 7
    
    30min
    
    - Introdução
    - Preparando o ambiente: Instalando o MySQL
    - Preparando o ambiente: Linux e Mac
    - Recuperando a base de dados
    - Para saber mais: erro na importação
    - Consolidando o seu conhecimento
    - O que aprendemos?
- [
    
    Stored Procedures Básico
    
    0 / 10
    
    42min
    
    ](https://cursos.alura.com.br/course/mysql-procedures/section/8300/tasks)
    
    - Conceitos Básicos
    - Mudança de delimitador
    - Criando primeiras Stored Procedures
    - Estrutura para criação da Stored Procedure
    - Alterando e excluindo Stored Procedures
    - Comando para alterar uma Stored Procedure.
    - Declarando variáveis
    - Estrutura de comando para criação de uma Stored Procedure
    - Consolidando o seu conhecimento
    - O que aprendemos?
- [
    
    Interações com o banco de dados
    
    0 / 10
    
    34min
    
    ](https://cursos.alura.com.br/course/mysql-procedures/section/8301/tasks)
    
    - Manipulando banco de dados
    - Atualizando a idade
    - Parametros
    - Atualizando a comissão
    - Controle de erros
    - Comando para tratar erros
    - Atribuição de valor usando SELECT
    - Usando SELECT para atribuir valores
    - Consolidando o seu conhecimento
    - O que aprendemos?
- [
    
    Controle de Fluxo
    
    0 / 12
    
    48min
    
    ](https://cursos.alura.com.br/course/mysql-procedures/section/8302/tasks)
    
    - IF THEN ELSE
    - Testando o número de notas fiscais
    - IF THEN ELSEIF
    - Faturamento anual
    - CASE END CASE
    - CASE NOT FOUND
    - CASE Condicional
    - Faturamento anual usando CASE CONDICIONAL
    - Looping
    - Número de notas para diversos dias
    - Consolidando o seu conhecimento
    - O que aprendemos?
- [
    
    Cursor e Função
    
    0 / 11
    
    46min
    
    ](https://cursos.alura.com.br/course/mysql-procedures/section/8303/tasks)
    
    - Problema do Select Into
    - Limitação do SELECT INTO.
    - Definição de Cursor
    - Looping com Cursor
    - Achando o valor total do crédito.
    - Cursor acessando mais de um campo
    - Calculando o valor total do faturamento
    - Entendendo Função
    - Função para obter o número
    - Consolidando o seu conhecimento
    - O que aprendemos?
- [
    
    Problema prático
    
    0 / 12
    
    78min
    
    ](https://cursos.alura.com.br/course/mysql-procedures/section/8304/tasks)
    
    - Criando números aleatórios
    - Tabela com números aleatórios
    - Obtendo cliente aleatorio
    - Fazendo função para produto aleatório
    - Fazendo função para vendedor aleatório
    - Incluindo a venda
    - Resolvendo o problema de PK
    - Melhorando Triggers
    - Aplicando Stored Procedures a Triggers
    - Conclusão
    - Consolidando o seu conhecimento
    - O que aprendemos?
-----------------------------------------------------------------------
# 01Introdução

## Transcrição

[00:00] Tudo bem, gente? Meu nome é Victorino Vila e eu vou ministrar o curso de "PROCEDURES E FUNÇÕES MySQL". Como eu já falei em cursos anteriores, a linguagem "ANSI", que é a linguagem onde o "SQL" é baseado, não tem uma estrutura de fluxo. Então, a gente não consegue pelo "SQL" fazer coisas mais complexas.

[00:24] Mas os bancos de dados implementam o que nós chamamos de stored procedures ou funções onde nós podemos construir programas um pouco mais estruturados. É essa linguagem que a MySQL disponibiliza para criar coisas mais estruturadas, que nós veremos nesse treinamento. A gente vai começar então, o treinamento, recuperando o ambiente.

[00:45] Porque, claro, a gente vai levar em consideração que já existe um banco com dados e, que a gente vai usar esse banco como fonte para os nossos exercícios. Então, nós vamos começar recuperando esse ambiente e a gente vai falar um pouquinho sobre o conceito do stored procedures. Como ela se organiza, como é que a gente cria uma história em procedure básica.

[01:04] E aí, vamos começar a aprender coisas um pouco mais complexas como, por exemplo, entender o que é uma variável dentro da stored procedures. Como a gente cria essa variável, é o que nós vamos aprender. Depois, nós vamos aprender como é que eu passo parâmetros para a stored procedures, ou seja, ao chamar a stored procedures, eu posso passar parâmetros para que esses parâmetros sejam, digamos assim, valores iniciais para a execução da história de procedures.

[01:35] Depois, nós vamos ver um ponto muito importante - como é que a gente trata erros na stored procedures. Caso aconteça erro, em vez de eu querer que a stored procedures pare de ser executada, eu posso fazer um tratamento desse erro. A gente vai ver, também, variáveis dentro da stored procedure, como é que a gente declara essas variáveis e como a gente atribuir valores a elas quando essas variáveis têm que receber valores que vem de um comando select.

[02:03] Algum select específico de alguma tabela. Eu quero buscar a informação que tá lá e atribuir a uma variável. A gente vai aprender como é que faz isso. Depois, nós vamos passar a entender o que realmente vale à pena, na stored procedures - que é o controle de fluxo. Como é que eu um "IF". Como é que eu uso um "CASE". E até mesmo como a gente constrói "LOOPS" dentro da própria stored procedures.

[02:29] Aí finalmente, nós vamos falar sobre uma estrutura chamada "CURSOR". O "CURSOR" é quando a gente quer guardar dentro de uma variável, não o valor específico, mas sim uma série histórica de um resultado que tá vindo lá das minhas "QUERIES". Depois nós vamos ver como é que a gente trabalha com funções. Qual é a diferença básica realmente entre stored procedures e "FUNÇÕES".

[02:54] E, finalmente, nós vamos ver dois problemas práticos: um é como a gente cria uma venda dentro do nosso banco de forma aleatória. E depois a gente vai falar sobre um problema que foi visto em um curso anterior a esse, na criação de triggers, como é que a gente melhora isso usando stored procedures. Temos bastante assunto a tratar nesse treinamento e espero que vocês gostem. Um grande abraço. Então, vamos iniciar. Tchau, tchau.

-----------------------------------------------------------------------
# 02Preparando o ambiente: Instalando o MySQL

## Transcrição

[00:00] Então, vamos conversar? A primeira coisa que a gente precisa fazer é ter nosso ambiente para poder fazer os exercícios práticos desse treinamento. E a primeira coisa que a gente precisa ter é o MySQL instalado na nossa máquina. Se você está fazendo todos os treinamentos na ordem, e a máquina que você está usando agora é a mesma máquina que você usou no curso passado.

[00:24] Ou seja, você tem o MySQL instalado, o "MySQL WORKBENCH" também instalado. Então, você não precisa nem seguir mais esse vídeo. Esse vídeo é mais para que, se você tem seguido a carreira de MySQL, mas por algum motivo está usando um computador vazio, em branco. Um computador onde você não tenha mais o ambiente instalado. Então, você tem que reinstalar o seu MySQL.

[00:51] Ou então, caso você tenha começado esse treinamento direto sem ter passado pelos outros. Então, se você já tem um MySQL na sua máquina, pode dar "PAUSE" aí. Se você não tem, então vou fazer o seguinte, eu vou colocar agora um outro vídeo onde eu mostro a instalação do MySQL. Então vamos lá. Vamos começar. Vamos, então, fazer a instalação do MySQL.

[01:18] Eu posso fazer essa instalação tanto no ambiente Windows quanto no Linux. O caso aqui, devido ao equipamento que eu tenho à disposição para fazer esse treinamento, eu vou fazer a instalação nesse vídeo usando o sistema operacional Windows. E, também, nós vamos instalar o "IDE" chamado "WORKBENCH". O que é um "IDE"? É um programa que permite que a gente possa visualizar os objetos do banco de uma maneira mais gráfica.

[01:49] Quando a gente vai trabalhar com o MySQL, por exemplo, tudo pode ser feito por linha de comando. Mas um "IDE" fica interessante a gente está utilizando. Porque aí, a gente pode ter várias consultas na mesma tela, olhar as tabelas de maneira gráfica. E o "WORKBENCH" é um "IDE" próprio do MySQL, ou seja, é a MySQL que fornece o "WORKBENCH".

[02:15] E sim, existem vários outros "IDEs" para MySQL no mercado, mas a gente vai usar o do próprio MySQL. E também, o "WORKBENCH" pode ser instalado tanto em ambiente Windows, quanto ambiente Linux. No caso aqui, eu vou fazer a instalação no ambiente Windows. E, inclusive, o pacote de instalação já instala não somente o servidor MySQL, mas também o "IDE WORKBENCH".

[02:40] Então, vamos começar. Eu vou abrir aqui o browser. Eu vou procurar por "MySQL DOWNLOAD". Então, tem aqui o link "MySQL DOWNLOADS". E aqui, nesse link, eu vou procurar por essa opção aqui: "MySQL COMMUNITY EDITION GLP". Lembra? Eu tenho a versão gratuita e a versão paga. Nós vamos usar a versão gratuita. Então, eu vou clicar aqui no link "COMMUNITY (GLP) DOWNLOADS" e eu vou procurar a opção, essa daqui.

[03:23] No meu caso, eu vou estar usando a "MySQL ON WINDOWS (INSTALLER & TOOLS)". Eu tenho aqui vários links. Por exemplo, se eu quiser só instalar o "WORKBENCH", eu escolheria esse link aqui. Mas, eu vou selecionar aqui a opção "MySQL INSTALLER". E aqui em baixo, eu tenho as opções da instalação que eu quero fazer. Então, eu vou estar escolhendo essa aqui "MySQL INSTALLER WEB COMMUNITY 8.0.15.0".

[04:11] Não necessariamente a versão que você vai estar instalando é a mesma que está aqui no vídeo. Depende da época em que você esteja assistindo a esse treinamento. Porque as versões de MySQL ficam mudando com uma certa frequência. No caso, se você encontrar uma versão mais atual, não tem problema, instale a que ele estiver sugerindo como sendo a última versão.

[04:33] Vou clicar aqui em "DOWNLOAD". E aí, ele vai me pedir para fazer um login no site da Oracle. Lembra do que eu falei? A Oracle comprou a "SUN MICROSYSTEMS" e a "SUN" era dona do MySQL. Então, a Oracle passou a ser a dona do MySQL. Para a gente poder instalar, baixar qualquer produto Oracle, a gente precisa se logar usando uma conta da Oracle.

[05:04] Se você não tem conta da Oracle nenhum problema. Você vem aqui, clica em "SIGN UP", aqui do lado em verde, no botão verde e faça um cadastro. Você vai colocar o nome, um e-mail, uma senha e só isso. Não precisa colocar cartão de crédito, não precisa pagar nada. No caso, eu já tenho um login. Então, eu vou clicar no botão "LOGIN". Vou colocar aqui meu usuário. E vou colocar aqui a minha senha. Vou clicar em "INICIAR SESSÃO".

[05:43] E aí, vou clicar agora no botão "DOWNLOAD NOW". Bem, ele vai fazer o download de um arquivo pequeno. Porque depois de tudo que eu vou instalar, ele vai fazer o download da internet no momento da instalação. Vou clicar, então, no programa aqui: "MySQL INSTALLER". Aí ele vai dizer uma opção opcional, se eu quero já checar se existem updates para serem feitos.

[06:21] Para que a gente possa fazer a instalação agora, não somente da versão que eu escolhi, mas também dos updates mais atuais. Eu vou clicar "YES". Nenhum problema de fazer as instalações desses upgrades. Ele está fazendo aqui o download do instalador com os upgrades. Pronto, comecei a instalação. Vou aceitar os termos da licença. Aqui, eu vou escolher a opção "DEVELOPER DEFAULT", porque aí eu vou instalar o servidor e uma série de conectores, tudo que é preciso para o MySQL estar funcionando.

[07:15] Clicar em "next". Aqui, eu quero fazer um conector com o "PYTHON", mas o caso não é o meu objetivo. Eu vou dar "next". Clico aqui, "YES". E aí eu tenho aqui tudo que ele vai baixar. Note que aqui no meio, eu já tenho a instalação do "WORKBENCH", ou seja, não vou precisar depois ter que instalar o "WORKBENCH" de forma separada. Eu vou clicar aqui "EXECUTE", e ele vai começar a fazer o download dos módulos que vão ser usados para a instalação.

[07:56] Então, eu vou fazer o seguinte. Vou parar o vídeo um instantinho aqui. E aí quando esse download terminar, eu volto para a gente continuar a instalação. Acabou a instalação, o download aqui dos componentes. Vou continuar a instalação. Clica em "next" novamente. Aí, eu tenho aqui dois tipos de estrutura de bancos de dados que eu vou estar trabalhando.

[08:19] Eu vou estar usando essa primeira aqui "STANDALONE MySQL SERVER / CLASSIC MySQL REPLICATION". Tem aqui as configurações de porta, forma de comunicação entre o cliente e o servidor. A gente vai manter o que está aqui. Aqui é a forma como eu vou usar a minha autenticação. Têm dois tipos: uma em que a senha é criptografada, que vale para o "MySQL 8.0", que é a versão atual.

[08:54] E uma que usa a segurança dos MySQL mais antigos. Eu vou manter a primeira opção selecionada. Aqui, eu vou colocar a minha senha. Vou estar colocando aqui. Ele não gostou muito da minha senha, diz que ela está fraca, mas não tem problema. Vou clicar aqui em "next". Eu não vou aqui, deixa eu voltar aqui um instante. Eu não vou criar outros usuários por enquanto, porque eu vou estar usando esse mesmo usuário que é o usuário que a gente chama de "ROOT".

[09:39] O quê que é o usuário root? É o usuário padrão do banco MySQL, e a gente vai usar esse usuário para acessar o banco e estar utilizando os nossos exercícios práticos. O que eu fiz aqui foi definir a senha desse usuário "ROOT". Não se esqueça dessa senha. "next" Aqui é o nome do serviço, porque o MySQL vai ser um serviço do Windows que vai ser sempre ser inicializado quando a máquina, por exemplo, for dar um "BOOT", alguma coisa.

[10:15] Sempre quando a máquina voltar, o banco vai estar no ar também. E aí embaixo a gente seleciona aqui. Qual é o usuário que vai gerenciar esse serviço? Aqui nós não vamos mudar nada. Tem aqui tudo que ele vai executar durante a instalação. Eu clico "Execute". E aí ele vai começar a fazer a instalação, inicializar o banco de dados, inicializar o servidor e assim por diante.

[10:45] Então eu vou parar o tempo aqui. Vou parar o vídeo um instantinho, e volto assim que todos os passos tiverem... Eu achei que ia demorar. Acabou rápido. Então, eu vou manter. Não vou nem parar o vídeo não. Vamos lá. Vou clicar em "FINISH". Vou dar aqui depois do Nexus. E agora vai fazer algumas outras configurações, por enquanto eu não vou não tá fazendo nada, clique em finish next novamente pelos aqui a conexão com o servidor eu vou colocar aqui a minha senha.

[11:27] Posso até clicar em "CHECK" para saber se a conexão é feita. A conexão entre o cliente e o servidor foi feita com sucesso. E vou executar essa segunda parte da instalação. Agora sim, eu vou parar o vídeo. Eu não sei quanto tempo vai demorar. Olha só, me pegou de novo. Eu achei que ia demorar. Foi rápido. Vou clicar aqui em "FINISH". Ele vai fazer novas configurações.

[12:02] E aqui, ao dar esse último "FINISH", ele já vai me inicializar o "WORKBENCH", que é aquela interface de "IDE" para a gente manipular o banco de dados MySQL. Vou clicar aqui em "FINISH". Essa tela que ele abriu aqui, a gente pode ignorar. E note, automaticamente ele já me criou aqui uma conexão. Essa aqui é a conexão local da minha máquina.

[12:33] Ou seja, a minha máquina tem o servidor, mas tem um cliente também. E o update já vem com essa conexão previamente configurada. Se eu clicar aqui nesse quadradinho, ele vai perguntar a senha do meus usuário "ROOT". Vou colocar aqui. Vou salvar a senha para não precisar ter que colocar a senha toda hora. E aí pronto. Eu entrei e eu tenho aqui já o meu "WORKBENCH" já configurado.

[13:12] Ele mostrou aqui uns códigos que, talvez, vocês não vão ver esse código aqui. Mas é porque essa minha máquina já tinha, antes de gravar esse treinamento, o MySQL instalado e tinha, na memória, alguns scripts de "SQL" já salvos. O que você vai ter, caso você tenha feito todos os passos de maneira correta, é essa tela aqui do "MySQL WORKBENCH". Tudo bem? Então, pronto. Já estamos preparados para começar o nosso tratamento de SQL.

-----------------------------------------------------------------------
# 03Preparando o ambiente: Linux e Mac

Se você estiver utilizando o sistema operacional Linux ou Mac, temos um excelente artigo que explica de forma detalhada o processo de instalação do MySQL. Recomendamos que você siga os passos descritos neste artigo antes de continuar com o curso:

- [MySQL: da instalação até a configuração](https://www.alura.com.br/artigos/mysql-instalacao-configuracao)

Caso surjam dúvidas durante o processo de instalação, não hesite em procurar assistência no fórum ou no Discord da Alura. Estamos aqui para ajudar você a ter uma experiência de aprendizado tranquila e produtiva.

Desejamos a você ótimos estudos e sucesso em sua jornada de aprendizado!

-----------------------------------------------------------------------
# 04Recuperando a base de dados

https://cursos.alura.com.br/course/mysql-procedures/task/56703

## Transcrição

> _O arquivo **RecuperacaoAmbiente.zip** pode ser baixado [aqui](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/01/RecuperacaoAmbiente.zip)._

[00:00] Ok. A gente, agora, vai ter que recuperar uma base que nós vamos usar como exemplo para esse treinamento. Se você já vem fazendo os cursos da carreira de MySQL na sequência e está com o ambiente que você usou nos treinamentos anteriores; essa base de dados que nós vamos usar como exemplo, ela já existe. Se você teve que instalar o MySQL agora, então faz o seguinte: continue assistindo a esse vídeo.

[00:24] E aí, eu vou mostrar agora aqui um outro vídeo onde a gente faz a recuperação desse ambiente. Então, não saia daí. Nesse momento todo mundo deve estar com o MySQL e o "MySQL WORKBENCH" instalados na máquina. Vamos agora recuperar a base. Eu vou executar o "MySQL WORKBENCH". E aí, vou acessar essa base aqui. Essa base não, essa conexão que foi configurada quando a gente instalou o nosso MySQL.

[01:00] Vou clicar. E claro, aqui eu não tenho nenhum banco à disposição. Se você está usando o MySQL do curso de introdução ao "SQL" com o MySQL, você deve estar olhando aqui, também, a base que nós usamos nesse treinamento anterior. Mas não importa, nós vamos criar uma base nova. E para criar essa base nova, eu clico com o botão direito do mouse sobre essa área.

[01:29] Clico em "CREATE ESQUEMA". E vou criar aqui uma base chamada "SUCOS_VENDAS". É esse o nome da base de dados que nós vamos trabalhar nesse treinamento. Vou clicar em "APPLY". "APPLY". "FINISH". Temos, então, aqui a nossa base "SUCO_VENDAS" criada, porém vazia. Sem tabela e sem nenhum dado. Mas vamos recuperar isso através de um link, que nós temos associado aqui a esse treinamento.

[02:07] Clique nele. Baixe. Você vai ver um arquivo zip com esse nome aqui: "RECUPERAÇÃOAMBIENTE.ZIP". Descompacte ele. Você deve ver uma lista de arquivos como mostrado aqui em cima. Mas a nossa mais importante (pasta) é esse subdiretório aqui: "DUMPSUCOSVENDAS". Eu vou voltar aqui ao "WORKBENCH". Eu vou clicar nesse link aqui primeiro.

[02:39] Na aba "ADMINISTRAÇÃO" e depois eu vou clicar em "DATA IMPORT/RESTORE". Cliquei e eu tenho aqui a minha caixa de diálogo, onde eu vou restaurar um arquivo que foi anteriormente feito o backup. No caso, é aquele diretório que eu especifiquei para vocês, o diretório "DUMPSUCOSVENDAS", que possui a base de dados que nós vamos recuperar.

[03:12] E aqui, nessa caixa de diálogo, eu vou selecionar aquele subdiretório. Então, eu vou clicar aqui. No meu caso, ele está aqui. Selecionei o diretório, que foi o diretório que veio, que apareceu na descompactação do arquivo, e eu tenho ele aqui. Já posso recuperar. Só que tem um probleminha aqui. Note que a resolução que eu estou usando aqui na máquina, ela é muito baixa.

[03:59] Justamente para gravar os vídeos e ficar umas letras um pouco maiores, para que vocês possam assistir ao vídeo de madeira mais clara. Só que eu não consigo aqui, não tem um scroll, eu não consigo clicar no botão de inicializar recuperação. Então, eu vou fazer uma coisa aqui. Eu vou mudar o meu computador, a configuração para 1600X1024, por exemplo.

[04:34] Deixa eu mudar aqui, eu vou colocar 1400X900. E aí, eu agora consigo visualizar esse botão aqui que é o botão "START IMPORT". Vou clicar nele. E aí a recuperação da base, ela começa a ser executada. Pronto. Terminei a recuperação. Deixa eu voltar de novo a minha resolução para a resolução original. Então, eu volto aqui para o "WORKBENCH". Então, a minha importação funcionou.

[05:28] Só para a gente ter certeza, eu vou clicar nessa pasta "query 1". Se você não tiver essa pasta, você clica aqui nesse botão. E aí, eu vou selecionar aqui uma consulta "SELECT*FROM". Vamos pegar aqui, por exemplo, a tabela de itens, notas fiscais, que é a tabela maior. Claro, eu tenho que selecionar o banco dando duplo clique sobre o banco "SUCOS_VENDAS" para ficar em negrito.

[06:07] Tudo isso eu ainda vou explicar melhor quando a gente começar a fazer as consultas. Talvez eu precise, também, explicar um pouquinho para vocês como é que a gente trabalha "WORKBENCH". Eu aqui só estou testando para saber se a minha recuperação da base funcionou. Aqui têm informações, então essa recuperação funcionou. Então, nesse momento, eu já estou pronto para iniciar o treinamento.

[06:35] Essa parte do vídeo é apenas caso você não tenha conseguido recuperar a sua base de dados através do diretório "DUMP", da recuperação deste diretório aqui. Por algum motivo, você não conseguiu. Deu erro. Então, faça o seguinte: eu vou mostrar uma segunda maneira de recuperar a base. Ela é um pouquinho mais trabalhosa, mas também tem mais probabilidade de funcionar.

[07:06] Eu vou então aqui, apagar a base "SUCOS_VENDAS". Atenção! Só faça isso se o primeiro método não funcionou. Se o primeiro método funcionou, você pode até parar de assistir o vídeo nesse ponto. Então, eu vou clicar aqui "DROP SCHEMA". Então, não tem mais a minha base. E eu vou criar ela novamente. Clico em "CREATE ESQUEMA". Selecionei o nome "SUCOS_VENDAS". Dou o "APPLY" e dou o "FINISH".

[07:50] Duplo clique sobre ela. Tenho a base de novo aqui criada, mas vazia. Aí, eu vou fazer o seguinte: eu vou clicar em "FILE", "RUN SQL SCRIPT". Vou escolher essa opção aqui. Eu tenho todos esses arquivos aqui com extensão ".SQL", que eu vou usar para importar a base de uma outra maneira. Eu vou começar com esse aqui. Primeiro arquivo: "CRIAÇÃO_ESQUEMA.SQL".

[08:26] Eu vou clicar nele. Vou clicar em abrir. Eu vou ver um script de recuperação e eu vou escolher aqui a base "SUCOS_VENDAS. E vou escolher aqui em "DEFAULT CHARACTER SET", que é essa opção "UTF8" que está aqui embaixo. Eu dou o "RUN" e ele vai terminar. Vou agora de novo e vou fazer para esse arquivo aqui "CARGA_TABELAS_CADASTRAIS.SQL".

[09:07] Seleciono a base. Seleciono "UTF8" e "RUN". Nesse momento, eu consegui recuperar as tabelas e os dados cadastrais. Agora, eu vou recuperar os dados referentes às notas fiscais. Clico de novo scripts em "RUN SQL SCRIPT" e vou escolher agora esse arquivo aqui "CARGA_NOTAS_01.SQL". Seleciono e dou "RUN". Esse script vai demorar um pouquinho mais, porque eu agora estou carregando dados com o volume substancial de linhas.

[10:05] Então, vou fazer o seguinte, eu vou parar o vídeo e no instante quando essa barra terminar eu volto. Se eu tiver essa mensagem aqui é porque tudo correu bem. Vou agora, recuperar, só que agora é o arquivo 2: "CARGA_NOTA_02". Seleciono aqui a base. O "UTF8" e "RUN". Bem, ele está processando o arquivo 2. Vocês vão fazer para o arquivo "CARGA_NOTAS_02" e depois para o "CARGA_NOTAS_03".

[10:51] E aí, toda parte do cabeçalho da nota fiscal vai estar importada no banco. Então, eu vou parar aqui o vídeo e eu vou voltar quando eu terminar o "CARGA_NOTAS_03". Vocês façam esses passos e me encontrem daqui à pouco. Pronto. Nesse momento, eu importei os arquivos: "CARGA_NOTAS" 01, 02 e 03. Eu, agora, vou importar o "CARGA_ITENS_NOTAS" de 01 à 07.

[11:29] Então, eu vou começar aqui com o 01. Seleciono a "SUCOS_VENDAS". Seleciono aqui o "UTF8" e dou o "RUN". Então, eu vou começar a importar o "CARGA_ITENS_NOTAS_01". Então, façam isso. O 01, o 02, 03 até o 07. E aí, quando vocês terminarem o último arquivo, a base vai estar recuperada. Pronto. Importei aqui o "CARGA_ITENS_NOTAS_07". Então, nesse momento, eu também tenho a minha base recuperada.

[12:15] Então, eu mostrei para vocês, nesse vídeo, duas maneiras de recuperar a base. Vocês devem tentar a primeira. Se não funcionar, tentem a segunda. Agora, estamos preparados para continuar o nosso treinamento.

-----------------------------------------------------------------------
# 05Para saber mais: erro na importação

O erro que é apresentado é decorrente a importação dos arquivos que contém caracteres codificados em um conjunto de caracteres (charmap) que não é suportado pelo MySQL.

Para solucionar o problema tente realizar uma nova tentativa de importação dos dados. Para isso, siga os passos abaixo:

- Baixe e extraia o arquivo [RecuperacaoAmbiente.zip](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/01/RecuperacaoAmbiente.zip):

![Gif que simula a extração de arquivos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/rgIQcrL.gif)

- Exclua o schema `suco_vendas`, essa etapa evitará possíveis interferências em configurações antigas:

![Gif do workbench. Nela o usuário clica com o botão direito em suco_vendas em seguida, seleciona a opção Drop Schema. Em seguida a opçao Drop Now](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/4QCVyiE.gif)

- Agora iremos criar o Schema suco_vendas. Para isso, na aba Schemas, com o botão direito do mouse, clique em **Create Schema**:

![Na aba Schema, ao clicar com o botão direito do mouse, seleciona a opção create schema.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/Yl64JUg.gif)

- Em seguida, nomeie o schema sucos_vendas. E clique em **Apply** para as seguintes etapas.

![Gif que simula a criação do Schema](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/mFvvlHj.gif)

- Para a importação de cada arquivos. Selecione a opção **Open SQL Script**, selecione o arquivo correspondente e **execute**.

![Gif SQL Workbench. Ao selecionear em file é escolhido o arquivo em seguida é executado o script](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/zsGlj35.gif).

Você fará essa ação para os demais arquivos, Cargas_Itens_Notas e Carga_Tabelas_Cadastrais.


-----------------------------------------------------------------------
# 06Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Se você está usando uma máquina limpa, você deve instalar o MYSQL. Por isso siga as instruções abaixo.

- Acesse o seu Browser e busque por MySQL Downloads. Acesse o link [http://www.mysql.com/downloads](http://www.mysql.com/downloads)
    
- Procure pelo link MySQL Community Edition (GPL) / Community (GPL) downloads.
    
- Vá para MySQL on Windows (Installer & Tools) / Downloads.
    
- Clique em MySQL Installer.
    
- Clique no botão de download ao lado da opção Windows (x86-32 Bits), MSI Installer (mysql-installer-web-community-8.0.15.0.msi).
    
- Faça um login no site da Oracle. Se você não possuir um login faça um cadastro.
    
- Após o Login clique em Download Now.
    
- Execute o programa que foi baixado.
    
- Clique em I Accept the license terms e depois em Next.
    
- Escolha a instalação Developer Default. Clique em Next duas vezes.
    
- Clique em Execute para o download e instalação do banco e seus componentes.
    
- Clique em Next duas vezes.
    
- Mantenha a escolha StandAlone MySQL Server / Classic MySQL Replication.
    
- Mantenha as propriedades padrões do serviço e da porta de comunicação. Clique Next.
    
- Mantenha a opção Use Strong Encryption for Authentication .... Clique em Next.
    
- Inclua a senha do usuário root duas vezes. Clique em Next.
    
- Mantenha as proprieades padrões. Clique em Next.
    
- Clique Execute para iniciar a instalação.
    
- Sempre selecione Next e Finish na medida que outras caixas de diálogo forem sendo exibidas. Se houver a pergunta sobre a senha do usuário root digite a senha configurada anteriormente na instalação.
    
- Automaticamente o Workbench será aberto. Clique na conexão que está configurada. Você então acessará o ambiente com o MySQL no ar.
    

> Instalação no Ubuntu
> 
> - Comando para verificar se o Mysql está instalado
>     
>     ```undefined
>     dpkg -l mysql-server
>     mysql -V
>     ```
>     
> - Comando para remover o Mysql
>     
>     ```csharp
>     sudo apt-get remove --purge mysql*
>     sudo apt-get purge mysql*
>     sudo apt-get autoremove
>     sudo apt-get autoclean
>     ```
>     
> - Comando para instalar o Mysql
>     
>     ```csharp
>     sudo apt-get install mysql-server
>     sudo apt-get install mysql-workbench
>     ```
>     
> - Configurando o Mysql `` ` `` sudo mysql_secure_installation Se você quiser fazer login como root através de programas externos: sudo mysql -u root ALTER USER 'root'@'localhost' IDENTIFIED WITH

1) Se você está usando uma máquina limpa, você deve recuperar a base de dados a ser usada neste curso. Por isso siga as instruções abaixo:

- Abra o MYSQL Workbench. Use a conexão LOCALHOST.
    
- Botão da direita do mouse sobre a lista das bases e escolha Create Schema.
    
- Insira o nome Sucos_Vendas. Clique em Apply duas vezes.
    
- Faça Download do arquivo RecuperacaoAmbiente.zip.
    
- Descompacte o arquivo.
    
- Selecione, na área Navigator, em Administration.
    
- Selecione o link Data Import/Restore.
    
- Na opção Import From Dump Project Folder escolha o diretório DumpSucosVendas.
    
- Selecione Start Import.
    
- Verifique na base Sucos_Vendas se as tabelas foram criadas.


-----------------------------------------------------------------------
# 07O que aprendemos?

Nesta aula, aprendemos:

- A instalar o MySQL
- A recuperar da base de dados a ser usada neste treinamento


-----------------------------------------------------------------------
# 01Conceitos Básicos

https://cursos.alura.com.br/course/mysql-procedures/task/56704

## Transcrição

[00:00] Quem já viu os outros cursos de "SQL" com MySQL, viu que a linguagem "SQL", ela não é uma linguagem estruturada. Ela não possui, por exemplo, comando de repetição, "IF" "THE", "ELSE". Geralmente, é uma sequência de comandos, onde eu posso colocar "SELECTS", "INSERTS", "UPDATES", "DELETES", "CREATE", "DROP, e assim por diante." Isso é uma fraqueza da linguagem "SQL".

[00:32] Então, o quê que os fabricantes de bancos de dados fizeram? Eles associaram, aos seus bancos de dados, uma linguagem estruturada. Onde, nessa linguagem estruturada, você pode usar comandos "SECOS", mas tem as suas regras básicas que valem para cada banco. E aí, essa linguagem estruturada interna, essa sim não segue um padrão "ANSI", como toda linguagem "SQL".

[01:03] Foi uma forma de a gente poder compensar essa fraqueza, que existe na linguagem "SQL", colocando comandos de repetição, comandos de decisão, "FOR", "WHILE", "IF" dentro da linguagem "SQL". Logo, a linguagem estruturada de cada banco de dados tem a sua própria regra. Você vai fazer a linguagem estruturada do MySQL, que vai ser diferente do "SQL SERVER", que vai ser diferente do Oracle e assim por diante.

[01:37] O que é padronizado é linguagem "SQL", mas a linguagem de stored procedure, onde você vai construir os seus programas, essa sim é um pouco diferente. Um profissional tem que se especializar em cada banco. Então, claro, a primeira coisa que eu tenho que aprender é a criar um programa, criar uma stored procedure dentro do meu banco de dados. E o comando para fazer isso tá mencionado aqui em cima.

[02:07] Eu tirei, claro, uma imagem do manual do MySQL, onde a gente tem todas as possibilidades para a criação de uma stored procedure. Mas, o mais importante é a gente aprender esse tipo de regra. Basicamente, o comando é "CREATE PROCEDURE", o nome da procedure e, entre parênteses, nós podemos colocar os parâmetros. E aí, nós temos um "BEGIN" e "END".

[02:38] Depois do "BEGIN", um "DECLARE", que é um comando que faz uma declaração de variáveis. E aí, temos as nossas linhas de comando. Vamos então, agora lá no "SQL", "MySQL WORKBENCH" e fazer a criação de uma stored procedure. Então, eu estou aqui no "WORKBENCH". Temos aqui o nosso banco de dados "SUCOS_VENDAS" e, aqui embaixo, nós temos uma opção stored procedures.

[03:09] É ali que eu vou fazer a criação dos meus programas. Então, vamos lá. Eu vou clicar com o botão direito do mouse. Eu tenho aqui a opção "CLIENT START PROCEDURES". E eu tenho essa caixa de diálogo aqui, onde eu tenho o comando "CREATE PROCEDURE", o nome da procedure que eu vou criar, "BEGIN" e "END". Então, eu vou colocar aqui, onde está "CREATE PROCEDURE", vou escrever "NÃO_FAZ_NADA".

[03:44] É o nome da nossa procedure. "NÃO_FAZ_NADA". Essa procedure não vai fazer nada, na verdade. Eu só vou criar ela sem comando nenhum. Só estou mostrando para vocês como a gente cria uma stored procedures. Eu vou clicar aqui em "APPLY". E aí eu tenho, na verdade, este comando aqui completo. Vamos aproveitar e falar um pouquinho sobre o que eu estou vendo aqui.

[04:09] Na primeira linha, eu forço a conexão com a base "SUCOS_VENDAS". Afinal, eu estou criando a stored procedure na base de dados "SUCOS_VENDAS". Depois, eu tenho um comando que diz o seguinte: se a procedure já existir, você apaga ela. Porque se eu estou rodando esse comando, eu vou executar a criação da stored procedure novamente.

[04:36] A cláusula "IF EXISTS", ela é muito legal porque é o seguinte: se for a primeira vez que eu estiver criando a stored procedure, esse comando não vai dar erro. Eu só vou "DROPAR" a procedure se ela existir. Uma coisa muito importante, é esse comando aqui "DELIMITER". A gente viu até agora que, quando a gente tem vários comandos "SECO" dentro do MySQL, a gente utiliza como separador de linha o ponto e vírgula.

[05:10] Se eu coloco vários "INSERTS", vários "SELECTS", etc. é o ponto e vírgula. Quando eu estou criando uma procedure, aqui dentro entre o "BEGIN" e o "END", eu vou ter uma série de linhas. E essas linhas internas, entre o "BEGIN" e o "END", eles vão estar separados com ponto e vírgula. Só que, quando eu rodar esses comandos todos, o quê vai acontecer?

[05:38] Ele vai confundir o ponto e vírgula do comando de criação da procedure, com o ponto e vírgula que vai estar aqui dentro das linhas da procedure. Então, quando eu digo: esse comando delimita, eu estou dizendo o seguinte. Daqui para baixo, o delimitador passa a ser "$$" (dólar, dólar). Toda a separação de linha, daqui para baixo, eu vou usar o "$$".


-----------------------------------------------------------------------

# 03Criando primeiras Stored Procedures

https://cursos.alura.com.br/course/mysql-procedures/task/56705

## Transcrição

[00:00] Vamos continuar? Falando um pouquinho do nome da stored procedure. Uma stored procedure deve ter apenas letras ou números. A gente pode usar o caracter "$" (dólar) e também o "_" (underscore) para separar, de repente, dois nomes, nomes compostos que, às vezes, a stored procedure pode ter. Em vez de usar o espaço vazio, a gente usa o "UNDERSCORE".

[00:24] O tamanho máximo do nome da stored procedure não pode passar de 64 caracteres. Esse nome deve ser único, ou seja, não posso ter mais de uma stored procedure dentro do mesmo banco com o mesmo nome. E a "CASE SENSITIVE", ou seja, do jeito que eu criar a stored procedure, do jeito que eu escrever no momento da criação é o jeito que eu tenho que me referenciar a ela quando eu usá-la durante as minhas consultas.

[00:52] Vamos fazer alguns exemplos bem simples de stored procedure. Então, eu vou vir aqui. Botão direito do mouse. "CREATE STORED PROCEDURES". Vou criar uma stored procedures, vou chamar aqui, por exemplo, de "HELLO WORLD" - alô mundo. Vamos escrever em português. "ALO_MUNDO". Aqui dentro do comando vou colocar "SELECT "AlO_MUNDO".

[01:22] Coloca o ponto e vírgula aqui para diferenciar o fim dessa linha. Então, eu tenho aqui uma stored procedure muito simples que faz um select. Dou o "APPLY". Tenho lá a minha estrutura básica de criação da stored procedure. Dou "APPLY" de novo e dou "FINISH". Então, eu tenho aqui a minha stored procedure chamada "ALO_MUNDO". Como é que eu uso ela?

[02:00] Eu venho aqui na minha estrutura, coloco "CALL ALO_MUNDO". Ou seja, eu estou chamando stored procedure. E aqui que esse "SENSITIVE" funciona. Do jeito que eu escrevi aqui, eu devo referenciar ela aqui. Então, se eu rodar isso daqui tenho pronto o meu resultado. Vamos mostrar mais alguma coisa. Eu posso, por exemplo, mostrar valores em vez de mostrar textos.

[02:39] Então, se eu vier aqui, por exemplo, criar uma nova stored procedure. Por exemplo: "MOSTRA_NÚMERO". Aí eu faço isso daqui "SELECT (1 + 9) - 5". Coloquei aqui uma expressão numérica qualquer. "(1 + 9) - 5". Dou "APPLY". Dou "APPLY" de novo. Dou "FINISH". Então, tem lá "MOSTRA_NÚMERO". Se eu vier aqui "CALL MOSTRA_NÚMERO ;", só vou executar esse comando. E tem lá o meu resultado que é o resultado da expressão.

[03:32] Agora, note que, tanto aqui em cima quanto aqui embaixo, a coluna da tabela ficou a pressão porque eu não botei um "ALIAS" lá no meu select. Eu posso colocar um apelido para a minha coluna. E a gente usa "ALIAS", normalmente, quando a gente lida com expressões. Então, eu posso vir aqui. Vou criar uma outra stored procedure. "MOSTRA_NÚMERO_ALIAS".

[04:02] Então, eu vou colocar aqui "SELECT (1 + 9) - 5 AS RESULTADO". Eu agora coloquei aqui o meu select com um "ALIAS". "APPLY". "APPLY" de novo. "FINISH". Se eu agora colocar um "CALL MOSTRA_NÚMERO_ALIAS", eu vou ver aquele mesmo resultado só que, claro, o nome da coluna já está um pouco mais, digamos assim, amigável. E aí, eu posso também concatenar coisas.

[04:52] Então, eu posso escrever assim... Usar funções, por exemplo, dentro da stored procedures. Então, eu vou colocar aqui "SP_ COM_FUNÇÕES". Então, olha lá, eu posso colocar aqui "SELECT CONCAT", quem não se lembra "CONCAT", ele concatena textos. Então, eu vou botar aqui "ALO_MUNDO", concatenado, por exemplo, com alguns pontinhos, concatenado com (1 + 9 - 5) "AS ITENS_COMBINADOS".

[05:45] Então, eu coloquei aqui um comando de select um pouquinho mais rebuscado. Vou dar um "APPLY". Vou dar um "APPLY" de novo. "FINISH". Então, se eu agora colocar aqui "CALL SP_COM_FUNÇÕES" e executar, tenho lá o meu resultado combinado aqui."ALO MUNDO", vários pontinhos e o cinco. Uma outra coisa interessante é a de colocar comentários na minha stored procedure.

[06:35] Então, eu vou vir aqui. Vamos criar uma outra. "SP_COM_COMENTÁRIOS". O comentário na stored procedure eu posso fazer da seguinte maneira: ou eu coloco isso daqui barra asterisco. "VAMOS EXIBIR ITENS COMBINADOS". Aí, o que eu escrever embaixo fica valendo o comentário. "ENTRE TEXTOS E NÚMEROS". E aí, para fechar o comentário, asterisco, barra. Está aqui a barra de volta.

[07:21] Se eu quiser colocar o comentário em uma única linha, eu boto "- -". Aí, eu posso escrever também usando a função "CONCAT". E aí, eu posso colocar aqui "SELECT CONCAT ALO MUNDO" concatenado com alguns pontinhos, concatenado com a expressão (1 + 9 - 5) "AS ITENS COMBINADOS". Ponto e vírgula. Aqui é um comentário mais complexo, maior. E aqui é o comentário de uma linha.

[08:18] Posso fazer isso dentro do "BEGIN" e "END" da stored procedure. "APPLY". "APPLY" de novo. "FINISH". Quando eu executar essa nova stored procedure. Vou colocar aqui "CALL SP_COM_COMENTÁRIOS". Se eu rodar, claro que os comentários não vão fazer diferença nenhuma. Eu vou ter o meu resultado aqui, normalmente, mas eu tenho o comentário dentro do programa, da stored procedure porque eu posso ter uma stored procedure bem complexa e depois outra pessoa vir fazer a manutenção.

[09:03] Ele tem comentário para que a pessoa possa ver a minha explicação do código. Fiz alguns exemplos bem simples de stored procedures para vocês entenderem.

-----------------------------------------------------------------------
# 05Alterando e excluindo Stored Procedures

https://cursos.alura.com.br/course/mysql-procedures/task/56706

## Transcrição

[00:00] A gente pode alterar ou até mesmo excluir uma stored procedure. Para a gente não perder aquilo que a gente fez, vamos fazer o seguinte. Eu vou criar aqui uma outra stored procedure. Vou chamar aqui de "ALO_MUNDO_2". E eu vou escrever aqui "SELECT ALO_MUNDO" AS RESULTADO". Vou dar o "APPLY". "APPLY" de novo e "FINISH".

[00:44] Então, tenho aqui o aluno um do dois, mas eu posso clicar sobre ele com o botão direito do mouse. Eu tenho aqui a opção "ALTER STORED PROCEDURE". Se eu clicar aqui , eu tenho a minha caixa de diálogo aqui "ALO_MUNDO". Por exemplo, "TUDO BEM?" Eu alterei, coloquei alguma coisa diferente. E aí, eu vou dar o "APPLY" e, note. Ele tem aqui aquele comando que, na verdade, ele vai dropar a stored procedure que existe e vai criar novamente.

[01:23] Esse "CREATE DEFINER" aqui está especificando, na criação da stored procedure, que quem vai estar criando essa nova rotina vai ser o usuário "ROOT". Mas isso não vai fazer nenhuma diferença aqui para a gente dentro do nosso ambiente. Antes de dar "APPLY", só um instante. Copiem esse texto aqui. Eu vou entrar aqui no notepad. Eu vou colar esse texto aqui.

[01:59] Vou deixar esse texto aqui salvo. Vamos voltar aqui para o nosso "WORKBENCH". Vou dar "APPLY", "FINISH". Então, agora se eu... Vamos voltar aqui para o nosso script. Se eu vier aqui e executar o "CALL ALO_MUNDO_2", eu vou ter aqui o meu resultado "ALO_MUNDO_TUDO BEM". Antes, de continuar alterando, eu poderia fazer a criação ou alteração da stored procedure direto por linha de comando. Basta eu rodar isso daqui.

[02:49] Não preciso colocar esse "DEFINE" aqui. Então, se eu quiser criar uma stored procedure "ALO_MUNDO_3", eu venho aqui. Faço isso "3". "3" de novo. "ALO_MUNDO TUDO BEM?" versão 3. E executo direto, no meu MySQL, esse grupo de comandos. Se eu executar aqui, ele foi executado com sucesso. Aqui, claro, tem que dar um "REFRESH" para olhar a rotina "ALO_MUNDO_3" criado.

[03:26] E apagar? Eu posso apagar uma stored procedure. Basta eu clicar sobre ela com o botão direito do mouse. Eu tenho a opção "DROP STORED PROCEDURE". O que, na verdade, vai acontecer é só rodar esse comando aqui. Sem rodar nenhum comando de cliente depois. Então, botão direito do mouse. Se eu selecionar aqui, ele vai me dar essa caixa de diálogo. Eu digo sim. Pode apagar e a rotina é apagada.

[03:59] Eu posso também, vou copiar esses dois comandos. Eu posso fazer um outro script que faz isso daqui: "DROP PROCEDURE IF EXISTS ALO_MUNDO_2". Se eu rodar isso daqui, rodei com sucesso. Note que a stored procedure já foi apagada. Então, assim, eu estou usando o "WORKBENCH" porque ele já me constrói o código, mais ou menos, para criar, alterar ou excluir a stored procedure.

[04:31] Mas, eu não precisava usar a caixa de diálogo. Basta eu digitar os comandos conforme o "WORKBENCH" me mostra. Se eu tiver usando uma linha de comando direto do MySQL que não tenha uma interface gráfica, só linha de comandos, basta eu fazer isso. Então, quer dizer que a caixa de diálogo do "WORKBENCH" ela só facilita o nosso trabalho, mas o que ela faz, na verdade, é escrever os comandos e executar os comandos no MySQL.


-----------------------------------------------------------------------
# 07Declarando variáveis

https://cursos.alura.com.br/course/mysql-procedures/task/56707

## Transcrição

[00:01] Qualquer estrutura de programação tem a variável. A variável é que permite a gente criar o dinamismo do nosso programa. E, é claro, stored procedures em MySQL possui variáveis. As variáveis, elas são declaradas através do comando "DECLARE", o nome da variável, um "DATATYPE", que é um tipo. "DEFAULT" e um valor padrão. Esse "DEFAULT", na verdade, é um valor inicial da variável.

[00:33] O "DATATYPE", ele é obrigatório ter. Toda variável tem que ter um tipo, mas ela, não necessariamente, precisa ter um valor "DEFAULT". O nome da variável deve ser apenas letras, números, o dólar, por exemplo, o underscore, se eu quiser. Esse nome de variável que eu criar, ela sempre tem que ser única dentro da stored procedure e, da mesma maneira que eu disse a respeito do nome da stored procedure, o nome da variável deve ser "CASE SENSITIVE".

[01:09] Toda vez que eu me referenciar à variável, eu tenho que respeitar como eu criei, como eu a criei, respeitando o nome dela. Se eu coloquei o nome maiúsculo, tem que ser maiúsculo. Se eu coloquei o nome minúsculo, tem que ser minúsculo. O tamanho máximo do nome da variável é 255 caracteres. Não tem muito sentido eu criar uma variável com 255 caracteres. Mas é a limitação que o MySQL apresenta.

[01:37] Se eu não tiver um valor "DEFAULT" para a variável, o valor dela será nulo até eu me referenciar a essa variável dentro do meu programa. E dentro de um "DECLARE", eu devo terminar ele com ponto e vírgula. Uma observação que tem aqui, que não tem aqui na apresentação, mas que é importante mencionar, é que dentro do "DECLARE", eu posso declarar várias variáveis, mas desde que com o mesmo tipo.

[02:10] Alguns tipos que nós podemos usar "varchar" ou "CHAR", entre parenteses e o número de caracteres essa variável vai poder ter, não no nome, mas no conteúdo. "INTEGER" é a variável do tipo inteiro. "DECIMAL", eu declaro uma variável que seria um número decimal ou, então, eu coloco como parâmetros um número de dígitos do número e, depois, o segundo parâmetro o número de casas decimais. Aqui representados pelo p e pelo s.

[02:50] "DATE", é uma variável do tipo data. Apenas a data. E quando ela for um "TIMESTAMP", ela representa data e hora. Vamos lá, então, no "MySQL WORKBENCH" e fazer alguns exemplos. Então, ok. Estou aqui no "WORKBENCH". Vamos, então, criar aqui uma stored procedures nova e eu vou chamar essa stored procedures de "EXIBE_VARIÁVEL".

[03:29] Então, eu vou primeiro declarar a minha variável. "DECLARE". Por exemplo, "TEXTO" vai ser o nome da variável. "CHAR (12)". Vai ser uma variável do tipo texto, tamanho máximo de 12 caracteres. "DEFAULT". E eu vou colocar aqui, entre parênteses, o "ALO_MUNDO". Ponto e vírgula porque eu acabei a linha de "DECLARE". E aqui embaixo, eu vou colocar um "SELECT TEXTO" e o ponto e vírgula.

[04:10] Então, vamos lá. Vamos rever. "DECLARE". Nome da variável. O tipo. "DEFAULT". E o valor "DEFAULT". E aqui eu faço uma referência à variável. Sendo que a gente tem que usar a mesma caixa alta ou caixa baixa. Eu escrevi texto tudo em minúsculo, então a referência da variável tem, também, que ser texto em minúsculo. "APPLY". "APPLY". "FINISH". Vou criar aqui um script novo e aqui eu vou escrever o "CALL EXIBE_VARIÁVEL".

[04:58] "DATA TOO LONG FOR COLUMN TEXTO AT ROLE ONE." Vamos olhar aqui onde foi o meu erro. Se eu der um "ALTER PROCEDURE". Vamos lá, 1 2 3 4 5 6 7 8 9 10 11 12. Note que até aqui, eu tive 12 caracteres e o texto, eu inicializei com 14. Eu falei que era 12, então, a inicialização foi maior do que o tamanho do texto. Então, vamos aumentar esse cara aqui para 20, por exemplo.

[05:42] Eu vou dar um "APPLY". "APPLY". "FINISH". Alterei a minha rotina. Agora, vamos lá. Eu vou rodar ela. Agora ela funcionou. Tenho aqui o meu resultado. Vamos fazer mais alguns outros exemplos. Vou criar outra rotina que eu vou chamar de "TIPOS_DE_DADOS". Então, note. Eu posso ter vários "DECLARES" dentro da própria stored procedures.

[06:24] Por exemplo: "DECLARE V varchar (5) DEFAULT TEXTO." "DECLARE I INTEGER DEFAULT (10). Então, declarei uma variável V do tipo texto, uma variável I do tipo inteiro, por exemplo. "DECLARE D DECIMAL (4,2) DEFAULT (56.12)". "DECLARE DT DATE DEFAULT 20190301. Então, note, aqui eu fiz várias declarações usando tipos diferentes. E aí, eu posso colocar um "SELECT V", "SELECT I", "SELECT D", "SELECT DT".

[08:03] Tá bom? Para poder exibir o resultado das quatro variáveis. Dou um "APPLY". "Dou um "APPLY" de novo. "FINISH". Se eu voltar aqui e rodar um "CALL TIPOS_DE_DADOS". Rodar só esta stored procedure, note que eu tenho aqui quatro resultados. Porque eu tive quatro selects. Então, no primeiro, eu tenho "TEXTO", no segundo eu tenho o inteiro, no terceiro tem o número decimal e o quarto, eu tenho a minha data.

[08:46] Vamos ver uma coisinha a respeito da criação de stored procedures e do uso de variáveis. Vou criar uma outra aqui que eu vou botar aqui, por exemplo, "DATA_HORA_LOCAL". Eu quero exibir, por exemplo, a data do computador. Eu posso dar um "DECLARE TS DATETIME DEFAULT", por exemplo, eu posso usar aqui uma função que chama-se "LOCALTIMESTAMP".

[09:28] E eu posso dar um "SELECT TS". Note que por "DEFAULT", eu usei uma função interna do MySQL para inicializar minha variável "TS" que era do tipo "DATETIME". Vou dar aqui um "APPLY". "APPLY" de novo. "FINISH". E aí, voltando aqui à minha rotina. Se eu colocar aqui um "CALL DATA_HORA_LOCAL". Vou exibir. Houve aqui um erro. Vamos olhar onde é que eu errei.

[10:23] "DATA_HORA_LOCAL". Declarei a variável como "LOCALTIMESTAMP" e dei um select. Ah, eu errei o nome aqui. Botei hota, é hora. Eu estou deixando no vídeo, esses erros, justamente para mostrar a vocês que a gente, às vezes, também comete erros. Quando a gente trabalha. Então, não vou nem editar esses problemas. Mas é legal, também... Agora foi. Olha lá. Tem aqui a hora do computador e a data.

[11:01] Mas é legal, também, a gente ter esses erros, para mostrar a vocês que quando a gente um comete um erro, o próprio MySQL te dá uma pista do que está errado. E aí, a gente consegue evoluir e, talvez, consertar. Coisa importante: a variável, ela deve sempre ser declarada. Vamos criar aqui mais uma outra stored procedure. Vou colocar assim "SEM_DECLARAÇÃO". E aí, aqui, eu vou fazer isso aqui: "SELECT TEXTO".

[11:39] Note que eu estou usando uma variável chamada "TEXTO", mas eu não declarei ela. É claro que, quando eu executar essa nova stored procedure, ele vai me reclamar. "SEM_DECLARAÇÃO". Ele vai reclamar porque, olha lá. A coluna texto não existe. Como eu não declarei texto, ele achou que texto fosse o nome da coluna de uma tabela. Eu fiz um select, o nome da variável. Apenas o MySQL interpretou como um problema.

[12:24] Eu falei que, dentro de um "DECLARE", eu posso ter várias variáveis do mesmo tipo. Vamos criar um exemplo para isso. Então, eu vou colocar aqui "MESMO_TIPO_DADOS". O nome da stored procedure. Então, vamos lá. Eu posso botar um "DECLARE DATA_1 DATA_2 DATE DEFAULT 20140913". E aí, eu vou dar um "SELECT DATA_1 DATA_2". Ponto e vírgula aqui. Ponto e vírgula aqui.

[13:28] Então, olha lá. Eu declarei duas datas, coloquei o "DEFAULT" e vou exibir. Pergunta: 13 de setembro de 2014 vai ser "DEFAULT" para a "DATA_2", apenas, ou para a "DATA_2" e "DATA_1"? Se a resposta desse select vier as mesmas datas, nas duas colunas, é que, apesar de ter colocado o "DATE DEFAULT" lá no final, ele valeu para todas as variáveis da linha. Vamos ver o que vai acontecer? Para a gente tirar essa conclusão.

[14:12] Vou dar aqui o "APPLY". "APPLY" de novo. Vamos rodar agora. Está aqui nosso script. "CALL", onde está nossa procedure aqui? O nome dela foi? Avancei demais. "MESMO_TIPO_DADOS". Então, vamos lá. "MESMO_TIPO_DADOS". Então, vamos lá. Se a gente ver o mesmo valor para as duas colunas, é porque o "DECLARE valeu para as duas variáveis na mesma linha.

[15:00] Se a gente ver só na segunda, eu teria que ter colocado "DECLARE" antes. Vamos ver. O valor ficou igual. Isso significa o seguinte. Quando a gente declara duas ou mais variáveis na mesma linha, o que a gente coloca depois como "TIPO" e como "DEFAULT" vale para todo mundo da linha. Então, assim. Se eu tenho duas ou mais variáveis que vão ter "DEFAULT"s diferentes, mesmo sendo do mesmo tipo, eu devo usar duas linhas de "DECLARE" diferentes.

[15:44] Porque se eu colocar o "DEFAULT" para uma, vai valer para a outra. Se elas não tiverem "DEFAULT", eu posso colocar todas as declarações na mesma linha, não importa. A gente pode, também, durante a procedure dar valores diferentes às variáveis diferentes daquelas que foram inicializadas no "DEFAULT". Vamos fazer aqui mais uma stored procedure que é "ATRIBUI_VALOR".

[16:20] Então, olha só. Eu vou dar um "DECLARE". Vou chamar a variável aqui de "TEXTO". Vai ser um "varchar (30), por exemplo. "DEFAULT TEXTO_INICIAL". E aí, eu vou dar aqui um "SELECT TEXTO". Depois, na linha debaixo, eu vou escrever isso daqui "SET TEXTO = TEXTO MODIFICADO". E aí, depois eu vou dar um outro "SELECT TEXTO". Então, vamos lá. Declarei a variável "TEXTO" como "DEFAULT_TEXTO_INICIAL". Aí, eu mostro o conteúdo dela na saída.

[17:26] Depois eu digo: olha, essa variável "TEXTO" vai receber um outro valor "TEXTO MODIFICADO". E aí, eu apresento o resultado de novo. Vamos ver o que vai acontecer. "APPLY. "APPLY" de novo. "FINISH". Vamos procurar lá o nosso script. Ele está aqui. Eu, agora, vou colocar "CALL", agora esse eu não vou esquecer o nome: "ATRIBUI_VALOR". Vamos lá. Então, está lá. Inicialmente, o valor de texto era "TEXTO INICIAL".

[18:07] Depois ficou "TEXTO MODIFICADO". Então, era um pouco isso que eu queria mostrar para vocês sobre declaração de variáveis. Como é que a gente pode.... Quais são as regras que eu tenho que usar na hora de declarar. O que eu posso mudar depois do valor da variável dentro do programa. Enfim, fiz um apanhado superficial. A gente ainda vai ver muita coisa sobre variável no decorrer do curso. Mas, como apresentação, eu acho que esse vídeo ficou legal.


-----------------------------------------------------------------------
# 08Estrutura de comando para criação de uma Stored Procedure

Crie 4 variáveis com as características abaixo:

```makefile
Nome: Cliente. 
Tipo: Caracteres com 10 posições. 
Valor: João
```

```makefile
Nome: Idade. 
Tipo: Inteiro. 
Valor: 10
```

```makefile
Nome: DataNascimento. 
Tipo: Data. 
Valor: 10/01/2007
```

```makefile
Nome: Custo. 
Tipo: Número com casas decimais. 
Valor: 10,23
```

Construa um script declarando estas variáveis, atribuindo valores a elas e exibindo na saída do MYSQL.(Dê o nome da procedure de sp_Exerc01).


-----------------------------------------------------------------------
# 09Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Abra o MYSQL Workbench e crie um novo script de comandos sql.

2) Vamos iniciar criando algumas Stored Procedures. Clique com o botão da direita do mouse sobre Stored Procedure, abaixo do banco sucos_vendas.

![0.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/02/0.png)

1) Digite, após o comando `CREATE PROCEDURE`, entre as aspas, o nome da Stored Procedure (alo_mundo).

2) Entre o BEGIN END digite:

```csharp
select 'Alô Mundo !!!!';
```

1) Clique em Apply. Iremos ver o comando abaixo:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `alo_mundo`;
DELIMITER $$
USE `sucos_vendas`$$
CREATE PROCEDURE `alo_mundo` ()
BEGIN
select 'Alô Mundo !!!!';
END$$
DELIMITER ;
```

1) Os comandos acima representam os comandos MYSQL para a criação da Stored Procedure. Se executarmos estes comandos direto no script MYSQL a SP (Stored Procedure) será criada.

2) Clique em Apply e depois Finish.

3) Podemos ver, abaixo do nó Stored Procedure, a mesma criada.

![1.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/02/1.png)

1) No Script digite e execute:

```sql
Call alo_mundo;
```

1) Temos o resultado:

![2.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/02/2.png)

1) Digite, no script SQL:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `mostra_numero`;
DELIMITER $$
USE `sucos_vendas`$$
CREATE PROCEDURE `mostra_numero` ()
BEGIN
select (1 + 9) - 5;
END$$
DELIMITER ;
```

Observação: Diferente um pouco dos vídeos onde as SPs foram criadas pelo assistente, aqui, no passo a passo, iremos apresentar o código MYSQL para cria a SP.

1) No Script digite e execute:

```sql
Call mostra_numero;
```

![3.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/02/3.png)

1) Vimos, aqui, uma SP que retorna uma expressão numérica.

2) Digite e execute:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `mostra_numero_alias`;
DELIMITER $$
USE `sucos_vendas`$$
CREATE PROCEDURE `mostra_numero_alias` ()
BEGIN
select (1 + 9) - 5 as RESULTADO;
END$$
DELIMITER ;
```

1) No Script digite e execute:

```sql
Call mostra_numero_alias;
```

![4.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/02/4.png)

Você pode ver que o resultado da SP trouxe o nome da coluna como um Alias.

1) Digite e execute:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `sp_com_funcoes`;
DELIMITER $$
USE `sucos_vendas`$$
CREATE PROCEDURE `sp_com_funcoes` ()
BEGIN
SELECT CONCAT('Alô Mundo !!!!', '.....', (1 + 9) - 5) as ITENS_COMBINADOS;
END$$
DELIMITER ;
```

1) No Script digite e execute:

```sql
Call sp_com_funcoes;
```

![5.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/02/5.png)

Vimos como podemos usar funções MYSQL dentro das SPs.

1) Digite e execute:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `sp_com_funcoes`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `sp_com_funcoes` ()
BEGIN
SELECT CONCAT('Alô Mundo !!!!', '.....', (1 + 9) - 5) as ITENS_COMBINADOS;
END$$
DELIMITER ;
```

1) No Script digite e execute:

```sql
Call sp_com_funcoes;
```

![6.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/02/6.png)

Vimos como podemos usar funções MYSQL dentro das SPs.

1) Digite e execute:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `sp_com_comentarios`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `sp_com_comentarios` ()
BEGIN

/* Vamos exibir itens combinados
entre textos e números */

-- Usando a função CONCAT

SELECT CONCAT('Alô Mundo !!!!', '.....', (1 + 9) - 5) as ITENS_COMBINADOS;
END$$
DELIMITER ;
```

1) No Script digite e execute:

```sql
Call sp_com_comentarios;
```

![7.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/02/7.png)

No exemplo acima vimos como usamos comentários dentro do código da SP.

1) Digite e execute:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `alo_mundo_2`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `alo_mundo_2` ()
BEGIN
SELECT 'Alô Mundo !!!!, tudo bem?' as RESULTADO;
END$$
DELIMITER ;
```

1) Vamos alterar uma SP existente. Para isso digite o comando abaixo:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `alo_mundo_3`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `alo_mundo_3`()
BEGIN
SELECT 'Alô Mundo !!!!, tudo bem? Versão 3' as RESULTADO;
END$$
DELIMITER ;
```

Note que o comando apaga a SP através de um DROP e a cria novamente com o novo código. É desta maneira que podemos alterar um SP já existente.

1) Como já mencionado no comando de alteração de uma SP, se quer apenas apagá-la, digite.

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `alo_mundo_2`;
```

1) Podemos usar variáveis para atribuir valores e usar as mesmas nos comandos da SP. Digite e execute o comando abaixo:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `exibe_variavel`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `exibe_variavel` ()
BEGIN
declare texto char(20) default 'Alô Mundo !!!!';
SELECT texto;
END$$
DELIMITER ;
```

Nesta SP declaramos uma variável (texto), atribuímos um valor inicial padrão e exibimos na saída.

1) Digite e execute:

```r
call exibe_variavel;
```

![8.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/02/8.png)


-----------------------------------------------------------------------
# 10O que aprendemos?

Nesta aula, aprendemos:

- A criar uma Stored Procedure (SP) que retorna um texto;
- Como a SP retorna um valor em sua saída;
- A usar funções do MYSQL e comentários na SP;
- Como alterar uma SP já existente;
- Como excluir uma SP.


-----------------------------------------------------------------------
# 01Manipulando banco de dados

## Transcrição

[00:00] Claro que o objetivo de a gente usar uma stored procedures é fazer uma manipulação no banco de dados. Então, vamos pegar agora aqui um pequeno exemplo onde a gente vai manipular a tabela de produtos aqui do nosso banco de dados "SUCO_VENDAS". A gente vai incluir alguns produtos, modificar eles e depois apagá-los.

[00:21] Primeiro, eu vou fazer esses comandos sem usar a stored procedures. Antes, baixe [aqui](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/03/Comandos.sql) o arquivo chamado "COMANDO.SQL". Eu vou abrir aqui ele com o editor de texto. E a gente tem aqui um insert onde eu insiro vários produtos do tipo Sabor da Serra. Depois, eu dou um update modificando o preço de lista dele que, originalmente, é 7.5 para 8.

[00:55] Depois, eu apago seus produtos. E a cada passo, eu faço um select aqui para poder ver o "STATUS" da tabela. Então, eu vou copiar esses comandos todos. Vou vir para o "WORKBENCH". E vou criar um script novo e vou colar eles aqui. Então, vamos lá. Eu, primeiro, vou rodar esse insert grandão aqui. Inserir dos registros. Se eu agora rodar o select, eu vejo aqui os doze registros incluídos.

[01:30] Depois, eu vou fazer o update modificando o preço de lista de 7.5 para 8. Modifiquei. Posso rodar o select de novo. Note que o preço de lista está 8 agora para todos os produtos do tipo Sabor da Serra. Depois, eu vou apagar esses produtos novamente. E se eu der um select para vê-los, eu não tenho mais nada. Apaguei da minha tabela. é apenas um exercício que não tem muita prática.

[02:04] Eu insiro alguns produtos, modifico e depois apago. mas é só como uma ilustração para a gente ver como é que a gente pode usar isso dentro do stored procedures. Então, eu vou copiar esses comandos e vou deixar na memória do meu clipboard. Vou vir aqui em stored procedures. "CREATE STORED PROCEDURES". E vou criar uma procedure chamada "MANIPULAÇÃO_DADOS".

[02:30] E, simplesmente, entre o "BEGIN" e o "END", eu vou colocar aqueles comandos todos. Vou dar um insert, vou dar o select, o update, o select, o delete, e o select novamente. Dou o "APPLY". Tem lá o código da stored procedures final. Dou, de novo, o "APPLY" e o "FINISH". Tenho, então, aqui a minha stored procedures criada "MANIPULAÇÃO_DADOS".

[03:04] Volto aqui para o meu script principal que eu executei as coisas e, aqui embaixo, eu vou dar um "CALL MANIPULAÇÃO_DADOS". Então, ao chamar essa stored procedures, eu vou executar todos aqueles comandos de uma vez só. Note que eu rodei e ele, na verdade, quando ele faz oinsert, o update ou o delete, ele não tem uma saída, ele não me mostra nada na saída.

[03:36] O que a stored procedures vai me mostrar são os select. E eu tenho três selects lá. Após o insert, após o update e após o delete. Então, o primeiro insert está aqui. Ele me listou todos os produtos do tipo Sabor da Serra que foram incluídos. O segundo select muda o preço de lista que era 7,50 para 8. E o último select apaga a lista.

[04:07] A gente pode fazer a coisa de uma maneira um pouco mais, assim, um pouco mais prática. Quer ver? Olha o que eu vou fazer. Deixa eu pegar esse insert aqui incial. Copia essas duas linhas aqui. Então, eu vou colocar aqui uma "CREATE STORED PROCEDURE" e eu vou colocar uma stored procedure tipo assim: "INCLUI_NOVO_PRODUTO".

[04:44] E aí, eu vou colocar aqui o meu insert. Eu vou fazer assim para ficar mais organizado o insert. E eu vou colocar, claro, ponto e vírgula. Só que eu vou fazer o seguinte, eu vou dar um "DECLARE". Por exemplo, "VCÓDIGO varchar (50) DEFAULT 3000001". Eu vou copiar esse código. Vou colocar aqui "VNOME".

[05:13] E eu vou colocar aqui um "SABOR_DO_MAR". Por exemplo, "700 ML MANGA". "DECLARE VSABOR varchar(50) DEFAULT MANGA. Então, eu estou inicializando as variáveis e colocando valor para elas. Então, vamos lá. Eu vou criar uma outra variável chamada "TAMANHO" e eu vou colocar aqui o "700 ML". A outra variável vai ser "EMBALAGEM". Vou colocar aqui "GARRAFA".

[06:53] E a última variável que é o preço, eu vou escrever assim "PRECO", vai ser um "DECIMAL", eu não sei. Vou colocar aqui dez de dois. "DEFAULT", eu vou colocar um preço aqui: 9.25. E aí, dentro do insert, ao invés de usar "VALUES" aqui, eu vou usar "VCÓDIGO", aqui eu vou colocar o "VNOME". Depois, eu vou colocar aqui o... Qual é o terceiro? "VSABOR". Depois, eu coloco aqui o "VTAMANHO".

[07:49] "VEMBALAGEM" e, finalmente, aqui no final, o "VPRECO". Vamos dar um enter aqui. Então, ficou assim. Declaro as variáveis, inicializo os valores delas e dou um insert. Aqui dentro do insert, notem que eu estou usando, diretamente, as variáveis. O nome vai ser "INCLUIR_NOVO_PRODUTO". Eu vou dar um "APPLY". "APPLY". "FINISH". Vamos voltar para cá.

[08:25] Aquele nosso produto, se eu der aqui um "SELECT* FROM TABELA_DE_PRODUTOS WHERE SABOR_DO_MAR". Se eu executar esse select, note que não veio nada. Porque eu ainda não inclui nenhum produto com o nome "SABOR_DO_MAR". Deixa eu botar aqui o m maiúsculo para ficar coerente com o select que eu estou usando lá para testar.

[08:59] Eu, agora, então, vou colocar aqui "CALL INCLUI_NOVO_PRODUTO". Vamos executar. Executou. Agora, se eu rodar o select, note que agora apareceu o novo produto. Ou seja, eu incluí o produto chamando uma stored procedure chamada "INCLUIR_NOVO_PRODUTO". E lá dentro tem as declarações. Claro que essa stored procedure, ela não é muito útil porque eu estou dentro da stored procedure editando o que eu quero inserir.

[09:47] Se eu quiser inserir um novo produto, eu vou ter que alterar essa stored procedure, modificar na mão os valores que serão incluídos, salvar e aí, depois, rodar novamente. Mas aí, vamos por partes. A gente está aprendendo aos pouquinhos o uso do stored procedures. Então, por enquanto, eu quis fazer esses dois exemplos que, talvez não sejam muito práticos, mas apenas para a gente sentir como é que é a manipulação de banco de dados através de stored procedures.


-----------------------------------------------------------------------
# 02Atualizando a idade

Crie uma Stored procedure que atualize a idade dos clientes. Lembrando que o comando para calcular a idade, na tabela Tabela_de_Clientes é:

```scss
TIMESTAMPDIFF(YEAR, c.data_de_nascimento, CURDATE()) as idade 
```

Nome da Stored Procedure: Calcula_Idade.

-----------------------------------------------------------------------
# 03Parametros

## Transcrição

[00:00] Lembra quando a gente mostrou a vocês a estrutura do comando do stored procedures?. Existia uma coisa aqui chamada "PARAMETROS", que, por enquanto, a gente não mexeu. Com os parâmetros, a gente pode melhorar aquela última stored procedures que inseria um produto novo, fazia uma inserção de um produto novo dentro de uma tabela de produtos.

[00:26] Ao invés de eu declarar as variáveis e ir lá dentro colocar o que eu quero inserir, eu vou colocar como parâmetro o valor que vai ser inserido dentro da tabela de produtos. Então, olha só. Vamos voltar aqui para o "WORKBENCH" e vamos fazer o seguinte. A gente tem aqui a... Se a gente olhar aqui, eu tenho aqui "INCLUIR NOVO PRODUTO". Eu vou clicar com o botão da direita do mouse sobre ela.

[00:59] Vou dar um "ALTER_STORED_PROCEDURES". Eu tenho ela aqui só para a gente não perder o conteúdo da stored procedures, eu vou copiar desde o "DECLARE" que está aqui até o final. Não vou copiar o "END". Eu vou dar um "COPY". Vou jogar no Notepad aqui o conteúdo desse comando e vou deixar aqui salvo. Eu, agora, vou criar uma stored procedures chamada "INCLUI_NOVO_PRODUTO_PARAMETRO".

[01:43] E aqui, eu vou colar aqueles comandos. Só que notem: ao invés de eu ter as variáveis, que vão fazer parte do insert no "DECLARE", eu vou colocar aqui dentro do parênteses. Eu vou colocar isso daqui. Cole somente o nome e o seu tipo. Então, vou colocar aqui código "varchar (50)" vírgula. Nome "varchar (50)" vírgula. Sabor também 50, vírgula. Tamanho também 50. Vou dar um "Enter" aqui.

[02:41] Embalagem. E o preço vai ser decimal 10 de 2. E aí, claro, esses comandos de "DECLARE" eu vou apagar. Então, ficou assim. "INCLUI_NOVO_PRODUTO_PAR METRO". Aqui, todos os parâmetros sendo declarados, todas as variáveis que eu vou usar no insert declaradas como parâmetros. E depois aqui, o insert com um "VALUES" aqui, as variáveis.

[03:20] Vou dar um "APPLY". "APPLY" de novo. E "FINISH". Agora, eu vou criar aqui um script novo. Vamos fazer o seguinte. Eu vou pegar um insert desse aqui qualquer, onde está o meu script novo. Está aqui. Eu vou jogar aqui só para ter um guia. Então, olha lá. Eu vou chamar a rotina "CALL INCLUI_NOVO_PRODUTO_PAR METRO". Abre parênteses. Aí, eu tenho que colocar, agora, o valor das variáveis.

[04:13] Então, digamos que primeiro eu vou colocar aqui o valor do código "4000001". Depois, eu coloco o nome. "SABOR_DO_PANTANAL" é o nome do produto. Um litro. Vou botar aqui "SABOR_MELANCIA" que é o nome do produto. Vírgula. Depois, eu coloco o sabor. "MELANCIA". Depois, eu coloco como parâmetro o tamanho. 1 litro. O próximo parâmetro que eu tenho que colocar é a embalagem.

[05:07] "PET". E depois, finalmente, o preço de lista. "4.67". Então, um, dois, três, quatro, cinco, seis. Um, dois, três, quatro, cinco. Isso aí mesmo. Então, na verdade, aqui eu vou apagar agora, eu tenho isso daqui. Note que a minha stored procedure, eu estou passando como parâmetro tudo que tem que ser incluído dentro da tabela de produto, mas eu não estou rodando nenhum comando insert.

[05:40] Eu não preciso saber nem o nome dos campos da tabela. Eu sei que eu tenho que passar essa lista. Antes de rodar esse cara aqui, vamos fazer um teste. Se eu der aqui um `SELECT*FROM TABELA_DE_PRODUTOS WHERE CÓDIGO_DO_PRODUTO = 4000001`. Vamos ver aqui a tabela. Se eu rodar esse comando select, ele não me traz nada. Aí, eu agora vou rodar essa procedure. Rodei.

[06:29] Se eu, agora, rodar o select, note que agora eu tenho o produto incluído. Então, veja que eu fiz uma rotina para incluir dados dentro da tabela de produtos, e o comando até ficou muito mais simples. Eu chamo a rotina e só passo os valores. Eu não preciso saber como é que usa o comando insert, eu não preciso saber o nome das colunas. Eu não preciso me referenciar à tabela.

[06:59] Eu tenho uma rotina que chamada incluir um novo produto parâmetro. Só isso. Claro que você não vai fazer uma stored procedure para rodar apenas um comando. Mas, pode ser que eu tenha que executar coisas que vão fazer várias "INSERT UPDATES" e sequenciais que apresentam uma transação, negócio. Digamos que ao efetuar uma compra, você tem que dar um insert de um "contas a receber".

[07:36] Ao mesmo tempo, dar uma entrada de "estoque". Então, digamos que um tipo de informação vai gerar, vai disparar no seu banco de dados diversas manipulações e tabelas diferentes. Aí, você cria a sua stored procedure para fazer isso, passa o parâmetro que tem que ser passado. E, dentro da stored procedures, tem a regra de negócio. Esse foi um exemplo simples de passagem de parâmetro para a stored procedures que faz a manipulação de dados.


-----------------------------------------------------------------------
# 04Atualizando a comissão

Crie uma Stored procedure para reajustar o % de comissão dos vendedores. Inclua como parâmetro da SP o %, expresso em valor (Ex: 0,90).

Nome da Stored Procedure: Reajuste_Comissao.

-----------------------------------------------------------------------
# 05Controle de erros
https://cursos.alura.com.br/course/mysql-procedures/task/56710

## Transcrição

[00:00] No último vídeo, a gente construiu uma stored procedure que fazia a inclusão de dados na tabela de produtos. Eu até executei, aqui, esse comando aqui de cima chamando a stored procedure e, passando os dados para serem incluídos na tabela de produto. A vantagem é que eu não preciso me preocupar com comando insert, eu não preciso saber o nome dos campos, da tabela e assim por diante.

[00:26] Só que se a gente observar o formato da tabela, por exemplo, eu tenho aqui a tabela de produtos e eu tenho esse ícone aqui com a letra "I" de informação. Se eu clicar sobre ele, eu abro aqui uma caixa de informações onde, seu eu vier aqui na aba "INDEX", eu vou ver que é chave primária o campo "CÓDIGO DO PRODUTO". O que isso significa? Eu não posso ter mais de um produto com o mesmo código.

[01:00] Porque o código do produto é a chave primária. Sabendo disso, vou fechar aqui, o quê acontece se eu repetir esse comando? Eu já tenho aqui, se eu rodar o select que está aqui em cima, eu já tenho o produto "4000001". Eu já tenho esse produto. Se eu rodar o comando de novo, o quê que vai acontecer? Aqui. Vai acontecer um erro. Já esperava que esse erro ia acontecer. Eu tenho um erro de chave primária duplicada.

[01:40] Eu estou tentando colocar um outro produto com o mesmo código. E aí, o próprio comando "SQL" me deu um erro. Será que é possível não ver esse erro? Ou apresentar uma mensagem mais amigável dizendo: "Olha, o seu produto foi incluído com sucesso ou não foi incluído porque a chave primária já existe"? Alguma coisa que não seja erro, que não me retorne do banco de dados esse status de erro aqui.

[02:12] É possível sim, através do "ERROR HANDLER". Eu vou mostrar para vocês como é que isso funciona. Eu vou, então, aqui clicar na nossa procedure, "INCLUIR_NOVO_PRODUTO_PARAMETRO". Clico com o botão direito do mouse e eu vou alterar a procedure. O quê eu vou fazer? Eu vou, aqui, declarar uma variável que eu vou chamar de mensagem. Ela vai ser um "VACHAR (30)", por exemplo.

[02:49] E aí, claro, aqui no final, eu vou fazer o seguinte "SET MENSAGEM = PRODUTO INCLUÍDO COM SUCESSO!!!". E aqui eu vou dar um "SELECT MESSAGE", ou mensagem. "SELECT MENSAGEM". Aqui tem que ter um ponto e vírgula. Então, pronto. Criei apenas uma variável do tipo mensagem, altero o valor depois do insert e mando exibir essa mensagem. Então, eu vou dar um "APPLY".

[03:40] Salvei a rotina. Eu vou vir aqui no meu "SQLFILE", vou, por exemplo, agora tentar incluir o produto "4000002". "4000002" não existe. Então, teoricamente, vai ter que funcionar. Eu vou rodar. "DATA TOO LONG FOR COLUMN MENSAGEM". Eu declarei a variável Messenger com tamanho muito pequeno. Vou alterar aqui. Botei 30 e a mensagem aqui, claro, contém mais de 30. Um, dois, três, quatro, cinco. Vamos contar aqui.

[04:28] De novo aqui, por causa das duas exclamações. Então, eu vou colocar mensagem aqui 40. Agora acho que vai funcionar direitinho. Não vou poder incluir o produto "4000002" de novo. Vou botar o 3. Vou executar a rotina. E aí, pronto. Ele me deu a mensagem: "PRODUTO INCLUÍDO COM SUCESSO". Mas, se eu rodo de novo o comando, continuo tendo o erro "1062", uma chave duplicada.

[05:10] Então, eu mostrei a mensagem quando o produto é incluído com sucesso, mas eu queria, agora, mandar uma mensagem através aqui desse retorno, do select. Uma mensagem dizendo: "PRODUTO COM PROBLEMA". Vamos, então, voltar lá para a rotina para fazer isso. "ALTER STORED PROCEDURE". E aí, aqui embaixo eu vou escrever o seguinte comando: "DECLARE EXIT".

[05:41] Ou seja, eu vou fazer o que eu vou escrever daqui para frente quando houver um erro. Então, eu vou sair do programa. "DECLARE EXIT HANDLER FOR". E aí, eu vou colocar agora o número do erro que eu quero tratar que é o "1062", que é esse número que está aqui. E aí, aqui, eu vou botar um "BEGIN" e um "END". Ponto e vírgula, novo "END". E aqui dentro, eu vou copiar essas duas linhas aqui onde eu configuro a variável "MENSAGEM".

[06:30] Eu vou primeiro colocar a mensagem "PROBLEMA DE CHAVE PRIMÁRIA" e vou exibir a mensagem. O quê que vai acontecer? Quando eu executar essa stored procedure, ele vai executar essa primeira linha para criar a variável. Vai executar essa segunda linha, mas nada vai acontecer. Ele só vai guardar em memória dizendo: "se houver o erro "1062", você saia do programa, mas antes de sair do programa, execute essas duas linhas.

[07:10] Mas, isso vai ficar guardadinho lá. Aí, ele vai inserir essa terceira linha que é o insert. E aí, essa linha vai dar problema. Ele vai descobrir que tem um problema, o quê que ele vai fazer? Ele não executa. Não executa essas linhas. Ele para aqui. Sai do programa, mas na hora de sair programa, ele executa esses dois comandos. Vamos ver se isso vai acontecer mesmo?

[07:35] Vou dar uma praia. Vamos voltar para cá, eu vou incluir o produto com final "004" agora. Não tenho esse produto. Está lá "PRODUTO INCLUÍDO COM SUCESSO". Eu, agora, vou repetir o comando novamente. Note, ele não me deu erro. Ou seja, a rotina rodou um sucesso. E ele escreveu a mensagem:"PROBLEMA DE CHAVE PRIMÁRIA". Claro, não foi incluído porque ele não pode incluir.

[08:19] Já existe o código final "004", mas o MySQL não retornou para mim erro. E ainda me mostrou uma mensagem mais amigável que eu tratei. Então é isso que eu queria mostrar a vocês sobre "ERROR HANDLER". É uma forma de eu tratar, de forma amigável, vários possíveis erros que podem acontecer com a minha rotina. Então, tá gente. Era isso que eu queria falar com vocês sobre esse assunto.

-----------------------------------------------------------------------
# 07Atribuição de valor usando SELECT

https://cursos.alura.com.br/course/mysql-procedures/task/56711

## Transcrição

[00:00] Vamos continuar estudando? Quando tem uma variável e eu quero atribuir um valor a ela, eu utilizo o comando "SET" para fazer isso. Aqui nessa última rotina que nós trabalhamos para tratar o erro, a gente faz isso aqui: eu dou "SET", o nome da variável e eu digo um valor. Agora, o que aconteceria se o valor que eu quero atribuir a uma variável, eu não sei se valor? Ele, na verdade, está vindo de uma tabela. Está vindo de uma consulta.

[00:33] Como é que eu faço essa atribuição de variável? É o que nós vamos ver agora. E nós vamos ver isso construindo uma nova stored procedure. Mas antes de ver isso, para a gente poder editar bem esse exemplo. Eu vou fechar essa janela aqui. Essa e essa. Vou deixar aqui nenhuma janela de stored procedure aberta por enquanto, só vou deixar os scripts.

[01:00] E aí, eu quero construir uma stored procedure que me retorna o sabor de um produto. Então, se eu for dar esse select aqui, "SELECT SABOR", "FROM TABELA_DE_PRODUTOS", "WHERE CÓDIGO_DO_PRODUTO" "=". Vou pegar esse 4001 como exemplo. Se eu rodar essa rotina. Na verdade, é tabela de produtos. Pronto. Eu tenho aqui o sabor do produto.

[01:47] Então, eu vou querer executar essa rotina, e jogar o valor que ia esse select está trazendo para dentro de uma variável. É o que eu vou fazer nesse exemplo aqui dessa nova stored procedure. Vou clicar com o botão direito do mouse aqui. Clicar em "CREATE STORED PROCEDURE". E vou criar uma stored procedure chamada "ACHA_SABOR_PRODUTO".

[02:11] Vou passar como parâmetro uma variável que eu vou chamar de "VER_PRODUTO" que é um "varchar (50)". Vou declarar aqui a variável "VSABOR". "varchar (50)". E ai, vou fazer um exemplo bem simples aqui. Se eu chegar aqui "SET VSABOR = MELANCIA" e der um "SELECT VSABOR". Claro que esse exemplo que está aqui, eu não usei "VPRODUTO" para nada, mas eu estou construindo aos poucos a rotina para vocês entenderem a diferença.

[03:01] Se eu, claro, der "APPLY" e "FINISH" aqui; se eu executar essa rotina "CALL ACHA_SABOR_PRODUTO". E se eu passar como parâmetro o "4234001", claro que eu vou ter o resultado melancia. Mas é um resultado constante. Independente do produto que eu colocar aqui, ele sempre vai dar esse valor. Só que agora, eu quero que o quê eu vou ver na saída seja o resultado desta consulta aqui.

[03:43] Então, eu vou copiar essa consulta. Vou clicar com o botão direito do mouse de novo em "ACHA_SABOR_PRODUTO". E vou dar um "ALTER STORED PROCEDURE". Então olha, aqui nesse ponto eu vou executar o select. Só que é claro que o código do produto que eu vou estar utilizando vai ser o conteúdo da variável que eu passei como parâmetro. Agora, como é que eu jogo o valor que isso retornou para esta variável? Esse que é o grande pulo do gato.

[04:19] Você faz assim. Eu vou apagar essa linha, e eu escrevo "SABOR INTO VSABOR". Ao fazer isso. Vamos organizar aqui o código. Ao fazer isso, eu estou jogando, o que estiver retornando desse campo através do select, para a variável. E aí, depois eu dou o select para exibir o resultado. E eu vejo no resultado da stored procedure, o sabor do produto que eu passei como parâmetro.

[04:57] Vou dar um "APPLY". "APPLY" de novo. E "FINISH". Então, se eu chegar aqui agora e rodar, ele não me retornou porque, na verdade, o parâmetro correto é isso aqui. É o "400000". Vamos rodar de novo. Está lá, melancia. Vamos pegar um outro produto qualquer. Primeiro, deixa eu pegar aqui códigos quaisquer. Vou dar um select genérico aqui da tabela. Vamos pegar esse aqui. Esse produto: "1013793".

[05:46] Se a gente olhar aqui, o sabor é "CEREJA/MAÇÃ". Então, se eu copiar esse código aqui e jogar no resultado da stored procedure, se eu rodar está lá "CEREJA/MAÇÃ". Então, essa atribuição. A atribuição para uma variável de um valor que é resultado de um select, eu utilizo através do comando "INTO" porque aí, eu faço a associação. Era isso que eu queria falar com vocês sobre esse assunto.


-----------------------------------------------------------------------
# 08Usando SELECT para atribuir valores

Crie uma variável chamada `NUMNOTAS` e atribua a ela o número de notas fiscais do dia 01/01/2017. Mostre na saída do script o valor da variável. (Chame esta Stored Procedure de Quantidade_Notas).

-----------------------------------------------------------------------
# 09Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Abra um novo script MYSQL.

2) Digite e execute:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `manipulacao_dados`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `manipulacao_dados` ()
BEGIN
INSERT INTO tabela_de_produtos (CODIGO_DO_PRODUTO,NOME_DO_PRODUTO,SABOR,TAMANHO,EMBALAGEM,PRECO_DE_LISTA)
     VALUES ('2001001','Sabor da Serra 700 ml - Manga','Manga','700 ml','Garrafa',7.50),
         ('2001000','Sabor da Serra  700 ml - Melão','Melão','700 ml','Garrafa',7.50),
         ('2001002','Sabor da Serra  700 ml - Graviola','Graviola','700 ml','Garrafa',7.50),
         ('2001003','Sabor da Serra  700 ml - Tangerina','Tangerina','700 ml','Garrafa',7.50),
         ('2001004','Sabor da Serra  700 ml - Abacate','Abacate','700 ml','Garrafa',7.50),
         ('2001005','Sabor da Serra  700 ml - Açai','Açai','700 ml','Garrafa',7.50),
         ('2001006','Sabor da Serra  1 Litro - Manga','Manga','1 Litro','Garrafa',7.50),
         ('2001007','Sabor da Serra  1 Litro - Melão','Melão','1 Litro','Garrafa',7.50),
         ('2001008','Sabor da Serra  1 Litro - Graviola','Graviola','1 Litro','Garrafa',7.50),
         ('2001009','Sabor da Serra  1 Litro - Tangerina','Tangerina','1 Litro','Garrafa',7.50),
         ('2001010','Sabor da Serra  1 Litro - Abacate','Abacate','1 Litro','Garrafa',7.50),
         ('2001011','Sabor da Serra  1 Litro - Açai','Açai','1 Litro','Garrafa',7.50);

         SELECT * FROM tabela_de_produtos WHERE NOME_DO_PRODUTO LIKE 'Sabor da Serra%';
         UPDATE tabela_de_produtos SET PRECO_DE_LISTA = 8 WHERE NOME_DO_PRODUTO LIKE 'Sabor da Serra%';

         SELECT * FROM tabela_de_produtos WHERE NOME_DO_PRODUTO LIKE 'Sabor da Serra%';
         DELETE FROM tabela_de_produtos WHERE NOME_DO_PRODUTO LIKE 'Sabor da Serra%';

         SELECT * FROM tabela_de_produtos WHERE NOME_DO_PRODUTO LIKE 'Sabor da Serra%';
END$$
DELIMITER ;
```

1) Execute:

```sql
Call manipulacao_dados;
```

1) A SP acima manipula uma série de comandos no banco de dados MYSQL.

Observação: Se você observar o seguinte erro:

![0.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/03/0.png)

É porque você deve efetuar uma modificação na configuração do seu MYSQL.

Vá, no menu, em Edit / Preference e na seção SQL EDITOR vá até o final do formulário e desmarque a opção Safe Updates (Reject UPDATEs and DELETEs with no restrictions).

![1.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/03/1.png)

1) Podemos também usar a SP para inserir dados na tabela usando variáveis. Digite e execute:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `inclui_novo_produto`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `inclui_novo_produto` ()
BEGIN
DECLARE vCodigo varchar(50) DEFAULT '3000001';
DECLARE vNome varchar(50) DEFAULT 'Sabor do Mar 700 ml - Manga';
DECLARE vSabor varchar(50) DEFAULT 'Manga';
DECLARE vTamanho varchar(50) DEFAULT '700 ml';
DECLARE vEmbalagem varchar(50) DEFAULT 'Garrafa';
DECLARE vPreco DECIMAL(10,2) DEFAULT 9.25;
INSERT INTO tabela_de_produtos
(CODIGO_DO_PRODUTO,NOME_DO_PRODUTO,SABOR,TAMANHO,EMBALAGEM,PRECO_DE_LISTA)
     VALUES (vCodigo,
     vNome,
     vSabor,
     vTamanho,
     vEmbalagem,
     vPreco);
END$$
DELIMITER ;
```

1) Execute:

```sql
Call inclui_novo_produto;
```

1) Veja que usamos referência direta as variáveis no comando INSERT, dentro da SP.

2) Podemos usar parâmetros para passar para a SP os dados que serão usados no comando de INSERT. Para isso digite e execute:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `inclui_novo_produto_parametro`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `inclui_novo_produto_parametro`(vCodigo varchar(50),
vNome varchar(50), vSabor varchar(50), vTamanho varchar(50),
vEmbalagem varchar(50), vPreco DECIMAL(10,2))
BEGIN
INSERT INTO tabela_de_produtos
(CODIGO_DO_PRODUTO,NOME_DO_PRODUTO,SABOR,TAMANHO,EMBALAGEM,PRECO_DE_LISTA)
     VALUES (vCodigo,
     vNome,
     vSabor,
     vTamanho,
     vEmbalagem,
     vPreco);
END$$
DELIMITER ;
```

1) Execute a SP:

```csharp
Call inclui_novo_produto_parametro('4000001', 'Sabor do Pantanal 1 Litro - Melancia',
'Melancia', '1 Litro', 'PET', 4.76);
```

1) Veja que o comando acima passa os dados que serão incluídos dentro da tabela através dos parâmetros.

2) Repita a execução do comando novamente:

```csharp
Call inclui_novo_produto_parametro('4000004', 'Sabor do Pantanal 1 Litro - Melancia',
'Melancia', '1 Litro', 'PET', 4.76);
```

1) Note que houve um erro de chave primária porque o produto 4000004 já existe na tabela:

![2.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/03/2.png)

1) Podemos tratar este erro para que ele apresente uma mensagem amigável quando ocorrer. Execute e digite:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `inclui_novo_produto_parametro_2`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `inclui_novo_produto_parametro_2`(vCodigo varchar(50),
vNome varchar(50), vSabor varchar(50), vTamanho varchar(50),
vEmbalagem varchar(50), vPreco DECIMAL(10,2))
BEGIN
DECLARE mensagem VARCHAR(40);
DECLARE EXIT HANDLER FOR 1062
BEGIN
   SET mensagem = 'Problema de Chave Primária !!!';
   SELECT mensagem;
END;

INSERT INTO tabela_de_produtos
(CODIGO_DO_PRODUTO,NOME_DO_PRODUTO,SABOR,TAMANHO,EMBALAGEM,PRECO_DE_LISTA)
     VALUES (vCodigo,
     vNome,
     vSabor,
     vTamanho,
     vEmbalagem,
     vPreco);
SET mensagem = 'Produto incluido com sucesso !!!';
SELECT mensagem;
END$$
DELIMITER ;
```

1) Execute e digite:

```csharp
Call inclui_novo_produto_parametro_2('4000004', 'Sabor do Pantanal 1 Litro - Melancia',
'Melancia', '1 Litro', 'PET', 4.76);
```

![3.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/03/3.png)

1) Repita o comando. Teremos:

![4.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/03/4.png)

1) Vimos que o comando `SET` é usado para atribuir valores as variáveis. Más podemos atribuir valores a ela usando comandos `SELECT` através do `SELECT INTO`. Execute e digite:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `acha_sabor_produto`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `acha_sabor_produto`(vProduto VARCHAR(50))
BEGIN
   DECLARE vSabor VARCHAR(50);
   SELECT SABOR INTO vSabor FROM tabela_de_produtos WHERE codigo_do_produto = vProduto;
   SELECT vSabor;
END$$
DELIMITER ;
```

1) Execute:

```csharp
Call acha_sabor_produto('1013793');
```

1) Teremos como resposta o sabor do produto passado como parâmetro.

![5.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/03/5.png)


-----------------------------------------------------------------------
# 10O que aprendemos?

Nesta aula, aprendemos:

- Como manipular comandos SQL dentro da SP;
- Como passar parâmetros para uma SP;
- Como tratamos erros;
- A atribuição de variáveis através de um comando `SELECT`.


-----------------------------------------------------------------------
# 01IF THEN ELSE

https://cursos.alura.com.br/course/mysql-procedures/task/56712

## Transcrição

[00:00] Quando eu falei para vocês sobre a linguagem "SEQUEL" que é um padrão de banco de dados, e quando a gente começou a ver os cursos de consulta e manipulação de dados; nós vimos que a linguagem "SEQUEL" é uma linguagem sequencial. Tem comandos insert, update, delete, select, "CREATE", "DROP".

[00:20] Mas se eu tenho um conjunto de comandos "SEQUEL" dentro do meu script, eu não consigo, por exemplo, fazer um desvio de fluxo, do tipo se alguma coisa acontecer faça isso, se não faça aquilo. As linguagens extras que cada banco resolveu criar através das stored procedures é uma maneira da gente melhorar, um pouco, a linguagem "SEQUEL".

[00:57] Por isso que cada construtor de banco de dados fez a sua linguagem própria de stored procedures. E aí, claro, o grande diferencial é que nas stored procedures nós temos o que nós chamamos de "CONTROLE DE FLUXO". Onde eu posso controlar o fluxo do programa. E aí, o primeiro controle de fluxo que nós vamos trabalhar é o "IF/THEN/ELSE".

[01:24] Que basicamente funciona como está sendo mostrado aqui. Eu coloco "IF", uma condição, "THEN", eu faço alguma coisa, "ELSE", eu faço outra e eu dou um "END IF". Vamos fazer um exemplo do "IF/THEN/ELSE/END IF" lá NO MySQL, um exemplo prático. Então, eu vou voltar aqui para o meu "WORKBENCH". Vou criar aqui uma outra rotina, e vou fazer o seguinte. Vamos dar um "SELECT* FROM TABELA_DE_CLIENTES".

[02:07] Então, eu tenho lá a lista dos meus clientes e eu tenho aqui um campo que a gente chama de "DATA DE NASCIMENTO". Eu vou fazer a seguinte stored procedure: eu vou dar um CPF de um cliente e, se ele nasceu depois do ano 2000, ele é um cliente jovem. Se ele nasceu antes do ano 2000, ele é um cliente velho. Um exemplo muito simples. Então, vamos construir aqui a nossa stored procedure.

[02:59] Clico com o botão direito do mouse, stored procedure. Criei a stored procedure. E aí, eu vou chamar essa stored procedure de "CLIENTE_NOVO_VELHO". E, é claro, vou passar como parâmetro o CPF. Vou botar o Varchar aqui de 20. Não tem esse "AS" não, só "varchar (20). A gente, às vezes, confunde as linguagens de programação em uma coloca a sintaxe da outra.

[03:41] É uma bagunça. Vamos lá. Eu vou declarar uma variável. Vou chamar de "RESULTADO" que vai ser um "varchar (20)" também. Uma outra variável, essa variável vai ser "VDATANASCIMENTO". Ela vai ser uma variável do tipo "DATE". Aí, eu vou voltar aqui para o script de "SQL" sem fechar essa rotina que eu ainda estou editando. E eu vou fazer isso daqui.

[04:28] "SELECT DATA_DE_NASCIMENTO FROM TABELA_DE_CLIENTES WHERE CPF =". Vou escolher um CPF qualquer só para tomar como exemplo. Esse CPF aqui. Então, essa consulta, ela me retorna a data de nascimento. Então, como eu aprendi no outro vídeo, eu vou copiar. Vou colar esse select aqui. Só que aí, na condição, eu vou ter o "VCPF" porque eu vou fazer a consulta para o CPF que eu passei como parâmetro.

[05:23] E aqui, na data de nascimento, eu vou escrever "INTO VDATANASCIMENTO". Eu posso até ir aqui e dar um enter. Não tem nenhum problema porque é o ponto e vírgula que diz que a linha acabou. Então, não tem problema ter um enter aqui. Eu disse que se o cliente nasceu do ano 2000, de primeiro de Janeiro do ano 2000 para frente, ele é jovem. Se for para trás, ele é velho.

[05:58] Então, eu vou escrever isso daqui "IF VDATANASCIMENTO < 20000101 THEN". Vou ter um "ELSE" e vou ter o "END IF". Dentro do "IF", ou seja, se ele nasceu menos do que o ano 2000, ele é um cliente velho. Então, aqui eu vou dizer que "SET RESULTADO = CLIENTE_VELHO". Vamos colocar o "ELSE"? "ELSE SET RESULTADO CLIENTE_NOVO". Vou colocar o ponto e vírgula aqui. Vou colocar o ponto e vírgula aqui.

[07:10] E aqui, no final, eu vou dar um "SELECT VER_RESULTADO" para poder ver a resposta, ver a saída. Se o cliente é velho ou se o cliente é novo. Vamos lá. O nome da rotina está legal. "CLIENTE_NOVO_VELHO". Vou dar um "APPLY". Vou dar outro "APPLY". Vou dar um "FINISH". Então, eu tenho a minha rotina salva. Vamos lá no script agora? "CALL CLIENTE_NOVO_VELHO", e aí como parâmetro eu vou passar o CPF.

[08:02] Passei o CPF e vamos executar. Opa. Esse cliente é um cliente velho. Vamos pegar outros clientes. Deixa eu ver aqui os clientes. Acima do ano 2000 eu tenho poucos, né? Fui muito infeliz nesse teste. Vamos pegar esse aqui que nasceu em 12 de Fevereiro de 2000. Esse é o CPF dele. O resultado da stored procedures tem que dar "CLIENTE NOVO". Vamos ver. "CLIENTE NOVO".

[08:45] Então, eu consegui fazer uma stored procedure que, dado um determinado resultado de um select, se acontecer uma coisa retorna de um jeito. Se acontecer outra, retorna de outro jeito. Então, esse foi um exemplo para eu mostrar para vocês como é que funciona o "IF/THEN/ELSE/END IF" dentro do MySQL.

-----------------------------------------------------------------------
# 02Testando o número de notas fiscais

Crie uma Stored Procedure que, baseado em uma data, contamos o número de notas fiscais. Se houverem mais que 70 notas exibimos a mensagem: ‘Muita nota’. Ou então exibimos a mensagem ‘Pouca nota’. Também exibir o número de notas. Chame esta Stored Procedure de Testa_Numero_Notas.

A data a ser usada para testar a nota será um parâmetro da Stored Procedure.


-----------------------------------------------------------------------
# 03IF THEN ELSEIF

https://cursos.alura.com.br/course/mysql-procedures/task/56713


## Transcrição

[00:00] A gente encontra no MySQL outro controle de fluxo "IF", só que ele tem o nome um pouquinho diferente. Ele é o "IF/THEN/ ELSEIF". O "ELSEIF" permite que a gente construa diversas condições. É como se fosse um "CASE". E aí, depois, finalmente, eu tenho o último "ELSE" que é como se fosse o "OVERWRITE", ou seja, se nada acontecer das condições acima, então faça isso.

[00:29] Aqui tem mais ou menos a ordem com que esse comando é construído. Tem lá "IF" é a condição. "THEN", coloco o que tem que fazer. "ELSEIF", aí eu coloco outra condição. Inclusive, a transparência está, aqui o slide está até errado. Vou até corrigir aqui online para vocês. Na verdade, a coisa teria que ser assim. Agora sim podemos apresentar. "IF" condição, "THEN" o que eu faço no "IF".

[01:02] "ELSEIF" outra condição, o que eu faço no "ELSEIF". "ELSEIF", outra condição. E aí, por diante. E aí, no último "ELSE" é se nada que eu tiver acima conseguir ser atendido. Vamos fazer um exemplo prático então. Vamos lá no nosso "MySQL WORKBENCH". E eu vou aqui, deixa eu fechar essa caixa de diálogo aqui. Vou criar aqui um outro script. E eu vou fazer aqui um "SELECT* FROM TABELA_DE_PRODUTOS".

[01:41] E eu tenho, aqui, o preço de lista dos produtos. Tem produto que custa que 6, outro que custa 8, outro custa 24, outro que custa 38. E aí, eu tenho a seguinte classificação. Vou até colocar comentário aqui. Se o produto for mais caro que 12 reais, ele é um produto muito caro. E, se ele tiver entre 7 reais e 12 reais, ele é um produto, digamos assim, em conta.

[02:24] E, se ele for um produto menor do que 7 reais, o preço de lista. Ele é um produto barato. Então, eu vou fazer uma stored procedures em que, eu vou passar o código do produto. Eu vou ver quem é o preço de lista daquele produto e saber dizer se ele é caro, em conta ou barato. E jogar a resposta na tela depois que eu executar a stored procedure.

[02:50] Então, a gente já vai de cara aqui rodar, qual é o comando select para retornar ao preço de lista? "SELECT PREÇO_DE_LISTA FROM TABELA_DE_PRODUTOS WHERE CÓDIGO_DO_PRODUTO" igual a um código específico. Só para a gente manter, aqui, a quare funcionando, eu vou pegar esse primeiro produto aqui. Selecionei a linha, rodei. Então, está lá o preço de lista.

[03:29] Vamos lá. CLico com o botão direito do mouse. stored procedure. "CREATE STORED PROCEDURE". Então, eu vou colocar aqui o nome: "ACHA_STATUS_PREÇO". Entro como parâmetro "VPRODUTO" é um "varchar (50)". Vou ter um "DECLARE", uma variável que vai pegar o preço de lista. "VPREÇO". Ela é um tipo "FLOAT". E eu vou ter uma outra mensagem. Vai ser um "varchar (30)".

[04:33] Aí eu, agora, vou pegar o preço de lista e jogar para a variável "VPREÇO". Então, eu vou rodar esta consulta aqui. Vou dar um enter aqui só para a gente poder ver o código da stored procedure toda na tela. "VPRODUTO" vai ser passado como um parâmetro e o valor do preço de lista, a gente vai jogar aqui no "INTO VPREÇO". Aí, nós vamos fazer agora os "IF"s. "IF VPREÇO > = 12 THEN".

[05:19] Vou dar um "SET VMENSAGEM = PRODUTO CARO". Ponto e vírgula. Aí, agora, eu boto "ELSEIF VPREÇO > = SET AND VPREÇO < 12 THEN". Vamos colocar a mensagem que o produto é em conta. "PRODUTO EM CONTA". E aí, eu tenho, eu poderia ter outro "ELSEIF", mas outro "ELSEIF". Mas no final, eu dou um "ELSE". E aí, o último "ELSE" eu não preciso especificar uma condição. Eu digo que o produto é barato.

[06:28] E aí termina aqui, no final, com "END IF". E, finalmente, aqui eu vou dar um "SELECT VMENSAGEM" para terminar o processo de consulta. Vamos olhar aqui. Note que ele está dando erros porque, na verdade, eu tenho que ter o ponto e vírgula terminando o último "END IF" para mostrar para o MySQL que isso tudo aqui é uma linha de comando.

[07:08] Não tenho nenhum erro. Ok. Vou dar o "APPLY". "APPLY". "FINISH". E aí, vamos lá. "CALL ACHA_STATUS_PRECO", e aí, eu passo aqui o código do produto. Então, ponto e vírgula aqui e aqui. Vamos rodar. "PRODUTO BARATO". Vamos pegar outros produtos. Só que ao invés de preço de lista, eu vou pegar aqui o asterisco, só para a gente poder pegar outros produtos.

[07:54] Vamos pegar esse aqui que tem como preço 11. Então, está entre 7 e 12. Vamos ver o que ele vai trazer aqui. "PRODUTO EM CONTA". Porque está entre 7 e 11. E agora, a gente vai pegar um produto caro. Vou pegar esse aqui 16,51. Esse é o código. Jogo aqui para a stored procedure executo. "PRODUTO CARO". Ok. Então, esse foi um exemplo simples do uso do "IF" e do "ELSE IF".

-----------------------------------------------------------------------
# 04Faturamento anual

Desafio! Veja a consulta abaixo:

```sql
SELECT SUM(B.QUANTIDADE * B.PRECO) AS TOTAL_VENDA FROM 
NOTAS_FISCAIS A INNER JOIN ITENS_NOTAS_FISCAIS B
ON A.NUMERO = B.NUMERO
WHERE A.DATA_VENDA = '20170301'
```

Ela retorna o valor do faturamento em uma determinada data.

Construa uma Stored Procedure chamada Comparativo_Vendas que compara as vendas em duas datas (Estas duas datas serão parâmetros da SP). Se a variação percentual destas vendas for maior que 10% a resposta deve ser "Verde". Se for entre -10% e 10% deve retornar "Amarela". Se o retorno form menor que -10% deve retornar "Vermelho".

-----------------------------------------------------------------------
# 05CASE END CASE

https://cursos.alura.com.br/course/mysql-procedures/task/56714

## Transcrição

[00:00] Vamos falar agora do "CASE". O "CASE" funciona da seguinte maneira: eu vou ter um uma variável que vai ser inicializada por um "DECLARE" e vai receber um valor. E eu comparo ela com uma lista de opções. Então, por exemplo, se essa variável for um número, eu falo se esse número for igual a 1, eu faço alguma coisa. Se ele for igual a dois, e faço outra.

[00:27] Posso, também, estar usando aqui dentro do "CASE" uma variável do tipo "varchar". E aí, eu vou comparar com determinados "STRINGS". E aí, dependendo desse valor, eu faço alguma coisa e caso nenhuma condição satisfaça, que é o "ELSE", eu faço uma ação final. Vamos fazer um exemplo prático. Antes disso, eu vou voltar aqui para o meu "MySQL WORKBENCH". Vou me certificar de que a base "SUCOS_VENDAS" está selecionada.

[01:03] E vou criar aqui um novo script. Deixa eu ver, aqui, quais são os tipos de sabores que eu tenho disponíveis na minha tabela de produtos. Para eu ver todos os sabores, eu coloco aqui um "DISTINT" e eu vou executar. Então, note. Eu tenho aqui esses sabores todos. Eu não sou um especializado muito em fruta não. Mas, se eu cometer algum erro agora, vocês não levem em consideração isso.

[01:41] Mas eu vou considerar desses sabores existentes que "LIMA/LIMÃO", eu vou considerar ele como um cítrico. Mas não só o "LIMA/LIMÃO". Eu vou colocar, por exemplo, o "LARANJA" também, eu vou considerar um cítrico. "MORANGO/LIMÃO" não. "MORANGO"? "LIMÃO" pode até ser cítrico, mas "MORANGO" não, ou é? Não sei. Vou considerar que seja. Eu posso estar meio enganado aqui.

[02:30] Cítrico. "LARANJA" também é cítrico. E vamos considerar agora, os produtos "UVA" e o produto, por exemplo, "MORANGO". Só o "MORANGO" como sendo, por exemplo, "NEUTROS". Não importa se eu estou fazendo uma classificação que tenha sentido. Eu estou pegando um grupo de produtos, de sabores, e dizendo que se forem esses três tipos aqui, eu vou chamar de cítrico.

[03:23] Se forem esses dois, eu vou chamar de "NEUTROS". E os outros, eu vou chamar de "Ácidos". Ok. Deixa eu copiar isso daqui, tirar fora aqui do script do "SQL" para não dar problema. Vou jogar aqui. Vou fazer, então, uma procedure, uma stored procedure que vai fazer um "CASE" e vai testar um sabor de um produto. Se esse sabor for "LIMA/LIMÃO", "LARANJA" e "MORANGO/LIMÃO", eu vou chamar de "CÍTRICO".

[04:09] "UVA" e "MORANGO", eu vou chamar de "NEUTRO". E, se nenhuma das condições forem satisfeitas, eu vou chamar de"ÁCIDOS". Eu poderia fazer isso pelo "IF/AND/ELSEIF", como a gente viu é no vídeo anterior. Mas eu vou usar a estrutura de "CASE" só para a gente poder ver a diferença do uso de uma outra estrutura de controle de fluxo. Então, eu vou voltar aqui para o meu "WORKBENCH", e se eu mantiver essa consulta aqui "WHERE CÓDIGO_DO_PRODUTO =". Vamos pegar aqui alguns produtos.

[05:03] Então, se eu pegar esse produto daqui, só para fazer um teste. É assim. Código_doproduto. Se eu rodar isso daqui, terá o sabor uva. Então, deixa eu rodar isso daqui epara a gente não perder ela. E vamos lá. Vou, agora, criar aqui uma stored procedure. Eu vou chamar esse cara de "ACHA_TIPO_SABOR". Vou entrar como um parâmetro "VPRODUTO". Vai ser um "varchar (50)".

[05:57] Vou dar um "DECLARE". Uma variável "VSABOR". E vai ser um "varchar (50). Aí agora, eu vou fazer um select para buscar o sabor do produto que foi passado como parâmetro, e jogar esse resultado para a variável "SABOR". Então, tu vou rodar essa consulta aqui que eu já separei. Só que eu coloco aqui "INTO VSABOR FROM TABELA WHERE CÓDIGO_DO_PRODUTO = VPRODUTO". Ponto e vírgula.

[06:47] Agora, eu vou começar minha estrutura de "CASE". Então, eu vou colocar "CASE". Qual é a variável que eu vou estar usando no "CASE"? É a variável "VSABOR". Eu vou colocar "WHEN". Então, vamos buscar aqui. Eu vou até já copiar esse bloco aqui. Vou colar aqui embaixo e vou usar lá. "WHEN LIMA/LIMÃO THEN SELECT CÍTRICO". Ponto e vírgula. Vou repetir esse cara duas vezes porque se for "LARANJA" também vai ser "CÍTRICO".

[07:53] Se for"MORANGO/LIMÃO" também vai ser "CÍTRICO". Eu vou ter outras duas condições aqui. Uma para "UVA". Outra para "MORANGO". Vou chamar esse aqui de "NEUTRO". E aí, quando nenhuma das cinco condições anteriores foram satisfeitas, eu coloco um "ELSE SELECT ÁCIDOS". E aí, eu fecho com um "END CASE". Na verdade, tem que fechar aqui esse "STRING". Já posso apagar esse rascunho aqui e eu fecho a minha stored procedure.

[09:03] Vamos dar uma olhada nela. Então, tem aqui. Declarei a variável. Joguei o valor do sabor, que veio desse parâmetro que é usado aqui embaixo. Jogo para a variável "VSABOR". Depois, eu testo. Se caso ela for "LIMA/LIMÃO", vai ser "CÍTRICO". Caso "LARANJA", vai ser "CÍTRICO". Caso "MORANGO/LIMÃO", vai ser "CÍTRICO". Caso "UVA", "NEUTRO. Caso "MORANGO", "NEUTRO".

[09:37] E se nada disso aqui for verdade, ele será "ÁCIDO". Vamos dar um "APPLY". "APPLY" de novo. "FINISH". Então, vamos lá. Esse produto aqui, ele é sabor "UVA". Então, eu posso vir aqui, dar um "CALL ACHA_SABOR_PRODUTO". Vou passar como parâmetro isso daqui. Essa é uma outra rotina, que a gente, quando roda, acha "UVA". Posso, agora, rodar a "ACHA_TIPO_SABOR" que é "UVA".

[10:34] Então, "UVA" pelo nosso teste, dá "NEUTRO". Então, se eu rodar agora esta rotina, eu vou ter como resposta o "NEUTRO". Então, eu mostrei para vocês um caso simples do uso do "CASE" em cima de uma determinada variável que recebe valor. E aí, eu tenho algumas opções e digo se aquelas opções satisfizerem, eu tenho o meu resultado final.


-----------------------------------------------------------------------
# 06CASE NOT FOUND

https://cursos.alura.com.br/course/mysql-procedures/task/56715

## Transcrição

[00:00] Vamos pegar aquela rotina que nós desenvolvemos agora, no vídeo anterior, usando o "CASE", e eu vou forçar um erro que pode acontecer quando a gente está trabalhando com a estrutura "CASE" dentro do nosso código. Então, eu vou pegar aqui a "ACHA_TIPO_SABOR", que foi a rotina que nós desenvolvemos. Clico com o botão direito do mouse "ALTER STORED PROCEDURE". E aí, eu vou fazer o seguinte.

[00:33] Eu vou tirar o "ELSE" e vai ficar assim. Não vai ter o "ELSE" dentro do "CASE". Então, se for "LIMA/LIMÃO", tem o "CÍTRICO", "LARANJA", "MORANGO", "LIMÃO", "UVA", agora se for alguma coisa diferente disso, eu não tenho dentro do "CASE" o que fazer. Eu vou então, chamar esse cara aqui de "ERRO". Vou dar um "APPLY". Ele me dá esse código aqui. O negócio é que se eu rodo aqui, ele vai apagar a minha stored procedure antiga e vai criar uma nova.

[01:18] Eu vou fazer o seguinte. Eu vou copiar esse código todo aqui, eu não dou o "APPLY", não clico na "APPLY". Vou dar um "CANCEL". E aí, eu vou criar aqui uma nova estrutura de script. Vou colar isso daqui. E eu vou tirar esse "DROP" daqui. Pronto. Vou executar. Ele rodou. Então, aqui se eu der um "REFRESH", eu tenho a original, que eu não perdi. E tenho a nova.

[01:53] Então, eu vou rodar agora aqui e ao invés de ser a "ACHA_TIPO_SABOR", vai ser a "ACHA_TIPO_SABOR_ERRO". Trouxe o neutro. Não tive nenhum problema. Agora, se a gente olhar aqui a lista de sabores, deixa eu colocar aqui também o código do produto e os sabores de cada produto. Eu vou pegar aqui, por exemplo, esse produto aqui: o "1004327", ele é "MELANCIA", E melancia não está contida naquelas opções do "CASE".

[02:41] Então, eu vou pegar esse número aqui e vou rodar esse processo, passando o número do produto cujo resultado é "MELANCIA". Note: eu vou ter um erro. Esse erro é o erro do número "1339", que está me dizendo que a condição que eu achei não está no "CASE". Ou seja, eu preciso, no "CASE", sempre montar um "ELSE" porque eu preciso dar todas as opções para a consulta "CASE" me devolver resultados.

[03:25] Se eu passar para o "CASE" uma opção que não me traga nenhum resultado, ele traz o erro "1339". Mas tem como a gente passar esse erro, tratando o erro da mesma maneira que nós tratamos quando a gente mostrou para vocês alguns vídeos passados. Aquele capítulo específico do erro "HANDLER". Quer ver? Eu vou pegar então, esse "ACHA_TIPO_SABOR_ERRO", clico com o botão direito do mouse. Vou dar o "ALTER_STORED_PROCEDURE".

[03:58] E aí, aqui, eu vou escrever isso aqui antes. Aqui no "DECLARE". "DECLARE HANDLER_MSG", na verdade é a mensagem. Vou chamar isso aqui de "MSG_ERRO". Vai ser um Varchar de 30. Ponto e vírgula. E aí, depois, eu vou dar um "DECLARE CONTINUE HANDLER FOR". E aí, o número do erro que eu vou tratar é o "1339". E eu vou setar a variável "msgERRO".

[04:51] Vai ser igual a, por exemplo, o "CASE não está completo". Ponto e vírgula no final. E aí, aqui no final do "CASE", eu vou dar um select. Vou dar um select nessa variável, que é a mensagem de erro. Vamos lá. Vou dar um "APPLY". APPLY" de novo. "FINISH". Aí, eu agora, vou onde está isto aqui. Vou rodar de novo aquela minha rotina, passando como parâmetro aquele produto cujo sabor é "MELANCIA.

[05:47] A gente sabe que "MELANCIA" não está na opção do "CASE". Rodei. Olha lá. O "CASE NÃO ESTÁ COMPLETO". Ou seja, eu não tenho erro aqui embaixo. Ele rodou com sucesso. Não me retornou erro, mas me retornou a mensagem de que o "CASE" não está completo. Então, isso é uma forma, também, de a gente evitar que o processo tenha um erro quando a gente esquecer de colocar todas as opções do "CASE".


-----------------------------------------------------------------------
# 07CASE Condicional

https://cursos.alura.com.br/course/mysql-procedures/task/56716

## Transcrição

[00:00] Tem um jeito da gente usar o "CASE" de uma forma muito semelhante ao "IF/ELSE IF". Vamos fazer, então, o seguinte. Eu vou procurar essa rotina aqui "ACHA_STATUS_PRECO", que foi uma rotina que nós desenvolvemos lá quando nós vimos o "IF/ELSE IF". Clico com o botão direito do mouse sobre ela, "ALTER STORED PROCEDURE". Então, temos lá: se o produto fosse, relembrandoa rotina, se o produto fosse mais do que 12, seria um produto caro.

[00:38] Entre 7 e 12, seria um produto em conta. Se não, seria um produto barato. Eu vou chamar essa rotina, vou mudar o nome dela de "ACHA_STATUS_PREÇO". Vou escrever aqui usando "CASE". Vou dar um "APPLY", mas não vou confirmar essa mudança. Eu vou, simplesmente, copiar esse bloco aqui. Eu não preciso copiar o "DROP" da rotina. Vou copiar apenas o bloco de "DELIMITER" para baixo.

[01:12] Vou dar um "CANCEL". E aí, vou criar um script novo e vou dar um colar aqui. E aí, antes de rodar, eu vou editar a rotina que está aqui dentro. Essa estrutura, então, aqui onde eu usei o "IF/ELSE IF", eu vou mudar para o "CASE". E como é que eu uso? Dessa maneira. Por enquanto, eu não vou apagar não. Vou deixar as duas para eu poder fazer uma por cima da outra. Depois eu apago a estrutura "IF".

[01:45] Eu vou dar aqui um "CASE". Só que ao dar o "CASE", eu não especifico nenhum indicador que eu vou testar. E aí, eu venho aqui com o meu "WHEN". Aí, eu coloco "PREÇO > 12 THEN". Eu vou colocar essa mensagem. "WHEN". Quando houver esta condição aqui "THEN", vou colocar essa mensagem. E aí, eu vou estar colocando também aqui "WHEN", por exemplo, "VPRECO < 7 THEN O PRODUTO É BARATO."

[02:48] E aí, no final, eu dou um "END CASE". Então, a estrutura ficou assim. Vou fazer a mesma coisa do "IF/ELSE IF". Qual é a diferença em termos de processamento? Quando eu tenho o "IF/ELSE IF", o processo vai fazer os testes; ele testa a primeira, vai para segunda, vai para a terceira, vai para quarta. E aí, quando ele acha quem tem a condição, ele roda. No "CASE" não. No "CASE" , ele já tem previamente definida a opção.

[03:28] E ao entrar aqui, ele já vai diretamente para a opção que vai ser selecionada para estar executando isso. Ou seja, o "CASE" acaba sendo um pouco mais eficiente. Mas nós estamos falando de microssegundos de processamento, que não fazem muita diferença. Mas é uma outra estrutura de fluxo que você pode está utilizando. Vou rodar, então, a criação dessa stored procedure: "ACHA_STATUS_PREÇO_CASE". Deixa eu rodar.

[04:02] Executei. E aí agora, eu vou aqui de novo. Na chamada, eu vou chamar agora o "CALL". Vamos dar um "REFRESH" aqui antes. Então, a gente tem aqui as duas. A de cima, eu uso "IF". A de baixo, eu uso "CASE". Então, eu vou colocar aqui: "ACHA_STATUS_PRECO_CASE" e vou passar como parâmetro. Vou escolher esse produto aqui. Vamos executar. Produto barato. Esse segundo aqui , vamos executar. Produto caro. Então, eu mostrei para vocês como é que eu posso usar o "CASE" substituindo o "IF/ELSE IF". Valeu.


-----------------------------------------------------------------------
# 09Looping

https://cursos.alura.com.br/course/mysql-procedures/task/56717

## Transcrição

[00:00] A gente, até agora, viu controle de fluxo onde, dependendo de uma condição, eu faço alguma coisa e continuo a execução da minha stored procedure. Eu agora vou falar de "LOOPS". "LOOPS" são repetições, ou seja, comandos que vão ser feitos de forma repetida até que uma condição seja satisfeita. Aí, eu saio desse bloco de repetição. Esse bloco de repetição a gente chama de "LOOP".

[00:28] E aí, a gente usa, dentro do MySQL: "WHILE", "DO" e "END WHILE". Onde a gente usa dessa forma que está aqui em cima. "WHILE", uma condição. Caso a condição satisfaça, eu coloco o comando "DO", e eu coloco as linhas do que eu quero executar e termino o bloco com um "END WHILE". Vamos lá para o "WORBENCH" fazer um exemplo prático disso.

[00:56] Eu vou criar aqui um novo script e eu vou fazer o seguinte. Eu vou criar aqui uma tabela chamada "TAB_LOOPING", que vai ter só um campo "ID" que vai ser do tipo inteiro. Criar essa tabela aqui. Pronto. A tabela foi criada. Como é que vai ser minha rotina? Eu vou passar dois parâmetros: um número inicial e um número final. E aí, eu vou fazer um contador onde eu vou contar a partir do número inicial, com intervalos de 1 a 1, até o número final.

[01:44] E aí, cada interação dessa, eu incluo o valor da sequência dentro dessa tabela "LOOP". É isso que nós vamos fazer e a gente vai usar o "WHILE" para fazer esse "LOOPING" interativo. Vamos botar a mão na massa. Eu vou vir aqui. Clico com o botão direito do mouse. "CREATE STORED PROCEDURE". E eu vou chamar essa stored procedure de, vou colocar aqui "LOOPING_WHILE".

[02:19] Vou passar como parâmetro um número inicial que vai ser inteiro e um outro número que vai ser o número final, que também vai ser inteiro. Aqui dentro, eu vou declarar uma variável que vai ser um contador. Que vai ser inteira e aí, antes de começar a interação, a minha tabela "TAB_LOOPING" pode ter dados que foram gravados mediante a execução dessa stored procedure em um outro momento.

[03:00] Então, vou fazer o seguinte. Antes de começar a executar tudo, eu vou apagar os dados da tabela "TAB_LOOPING". Então, a "TAB_LOOPING" vai estar vazia. Vou inicializar o contador com, então média 7, o valor inicial. Inicializei o contador com o número inicial. Aí, eu vou escrever "WHILE VCONTADOR MENOR OU IGUAL A VNUM FINAL". Enquanto essa condição for verdadeira, eu vou estar dentro do "LOOP".

[03:57] E esse "LOOP" começa com um "DO" e termina com um "END". Então, aqui dentro é que eu vou estar executando. Aqui dentro que eu vou estar executando a repetição dos comandos. E aqui dentro, eu vou fazer assim. Eu vou dar um insert. "INTO", uma tabela de "LOOPING". O campo é "ID". E vou inserir como o valor dessa tabela o contador.

[04:37] Aqui, na verdade, não é "END" só. É "END_WHILE". Aqui, a gente fecha o "LOOP" com "END_WHILE". Por isso que estava dando um erro. Depois que inserir o valor do contador dentro da tabela, eu vou somar de 1. Aí, a variável "VCONTADOR" vai somar de 1. Aí, eu volto aqui para cima e vejo se a condição ainda satisfaz. Se ainda contador for menor ou igual ao número final, eu faço um novo insert e aumento o contador de um.

[05:23] Vamos ver se vai funcionar. Mas antes, depois que eu terminar tudo isso, eu exibo o conteúdo da tabela "TAB_LOOPING" para poder ver os computadores gravados dentro da tabela. Vou dar um "APPLY". O nome da procedure não está aqui, não. "LOOPING_WHILE" está legal. Vou dar o "APPLY". E "FINISH". Então, vamos lá. Vou chamar a "LOOPING_WHILE".

[06:01] E eu vou passar como parâmetro o número 1 vírgula e o número 10. Vou executar. Está lá: um, dos, três até 10. Se eu colocar aqui 1000, você vai ver que ele demora até um pouquinho mais para executar. Mas agora, ele gerou aqui uma tabela que vai de um até mil. Era isso que eu queria mostrar para vocês sobre a estrutura de "LOOPING" dentro da stored procedures.


-----------------------------------------------------------------------
# 10Número de notas para diversos dias

Sabendo que a função abaixo soma de 1 dia uma data:

`SELECT ADDDATE(DATA_VENDA, INTERVAL 1 DAY);`

Faça uma Stored Procedure que, a partir do dia 01/01/2017, iremos contar o número de notas fiscais até o dia 10/01/2017. Devemos imprimir a data e o número de notas fiscais. Chame esta Stored Procedure de Soma_Dias_Notas.

Dicas:

Declare variáveis do tipo `DATE`: Data inicial e final; Faça um loop testando se Data inicial < Data final; Imprima na saída do MYSQL a data e o número de notas. Não esquecer de converter as variáveis para VARCHAR; Some a data em 1 dia.


-----------------------------------------------------------------------
# 11Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Abra um novo script MYSQL.

2) Digite e execute:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `cliente_novo_velho`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `cliente_novo_velho`(vCPF VARCHAR(20))
BEGIN
   DECLARE vResultado VARCHAR(20);
   DECLARE vDataNascimento DATE;
   SELECT DATA_DE_NASCIMENTO INTO vDataNascimento FROM
   tabela_de_clientes WHERE CPF = vCPF;
   IF vDataNascimento < '20000101' THEN
      SET vResultado = 'CLIENTE VELHO';
   ELSE
      SET vResultado = 'CLIENTE NOVO';
   END IF;
   SELECT vResultado;
END$$
DELIMITER ;
```

1) Execute a SP.

```csharp
Call cliente_novo_velho ('19290992743');
```

![0.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/04/0.png)

1) Esta SP usa a estrutura IF-THEN-ELSE para classificar um cliente como sendo novo ou velho, baseado em sua idade.

2) Vamos ver outra estrutura de controle de fluxo. Digite e execute:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `acha_status_preco_2`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `acha_status_preco_2` (vProduto VARCHAR(50))
BEGIN
   DECLARE vPreco FLOAT;
   DECLARE vMensagem VARCHAR(30);
   SELECT PRECO_DE_LISTA INTO vPreco FROM tabela_de_produtos
   WHERE codigo_do_produto = vProduto;
   IF vPreco >= 12 THEN
      SET vMensagem = 'PRODUTO CARO.';
   ELSEIF vPreco >= 7  AND vPreco < 12 THEN
      SET vMensagem = 'PRODUTO EM CONTA.';
   ELSE
      SET vMensagem = 'PRODUTO BARATO.';
   END IF;
   SELECT vMensagem;
END$$
DELIMITER ;
```

1) Digite e execute:

```csharp
Call acha_status_preco_2 ('1000889');
```

1) Observe que a estrutura `IF-THEN-ELSEIF` permite encadear diversos testes.

2) O encadeamento de condições pode ser expresso, também, usando o comando CASE-END-CASE. Para isso digite e execute:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `acha_tipo_sabor`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `acha_tipo_sabor`(vProduto VARCHAR(50))
BEGIN
  DECLARE vSabor VARCHAR(50);
  SELECT SABOR INTO vSabor FROM tabela_de_Produtos
  WHERE codigo_do_produto = vProduto;
  CASE vSabor
  WHEN 'Lima/Limão' THEN SELECT 'Cítrico';
  WHEN 'Laranja' THEN SELECT 'Cítrico';
  WHEN 'Morango/Limão' THEN SELECT 'Cítrico';
  WHEN 'Uva' THEN SELECT 'Neutro';
  WHEN 'Morango' THEN SELECT 'Neutro';
  ELSE SELECT 'Ácidos';
  END CASE;
END$$
DELIMITER ;
```

1) Digite e execute:

```csharp
CALL acha_tipo_sabor('1000889');
```

1) Uma estrutura derivada da mostrada é o CASE-NOT-FOUND. Para isso vamos criar a SP Acha_Tipo_Sabor_Erro. Digite e execute:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `acha_tipo_sabor_erro`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE  PROCEDURE `acha_tipo_sabor_erro`(vProduto VARCHAR(50))
BEGIN
  DECLARE vSabor VARCHAR(50);
  SELECT SABOR INTO vSabor FROM tabela_de_Produtos
  WHERE codigo_do_produto = vProduto;
  CASE vSabor
  WHEN 'Lima/Limão' THEN SELECT 'Cítrico';
  WHEN 'Laranja' THEN SELECT 'Cítrico';
  WHEN 'Morango/Limão' THEN SELECT 'Cítrico';
  WHEN 'Uva' THEN SELECT 'Neutro';
  WHEN 'Morango' THEN SELECT 'Neutro';
  END CASE;
END$$
DELIMITER ;
```

1) Esta SP difere da anterior apenas porque foi retirada a linha abaixo.

```sql
ELSE SELECT 'Ácidos';
```

Estamos criando uma situação onde nenhuma das condições podem ser satisfeitas.

1) Execute a SP:

```csharp
CALL acha_tipo_sabor_erro('1004327');
```

1) Temos o erro:

![1.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/04/1.png)

1) Para evitar de não incluirmos opções no CASE que contemplem todas as situações podemos acrescentar o tratamento de erro. Altere a SP executando:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `acha_tipo_sabor_erro`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE  PROCEDURE `acha_tipo_sabor_erro`(vProduto VARCHAR(50))
BEGIN
  DECLARE vSabor VARCHAR(50);
  DECLARE msgErro VARCHAR(30);
  DECLARE CONTINUE HANDLER FOR 1339 SET msgErro = 'O case não está completo';
  SELECT SABOR INTO vSabor FROM tabela_de_Produtos
  WHERE codigo_do_produto = vProduto;
  CASE vSabor
  WHEN 'Lima/Limão' THEN SELECT 'Cítrico';
  WHEN 'Laranja' THEN SELECT 'Cítrico';
  WHEN 'Morango/Limão' THEN SELECT 'Cítrico';
  WHEN 'Uva' THEN SELECT 'Neutro';
  WHEN 'Morango' THEN SELECT 'Neutro';
  END CASE;
  SELECT msgErro;
END$$
DELIMITER ;
```

1) Execute a SP:

```csharp
CALL acha_tipo_sabor_erro('1004327');
```

Teremos o erro tratado.

![2.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/04/2.png)

1) O Case Condicional utiliza uma estrutura de Case semelhante a usada quando executamos um comando SELECT. Digite e execute:

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `acha_status_preco_case`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `acha_status_preco_case`(vProduto VARCHAR(50))
BEGIN
    DECLARE vPreco FLOAT;
    DECLARE vMensagem VARCHAR(30);
    SELECT PRECO_DE_LISTA INTO vPreco FROM tabela_de_produtos
    WHERE codigo_do_produto = vProduto;
    CASE
    WHEN vPreco >= 12 THEN SET vMensagem = 'PRODUTO CARO.';
    WHEN vPreco >= 7 AND vPreco < 12 THEN  SET vMensagem = 'PRODUTO EM CONTA.';
    WHEN vPreco < 7 THEN SET vMensagem = 'PRODUTO BARATO';
    END CASE;
    SELECT vMensagem;
END$$
DELIMITER ;
```

1) Digite e execute:

```csharp
CALL acha_status_preco_case('1004327');
```

1) A estrutura de Loop permite repetir um conjunto de comandos até que determinada condição aconteça. Digite e execute:

```sql
CREATE TABLE TAB_LOOPING (ID INT);
```

1) Após a criação de uma tabela auxiliar digite e execute

```sql
USE `sucos_vendas`;
DROP procedure IF EXISTS `looping_while`;
DELIMITER $$

USE `sucos_vendas`$$
CREATE PROCEDURE `looping_while`(vNumInicial INT, vNumFinal INT)
BEGIN
   DECLARE vContador INT;
   DELETE FROM TAB_LOOPING;
   SET vContador = vNumInicial;
   WHILE vContador <= vNumFinal
   DO
      INSERT INTO TAB_LOOPING (ID) VALUES (vContador);
      SET vContador = vContador + 1;
   END WHILE;
   SELECT * FROM TAB_LOOPING;
END$$
DELIMITER ;
```

1) Vamos executar a SP passando como parâmetro um número inicial e um número final para criação de uma sequência numérica na tabela temporária. Digite e execute:

```cpp
call looping_while (1, 1000);
```

![3.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/04/3.png)

Teremos uma sequência numérica que vai de 1 a 1000.


-----------------------------------------------------------------------
# 12O que aprendemos?

Nesta aula, aprendemos:

- O control de fluxo `IF-THEN-ELSE`.
- Uma variação do controle anterior chamado `IF-THEN-ELSEIF`.
- A estrutura `CASE`;
- Como tratar erros no `CASE` quando nem todas as opções são contempladas;
- o `CASE` condicional, semelhante ao usado nos comandos SQL;
- O uso de Loops para repetir um conjunto de comandos até uma condição ser satisfeita.


-----------------------------------------------------------------------
# 01Problema do Select Into

https://cursos.alura.com.br/course/mysql-procedures/task/56718

## Transcrição

[00:00] Vou voltar um pouquinho e rever aquele comando que a gente já tem utilizado muito, que é o "SELECT_INTO". Para que a gente possa fazer uma consulta na base de dados, e o resultado dessa consulta atribuir a uma variável que foi definida no "DECLARE". Vou criar aqui uma outra stored procedure que eu vou chamar aqui de "TESTE_SELECT_INTO".

[00:31] Eu vou fazer a seguinte coisa: eu vou declarar uma variável, que eu vou chamar de "VNOME". E ela vai ser um "varchar (50)". Aí, eu vou fazer agora um select na tabela de clientes, para buscar o nome do cliente, e jogar dentro dessa variável "VNOME". "INTO", não, na verdade é "NOME", que é o nome do campo, "INTO_VNOME_FROM_TABELA_DE_CLIENTES".

[01:13] E aí, eu quero ver o resultado disso. Antes de rodar, deixa eu mostrar o quê eu estou fazendo aqui. Eu estou aqui selecionando todos os clientes da tabela de clientes. Eu não tenho aqui nenhum "WHERE". "WHERE_CLIENTE = 1", "WHERE_CLIENTE_SÓ_DO_RIO_DE_JANEIRO". Eu não estou segregando a consulta. Eu estou trazendo todo mundo.

[01:50] Então, o quê vai acontecer? Esse retorno aqui do campo nome não será apenas um valor, será uma consulta inteira. E eu vou atribuir esse vetor a uma variável que é escalar. Só que eu não quero fazer isso. Eu gostaria de jogar o conteúdo de um "ARRAY", de um vetor para uma variável, para eu poder percorrer esse "ARRAY" e fazer alguma coisa com ele.

[02:24] Será que o "SELECT_INTO" desse jeito vai funcionar? Será que ele vai ser inteligente o suficiente para entender que o resultado do meu select é um "ARRAY"? Então, eu, automaticamente, quando usar o "INTO", eu vou jogar isso para a variável, ela vai se transformar numa "ARRAY"? Vamos testar. Vou dar um "APPLY"."APPLY" de novo. "FINISH".

[02:51] E aí, eu vou criar aqui agora um novo script. E eu vou chamar o meu teste "SELECT_INTO". Não tem parâmetro. Vou rodar. Note: ele me trouxe um erro de número "1172". O resultado consiste de mais de uma linha, ou seja, quando eu uso o "SELECT_INTO", eu tenho que garantir que aquele select só retorne uma linha. Aí sim. Aquele valor que está vindo, eu atribuo à variável que está depois do "INTO".

[03:51] Mas e se eu quisesse gravar numa variável um vetor para eu poder percorrer esse ambiente? O "SELECT_INTO" não me resolveria esse problema. Na verdade, o que resolve esse problema é uma outra estrutura que existe no MySQL chamada "CURSOR". Esse sim é uma variável como se fosse uma "ARRAY", onde eu posso dar um select e no resultado do "CURSOR", do select desculpe.

[04:27] Eu jogo para o "CURSOR". Então, eu tenho como se fosse um vetor em memória, em que eu posso trabalhar ele, por exemplo, através de um "LOOPING". E aí cada elemento deste vetor, eu vou usar para um tipo de processamento. Então, o "SELECT_INTO" variável não me resolve quando eu tenho que buscar elementos que sejam mais do que uma linha. Inclusive, o "CURSOR", ele também pode guardar na sua estrutura interna mais de uma coluna. Mas aí, sobre cursores, a gente vai ver mais no próximo vídeo.

-----------------------------------------------------------------------
# 03Definição de Cursor

https://cursos.alura.com.br/course/mysql-procedures/task/56719

## Transcrição

[00:00] Então, a gente viu, no vídeo anterior, que eu não consigo associar a uma variável quando o resultado do meu select for um vetor. Então, o "SELECT INTO" não funciona nesses casos. E aí, eu disse para vocês que existe uma estrutura chamada "CURSOR" que faz isso. Então, eu vou apresentar um pouquinho. Como é que funciona essa estrutura. Então, o "CURSOR" é uma estrutura que é implementada no MySQL que permite uma interatividade linha a linha através de uma determinada ordem.

[00:33] Essa ordem, claro, é determinada pelo comando select que define o "CURSOR". Temos algumas fases para usar o "CURSOR". Primeiro, eu faço uma declaração. Eu declaro o "CURSOR", digo qual é o nome dele e especifico qual é o comando "SQL" que está associado a esse "CURSOR". Depois, nós abrimos o "CURSOR", ou seja, quando é definido, ele ainda não está disponível para uso.

[01:00] Eu abro o "CURSOR" e aí, eu vou percorrer linha a linha na ordem com que o cursor é organizado. E aí, quando eu chego no final do "CURSOR", eu fecho o mesmo e limpo a memória. Vamos olhar isso de uma forma mais gráfica. Então assim, eu tenho essa tabela aqui do lado e eu defino um "CURSOR" simplesmente fazendo esse select aqui. Eu vou pegar o campo "NOME DA TABELA".

[01:31] E aí, ele vai me dar esse vetor aqui com todos os nomes, apenas, que vão ficar carregados dentro do meu "CURSOR". Depois, eu abro o "CURSOR", então ele fica à minha disposição. Eu posso me referenciar a ele nesse momento. Depois, eu dou um comando "FETCH". O comando "FETCH", ele vai pegar a posição atual que eu estou olhando o "CURSOR" e buscar aquela informação.

[02:02] Então, eu vou buscar a posição atual que eu estou no o "CURSOR" e jogar na variável "NOME". Então, no caso, a primeira posição, porque eu acabei de abrir o "CURSOR", na primeira posição eu tenho o João. Eu vou jogar João para a variável "NOME". Depois, eu vou dando "FETCH" e, na medida em que eu vou dando "FETCH", eu vou avançando dentro do "CURSOR" até o final.

[02:29] Quando chegar no último "FETCH", eu vou ter carregado aqui o nome Lúcia. E aí, finalmente, eu fecho o "CURSOR" e ele é limpo da memória. Vamos agora fazer um pequeno exemplo mostrando a manipulação dos cursores. Então, eu vou aqui cancelar a apresentação. Vir aqui para o "MySQL WORKBENCH" e eu vou criar aqui uma stored procedure. Eu vou chamar ela de "CURSOR_PRIMEIRO_CONTATO".

[03:11] Vou declarar uma variável que vai se chamar "VNOME". Vai ser do tipo "varchar (50)". E aí, agora, vou definir o meu "CURSOR". Vou dar aqui o meu "DECLARE C", vai ser o nome do "CURSOR". Escrevo "CURSOR FOR" e aí, eu faço um comando select. "SELECT NOME FROM TABELA_DE_CLIENTES". Depois desse select, eu vou escrever isso daqui: "LIMIT 4".

[04:14] Para quem não se lembra, quando a gente coloca a cláusula "LIMIT" depois de um select, eu estou limitando a minha saída para 4 linhas. Eu estou fazendo isso só para, realmente, eu saber de antemão que o meu "CURSOR" tem quatro elementos. Feito isso, eu vou abrir o "CURSOR". "OPEN" e eu abro o "CURSOR C". Ao abrir o "CURSOR", eu estou na primeira posição.

[04:46] Então, eu vou pegar o elemento da primeira posição do "CURSOR" e jogar para a variável "VNOME". Então, é "FETCH C INTO VNOME". E aí, eu vou dar um select aqui para eu exibir o conteúdo de "VNOME". Nesse caso aqui, eu estou na primeira posição. Só que se eu der de novo esses dois comandos assim, eu passo para a segunda posição. Então, eu dou um novo "FETCH".

[05:30] Ao fazer isso, eu vou da primeira para a segunda posição, busco o elemento da segunda posição e exibo através do select. E como eu sei que eu tenho quatro posições, eu vou repetir, então, o "FETCH" e o select umas duas vezes. Totalizando quatro. E aí, claro, no final, eu fecho o "CURSOR". Dou um "CLOSE" e o nome do "CURSOR". Então, aqui, eu declarei a variável. Defini o "CURSOR". Abri o "CURSOR". Dei o "FETCH".

[06:12] Busquei no "CURSOR" e joguei na variável e exibi a variável. E eu faço isso quatro vezes. E aí, depois no final, eu fecho o "CURSOR". Vou dar o "APPLY". "APPLY" de novo. "FINISH". E aí, eu vou rodar essa "STORED PROCEDURE CURSOR_PRIMEIRO_CONTATO". Vamos ver o que vai acontecer. Ele me exibiu aqui 4 resultados. Cada resultado foi um select.

[06:54] Então, o primeiro cliente é "Érica Carvalho", segundo "Fernando Cavalcante", terceiro "César Teixeira" e quarto "Marcos Nogueira". Então, se eu vier aqui e fizer isso daqui: "SELECT NOME FROM TABELA_DE_CLIENTES LIMIT 4". Se eu rodar esses dois comandos aqui, eu tenho aqui os quatro primeiros clientes que foram obtidos através desse select, que foi a fonte do "CURSOR".

[07:27] E note que esses quatro estão sendo representados aqui. Só que tem um problema. Eu sabia de antemão que o meu "CURSOR" retornaria, teria quatro posições porque eu forcei, no meu select para trazer quatro. Por isso, eu escrevi o "FETCH" 4 vezes. Mas, em 99,99% dos casos, eu não sei o tamanho do meu "CURSOR". Eu não sei se ele acabou ou não antes de dar um "FETCH", ou seja, ao dar um "FETCH", eu preciso saber se o "CURSOR" tem ainda espaço para isso ou não. Como é que eu faço isso? Você vai ver isso no próximo vídeo.


-----------------------------------------------------------------------
# 04Looping com Cursor

https://cursos.alura.com.br/course/mysql-procedures/task/56720

## Transcrição

[00:00] Então, ok. Eu me deparei, então, com o seguinte problema. Eu tenho que saber quando que o "CURSOR" vai acabar. Ou mais precisamente, antes de dar um "FETCH", eu tenho que saber se o"CURSOR" acabou ou não. Olha só isso aqui. Eu vou pegar a stored procedures que nós criamos , a "CURSOR_PRIMEIRO_CONTATO". Vou dar um "ALTER_STORED_PROCEDURES" e, aqui, eu vou dar um outro "FETCH".

[00:33] Ou seja, eu estou dando aqui cinco "FETCH"s. Esse aqui é o quinto. Só que o "CURSOR" só tem quatro posições. O quê que vai acontecer? Eu vou dar um "APPLY". "APPLY" de novo. "FINISH". E aí, eu vou executar de novo o "CURSOR_PRIMEIRO_CONTATO". Note, ele vai fazer os quatro, mas quando eu der o quinto "FETCH", ele vai me apresentar esse erro aqui "1329 NO DATA - ZERO ROWS FETCHED, SELECTED, OR PROCESSED".

[01:11] Ou seja, eu cheguei ao final do "CURSOR". OK, eu forcei o erro. Mas, normalmente, eu não sei quantas linhas eu tenho. Eu não sei quantas posições o "CURSOR" tem. Como é que a gente faz isso? Bem, eu vou fazer uma stored procedures agora, aqui, para vocês, usando o "LOOPING". E na condição de "LOOPING", na condição lá do meu "WHILE" eu vou testar para saber se o "CURSOR" já terminou. Se ele terminou, eu paro.

[01:44] Se ele não terminou, eu continuo dando "FETCH". Vamos, então, fazer isso. Eu vou criar uma nova stored procedure que eu vou chamar de "CURSOR_LOOPING". E aí eu vou repetir as mesmas coisas que eu fiz na outra, eu vou dar um "DECLARE VNOME varchar(5)". Vou declarar o "CURSOR". "DECLARE CCURSOR FOR SELECT NOME FROM TABELA_DE_CLIENTES LIMIT = 4".

[02:38] Agora que vem o lance. Eu preciso ter uma variável, criar uma variável dentro da minha stored procedures, e que ela diga se o "CURSOR" tem ou não elementos. E aí, essa variável vai ser 1 ou 0. Zero significa falso, ou seja, não é fim do "CURSOR". Um significa verdadeiro. Cheguei ao fim. Então, vou criar essa variável aqui em cima, "FIM_DO_CURSOR". Vai ser um "varchar (1).

[03:20] Não, vou colocar "INT". E vai ser um valor "DEFAULT 0", ou seja, o fim do "CURSOR" é falso porque eu vou começar a trabalhar com o "CURSOR". Aí, aqui embaixo, antes de abrir o "CURSOR", eu vou declarar uma "ERROR HANDLER" .Ou seja, caso haja um erro, você vai mudar essa variável de 0 para 1. E aí, tem um erro específico. Que erro é esse específico? Vocês vão ver.

[03:58] Vou, aqui, dar um "DECLARE CONTINUE", ou seja, não para o programa caso tenha erro. "HANDLER FOR NOT FOUND". Ao escrever o "FOR NOT FOUND". Eu estou definindo que, o tipo de erro que eu não quero que 'break' o processamento da minha stored procedure. É um erro do tipo "NOT FOUND". E quando eu dou um "FETCH" numa posição do "CURSOR", onde esta posição do "CURSOR", ela não exista mais elementos é o erro do tipo "FOR NOT FOUND".

[04:50] E aí, eu vou colocar aqui um "SET FIM_DO_CURSOR = 1", ou seja, quando achar o erro de "NOT FOUND", eu passo o "CURSOR" de zero para um. Desculpe, o "CURSOR" não, a variável "FIM_DO_CURSOR" de zero para um. Aí, eu vou dar aqui o meu "OPEN". Vou abrir o "CURSOR C" e aí, eu posso colocar o meu "WHILE FIM_DO_CURSOR". Eu vou fazer esse "LOOPING" sempre enquanto o fim do "CURSOR" for igual a zero.

[05:13] Eu tenho o "DO" e eu tenho o "END WHILE" aqui. E aqui dentro do "DO" e "END WHILE", eu vou dar o meu "FETCH C INTO VNOME" e depois, eu vou dar o meu "SELECT VNOME". Quer dizer, aquela estrutura que eu repetia Nvezes, ela está aqui dentro da estrutura do "WHILE". E aí, no final, eu dou o meu "CLOSE C". Então, o quê que ele vai fazer? Quando eu começar aqui o meu "LOOPING", o fim do curso é zero e eu estou na primeira posição.

[06:26] Vou dar um "FETCH" e vou dar um "SELECT. Volto para o "LOOPING", o fim do "CURSOR" é zero. Vou dar outro "FETCH" e outro select. "FETCH", select. Quando eu fizer a quarta vez, eu vou entrar aqui no "WHILE", o fim do "CURSOR" ainda é zero. E aí, eu vou dar meu quinto "FETCH". Ao dar o meu quinto "FETCH", eu desvio para o "ERROR HANDLER".

[06:55] E como é do tipo "CONTINUE", ele não vai parar o programa. Mas antes de continuar, ele vai dizer que o fim do "CURSOR" é igual a 1. Aí, ele vai escrever de novo "VNOME", talvez seja um probleminha porque aí ele vai acabar tendo que escrever o "VNOME" duas vezes. Tudo bem. Depois a gente melhora isso. E aí, quando ele for para o "WHILE", esse cara vai ser igual a um, eu vou acabar e eu vou dar o "CLOSE".

[07:24] Vou dar o "APPLY". "APPLY". "FINISH". Então, é "CURSOR LOOPING". Então, eu vou executar aqui. Vamos executar? Está lá. Fez o primeiro. Fez o segundo. Fez o terceiro. Fez o quarto e aquele probleminha. Ele acabou fazendo o quinto duas vezes. Na verdade, para a gente corrigir isso. Onde está aqui, vamos dar um "REFRESH" aqui. Eu teria que fazer isso daqui.

[08:12] "IF FIM_DO_CURSOR = 0 THEN". Aí eu rodo o "SELECT NOME" e o "END IF" aqui. Ou seja, eu só vou executar o select se eu ainda não cheguei no fim. Então, quando ele fizer o "FETCH" pela quinta vez, o fim do "CURSOR" vai passar de 0 para 1, eu não faço o select e saio do "LOOPING". Vamos rodar de novo. Agora sim. Ele escreveu quatro vezes como deveria: o primeiro, o segundo, o terceiro e o quarto.

[08:59] A gente pode, inclusive, fazer isso daqui. Esse é o último? É. Por exemplo. Vamos ver aqui. Dar o "ALTER STORED PROCEDURE" mais uma vez. Não. Não é essa. É o "CURSOR LOOPING". Eu vou tirar esse "LIMIT" aqui. Porque agora eu não preciso mais limitar o tamanho do "CURSOR" porque eu botei "LIMIT = 4", porque eu queria fazer quatro "FETCH"s.

[09:32] Agora, eu tenho um "LOOPING". Então, eu não preciso saber de antemão o tamanho do "CURSOR". Vou dar "APPLY". "APPLY" de novo. "FINISH". Então, agora se eu fizer isso daqui, ele vai fazer, ele vai me mostrar todos os clientes. Vamos rodar aqui. Olha lá. Me mostrou vários resultados. Um resultado para cada cliente da tabela e ele foi até o final do "CURSOR".


-----------------------------------------------------------------------
# 05Achando o valor total do crédito.

Crie uma Stored Procedure usando um cursor para achar o valor total de todos os créditos de todos os clientes. Chame esta SP de Limite_Creditos.

Dicas:

Declare duas variáveis: Uma que recebe o limite de crédito do cursor e outra o limite de crédito total; Faça um loop no cursor e vá somando na variável limite de crédito total o valor do limite de cada cliente; Exiba o valor total do limite.


-----------------------------------------------------------------------
# 06Cursor acessando mais de um campo

https://cursos.alura.com.br/course/mysql-procedures/task/56721

## Transcrição

[00:00] Então, eu resolvi o problema do tamanho do "CURSOR". Eu não preciso saber o tamanho do "CURSOR", basta eu colocar aquele "ERROR HANDLER" para mudar o tamanho de uma variável. E fico testando essa variável toda vez que eu vou buscar um novo elemento do "CURSOR". Mas se nós olharmos a rotina que nós desenvolvemos aqui, note que eu associe o "CURSOR" a apenas uma variável.

[00:31] E se eu quiser associar a mais de uma variável? Vamos fazer, então, um exemplo mostrando isso. O meu objetivo vai ser o seguinte. Eu tenho a minha tabela de clientesa aqui. Deixa eu até rodar o select dela novamente. Vou rodar ela aqui. Eu tenho aqui o nome do cliente e o endereço que é a rua, o bairro, a cidade, o estado e o CEP. Digamos que eu queira, então, montar uma saída que seja todos esses campos concatenados.

[01:13] Eu vou jogar para um "CURSOR" todas essas colunas e eu quero exibir esses valores, digamos assim, concatenados. Então, vamos lá. Eu vou criar aqui a stored procedure. Vou chamar de "LOOPING_CURSOR_MÚLTIPLAS_COLUNAS". Então, eu vou começar declarando a variável de fim de "CURSOR", que vai ser uma inteira e vai começar com 0.

[02:05] Eu vou ter que declarar uma variável para cada coluna que eu vou ler do "CURSOR". Então, se eu vou ler endereço, bairro, cidade, estado e CEP, e vou também botar o nome. Então, eu vou criar essas seis variáveis aqui. Como elas vão ser do mesmo tipo, eu posso colocar assim "VNOME", "VENDEREÇO", "VCIDADE", "VESTADO", "VCEP", "varchar (50). Na verdade, para cidade, estado e CEP, que é "varchar (50).

[02:52] Eu vou colocar, aqui, essas aqui como sendo "varchar (150)". Eu já declarei as variáveis que vão receber os valores do "CURSOR" e a variável que controla o fim do "CURSOR". Então, agora, vamos declarar o "CURSOR". "DECLARE CURSOR FOR", vou colocar aqui embaixo. "SELECT NOME, ENDEREÇO_1, CIDADE, ESTADO, CEP FROM TABELA_DE_CLIENTES".

[03:39] Então, eu joguei para o "CURSOR" não um vetor de uma única coluna, mas uma matriz de cinco colunas. Porque no meu "CURSOR", eu vou ter essas cinco colunas. Então, é como se fosse uma tabela em memória com cinco colunas e várias linhas. Só que agora eu vou colocar o "ERROR HANDLER". "DECLARE CONTINUE HANDLER FOR NOT FOUND SET FIM_DO_CURSOR = 1".

[04:33] Vou abrir o "CURSOR" e vou fazer o meu "WHILE". "WHILE FIM_DO_CURSOR = 0". "DO". "END WHILE". E no final, "CLOSE C". Dentro do comando do "DO" e "END WHILE", eu vou fazer um "FETCH C INTO", aí agora, eu vou colocar as variáveis na mesma ordem, atenção, na mesma ordem que eu coloquei na declaração do select. Então, vai vir "VNOME", a primeira. Depois "VENDEREÇO", é a segunda. "VCIDADE, VESTADO, VCEP".

[05:42] Aí, eu vou testar. "FIM_DO_CURSOR = 0". "END IF". E aí, aqui dentro, eu vou dar o meu select. Então, eu vou usar a função "CONCAT" e eu vou concatenar todas as variáveis que receberam valores do "CURSOR". Então, "VNOME" concatenado com a palavra seguinte endereço. Dois pontos. Concatenado com "VENDEREÇO". Concatenado com uma vírgula. Concatenado com "VCIDADE". Concatenado com um traço.

[06:37] "VESTADO". Concatenado com a palavra "CEP", dois pontos. Concatenado com "VCEP". Vou dar um enter aqui para ficar mais claro aqui, para ver o que nós fizemos. Então, eu estou concatenando todas as variáveis em uma única saída. Eu acho que está certo. Vamos ver. "APPLY". "APPLY" de novo. Então, é o "LOOPING_CURSOR_MÚLTIPLAS_COLUNAS".

[07:15] Deixa eu executar então aqui. "CALL LOOPING_CURSOR_MÚLTIPLAS_COLUNAS'. Vamos pegar o nome certo: "LOOPING_CURSOR_MÚLTIPLAS_COLUNAS". Agora foi. Você vê que ele escreveu isso aqui na saída: "Fábio Carvalho Endereço: R. dos Jacarandás da Península, Rio de Janeiro - RJ22002020". Só o CEP que ficou meio junto. Na verdade, depois do estado teria a palavra CEP.

[08:51] E depois CEP. É. Eu vou corrigir aqui. Aqui tem uma vírgula. Aqui eu tinha colocado uma letra mais uma vírgula. Vou dar "APPLY". "APPLY" de novo. "FINISH". Vamos ver se agora funciona. Agora ficou certo. "Fábio Carvalho Endereço: R. dos Jacarandás da Península, Rio de Janeiro - RJ CEP: 22002020". Então, pronto. Mostrei para vocês o exemplo de como é que eu consigo usar, dentro do meu "CURSOR", múltiplas colunas.


-----------------------------------------------------------------------
# 07Calculando o valor total do faturamento

Crie uma Stored Procedure usando um cursor para achar o valor total do faturamento para um mês e um ano.

Dicas:

Declare três variáveis: Uma que recebe a quantidade, outra o preço e uma terceira que irá acumular o faturamento; Faça um loop no cursor e vá somando o faturamento de cada nota; Exiba o valor total do limite; Lembrando a consulta que obter o faturamento dentro de um mês e ano.

```sql
SELECT INF.QUANTIDADE, INF.PRECO FROM ITENS_NOTAS_FISCAIS INF
INNER JOIN NOTAS_FISCAIS  NF ON NF.NUMERO = INF.NUMERO
WHERE MONTH(NF.DATA_VENDA) = 1 AND YEAR(NF.DATA_VENDA) = 2017
```

Chame esta Stored Procedure de Mais_Um_Campo.

-----------------------------------------------------------------------
# 08Entendendo Função

https://cursos.alura.com.br/course/mysql-procedures/task/56722

## Transcrição

[00:00] Para quem já trabalha com programação, sabe a diferença entre sub-rotina e função. Sub-rotina executa uma série de comandos E aí, pronto. São comandos que são repetitivos. Eu quero executar aquela série de comandos várias vezes, então eu crio uma sub-rotina. Função são comandos que, na verdade, vão ser executados, mas no final vai me resultar num valor.

[00:31] A função me retorna algo para eu poder usar, ou em outras funções, ou em outras sub-rotinas. Por que eu estou falando disso? Porque, na verdade, a nossa stored procedure é como se fosse uma sub-rotina. A stored procedure tem uma série de comandos que eu executo, interage com o banco de dados e pronto. A stored procedure pode rodar com sucesso ou com erro. Mas aí, é um problema interno do comando.

[01:00] A stored procedure não retorna nada para mim. Às vezes, eu posso colocar um select para ver o resultado final. Mas, na verdade, a stored procedures, ela executa bastante comandos de forma repetitiva e acabou. A função não. A função vai executar uma série de comandos no MySQL. Cálculos, contas, não interessa. Só que, no final, ela tem que me retornar alguma coisa.

[01:26] E aí, essa função eu posso usar em outras funções ou dentro de stored procedures ou, até mesmo, dentro de comandos select, update e assim por diante. Aqui em cima, eu mostro para vocês a forma com que eu crio uma função no MySQL. Eu coloco "CREATE FUNCTION", o nome da função, entre parênteses unsparâmetros. E aí, depois, eu entro com essa cláusula "RETURNS DATATYPE".

[01:55] O "DATATYPE" é o tipo de dado que essa função vai retornar. A função pode retornar uma data, pode retornar um número, pode retornar um texto. Então, aqui eu vou dizer o tipo de retorno. Depois, eu tenho um "BEGIN" e um "END". E aqui dentro, eu tenho "DECLARE"s, comandos normais. Os mesmos usados na stored procedure, porém eu sou obrigado, em algum momento desse código, ter esse comando "RETURN".

[02:23] E aqui dentro uma variável, ou valor, ou uma expressão, não interessa. Alguma coisa e esse "STATEMENT" aqui, ele tem que bater com o "DATATYPE". Uma observação: para o seu ambienteMySQL poder criar funções é preciso que você estipule este parâmetro - "LOG_BIN_TRUST_FUNCTION_CREATORS". Normalmente, as instalações MySQL não permitem que você crie funções.

[03:01] Mas se você especificar esse parâmetro, o seu ambiente consegue criar funções. É só uma observação antes de a gente poder fazer alguns exemplos práticos. Então, vamos lá. Entrei aqui para o "WORKBENCH" e eu vou aproveitar uma stored procedure que eu fiz, que é esse "ACHAR_TIPO_SABOR". Essa stored procedure aqui, que nós criamos em algum momento durante esse treinamento.

[03:37] Se eu clicar com o botão direito do mouse e der aqui um "ALTER STORED PROCEDURE". Relembrando, a gente usa aqui, baseado numa variável sabor, o sabor que eu estou retornando do banco. Eu vejo se ele é "CÍTRICO", "NEUTRO" ou "ÁCIDO". Eu vou fazer uma função em que eu vou passar como parâmetro o sabor e, eu quero como retorno se ele é "CÍTRICO", "NEUTRO" ou "ÁCIDO".

[04:09] Eu vou copiar esse código que está aqui. Vou colar aqui no notepad, só para manter ele salvo porque eu vou reaproveitar ele na criação da minha função. Então, deixa eu fechar essa janela aqui. A função, ela é criada aqui in "FUNCTIONS". Eu dou botão direito do mouse sobre "FUNCTIONS". "CREATE FUNCTIONS". Então, aqui eu vou fazer o seguinte. Eu vou criar a função com um f na frente. "F_ACHA_TIPO_SABOR".

[04:52] Esse é o nome da função. E eu vou passar como parâmetro o sabor que é um "varchar (50)". O Retorno vai ser um texto. Então, eu vou botar aqui um "varchar (20)". E aqui dentro, eu já vou dar um "DECLARE". Vou pegar uma variável que eu vou chamar "VRETORNO". Vai ser do tipo "varchar (20). E ela vai ter como "DEFAULT" "VAZIO". Não tem esse igual. É assim.

[05:44] "VSABOR" é o parâmetro da função. Então, eu vou pegar aqui esse código. Vou jogar aqui. Só que ao invés de ter aqui um select, eu vou dizer o seguinte. Eu vou dizer que "SET VRETORNO" recebe a palavra "CÍTRICO. E aí, eu vou copiar isso daqui e colar aqui, aqui, aqui, aqui e aqui. Então, vamos lá. "VSABOR" é um parâmetro. Entrou na função.

[06:31] Se ele for "LIMA/LIMÃO", a variável retorno, que foi declarada aqui, e que por padrão ela é vazia, recebe a palavra "CÍTRICO". Se for "LARANJA", "CÍTRICO". Se for "MORANGO/LIMÃO", "CÍTRICO" e assim por diante até o final. Então, "CASE" aqui. Eu vou sair desse "CASE" com "VRETORNO" com algum valor. E aí, eu preciso, antes de terminar a função, dar um "RETURN" de quem? De "VRETORNO".

[07:10] Vou dar o "APPLY". Vou dar o "APPLY". E vou dar o "FINISH". No meu caso, não deu erro. Talvez, no computador de vocês dê erro se vocês fizerem isso. Então, relembrando. Vocês antes ou antes de salvar a função, vocês executem este comando aqui. Cadê ele? "SET GLOBAL LOG_BIN_TRUST_FUNCTION_CREATORS = 1". Vocês executem esse comando, e aí sim, vocês conseguem depois salvar a sua função.

[07:59] Normalmente, esses comandos "SET GLOBAL", existe uma série de comandos de configuração do MySQL, é o administrador do ambiente que vai determinar para você. Quando eu faço isso, eu estou fazendo com que a minha sessão tenha esse parâmetro, mas não significa que o banco MySQL tenha esse parâmetro. Seria interessante que esse parâmetro fosse colocado no arquivo de inicialização do MySQL.

[08:29] Para, quando o serviço do MySQL for inicializado, todas as sessões que serão criadas dali para frente tenham esse parâmetro igual a um configurados. Mas não vamos nos preocupar com isso agora. Simplesmente, coloquem o comando "SET GLOBAL". Esse nome grande é igual a 1. Rodem ele na sessão em que você está com o "WORKBENCH" aberto antes de salvar a função.

[09:02] Visto isso, temos a função criada. Claro que se eu der isso aqui "CALL F_ACHA_TIPO_SABOR", e aí vou botar aqui dentro entre aspas simples: "LARANJA". Quer dizer, entre aspas duplas. Se eu rodar isso daqui, ele vai me dar erro. Porque o "CALL" chama uma procedure, não chama uma função. Só que eu uso isso daqui assim. Se eu der aqui um select, este cara, aí sim, isso vai voltar com uma função.

[09:52] Veio "CÍTRICO". Porém, melhor. Olha só. Se eu der um "SELECT SABOR FROM". Não, vamos fazer assim. "NOME SABOR FROM TABELA_DE_PRODUTOS". Eu vou executar esse comando select aqui. Não é "NOME". É "NOME_PRODUTO". "NOME_DO_PRODUTO". Você vê que eu trago o nome do produto e o sabor. Agora, eu posso, aqui, depois, criar mais um campo onde eu uso a função.

[10:52] Só que, é claro, eu não vou passar como parâmetro "LARANJA". Eu vou passar como parâmetro o campo "SABOR" dentro do meu select. Vou botar aqui "AS", um "ALLIAS" para a coluna ter um nome. Então, se eu rodar isso daqui, eu tenho o meu resultado aqui do lado. "CÍTRICO", "NEUTRO", "ÁCIDO" e assim por diante. Posso, inclusive, fazer isso daqui. Deixa. Eu vou manter esse comando.

[11:32] Eu vou copiar. Colar aqui. Posso, inclusive, fazer isso daqui "WHERE". A função = "NEUTRO". Só trouxe os produtos neutros. Então, a função, ela tem esse poder. Quando a gente dá um, como por exemplo, quando eu rodo isso daqui "CONCAT" do campo nome, do produto, com espaço, com sabor. Isso daqui, a gente aprendeu isso lá no curso de consultas avançadas.

[12:38] Isso daqui é uma função. Só que é uma função que já vem pronta dentro do MySQL. Isso aqui é uma função igualzinha. Só que é uma função que eu construí. E aí, o comportamento da função que eu construí é o mesmo das funções que já vêm prontas dentro do MySQL.

-----------------------------------------------------------------------
# 09Função para obter o número

Veja a Stored Procedure abaixo:

```sql
CREATE PROCEDURE `sp_numero_notas` ()
BEGIN
DECLARE NUMNOTAS INT;
SELECT COUNT(*) INTO NUMNOTAS FROM notas_fiscais WHERE DATA_VENDA = '20170101';
SELECT NUMNOTAS;
END
```

Transforme esta SP em uma função onde passamos como parâmetro da data e retornamos o número de notas. Chame esta função de NumeroNotas. Após a criação da função teste seu uso com um `SELECT`.


-----------------------------------------------------------------------
# 10Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Quando o resultado de um `SELECT` possui mais de uma linha não podemos atribuí-lo a uma variável usando o `SELECT INTO`. Para isso temos que usar o Cursor para receber valores vindos de uma tabela, com uma ou mais colunas.

2) Vamos criar uma SP que utilize Cursor. Digite e execute:

```sql
USE sucos_vendas;

DROP procedure IF EXISTS cursor_primeiro_contato;

DELIMITER $$

USE sucos_vendas$$

CREATE PROCEDURE `cursor_primeiro_contato` ()

BEGIN
  DECLARE vNome VARCHAR(50);
  DECLARE c CURSOR FOR SELECT NOME FROM tabela_de_clientes limit 4;
  OPEN c;
  FETCH c INTO vNome;
  SELECT vNome;
  FETCH c INTO vNome;
  SELECT vNome;
  FETCH c INTO vNome;
  SELECT vNome;
  FETCH c INTO vNome;
  SELECT vNome;
  CLOSE c;
END$$
DELIMITER ;
```

1) Note que cada linha da seleção é atribuída a variável `vNome`, uma de cada vez. Execute:

```r
call cursor_primeiro_contato;
```

![1.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/05/1.png)

![2.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/05/2.png)

![3.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/05/3.png)

![4.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/05/4.png)

1) Na SP acima executamos um Cursos controlado onde sabíamos quantos elementos o mesmo tinha. Mas, normalmente, não sabemos esta informação. Por isso usamos sempre o Cursos combinados com um Looping. Digite e execute a criação da SP abaixo:

```sql
USE sucos_vendas;

DROP procedure IF EXISTS cursor_looping;


DELIMITER $$

USE `sucos_vendas`$$

CREATE PROCEDURE `cursor_looping` ()

BEGIN

   DECLARE fim_do_cursor INT DEFAULT 0;

   DECLARE vNome VARCHAR(50);

   DECLARE c CURSOR FOR SELECT NOME FROM tabela_de_clientes;

   DECLARE CONTINUE HANDLER FOR NOT FOUND SET fim_do_cursor = 1;

   OPEN c;

   WHILE fim_do_cursor = 0
   DO
       FETCH c INTO vNome;
       IF fim_do_cursor = 0 THEN
          SELECT vNome;
       END IF;
   END WHILE;

   CLOSE c;

END$$

DELIMITER ;
```

1) Executando a SP:

```r
call cursor_looping;
```

Teremos diversos resultados em diferentes consultas.

![5.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/05/5.png)

1) O Cursor pode suportar mais de uma coluna. Crie a SP abaixo:

```sql
USE sucos_vendas;

DROP procedure IF EXISTS looping_cursor_multiplas_colunas;


DELIMITER $$

USE sucos_vendas$$

CREATE PROCEDURE `looping_cursor_multiplas_colunas` ()

BEGIN

  DECLARE fim_do_cursor INT DEFAULT 0;

  DECLARE vCidade, vEstado, vCep VARCHAR(50);

  DECLARE vNome, vEndereco VARCHAR(150);

  DECLARE c CURSOR FOR

  SELECT nome, endereco_1, cidade, estado, cep FROM tabela_de_clientes;

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET fim_do_cursor = 1;

  OPEN c;

  WHILE fim_do_cursor = 0

  DO

     FETCH c INTO vNome, vEndereco, vCidade, vEstado, vCep;

     IF fim_do_cursor = 0 THEN

        SELECT CONCAT(vNome, ' Endereço: ',

        vEndereco, ', ', vCidade , ' - ', vEstado, ' CEP: ' , vCep);

     END IF;

  END WHILE;

  CLOSE c;

END$$

DELIMITER ;
```

1) Execute-a:

```r
call looping_cursor_multiplas_colunas;
```

Esta SP também retorna múltiplas consultas.

![6.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/05/6.png)

1) Também podemos criar uma função. A diferença de uma função e uma SP é que a função retorna um valor e pode ser usada dentro de um comando `SELECT`, `INSERT`, `UPDATE` e condições de `DELETE`.

2) Para criar uma função vá com o botão da direita do mouse sobre Function e selecione Create Function:

![7.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/05/7.png)

1) Acrescente o código abaixo:

```sql
CREATE FUNCTION `f_acha_tipo_sabor`(vSabor VARCHAR(50)) RETURNS varchar(20) CHARSET utf8mb4

BEGIN

  DECLARE vRetorno VARCHAR(20) default "";

  CASE vSabor

  WHEN 'Lima/Limão' THEN SET vRetorno = 'Cítrico';

  WHEN 'Laranja' THEN SET vRetorno = 'Cítrico';

  WHEN 'Morango/Limão' THEN SET vRetorno = 'Cítrico';

  WHEN 'Uva' THEN SET vRetorno = 'Neutro';

  WHEN 'Morango' THEN SET vRetorno = 'Neutro';

  ELSE SET vRetorno = 'Ácidos';

  END CASE;

  RETURN vRetorno;

END
```

1) Clique em Apply. Teremos o código que poderá ser eecutado diretamente do script MYSQL.

```sql
USE sucos_vendas;

DROP function IF EXISTS f_acha_tipo_sabor;


DELIMITER $$

USE `sucos_vendas`$$

CREATE FUNCTION `f_acha_tipo_sabor`(vSabor VARCHAR(50)) RETURNS varchar(20) CHARSET utf8mb4

BEGIN

  DECLARE vRetorno VARCHAR(20) default "";

  CASE vSabor

  WHEN 'Lima/Limão' THEN SET vRetorno = 'Cítrico';

  WHEN 'Laranja' THEN SET vRetorno = 'Cítrico';

  WHEN 'Morango/Limão' THEN SET vRetorno = 'Cítrico';

  WHEN 'Uva' THEN SET vRetorno = 'Neutro';

  WHEN 'Morango' THEN SET vRetorno = 'Neutro';

  ELSE SET vRetorno = 'Ácidos';

  END CASE;

  RETURN vRetorno;

END$$


DELIMITER ;
```

1) Clique em Apply. Teremos o código que poderá ser executado diretamente do script MYSQL.

Observação: Se você verificar um erro como mostrado abaixo:

![8.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/05/8.png)

É porque o MYSQL não permite a construção de Funções. Para permitir, execute o comando:

```sql
SET GLOBAL log_bin_trust_function_creators = 1;
```

E crie a função novamente.

1) Execute a função:

```cpp
SELECT f_acha_tipo_sabor ("Laranja");
```

![9.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/05/9.png)

1) Podemos usar a função num comando `SELECT`. Digite e execute:

```vbnet
SELECT NOME_DO_PRODUTO, SABOR, f_acha_tipo_sabor (SABOR) as TIPO

 FROM tabela_de_produtos;
```

![10.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/05/10.png)


-----------------------------------------------------------------------
# 11O que aprendemos?

Nesta aula, aprendemos:

- Conhecemos a estrutura de Cursor onde podemos atribuir valores resultados de um `SELECT` com múltiplas linhas.
- Vimos que podemos atribuir ao Cursor mais de uma coluna.
- Aprendemos como usar o Cursor em conjunto com um Looping.
- Foi mostrado como criamos e usamos uma função.

-----------------------------------------------------------------------
# 01Criando números aleatórios

https://cursos.alura.com.br/course/mysql-procedures/task/56723

## Transcrição

[00:00] Agora eu vou criar uma aplicação prática usando todo o conhecimento que nós tivemos nesse tratamento. E essa aplicação, ela vai criar uma venda fictícia na base de dados da empresa de suco de frutas. Como é que vai funcionar essa stored procedure? Eu vou passar para ela alguns parâmetros. Basicamente, uma data, que é a data onde essa venda fictícia vai acontecer.

[00:28] O número máximo de itens da nota fiscal. Lembra? Uma nota fiscal é formada por um cabeçalho e vários itens. Então, quantos itens máximos essa nota vai poder ter? E para cada item comprado, qual é o número máximo de quantidade de produtos comprados? Com esses três parâmetros, a stored procedures vai na tabela de clientes e vai buscar um CPF, de forma aleatória.

[00:57] Vai buscar uma matrícula, de forma aleatória. E com a matrícula, o CPF e a data vai formar um cabeçalho da nota fiscal. Depois, ele vai achar um número de itens dessa nota, também de forma aleatória, entre 1 e o número máximo de itens. E ,dependendo do número de itens, ele vai buscar códigos de produto, os preços de lista desses códigos de produtos.

[01:24] E para cada item desse vai pegar uma quantidade aleatória baseado no número máximo de quantidades que eu posso estar comprando nessa venda fictícia. E aí, ele vai formar uma nota fiscal com um cabeçalho e vários itens. E aí, colocar isso nas tabelas. Então, é isso que a nossa stored procedures vai fazer. Como deve ter sido meio óbvio, muitas das coisas aqui, nós vamos pegar de forma aleatória.

[01:55] Eu vou pegar uns clientes de forma aleatória, uma matrícula. O número máximo de itens será aleatório. A quantidade de cada item também ser aleatório. Bem como os produtos. Enfim. Então, a primeira coisa que eu tenho que fazer é criar uma função que me traga um número aleatório. Como é que eu faço isso no MySQL? Vamos, então, lá para o "MySQL WORKBENCH".

[02:21] Pronto. Estou aqui no "WORKBENCH". E aí, eu vou criar aqui um novo script de "SQL". E aí, para começar, eu vou mostrar uma função interna que existe no MySQL que é a função "RAND". Ela se escreve assim. Ela não têm parâmetros. Se eu executo a função "RAND", eu acho um número aleatório entre 0 e 1. No caso aqui, eu rodei e achou o número 0.9642.

[02:57] Se você rodou a função "RAND" aí junto comigo, com certeza o número que você achou vai ser diferente porque é um número aleatório. Vou rodar de novo. 0.7000. 0.6704. E assim por diante. Ou seja, a cada vez que eu rodar esse select, ele vai me trazer um número aleatório diferente entre 0 e 1. Só que números aleatórios entre 0 e 1 não me servem. Por que não me servem?

[03:29] Deixa eu voltar aqui para a apresentação. Como é que eu vou buscar um cliente aleatório, ou um vendedor aleatório da tabela de clientes ou de vendedores. Ou até mesmo um produto aleatório. Eu vou fazer a seguinte coisa. Digamos que eu tenha 50 clientes na tabela de clientes. Eu vou. Eu posso fazer um select para saber o número de clientes que eu tenho na tabela. Eu tenho 50, por exemplo.

[04:00] Então, eu vou buscar um número aleatório entre 1 e 50. Digamos que dê 27. Eu vou pegar esse número 27, vou percorrer a tabela e buscar o vigésimo sétimo elemento da tabela. Ah, o número aleatório deu 12. Então, o cliente que eu vou pegar é o cliente que está na 12ª posição na tabela e assim por diante. Então, o que me interessa não são números aleatórios entre 0 e 1, mas números aleatórios entre um valor mínimo e um valor máximo.

[04:39] Por exemplo, digamos que eu vou especificar que o número máximo que eu posso comprar de quantidades dos produtos sejam 100 garrafas ou 100 latas. 100 unidades do meu produto das empresa de suco de frutas. Mas eu posso especificar, também, um valor mínimo. Olha, o menor valor de venda é 5. Então, eu vou precisar, quando for criar aqui, achar uma quantidade aleatória para um determinado item, um número aleatório entre 5 e 20, entre 5 e 100.

[05:13] Ou seja, eu vou ter que estar buscando números aleatórios sempre entre o número mínimo e o número máximo. Visto que eu preciso disso para continuar, como é que eu faço isso? Eu vou mostrar uma mágica para vocês. Não é o objetivo deste treinamento dar aulas de matemática, mas basicamente o seguinte, se eu quiser pegar esse número de 0 a 1 e subir para uma base, ou seja, pegar ele e transcender para um número que seja, por exemplo,, 10 12, 15 vezes.

[05:54] Porque, por exemplo, se eu pego um número aleatório entre 0 e 1. Eu quero pegar esse cara e fazer uma regra de três para buscar qual seria o número correspondente se fosse entre 5 e 200, por exemplo. Eu faço isso, eu pego o número aleatório que eu tenho. Eu multiplico pelo número máximo, menos o número mínimo, mais um. E esse valor todo, toda essa expressão aqui, eu faço, eu somo o número mínimo.

[06:34] Então, é essa que é a fórmula matemática para pegar um número aleatório, que está entre 0 e 1, e passar a olhar ele entre um número mínimo e o número máximo. Vamos ver se isso vai funcionar. Vamos supor aqui que o meu número mínimo é 15, e o meu número máximo é 300. Vamos ver se vai funcionar. Então, eu vou pegar agora aqui essa expressão. E vou colocar aqui do lado só que, aleatória não existe. O que existe é a função randômica.

[07:19] E o meu máximo 300 menos o mínimo que é 15 + 1 + o mínimo que é 15. Então, vamos rodar agora esse select. 283.0431 e assim por diante. É um número aleatório entre 15 e 300. Vamos rodar de novo? 262.159. 284. 69. 52. Consegui, então, pegar números aleatórios. Só que, ainda não está legal porque como eu vou buscar o cliente para uma posição, ou seja, eu quero pegar o cliente número 25 ou o cliente número 32, números decimais, como resultado da minha função aleatória, não vão me servir.

[08:20] Eu preciso pegar somente a parte inteira do número. Então, eu aplicar a função "FLOOR". Que é a função matemática do MySQL que pega só a parte inteira de um número decimal. Então, vamos rodar agora. 36. 298. 225. 213 e assim por diante. Então, já tenho aqui o meu select que me traz um número aleatório, entre um número mínimo e o número máximo.

[09:00] Visto isso, vamos agora construir a nossa funçãos para fazer isso de forma automática passando como parâmetro para função do MySQL o número mínimo e o número máximo. Então eu vou clicar aqui com o botão direito do mouse sobre "FUNCTIONS". Vou criar uma nova função. Essa função, eu vou chamar ela de "F_NÚMERO_ALEATÓRIO". E vou passar como parâmetro, o quê? O número mínimo e o número máximo.

[09:37] O retorno dessa função vai ser um número inteiro, porque vai ser um número... Eu passo o mínimo e máximo como inteiros e eu vou ter como retorno o número inteiro. Vou criar aqui uma variável que eu vou chamar de "VRETORNO, que vai ser inteira. E essa variável vai ser a variável que vai ser o retorno da função. Então, aqui, eu vou substituir esse número um, que meio que um padrão que ele mostra aqui para mim quando eu vou editar função pelo "VRETORNO".

[10:11] Agora aqui no meio, eu vou associar "VRETONO" àquele select que eu mostrei para vocês, que está aqui no script. Então, eu vou pegar esse select aqui. Vou copiar. Vou colar aqui. Esse valor vai ser atribuído "INTO" à variável "VRETORNO". E aqui, eu vou substituir. Onde está o 300, é o "MAX". Onde está o 15, é o mínimo. E aqui também é o mínimo.

[10:38] Então, ficou assim. Eu passo o mínimo e o máximo. Declaro uma variável retorno, porque eu estou dizendo que a função vai retornar ao inteiro. Então, essa variável tem que ser um inteiro. Aplico. Busco um número aleatório entre o valor mínimo e máximo, pela fórmula matemática. Atribuo esse valor à variável "VRETORNO". E eu termino a função jogando para fora o valor calculado.

[11:13] Vou dar um "APPLY". "APPLY" de novo. E "FINISH". Pronto. Está aqui a minha função criada. Voltando, então, aqui para o meu script. Se eu botar aqui "SELECT F NÚMERO_ALEATÓRIO". Se eu colocar "15,300", eu vou estar buscando um número aleatório entre 15 e 300. Vamos rodar? 18. 115. 220. 170. 176. 68 e assim por diante. Se eu quero um número aleatório entre 1 e 10, olha lá: 7, 6, 9, 5, 9, 8 e assim por diante.

[12:08] Então, o nosso primeiro passo para a gente construir a nossa aplicação, que crie uma venda fictícia, foi criar uma função que gere para mim um número aleatório entre o número mínimo e o máximo. E ela está criada aqui.


-----------------------------------------------------------------------
# 02Tabela com números aleatórios

Crie uma tabela chamada `TABELA_ALEATORIOS`. O comando para cria-la é mostrado abaixo:

`CREATE TABLE TABELA_ALEATORIOS(NUMERO INT);`

Faça uma SP (Chame-a de Tabela_Numeros) que use um loop para gravar nesta tabela 100 números aleatórios entre 0 e 1000. Depois liste numa consulta esta tabela.

(Use a função f_numero_aleatorio criado no vídeo desta aula).


-----------------------------------------------------------------------
# 03Obtendo cliente aleatorio

https://cursos.alura.com.br/course/mysql-procedures/task/56724

## Transcrição

[00:00] Vamos fazer agora a função que pega o cliente de forma aleatória. Então, vamos logo criar aqui a função. Botão direito do mouse sobre "FUNCTIONS". Eu vou criar uma função chamada "F_CLIENTE_ALEATÓRIO". Eu não preciso passar nenhum parâmetro porque eu só vou buscar um cliente aleatório. E a gente sabe que o CPF, vamos olhar aqui na tabela de clientes. O CPF é um "varchar (11). E é esse cara que tem que retornar a função.

[00:41] Então, o "RETURNS" aqui vai ser um "varchar (11)". E eu vou declarar já a variável, aqui, retorno "varchar (11)", que vai ser retornada pela função. Eu preciso, então, saber quantos clientes eu tenho na tabela de clientes. Lembra? Eu vou usar um número aleatório entre 1 e o número máximo de clientes da tabela de clientes. Então, vou criar aqui "DECLARE NÚMERO_MÁXIMO_TABELA". Vai ser um inteiro.

[01:31] Porque é um número que eu quero buscar. O número de linhas da tabela é um número inteiro. Eu não tenho um ponto cinco linhas, um ponto sete linhas. Ou é cinco, ou é 10, ou é 20 e assim por diante. Como é que eu obtenho o número de linhas de uma tabela? Basicamente, eu uso o "COUNT" usando essa fórmula de grupamento da tabela. Então, se eu fizer isso "SELECT COUNT FROM TABELA_DE_CLIENTES".

[02:06] Eu tenho aqui. Eu tenho 15 linhas na tabela de clientes. Então, eu vou até aproveitar esse select que está aqui. Vou jogar aqui. Só que eu vou aplicar aqui o "INTO NUM_MAS_TABELA". Então, já tenho na variável "NUM_MAX_TABELA", o número máximo de clientes. Quantos clientes eu tenho na tabela. Agora, eu preciso pegar um número aleatório entre 1 e esse número.

[02:47] Então, eu vou "DECLARE_NUM_ALEATÓRIO_INTEIRO". E aí, eu vou. Como é que eu vou lhe referenciar, como é que eu vou obter esse número? Usando aquela outra função que eu criei no vídeo anterior. Então, eu vou botar "SET NUM_ALEATÓRIO = F_NUMÉRO_ALEATÓRIO" entre 1 e o número máximo que eu tenho na tabela. Nesse ponto, eu tenho aqui um número entre 1 e o número máximo de clientes.

[03:32] Eu agora tenho que buscar, da tabela de clientes, esse cara nessa posição. Como é que eu faço isso? Se eu tenho 15 clientes, e o número aleatório deu 12, como é que eu pego o décimo segundo cliente da tabela de clientes? Deixa eu mostrar para vocês uma coisa que nós vimos já no curso de consultas avançadas de MySQL. Nós vamos fazer uma revisão dessa cláusula, que a gente pode usar no comando select, que é a "LIMIT".

[04:05] Como é que ela funciona dentro do MySQL. Digamos que eu faça um "SELECT FROM TABELA LIMIT 5". Eu vou até repetir esse comando aqui. Por exemplo, eu faço isso: "SELECT* FROM TABELA_DE_CLIENTES LIMIT 5". Ao fazer isso, eu pego cinco clientes da tabela de clientes. O primeiro cliente é 147. 192. 260, ele vai até o 492. Se eu rodo todos, note que o quinto cliente está aqui. Só que aí, o "SELECT*" traz todo mundo.

[04:57] Se eu coloco "LIMIT", ele traz só os cinco primeiros. Levando em consideração a ordem com que esses clientes foram gravados na tabela. A ordem natural da tabela. Voltando, então, aqui. Agora, se eu coloco "5,1" lá no comando "LIMIT". Ele vai pegar os cinco primeiros clientes e, como é igual a 1, ele vai pegar o próximo abaixo do quinto cliente. Então, ele vai pegar daqui até aqui, que são cinco. Porque ele pegou esse parâmetro.

[05:38] E aí, como tem um parâmetro 1, ele vai pegar o próximo a seguir. A partir do quinto. Então, ele vai pegar o cliente 6 quando eu aplicar isso daqui. Vamos ver? Se eu rodo aqui esse select. Vamos lá. Quem é o sexto cliente? Primeiro, segundo, terceiro, quarto, quinto. O sexto é esse cara aqui. Vou até copiar ele e colocar o código dele aqui. É o cliente "505344".

[06:14] Se eu rodo essa consulta "LIMIT", eu vou até o quinto cliente. Agora, se eu coloco aqui vírgula um. Olha lá o cliente que ele traz o "505344", ou seja, o próximo cliente depois do quinto cliente. Se eu colocar aqui o8 de 1, ele vai pegar o cliente 9. Vai pegar até o 8º e vai vir de 1. Se eu colocar 12 de 1, ele vai pegar o cliente na posição 13. Vamos voltar aqui para a apresentação.

[07:00] Agora, o que acontece se eu colocar 8 de 1? Eu tenho 8 clientes na tabela. Eu quero pegar o próximo a partir do oitavo. Como a tabela termina no 8, quando eu botar 8 de 1, ele vai trazer "NULO". Quer ver? Eu vi aqui pe lo "COUNT" que eu tenho 15 clientes. Antão, se eu pegar... Eu vou fazer assim: 14 de 1. Eu estou pegando o último cliente que é o "95939".

[07:42] Se eu pegar a tabela toda, olha lá. O último é o "95939". É o último da tabela. Agora, se eu pegar aqui 15 de 1. Ele vai trazer "NULO". Então, a minha posição... Sempre, esse cara aqui não pode ser minha posição da tabela. Então, ele não pode ser 15. Ele tem que ir até 14. Já que a tabela tem 15 posições. E olha o outro caso. Se eu pego o "LIMIT" de 0 e vejo o próximo, eu estou pegando o primeiro cliente da tabela.

[08:25] Se eu der um "SELECT*", o primeiro cliente é "1471156710". Então, se eu pegar agora aqui "LIMIT" 0 de 1, olha lá. "1471156". Então, eu vou pegar isso daqui. Vou copiar essa consulta. Vou voltar para a função. E aí, o CPF que eu quero buscar vai ser o "SELECT CPF INTO VRETORNO FROM TABELA_DE_CLIENTES LIMIT". Eu tenho um número aleatório aqui. Vamos fazer isso aqui por enquanto.

[09:25] O número aleatório vírgula um. O quê que vai acontecer se eu manter isso daqui? O número aleatório é entre 1 e o número máximo de registros da tabela. Então, se ele der 1, esse cara vai ser 1 de 1. Se o número aleatório der 1, vai ser "LIMIT 1,1". O quê que vai acontecer "1,1"? Se eu rodar aqui "1,1", ele vai pegar o segundo elemento da tabela. Quer dizer, o menor número aleatório, que é 1, vai me retornar o segundo elemento da tabela.

[10:07] E o maior número aleatório, que é 15, vai me retornar "NULO". Então, o número aleatório que eu achar, eu tenho que fazer o quê? Eu tenho que diminuir de 1. Ou seja, se eu achar como número aleatório 1, eu tenho que botar no limite zero. Se eu achar número aleatório 15, eu tenho que jogar no "LIMIT" 14. Ou seja, eu tenho que diminuir de 1, o número obtido pela função aleatório.

[10:39] Então, eu vou fazer aqui assim: "SET NUM_ALEATÓRIO = NUM_ALEATÓRIO - 1". Fazendo isso, eu acerto o parâmetro que eu tenho que colocar no "LIMIT". Eu vou buscar o CPF nesta posição aqui. Vou jogar em "VRETORNO" e ele vai retornar para mim da função. Vou dar um "APPLY". "APPLY" de novo. "FINISH". Então, tenho a função criada. Agora, vamos lá.

[11:27] Se eu fizer isso daqui. "SELECT F_CLIENTE_ALEATÓRIO". Vamos lá. Achei um CPF lá. "771579779". Se eu rodar de novo, outro CPF. Outro CPF. Ou seja, cada vez que eu rodo essa função, eu estou trazendo um número, um CPF de forma aleatória. Já tem, então, a função para obter o cliente de forma aleatória pronta.

-----------------------------------------------------------------------
# 06Incluindo a venda

https://cursos.alura.com.br/course/mysql-procedures/task/56725

## Transcrição

[00:00] Então, eu já tenho, nesse momento, a função que me dá o cliente aleatório. E também já tenho aqui. Deixa eu dar aqui um "REFRESH" nas minhas funções. Eu também já tenho aqui a função que me dá o produto de forma aleatória e o vendedor de forma aleatória. Essas duas funções estão no exercício do vídeo anterior, cujo objetivo foi que vocês construam a função que obtém o produto aleatório, e a que obtém o vendedor aleatório.

[00:38] Então, o objetivo é que vocês tentem construir sozinhos essas duas funções. Caso vocês não consigam, vocês podem ou ver na resposta do exercício essas funções e aí, criar no seu ambiente. Ou, então, lá no mão na massa, eu mostro como se cria essas duas funções. Mas para a gente poder seguir aqui no vídeo daqui para frente, você precisa ter essas duas funções já dentro do seu MySQL funcionando.

[01:09] Eu vou supor, então, que todo mundo já tem a função que obtém o cliente de forma aleatória, o produto e o vendedor. Então, eu posso, até aqui por exemplo, fazer um teste. Se eu rodar esse select aqui: "F.PRODUTO_ALEATÓRIO". E se eu rodar "F.VENDEDOR_ALEATÓRIO". Se eu rodar um select rodando as três funções ao mesmo tempo, eu obtenho lá um cliente aleatório, um produto aleatório e um vendedor aleatório.

[01:52] Se eu rodar de novo, eu tenho sempre o programa buscando de forma aleatória três entidades ao mesmo tempo. Vamos, então, agora fazer a nossa stored procedure para que eu possa incluir os dados de uma venda fictícia. Então, é stored procedure. Então, eu vou vir aqui stored procedure, direita do mouse, stored procedure.

[02:18] O nome dessa procedure, eu vou colocar assim "P_INSERIR_VENDA". Eu vou passar como parâmetro a data, que vai ser do tipo "DATE", o número no máximo de itens. Máximo de itens que vai ser um inteiro. quer dizer, quantos itens, no máximo, uma nota fiscal deve ter? E qual é a quantidade máxima que um cliente pode comprar. Também vou botar um número inteiro.

[02:58] Deixa eu dar um "Enter" aqui para a gente poder olhar o código da stored procedures toda dentro da tela. Vamos começar. É uma stored procedure. Primeira coisa que eu vou precisar ter, é claro, são variáveis que vão me retornar o cliente aleatório, o produto aleatório e o vendedor aleatório. Então, eu vou já é "DECLARE V_CLIENTE varchar", vamos relembrar aqui.

[03:26] Tabela de clientes. CPF. "varchar (11)". "DECLARE V_PRODUTO varchar". Vamos ver aqui produto, eu tenho a coluna matrícula. Está aqui. É um "varchar (5)". Vamos pegar vendedor. "VENDEDOR varchar (5)". Na verdade, eu olhei errado. Produto é aqui. Tabela de produtos. Produto é "varchar (10)". Então, aqui é 10. Vendedor que é "varchar (5)".

[04:30] Que outras variáveis, eu vou precisar? Eu vou precisar também de uma variação que vai ter a quantidade de um item. Então, vai ser um inteiro. Vou precisar também de uma variável que vai me dar o preço do item. "DECLARE VPRECO", vai ser um "FLOAT". Porque preço pode ser um número decimal. Eu tenho, também, uma variável que vai me dar o número de itens que a nota fiscal vai ter, que também vai ser número inteiro.

[05:11] Então, eu vou botar aqui "DECLARE VITENS" é inteiro. Vamos lá. Por enquanto, é isso daqui. Talvez eu precise declarar mais variáveis. Vamos continuar a fazer a rotina. Ah, já vou até começar outra aqui também. Quando eu vou criar uma venda nova, eu preciso saber o número da nota fiscal. O número da nota fiscal é um número sequencial. Então, se eu tenho 200 notas, quando eu for criar a próxima nota vai ser 201.

[05:52] Ou seja, vai ser sempre o maior número de nota mais um. Então, eu vou também ter que ter uma variável "DECLARE VNÚMERO_NOTA" que vai ser o número nota. Vamos ver aqui como é que ela é. Eu tenho o número nota aqui na tabela de notas fiscais. Esse campo "INT(11)", então é um inteiro. Vamos começar pela nota. Eu vou criar uma nova nota fiscal. Eu preciso saber qual é o próximo número de nota fiscal.

[06:30] Como é que eu obtenho isso? Vamos vir aqui. Se eu chegar aqui e fizer isso daqui: "SELECT NÚMERO FROM NOTAS_FISCAIS". Eu vou ver a lista dos números das notas fiscais que eu tenho na tabela. Olha lá: 100, 103. Qual seria o próximo número? Se eu tiver o "MAX" desse número, eu vou ver o maior número, o maior "ID" de nota fiscal que eu tenho no meu cadastro.

[07:10] Então, o maior "ID" que eu tenho é "87996". Como eu tenho que criar uma nota fiscal nova, como é que eu faço? Vai ser esse número mais um. Normalmente, os sistemas que emitem nota fiscal, eles têm, internamente, um contador que vai criando aleatoriamente. Aleatoriamente não. Na sequência o número da nota fiscal. Então, esse cara aqui, se eu pegar o "MAX" e mais um, ele é o número da nota fiscal nova.

[07:41] Um novo número de nota fiscal. Então, eu vou copiar esse select aqui e vou colocar aqui. Só que eu vou jogar esse "MAX" aqui: "INTO VNÚMERO_NOTA". Então, o número da nota, eu já tenho. Vamos agora obter um vendedor e um cliente de forma aleatória. Porque quando eu for inserir dados no cabeçalho da nota, eu preciso só de um cliente, de um vendedor. Isso eu vou obter através de um número aleatório.

[08:25] A data é um parâmetro que está vindo da stored procedures. O novo número da nota, eu já mostrei para vocês. Vai ser o "MAX" do número mais 1. E o imposto. Esse cara aqui, eu vou colocar uma constante dentro da stored procedures. Não vou entrar muito em detalhes. Poderia, também, o imposto ser uma coisa que também poderia ser um parâmetro.

[08:50] Porque pode ser que, em um determinado mês, o imposto sobre vendas dos produtos da empresa de suco de frutas possa aumentar ou diminuir. Mas, por enquanto, eu vou deixar constante. Então, já tenho mais ou menos esses cinco elementos. Quer dizer, eu não tenho ainda o número aleatório do cliente ou do vendedor. Mas isso eu vou fazer agora. Então, vamos fazer aqui.

[09:18] "SET VCLIENTE = F_CLIENTE_ALEATÓRIO". E o vendedor aleatório vai ser: "F_VENDEDOR_ALEATÓRIO". Então, eu já tenho o imposto, vai ser constante. Data, eu já tenho aqui. Número da nota, já tenho aqui. Cliente, já tenho aqui. Vendedor, já tenho aqui. Então, o quê eu vou fazer? "INSERT INTO NOTAS_FISCAIS". E aí, vamos colocar o CPF, matrícula. Estou colocando aqui os campos da tabela.

[10:22] Matrícula. Data. Venda. Número. Imposto. Valores. Vamos colocar as variáveis. Então, CPF vai vir de "VCLIENTE". Matrícula vai vir de "VVENDEDOR". Data da venda vem do parâmetro aqui de cima. Número vai vir do número da nota que está aqui. E imposto, vou colocar aqui "0.18", por exemplo. Esse número de imposto foi uma constante. bom? Então, nesse ponto aqui, eu já tenho incluído o cabeçalho da nota.

[11:17] Agora, eu preciso inserir os itens. Os itens da nota fiscal estão aqui. Eu tenho que incluir um número que eu já tenho. Um produto aleatório. A quantidade e o preço. Mas, vamos lá. Quantos itens a nota fiscal vai ter? Pela minha especificação, isso vai ser um número aleatório entre 1 e o quê? E o número máximo de itens que é passado como parâmetro para a minha stored procedures.

[11:54] Então, aqui eu tenho essa variável "VITENS", que eu justamente declarei para ter o número máximo de itens. Então, eu vou agora vir aqui e dizer o seguinte: "SET VITENS = F_NÚMERO_ALEATÓRIO" entre 1 e quem? E o número máximo de itens que eu passei aqui. Agora, o quê que eu vou precisar ter? Eu tenho o número de itens: 5, 6, 10, 12. Não importa.

[12:35] Eu agora preciso fazer um "LOOPING" para inserir 12 itens, ou 15 itens, ou 3 itens, dependendo do que deu esse número aleatório. A gente viu isso quando a gente viu o "WHILE". Então, a gente vai fazer o seguinte. A gente vai precisar de um contador que vai ter que contar o número de interações que esse "LOOPING" vai ter até chegar ao número de itens, que foi determinado aqui pelo número aleatório.

[13:04] Então, nova variável aqui, que eu vou chamar ela de "VCONTADOR". Que vai ser inteiro e esse contador já pode ser inicializado com o número 1. Porque eu vou começar a contar pelo 1. Então, eu vou contar do 1 até o número de itens que deu aqui. Então, vamos fazer aqui agora o nosso "LOOPING". "DO". "WHILE". E aqui no final, a gente vai. Na verdade, é ao contrário. "WHILE". "DO". "END WHILE". No "WHILE", eu vou fazer a condição.

[13:46] Qual é a condição que vai me fazer estar dentro do "LOOPING"? Sempre quando o "VCONTADOR" for menor ou igual ao "VITENS". Tem que botar o ponto e vírgula aqui. Vamos lá. Então, eu estou lá pegando o primeiro item. O que eu preciso fazer para cada item? Primeiro: buscar um produto aleatório.

[14:17] "SET VPRODUTO = F_PRODUTO_ALEATÓRIO". Então, eu peguei um produto aleatório para aquele item. Cada nota fiscal pode ter vários itens. Cada item, eu tenho que buscar um produto aleatório. Próximo. Eu preciso pegar uma quantidade. Quantidade eu já tenho aqui. A variável já está aqui, a quantidade. Vai ser o quê? Um número aleatório entre, vamos lá.

[14:55] A quantidade mínima, por exemplo, é 10 unidades e a quantidade máxima, eu passei como parâmetro aqui. "MAX_QUANTIDADE". Então, já tenho, desse item, o produto e a quantidade. Eu preciso do preço. O preço, eu disse que o preço é o preço de lista do produto. Então qual é a consulta que obtém o preço de lista? Olha lá. Se eu vier aqui e fizer isso daqui: "SELECT PRECO", vamos olhar aqui a tabela de produtos.

[15:38] É "PRECO_DE_LISTA FROM TABELA_DE_PRODUTOS WHERE CÓDIGO_DO_PRODUTO =", eu não sei aqui. Deixa eu ver aqui. Vamos pegar um produto qualquer. Pegar esse produto aqui 1000889. Então, se eu rodar essa consulta aqui: "PRECO_DE_LISTA FROM" aquele produto específico, eu vou ter o preço de lista. Então, esta consulta aqui, eu vou copiar. Vou colar aqui. Vamos dar um "Enter" só para ficar visível essa linha.

[16:33] Só que aqui, eu vou jogar o quê? "INTO", qual é a variável que recebe o preço? Está aqui. É a "VPRECO". Só que esse "WHERE" aqui, eu tenho que editar. Quem é que vai estar aqui? É o produto aleatório que eu obtive rodando essa linha aqui. Então, nesse ponto, eu já tenho tudo que eu preciso. O número da nota está aqui em cima. Está aqui o número da nota. Foi obtida aqui. O número do produto está aqui. A quantidade, aqui.

[17:13] E o preço aqui. Então, eu vou colocar o "INSERT INTO", o nome da tabela é "ITENS_NOTAS_FISCAIS". Aí, vamos colocar os campos. Vamos abrir aqui para olhar os campos. É número. Código do produto. Quantidade. Vou dar "Enter" aqui. "PRECO". "VALUES". Vamos lá. "VNÚMERO" é o número da nota. O código do produto é "VPRODUTO". A quantidade tá em "VQUANTIDADE". E o preço está em "VPRECO".

[18:16] Vamos fazer assim. Eu vou dar "Enter" aqui. Vamos puxar daqui para cá. Você consegue ver tudo aqui. Terminou? Não. Porque se eu não fizer nada, esse contador vai ficar sempre igual a 1, que é o ponto inicial, e vai ficar nesse "LOOPING" infinito. Então, eu preciso "SET VCONTADOR = VCONTADOR + 1". Então, pronto. Nesse ponto aqui, quando eu sair aqui, eu vou ter os itens de notas fiscais criados.

[18:59] Eu vou colocar aqui, vou clicar em "APPLY". "APPLY" de novo. Deu certo. Vamos ver se não vai dar erro. Eu venho aqui, Vou rodar a minha "P_INSERIR_VENDA", opa. É "CALL P_INSERIR_VENDA". Vou colocar aqui, como parâmetro, uma data. Vou pegar o dia de hoje aqui 20190517. Entro com o quê? Segundo parâmetro. Entro com o número máximo de itens. Eu vou colocar aqui 3. E o número máximo de quantidade 100.

[19:58] Vamos rodar. Opa. Tive um erro aqui. "F_ALEATORIO" não existe. Eu devo ter errado aqui porque a função não é "F_ALEATORIO". A função que nós temos aqui é "F_NUMERO_ALEATORIO". Então, eu faço seguinte. Minha stored procedures está aqui. "INSERIR VENDA". Botão direito do mouse. "ALTER STORED PROCEDURES". Então, em algum momento aqui, eu usei aqui. É aqui. É "F_NUMERO_ALEATORIO".

[20:44] Em algum outro lugar. Eu uso aqui e uso aqui. Então, eu acho que agora eu consertei o problema. vamos dar um "APPLY". "APPLY". "FINISH". Vou voltar aqui para o comando que eu tentei rodar. Vou rodar de novo. Outro número. Coluna "V_NUMERO" não existente. Vamos olhar de novo aqui onde é que eu errei. Botão direito do mouse. "ALTER STORED PROCEDURES". "V_NUMERO_NOTA". Eu botei "V_NUMERO".

[21:26] Então, aqui "NUMERO_NOTA" é aqui. "V _NUMERO_NOTA". Também meu erro foi aqui. Eu tinha cometido um erro aqui, que eu chamei a função de forma errada. E a variável eu coloquei "V_NUMERO", mas o certo seria "V_NUMERO_NOTA". Novamente, só um parênteses assim para explicar para vocês. Eu gosto de... Eu poderia ter essa stored procedures toda prontinha e está copiando a mesma.

[21:58] Mas, não. Eu gosto de fazer, pensar no problema e fazer na hora. E mostrar às vezes o erro porque a gente é humano, a gente sempre erra. É bom a gente ver o erro acontecendo e saber como corrigi-los. Claro que o código final dessa rotina aqui vai estar lá no passo a passo já corrigida funcionando. Eu, normalmente, coloco no passo a passo o resultado desse script que eu faço durante a aula.

[22:25] Mas vamos seguindo. Será que tem mais algum erro? Não sei. Vamos rodar de novo e vamos ver. "APPLY". "APPLY" de novo. Então, vamos voltar aqui para... E eu vou executar. Agora deu certo. Rodou. Vamos conferir se deu tudo certo mesmo. E se ainda não tem mais alguma coisa de errado que pode acontecer nessa rotina, mas no próximo vídeo, para não deixar esse vídeo aqui muito extenso. Então, está bom. Espero vocês no próximo vídeo.


-----------------------------------------------------------------------
# 07Resolvendo o problema de PK

https://cursos.alura.com.br/course/mysql-procedures/task/56726

## Transcrição

[00:00] Vamos agora, dar uma conferida para saber se a nossa stored procedures está rodando direitinho. Eu vou fazer o seguinte. Aqui embaixo, eu vou fazer uma consulta que vai fazer o faturamento por nota fiscal dentro de uma data, para a gente saber se as notas fiscais estão sendo incluídas com sucesso. E se está sendo feita de forma corretamente correta.

[00:24] Vamos lá. Eu vou fazer isso aqui. "SELECT A.NÚMERO, B.QUANTIDADE, B.PRECO" só que, na verdade, eu vou dar um "SUM" de quantidade vezes preço. É, faturado. "FROM". Nós vamos pegar, então, da tabela de "NOTAS_FISCAIS" que vai ser a tabela A. "INNER JOIN". A tabela de "ITENS_NOTAS_FISCAIS", que vai ser a tabela B. "ON A.NÚMERO = B.NÚMERO WHERE DATA_DA_VENDA", que está na tabela A, na tabela de notas.

[01:31] Igual a "20190517". Como eu estou usando "SUM", "GROUP BY" e o número. Então, eu estou fazendo aqui um select que está buscando da tabela A, que é a tabela de notas fiscais, o número. Da tabela B, a quantidade vezes o preço. E está somando isso. E eu estou pegando isso só para a data da venda no dia de hoje, que é o dia que eu estou incluindo aqui, onde eu vou começar a incluir novas vendas.

[02:13] A gente pode até colocar isso daqui: "COUNT NÚMERO ITENS" para a gente saber quantos itens têm. Vamos ver se está legal esse select. Vou rodar e está lá. Eu vou inserir a nota fiscal "8799". Foram dois itens. Eu tenho que pegar um número aleatório entre 1 e 3. Deu 2. E o total faturado deu isso daqui. Se eu rodar de novo esse cara, ele vai criar uma nova venda. Rodou.

[02:49] Se eu rodar o select, ele já criou aqui uma nova venda. Aqui, ele escolheu um item só e colocou o valor faturado. Então, aparentemente, parece que está incluindo. Agora, olha só uma coisa. Eu vou colocar aqui 10 itens. Posso ter nota fiscal com um montão de item. Vou rodar aqui. Deu certo. Estou rodando. E a gente vai ver aqui o nosso select que está funcionando.

[03:26] Só que, note, teve um erro aqui. Quando eu rodei esse cara aqui, ele deu um erro. "DUPLICATE ENTRY". O que deve ser esse erro? Olha só. Ou seja, se eu começar a rodar essa stored procedure várias vezes, olha lá. Eu não sei em quanto tempo vocês vão achar o erro. Mas eu vou... Vamos lá. Rodei uma, deu certo. Certo. Certo. Certo. Tem uma que deu errado. Mas se eu continuar, está rodando certo.

[04:04] Mas chega uma hora que dá errado. Quer ver uma coisa? Se ao invés de 10 itens, eu colocar 100 itens. Já vai dar erro de cara. Todos vão dar erro. Ou seja, tem algum problema aqui nos itens dos produtos. O quê que pode ser? Vamos analisar? Vou abrir a stored procedure de novo. Deixa eu diminuir um pouquinho aqui. O que acontece é o seguinte.

[04:46] Imagina uma coisa. Eu tenho aqui meu número de itens. Digamos que eu tenha cinco itens. Ele vai chegar aqui, vai achar um produto aleatório e vai inserir. Depois, no segundo item, ele vai pegar outro produto aleatório e vai ser o inserir. No terceiro item, vai pegar outro produto aleatório e inserir. Até aí tudo bem. Era isso que eu queria. Mas, note uma coisa.

[05:12] O número da nota fiscal é o mesmo, porque o número é determinado lá quando eu crio o cabeçalho. O quê vai variando são os produtos. Cada item vai ter um produto diferente. Porque a chave da tabela de notas fiscais, quem não se lembra, é número e código. Agora, olha só. Eu acabei de afirmar os produtos devem ser diferentes. Será que são mesmo diferentes? Porque a cada interação, eu pego um produto de forma aleatória.

[05:51] Se eu digo que eu posso ter, no máximo, três itens, a probabilidade de eu pegar dois produtos iguais é pequena. Porque, vamos ver aqui. Deixa eu criar um outro script aqui do lado "SELECT COUNT FROM TABELA_DE_PRODUTOS". Eu tenho 36 produtos. Se eu tento buscar três produtos aleatórios dentro de 36, a probabilidade de eu escolher um mesmo produto duas vezes é pequena.

[06:37] Agora, se eu digo para você que o número máximo de itens é 20, dentre 36 produtos, qual é a probabilidade de eu escolher o mesmo produto duas, três vezes? Aí já fica grande. E aí, quando ele for tentar inserir o item na Nota Fiscal, eu vou acabar tentando inserir na mesma nota o mesmo produto duas vezes. E aí, eu vou ter um problema de chave primária dessa tabela aqui.

[07:14] Por isso que o erro que ele mostra aqui é um erro de "DUPLICATE KEY" na chave primária. Então, o que eu preciso fazer é, na minha stored procedure, eu preciso ter um tipo de controle para não deixar eu criar, determinar, na hora que eu for buscar o produto de forma aleatória, um produto que já exista na Nota Fiscal. Eu preciso fazer isso. Então, vamos lá. Vamos melhorar essa parte, agora, aqui.

[07:57] Eu vou, então, editar a minha stored procedure e vou aqui criar uma variável que vai me dizer quantos itens eu já tenho na nota fiscal de um determinado produto. "ITENS_NOTA" vai ser um inteiro. E como é que eu acho isso? Olha só. Nesse momento aqui, eu tenho o meu produto. Eu já tenho o número da minha nota fiscal aqui. Antes de incluir esse produto, eu vou ver se já existe algum item deste mesmo produto na mesma Nota Fiscal.

[08:46] Se tiver, eu tenho que achar outro produto aleatório. É porque eu acabei achando um produto aleatório igual a outro que eu achei numa interação anterior. E como é que eu acho esse valor? Eu vou jogar isso nessa variável aqui: "NUMÉRO_ITENS_NOTA". Então, eu vou colocar aqui "SELECT COUNT INTO", esse cara. "FROM ITENS_NOTAS_FISCAIS". É isso mesmo o nome da tabela?

[09:27] É isso mesmo. "WHERE", para que nota? A nota é o número da nota que está nessa variável. "AND CÓDIGO_DO_PRODUTO =", deixa eu só conferir aqui o nome das colunas da tabela. É isso aí. "CÓDIGO_DO_PRODUTO = VPRODUTO". Então, eu digo. Olha, quantos itens esta nota fiscal tem deste produto que eu acabei de escolher, de forma aleatória?

[10:09] Se esse vier zero significa que não existe, para essa nota fiscal, nenhum produto com esse código. Então, eu posso inserir o produto que eu não vou ter problemas de chave primária. Então, eu faço aqui um "IF VNUM_ITENS_NOTA". Se for igual a zero, "THEN". Eu vou executar todos esses comandos aqui. Vou até inventar um pouco aqui para diferenciar. E eu vou colocar o "END IF".

[10:58] Uma dúvida. Esse contador tem que estar fora ou dentro do "IF". Depende. Se você quiser manter o número de itens originais, ou seja, eu posso ter no máximo cinco itens. O sistema achou 3. Então, eu vou ter que ter três itens. Mas quando eu for pegar o segundo, eu escolhi como um produto aleatório o mesmo do primeiro. Se o contador estiver fora, eu vou desprezar esse segundo item.

[11:32] E o contador vai subir de 1. Então, eu não vou conseguir ter três itens. Eu vou ter pelo menos 2. Se o contador estiver dentro do "IF", se o segundo elemento vier. Então, fazer isso daqui. Se o segundo elemento, eu já escolhi. Ele vai tentar pegar outro aleatório. E se for o mesmo, vai tentar pegar outro. E vai pegar outro até achar um que nunca tenha sido escolhido.

[12:05] O perigo de colocar o contador dentro do "IF" é que se eu tiver o número máximo de itens muito próximo do número de produtos, ou seja, olha, uma nota fiscal pode ter 20 itens, no máximo, e eu tenho... Deixa eu ver aqui quantos produtos eu realmente tenho. Eu tenho 36. Vai ter uma hora que eu vou começar a escolher produto, e esse produto já existe, e eu vou ficar tentando, tentando.

[12:33] Pode ser que o programa demore muito a terminar. Então, eu vou considerar a seguinte coisa. Eu vou considerar o contador fora daqui. Do tipo, cara, se eu escolher um produto que já existe, ok. Desisto daquele. Passo para o próximo e aí, eu perdi o item. Minha nota fiscal ao invés de três, vai ter dois itens só, por exemplo. Vou deixar assim. Eu acho que isso resolve o problema.

[13:02] Vou dar "APPLY". "APPLY" de novo. "FINISH". Então, eu agora vou rodar aqui. Vamos rodar de novo aqui o "CALL B_INSERE". Eu já tenho até o script aqui pronto. Deixa eu pegar daqui essas duas linhas. Está lá no final. Vou colar aqui. Então, vou rodar aqui mais uma e vou ver a quantidade. Está lá. Inseri mais uma nota fiscal nova aqui. Houve erro de stored procedure? Não houve erro.

[13:59] Vamos colocar aqui o número máximo de produtos. Por exemplo 20. Vou rodar. Rodei. Rodei. Note que eu estou rodando e não está dando mais erro de "PRIMARY" aqui. Mesmo que eu rode ele várias vezes. Ou seja, aquela minha rotina resolveu o problema. Se o produto aleatório que eu escolhi já foi escolhido antes, em uma interação anterior, eu pulo e vou para o próximo.

[14:33] E aí, vou. Se eu escolhi de novo. Opa, esse cara eu também já escolhi o próximo. Se eu escolher um produto, não esse cara não faz parte da minha nota fiscal, aí eu incluo o item da Nota Fiscal. Então, essa pequena modificação resolveu meu problema.


-----------------------------------------------------------------------
# 08Melhorando Triggers

https://cursos.alura.com.br/course/mysql-procedures/task/56727

## Transcrição

> Você pode baixar o arquivo SQL de criação de Triggers [clicando aqui](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/06/criando-triggers.zip)

[00:00] Vamos clicar no link que está aqui embaixo desse vídeo, e abrir o arquivo .SQL" que já está aqui. Eu já baixei, aqui, na minha máquina. É esse aqui: "CRIANDO TRIGGERS". Vamos abrir ele no editor de texto. Já está aberto aqui. Ele é o seguinte. Eu crio aqui uma tabela temporária e, depois, eu tenho três triggers. Uma que é executada após o insert, outra após o update. E outra após o delete.

[00:39] Quem não se recorda, essas três triggers, eu criei no curso manipulação de dados usando MySQL, o curso anterior a este treinamento. E, durante os vídeos daquele curso, eu enfatizei que no MySQL ou eu tenho uma trigger de insert, ou uma de update ou uma de delete. Eu não posso ter, por exemplo, uma trigger que seja executada após o insert, o update e o delete ao mesmo tempo.

[01:12] Eu tenho que criar três triggers separadas. Ok. Até aí tudo bem. A gente pode criar. Não vejo nenhum problema nisso. O problema está, que, o código de cada trigger dessa é o mesmo. Isso significa que se eu tiver que fazer uma manutenção numa dessas triggers. Ah, esse comando aqui eu tenho que mudar, a forma como eu executo ele. Eu tenho que lembrar de ir na de update e ir na de delete e fazer a mesma coisa.

[01:45] E aí, eu posso esquecer. Posso modificar a regra de negócio no insert, mas não fazer nem no update, nem no delete. E aí, o negócio vai ficar meio que desbalanceado. Só que, felizmente, nesse treinamento, a gente aprendeu o stored procedures. Então, qual é a solução técnica? Eu devo pegar esses comandos que se repetem e criar uma stored procedures para eles.

[02:09] E aí, a trigger vai chamar a stored procedure e não, os comandos diretamente. Aí, se eu tiver que modificar uma regra de negócio, basta eu modificar a stored procedure que, automaticamente, todas as triggers vão estar modificadas. Então, é esse tipo de exercício que nós vamos fazer agora. Porém, como essa base aqui é diferente da que foi usada no treinamento anterior.

[02:37] Vamos primeiro criar a tabela temporária e as triggers. Então, eu vou primeiro aqui no meu "WORKBENCH". Vou criar, aqui, um novo script "SQL". Vou copiar o comando que cria a tabela temporária. Tabela temporária não. A tabela auxiliar. Esse é o melhor termo. Aqui, no meu caso, eu já tenho essa tabela. Então, deixa eu dropar ela. Vocês não vão ter essa tabela no banco de vocês.

[03:16] Isso só foi no meu porque eu já estava fazendo alguns testes aqui antes de gravar o vídeo e esqueci de dropar essa tabela. Agora sim. Criei a tabela. E eu vou criar, aqui, as três triggers. Criei. Então, por exemplo, se eu executar aqui aquela stored procedures que nós criamos no vídeo anterior. "CALL P_INSERIR_VENDA", eu passo como parâmetro a data" 20190517".

[04:03] O número máximo de itens e a maior quantidade de venda. Se eu rodar essa stored procedures. Rodei. E aí, agora, se eu vier aqui e der um "SELECT* FROM TAB_FATURAMENTO WHERE". Como é que é o nome do campo de data? É data venda?Não sei. Vamos ver aqui o nome do campo. A tabela é a "TAB_FATURAMENTO" está aqui. A coluna é "DATA_VENDA". Isso mesmo.

[04:44] " WHERE DATA_VENDA = 20190517". Se eu rodo esse cara, eu tenho lá o total de venda que está aqui 190.671. Se eu rodar de novo, novamente essa stored procedures. se eu rodar agora o select, a venda aumentou um pouquinho, ou seja, essa tabela mostra para mim o valor total por dia já pré-calculado. Por que? Porque quando eu rodo essa stored procedures, eu faço o insert na tabela de itens.

[05:24] Ao fazer o insert, ele executa a stored procedures e executa esse comando, aqui, para recalcular o valor total na tabela auxiliar. Está tudo funcionando, mas eu vou melhorar. Então, eu vou fazer o seguinte. Esses dois comandos, aqui, que eu executo, eu vou copiar eles e eu vou, aqui, criar uma stored procedures. Eu vou chamar ela de "P_CÁLCULO_FATURAMENTO"

[06:00] Não vou passar parâmetro. E aqui dentro, eu colo, justamente, os comandos que eu tenho que executar quando eu executar a trigger. Vou dar um "APPLY". "APPLY". "FINISH". Então, esse é o nome da stored procedures. Agora, eu vou vir aqui. Onde está? Onde está, aqui, a lista de triggers. Dentro da minha tabela tem as notas fiscais. Então, está aqui. Eu tenho aqui as triggers.

[06:39] Vou clicar na primeira. Na verdade, eu não tenho como alterar visualmente, mas eu tenho aqui o código que cria elas, que é o mesmo código que está aqui. Que eu copiei. Então, eu vou fazer o seguinte. Eu vou antes aqui dar um "DROP TRIGGER TG_CALCULA_FATURAMENTE_INSERT".

[07:17] Depois, eu vou dropar a trigger, eu vou copiar duas vezes. Eu vou dropar a "TRIGGER UPDATE" e vou dropar a "TRIGGER DELETE". Vamos lá. Vamos rodar? Se eu vier aqui nas triggers e dar um "REFRESH", não tenho mais nada. Aí, eu vou criar as triggers novamente. Só que, aqui, no lugar desses comandos, eu vou executar o "CALL", o nome da stored procedure está aqui do lado.

[07:52] Deixa eu abrir um pouquinho mais aqui. É a "P_CÁLCULO_FATURAMENTO". Então, "CALL P_CÁLCULO_FATURAMENTO". E eu vou fazer isso, também, aqui na update, e aqui na como delete. Então, vou executar agora a criação de novo das triggers. Criei. Então, agora, se eu rodar de novo aqui, a minha criação de novas notas fiscais. Rodou. Se eu olhar o faturamento, está lá. Ele aumentou já um pouquinho mais.

[08:43] Então, agora, se amanhã eu precisar alterar o código da regra de negócio que roda dentro da trigger, eu não preciso mais editar a trigger. Eu venho aqui. Procuro a stored procedures que é a "P_CÁLCULO_FATURAMENTO". Dou um "ALTER STORED PROCEDURE". E, aqui, eu edito e salvo. E aí, a TRIGGER vai estar, automaticamente, modificada.


-----------------------------------------------------------------------
# 10Conclusão

https://cursos.alura.com.br/course/mysql-procedures/task/56728


## Transcrição

[00:01] Parabéns. Se você chegou até aqui, é porque você completou o treinamento de procedures e funções usando o MySQL. A gente construiu vários exemplos de procedures e funções. Olha só a lista como é que ficou grande. E sempre cobrindo um determinado problema. Mas releembrando o quê nós fizemos neste treinamento. A gente começou, claro, recuperando o ambiente.

[00:27] Porque eu precisava ter essa base para a gente poder fazer os nossos exemplos. E aí depois, a gente viu os conceitos básicos de como adquirir uma stored procedure. Vimos através de comandos. E vimos que clicando com o botão direito do mouse e vindo aqui dentro do próprio cliente, escolhendo "CREATE STORED PROCEDURE", eu posso, aqui dentro, editar a minha procedure e criá-la.

[00:49] Aí, nós começamos a criar procedures, inicialmente, básicas onde eu apenas exibia na saída da stored procedure um determinado valor. E a gente começou, claro, a ver variáveis. Onde, eu posso declarar variáveis dentro da stored procedure, atribuir valores a elas através do comando "SET". E, usando essas variáveis, exibindo uma saída um pouco diferente.

[01:16] Aí depois, a gente começou a ver sobre como é que eu posso passar parâmetros para a stored procedure. Normalmente, esses parâmetros são valores de variáveis que eu crio fora da stored procedure e essas variáveis, claro, serão úteis dentro do código da "SP". Depois que a gente viu a criação de variáveis, a gente viu uma coisa importante: como tratar erros.

[01:42] Se eu tenho um problema, um erro dentro da stored procedure, ela para de ser executada se esse erro acontece. Mas eu posso tratar esse erro. Tentar identificar antes os erros que podem acontecer. E aí, dar um retorno um pouco mais amigável para a stored procedure, caso aconteça. Ao invés de, por exemplo, o próprio MySQL me mostrar que o conjunto rodou de forma errada.

[02:10] Depois, a gente começou a trabalhar com controle de fluxos. Nós vimos vários tipos de controle de fluxos usando "IF", usando "CASE" e também, por exemplo, usando aqui, no caso estou abrindo aqui, usando "LOOPINGS". Onde, através do "WHILE", do "END_WHILE", eu consigo fazer comandos repetitivos respeitando alguma regra. Vimos, então, depois o "CURSOR".

[02:41] O "CURSOR" é uma estrutura muito usada na stored procedures. É como se fosse uma variável onde, ao invés de atribuir um valor, eu atribuo um vetor, que pode ter uma ou n colunas. E aí, eu percorro esse vetor utilizando, normalmente, "LOOPINGS" para, mediante cada valor desse vetor, eu faço alguma coisa. Depois, a gente falou sobre funções.

[03:06] As funções têm uma diferença muito grande em relação às stored procedures porque a função me retorna um valor. Enquanto que a stored procedure apenas executa alguns comandos. Criamos vários exemplos de funções. Inclusive, quando a gente viu o nosso exemplo prático, onde a gente criou uma stored procedure para criar uma venda aleatória, nós criamos várias funções que depois foram chamados por essa stored procedure.

[03:36] E aí, esse treinamento, eu terminei falando sobre um problema que nós vimos lá no curso de consultas avançadas em MySQL, que foi no momento em que nós criamos triggers. E que essas triggers tinham um código que se repetia nas triggers de insert, update e delete. E que essa repetição era problemática caso eu quisesse fazer uma manutenção nesse código.

[04:01] Porque eu teria que lembrar de fazer a manutenção igual em todas as três triggers. E a gente viu que usando stored procedure, o problema da manutenção é resolvido. Esse foi o último curso da parte de análise do MySQL. Ele começou desde o curso de introdução. Nós vimos o curso de consultas. Vimos o curso de manipulação de dados. E, finalmente, o de stored procedures.

[04:31] Então, se você fez todos os cursos, eu espero que todos esses treinamentos tenham dado a você uma melhor base. Uma base de conhecimento muito boa para você começar a trabalhar e lidar com o banco de dados MySQL. Seja, você lidar com esse banco diretamente como um analista de banco de dados, ou até mesmo, caso você for para uma linguagem de programação, onde você vai querer desenvolver algum tipo de programa que vai ter algum tipo de interface com o banco de dados MySQL.

[05:09] Então, gente. Muito obrigado pela atenção e espero vocês nos próximos cursos. Tchau, tchau.

-----------------------------------------------------------------------
# 11Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com os próximos cursos que tenham este como pré-requisito.

1) Vamos colocar nossos conhecimentos em prática. Iremos criar uma SP que irá criar uma venda aleatória.

2) Iniciamos com uma função que retorna um número aleatório entre dois valores. Para isso crie a função abaixo:

```sql
USE sucos_vendas;

DROP function IF EXISTS f_numero_aleatorio;


DELIMITER $$

USE sucos_vendas$$

CREATE FUNCTION f_numero_aleatorio(min INT, max INT) RETURNS int(11)

BEGIN

   DECLARE vRetorno INT;

   SELECT  FLOOR((RAND() * (max-min+1)) + min) INTO vRetorno;

RETURN vRetorno;

END$$


DELIMITER ;
```

1) Teste a função várias vezes para verificar que os números aleatórios são criados:

```scss
SELECT f_numero_aleatorio(1, 10);
```

![1.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/06/1.png)

1) Usaremos a função abaixo para escolher um cliente de forma aleatória da tabela de clientes. Iremos escolher uma posição entre 1 e o número de registros da tabela e retornar o cliente escolhido conforme o número aleatório determinado. Digite e execute:

```sql
USE sucos_vendas;

DROP function IF EXISTS f_cliente_aleatorio;


DELIMITER $$

USE sucos_vendas$$

CREATE  FUNCTION f_cliente_aleatorio() RETURNS varchar(11) CHARSET utf8mb4

BEGIN

    DECLARE vRetorno VARCHAR(11);

    DECLARE num_max_tabela INT;

    DECLARE num_aleatorio INT;

    SELECT COUNT(*) INTO num_max_tabela FROM tabela_de_clientes;

    SET num_aleatorio = f_numero_aleatorio(1, num_max_tabela);

    SET num_aleatorio = num_aleatorio - 1;

    SELECT CPF INTO vRetorno FROM tabela_de_clientes

    LIMIT num_aleatorio, 1;

RETURN vRetorno;

END$$


DELIMITER ;
```

1) Teste a função para determinar um cliente aleatoriamente:

```csharp
SELECT f_cliente_aleatorio();
```

![2.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/06/2.png)

1) Nos exercícios associados a esta aula criamos a função para buscar, de forma aleatória, um produto e um vendedor. Mas caso não tenha sido feito o exercício proceda criando as duas funções conforme o código abaixo:

```sql
DELIMITER $$

USE `sucos_vendas`$$

CREATE DEFINER=`root`@`localhost` FUNCTION `f_produto_aleatorio`() RETURNS varchar(10) CHARSET utf8mb4

BEGIN

    DECLARE vRetorno VARCHAR(10);

    DECLARE num_max_tabela INT;

    DECLARE num_aleatorio INT;

    SELECT COUNT(*) INTO num_max_tabela FROM tabela_de_produtos;

    SET num_aleatorio = f_numero_aleatorio(1, num_max_tabela);

    SET num_aleatorio = num_aleatorio - 1;

    SELECT CODIGO_DO_PRODUTO INTO vRetorno FROM tabela_de_produtos

    LIMIT num_aleatorio, 1;

RETURN vRetorno;

END$$


DELIMITER ;

;


DELIMITER $$

USE sucos_vendas$$

CREATE DEFINER=root@localhost FUNCTION f_vendedor_aleatorio() RETURNS varchar(5) CHARSET utf8mb4

BEGIN

    DECLARE vRetorno VARCHAR(5);

    DECLARE num_max_tabela INT;

    DECLARE num_aleatorio INT;

    SELECT COUNT(*) INTO num_max_tabela FROM tabela_de_vendedores;

    SET num_aleatorio = f_numero_aleatorio(1, num_max_tabela);

    SET num_aleatorio = num_aleatorio - 1;

    SELECT MATRICULA INTO vRetorno FROM tabela_de_vendedores

    LIMIT num_aleatorio, 1;

RETURN vRetorno;

END$$


DELIMITER ;

;
```

1) Podemos testar as funções num único SELECT:

```scss
SELECT f_cliente_aleatorio(), f_produto_aleatorio(), f_vendedor_aleatorio();
```

![3.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/06/3.png)

1) Vamos, finalmente, criar a SP para incluir uma venda de forma aleatória. Digite e execute a criação da SP abaixo:

```sql
USE sucos_vendas;

DROP procedure IF EXISTS p_inserir_venda;


DELIMITER $$

USE sucos_vendas$$

CREATE PROCEDURE p_inserir_venda(vData DATE, max_itens INT,

max_quantidade INT)

BEGIN

DECLARE vCliente VARCHAR(11);

DECLARE vProduto VARCHAR(10);

DECLARE vVendedor VARCHAR(5);

DECLARE vQuantidade INT;

DECLARE vPreco FLOAT;

DECLARE vItens INT;

DECLARE vNumeroNota INT;

DECLARE vContador INT DEFAULT 1;

SELECT MAX(numero) + 1 INTO vNumeroNota from notas_fiscais;

SET vCliente = f_cliente_aleatorio();

SET vVendedor = f_vendedor_aleatorio();

INSERT INTO notas_fiscais (CPF, MATRICULA, DATA_VENDA, NUMERO, IMPOSTO)

VALUES (vCliente, vVendedor, vData, vNumeroNota, 0.18);

SET vItens = f_numero_aleatorio(1, max_itens);

WHILE vContador <= vItens

DO

   SET vProduto = f_produto_aleatorio();

   SET vQuantidade = f_numero_aleatorio(10, max_quantidade);

   SELECT PRECO_DE_LISTA INTO vPreco FROM tabela_de_produtos

   WHERE CODIGO_DO_PRODUTO = vProduto;

   INSERT INTO itens_notas_fiscais (NUMERO, CODIGO_DO_PRODUTO,

   QUANTIDADE, PRECO) VALUES (vNumeroNota, vProduto, vQuantidade, vPreco);

   SET vContador = vContador + 1;

END WHILE;

END$$

DELIMITER ;
```

1) Execute a SP para criar uma venda:

```csharp
Call p_inserir_venda('20190517', 3, 100);
```

1) Se executarmos várias vezes a criação da venda teremos, num determinado momento, erro de PK.

![4.png](https://cdn3.gnarususercontent.com.br/1223-mysqlproceduresefuncions/06/4.png)

1) Para resolver este problema precisamos testar se o produto aleatório determinado pela função já existe na tabela de vendas. Modifique a SP com o código abaixo:

```sql
USE sucos_vendas;

DROP procedure IF EXISTS p_inserir_venda;


DELIMITER $$

USE sucos_vendas$$

CREATE DEFINER=root@localhost PROCEDURE p_inserir_venda(vData DATE, max_itens INT,

max_quantidade INT)

BEGIN

DECLARE vCliente VARCHAR(11);

DECLARE vProduto VARCHAR(10);

DECLARE vVendedor VARCHAR(5);

DECLARE vQuantidade INT;

DECLARE vPreco FLOAT;

DECLARE vItens INT;

DECLARE vNumeroNota INT;

DECLARE vContador INT DEFAULT 1;

DECLARE vNumItensNota INT;

SELECT MAX(numero) + 1 INTO vNumeroNota from notas_fiscais;

SET vCliente = f_cliente_aleatorio();

SET vVendedor = f_vendedor_aleatorio();

INSERT INTO notas_fiscais (CPF, MATRICULA, DATA_VENDA, NUMERO, IMPOSTO)

VALUES (vCliente, vVendedor, vData, vNumeroNota, 0.18);

SET vItens = f_numero_aleatorio(1, max_itens);

WHILE vContador <= vItens

DO

   SET vProduto = f_produto_aleatorio();

   SELECT COUNT(*) INTO vNumItensNota FROM itens_notas_fiscais

   WHERE NUMERO = vNumeroNota AND CODIGO_DO_PRODUTO = vProduto;

   IF vNumItensNota = 0 THEN

      SET vQuantidade = f_numero_aleatorio(10, max_quantidade);

      SELECT PRECO_DE_LISTA INTO vPreco FROM tabela_de_produtos

      WHERE CODIGO_DO_PRODUTO = vProduto;

      INSERT INTO itens_notas_fiscais (NUMERO, CODIGO_DO_PRODUTO,

      QUANTIDADE, PRECO) VALUES (vNumeroNota, vProduto, vQuantidade, vPreco);

   END IF;

   SET vContador = vContador + 1;

END WHILE;

END$$


DELIMITER ;
```

1) No curso de manipulação de dados vimos, quando aprendemos `TRIGGERs`, que devemos criar uma para inclusão, uma para alteração e outra para exclusão. Se, dentro delas, tivemos que executar os mesmos comandos a manutenção será problemática porque qualquer mudança na regra de negócio deverá ser feita nas três `TRIGGERs`. Mas, se usarmos SP, as mudanças deverão ser feita apenas na SP e não em cada uma das `TRIGGERs`.

2) Criando a SP:

```sql
USE sucos_vendas;

DROP procedure IF EXISTS p_calculo_faturamento;


DELIMITER $$

USE sucos_vendas$$

CREATE PROCEDURE p_calculo_faturamento()

BEGIN

  DELETE FROM TAB_FATURAMENTO;

  INSERT INTO TAB_FATURAMENTO

  SELECT A.DATA_VENDA, SUM(B.QUANTIDADE * B.PRECO) AS TOTAL_VENDA FROM

  NOTAS_FISCAIS A INNER JOIN ITENS_NOTAS_FISCAIS B

  ON A.NUMERO = B.NUMERO

  GROUP BY A.DATA_VENDA;

END$$


DELIMITER ;
```

1) Criando as `TRIGGERs` usando a SP:

```sql
CREATE TABLE TAB_FATURAMENTO

(DATA_VENDA DATE NULL, TOTAL_VENDA FLOAT);


DELIMITER //

CREATE TRIGGER TG_CALCULA_FATURAMENTO_INSERT AFTER INSERT ON ITENS_NOTAS_FISCAIS

FOR EACH ROW BEGIN

  Call p_calculo_faturamento;

END//


DELIMITER //

CREATE TRIGGER TG_CALCULA_FATURAMENTO_UPDATE AFTER UPDATE ON ITENS_NOTAS_FISCAIS

FOR EACH ROW BEGIN

  Call p_calculo_faturamento;

END//


DELIMITER //

CREATE TRIGGER TG_CALCULA_FATURAMENTO_DELETE AFTER DELETE ON ITENS_NOTAS_FISCAIS

FOR EACH ROW BEGIN

  Call p_calculo_faturamento;

END//
```


-----------------------------------------------------------------------
# 12O que aprendemos?


Nesta aula, aprendemos:

- Usamos nosso conhecimento prático para criação de uma SP que cria uma venda aleatória;
- Vimos como a SP pode melhorar o gerenciamento de `TRIGGERs`.

-----------------------------------------------------------------------
