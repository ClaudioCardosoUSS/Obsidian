---
type: "9"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
fonte_curso: https://cursos.alura.com.br/course/chatgpt-programacao-aumente-produtividade
---

Tópico:: #Java #JPA #Spring_Boot #chatgpt #claude #IA #Inteligencia_Artifical 


# Conhecendo a API de Open AI

https://www.youtube.com/watch?v=5hVaIi3IOeo

https://platform.openai.com/playground/chat?models=gpt-4o-mini

![[Pasted image 20250108232655.png]]

https://platform.openai.com/chat-completions

![[Pasted image 20250108232747.png]]

![[Pasted image 20250108232828.png]]

-----------------------------------------------------------------------
# Integrando uma aplicação Java com a API da OpenAI

https://www.youtube.com/watch?v=bCurua9kMBE

![[Pasted image 20250108232518.png]]
-----------------------------------------------------------------------

-----------------------------------------------------------------------

-----------------------------------------------------------------------




-----------------------------------------------------------------------




-----------------------------------------------------------------------






-----------------------------------------------------------------------




-----------------------------------------------------------------------






-----------------------------------------------------------------------




-----------------------------------------------------------------------






-----------------------------------------------------------------------




-----------------------------------------------------------------------

