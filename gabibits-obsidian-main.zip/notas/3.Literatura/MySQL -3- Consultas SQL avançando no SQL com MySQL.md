---
type: "9"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
fonte_curso: https://cursos.alura.com.br/course/mysql-consultas-sql
Url_video_curso: https://dev.mysql.com/doc/
MySql_funcions: https://dev.mysql.com/doc/refman/8.0/en/functions.html
w3schools: https://www.w3schools.com/sql/sql_ref_mysql.asp
---

Tópico:: #MySQL #DataBase

- Pagine seus dados com LIMIT
- Filtre consultas com HAVING
- Entenda a diferença entre o LEFT e RIGHT JOIN
- Saiba usar Sub-Queries
- Use funções do MySQL
- Ordene os seus dados usando o ORDER BY
- Agrupe dados com GROUP BY


## Aulas

- [](https://cursos.alura.com.br/course/mysql-consultas-sql/section/8141/tasks)
    
    [Configurando ambiente e conhecendo o SQL](https://cursos.alura.com.br/course/mysql-consultas-sql/section/8141/tasks) [Ver primeiro vídeo](https://cursos.alura.com.br/course/mysql-consultas-sql/task/55575)
    
    0 / 9
    
    47min
    
    - Introdução
    - Preparando ambiente
    - Para saber mais: erro na importação
    - História do SQL
    - Vantagem da linguagem SQL
    - Longevidade do SQL
    - História do MYSQL
    - Consolidando o seu conhecimento
    - O que aprendemos?
- [
    
    Filtrando as consultas de dados
    
    0 / 12
    
    57min
    
    ](https://cursos.alura.com.br/course/mysql-consultas-sql/section/8142/tasks)
    
    - Conhecendo o banco de dados
    - Por que visualizar o esquema de dados
    - Revisando consultas
    - Listando dados de uma tabela
    - Consultas condicionais
    - Resolvendo a estrutura lógica
    - Aplicando consultas condicionais
    - Selecionar vendas
    - Usando o LIKE
    - Buscando clientes
    - Consolidando o seu conhecimento
    - O que aprendemos?
- [
    
    Apresentação dos dados de uma consulta
    
    0 / 14
    
    51min
    
    ](https://cursos.alura.com.br/course/mysql-consultas-sql/section/8143/tasks)
    
    - Usando DISTINCT para visualizar a tabela
    - Bairros da cidade do Rio de Janeiro
    - Limitando a saída da consulta
    - Observando uma amostra de dados
    - Ordenando a saída da consulta
    - Maior venda
    - Agrupando os resultados
    - Número de vendas
    - Usando a condição HAVING
    - Clientes de compras em 2016
    - Classificar resultados
    - Classificando o número de vendas
    - Consolidando o seu conhecimento
    - O que aprendemos?
- [
    
    Juntando tabelas e consultas
    
    0 / 14
    
    70min
    
    ](https://cursos.alura.com.br/course/mysql-consultas-sql/section/8144/tasks)
    
    - Usando JOINS
    - Obtendo o faturamento anual
    - Exemplos de LEFT e RIGHT JOIN
    - Selecionando o tipo de JOIN
    - Exemplos de FULL e CROSS JOIN
    - Nova seleção do tipo de JOIN
    - Juntando consultas
    - Diferenças de UNION e UNION ALL
    - Subconsultas
    - Relação entre HAVING e subconsulta
    - Visão
    - Características da visão
    - Consolidando o seu conhecimento
    - O que aprendemos?
- [
    
    Funções do MYSQL
    
    0 / 10
    
    53min
    
    ](https://cursos.alura.com.br/course/mysql-consultas-sql/section/8145/tasks)
    
    - Funções de string
    - Listando o endereço completo.
    - Funções de datas
    - Idade dos clientes
    - Funções matemáticas
    - Formato do faturamento
    - Conversão de dados
    - Listando expressão natural
    - Consolidando o seu conhecimento
    - O que aprendemos?
- [
    
    Exemplos de relatórios
    
    0 / 9
    
    52min
    
    ](https://cursos.alura.com.br/course/mysql-consultas-sql/section/8146/tasks)
    
    - Relatório de vendas válidas
    - A consulta do relatório
    - Relatório de vendas por sabor
    - Vendas percentuais por tamanho
    - Consolidando o seu conhecimento
    - O que aprendemos?
    - Conclusão
    - Próximos passos
    - Projeto do curso
-----------------------------------------------------------------------
Introdução

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55575

## Transcrição

Olá, sou Victorino Vila e serei seu instrutor neste curso de consultas avançadas com MySQL. Se este for o seu primeiro contato com a linguagem SQL (_Structured Query Language_), sugiro que antes veja nosso [curso de Introdução ao SQL com MySQL](https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql) para que consiga acompanhar com tranquilidade o conteúdo a seguir, que é um pouco mais aprofundado.

No início deste curso, vamos rever a história do SQL e do MySQL (como esse banco surgiu, a situação dele hoje no mercado e quais são suas principais características) e reservaremos um momento para a preparação do ambiente de trabalho. Caso você não tenha o MySQL instalado na sua máquina, recomendo que assista ao tutorial do curso introdutório citado anteriormente.

Feito isso, com uma base de dados já alimentada, começaremos pelo básico: consultas de tabelas com seleções simples e seleções condicionais, aprendendo aos poucos sobre expressões lógicas e operadores, como o `LIKE`. Em seguida, daremos foco às saídas de nossas consultas, estudando especialmente como limitar e ordenar os dados exibidos.

São várias as estruturas a serem exploradas nesse curso, entre elas o `HAVING`, aplicada geralmente quando um dado agrupado faz parte do critério de filtros; e diferentes tipos de `JOIN`, bastante importantes no SQL, que permitem juntar duas tabelas em uma única consulta.

Além disso, aprenderemos sobre subconsultas (ou seja, uma consulta dentro de outra) e visões, também chamadas de _views_, que, grosso modo, são consultas que ficam armazenadas de forma lógica no banco de dados e podem ser usadas como se fossem uma tabela.

Depois, estudaremos as funções. São elas que realmente diferenciam os diversos bancos de dados relacionais entre si. Como citado no outro curso, todos os bancos de dados seguem o padrão _ANSI_, sendo possível aplicar os mesmos conhecimentos em MySQL, SQL Server ou Oracle. Entretanto, cada banco de dados trabalha de maneira diferente em relação às funções.

Aqui abordaremos funções que trabalham com `string` (textos), funções matemáticas, funções de datas e de conversão (que permitem converter dados em diferentes tipos). Por fim, encerraremos esse treinamento aplicando nossos novos conhecimentos em casos reais, criando duas consultas bem complexas sobre os dados da nossa empresa de suco de frutas.

Será um curso extenso e com bastante conteúdo, porém um excelente passo inicial para quem está começando os estudos com SQL!

-----------------------------------------------------------------------
# 02Preparando ambiente

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55576

## Transcrição

O primeiro passo para seguirmos neste curso é ter um ambiente devidamente configurado com o MySQL. Então, caso você não tenha o MySQL instalado na sua máquina, você pode ir ao nosso [curso de Introdução ao SQL com MySQL](https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql) e assistir ao vídeo 4 da aula 1, no qual ensino como fazer essas instalações e configurações.

Feito isso, você terá o MySQL e o MySQL Workbench instalados. Vamos, então, seguir com mais alguns ajustes.

Para aprender sobre consultas SQL, é preciso ter dados para consultar, portanto, nosso passo seguinte será criar uma base de dados. Para isso, executaremos o MySQL Workbench e acessaremos a nossa conexão local que foi configurada quando instalamos o MySQL.

À esquerda, temos uma área denominada _SCHEMAS_. Com o botão direito do mouse, vamos clicar nessa área, selecionar _"Create Schema..."_ e dar um nome para nossa nova base: "sucos_vendas". Em seguida, clicaremos no botão _Apply_, depois _Apply_ novamente e, por fim, em _Finish_. Assim, teremos criado a base de dados (ela aparecerá na área _SCHEMAS_), porém ela ainda estará vazia - ou seja, sem tabelas e sem dados.

Portanto, vamos recuperar alguns dados. Para isso, [você pode fazer aqui o download do arquivo RecuperacaoAmbiente.zip](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/1.2SQL.zip). Nas versões mais recentes do MySQL, a _collation_ `utf8mb4_0900_ai_ci` foi descontinuada. Então, caso você tenha problemas em utilizar a versão do arquivo disponibilizada acima, [você pode fazer aqui o download desta outra versão](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/RecuperacaoAmbiente.zip).

Vamos descompactar o arquivo baixado e, dentro dele, você encontrará um subdiretório chamado **DumpSucosVendas**. Lembre-se da localização desse diretório, vamos usá-lo em breve.

No MySQL Workbench, abaixo da área _SCHEMAS_, há duas abas: _"Administration"_ e _"Schemas"_. Clicaremos na primeira e, em seguida, selecionaremos _"Data Import/Restore"_ (em português, importar/restaurar dados). Isso abrirá uma caixa de diálogo e você notará que a opção _"Import from Dump Project Folder"_ já está selecionada. À direita dessa opção, clicaremos no botão "..." e selecionaremos a pasta **DumpSucosVendas**.

Por fim, clicaremos em _"Start Import"_, no canto direito inferior da caixa de diálogo. Com isso, teremos recuperado os dados e nossa base "sucos_vendas" não estará mais vazia.

Para se certificar de que esse processo foi bem-sucedido, daremos um clique duplo sobre o nome do banco de dados "sucos_vendas", na área _SCHEMAS_, para que fique destacado em negrito. Depois, abriremos um novo arquivo `.sql` (com o atalho "Ctrl + T" ou clicando no primeiro ícone na barra superior do programa) e digitaremos `SELECT * FROM itens_notas_fiscais`. Para executar este _script_, clicaremos no terceiro ícone (um símbolo de raio) presente na barra localizada logo acima da área em que você acabou de digitar. Se tudo estiver certo, você verá uma tabela com os dados das notas fiscais. Ou seja, você recuperou os dados com sucesso!

Caso você não tenha conseguido recuperar os dados dessa maneira, a seguir explicarei uma forma alternativa de fazer esse processo. Porém, se o primeiro método funcionou, você já pode seguir para o próximo material.

Então, vamos ao método alternativo...

Primeiro, vamos apagar o banco de dados, clicando com o botão direito sobre "sucos_vendas" e selecionando _"Drop Schema..."_. Aparecerá uma mensagem de confirmação, pressionaremos _"Drop Now"_.

A seguir, vamos criar a base novamente. Essa parte é igual à criação que fizemos anteriormente: clicaremos com o botão direito na área _SCHEMAS_, selecionaremos _"Create Schema..."_ e nomearemos a base "sucos_vendas". Com o banco criado, daremos um clique duplo para selecioná-lo (ele ficará em negrito).

Em seguida, no menu superior do programa, clicaremos em **"File > Run SQL Script..."**. Vamos procurar pela pasta que descompactamos anteriormente, nela vamos encontrar vários arquivos com extensão `.sql`. Selecionaremos o arquivo **Criacao_Esquema.sql**. Isso abrirá uma caixa de diálogo, com dois campos a serem modificados. Em _"Default Schema Name"_, selecionaremos "sucos_vendas". Em _"Default Character Set"_, escolheremos "utf8". Depois, clicaremos em "Run".

Vamos repetir essa última etapa com cada um dos arquivos `.sql` da pasta descompactada, seguindo a seguinte ordem:

- Carga_Tabelas_Cadastrais.sql
- Carga_Notas_01.sql
- Carga_Notas_02.sql
- Carga_Notas_03.sql
- Carga_Itens_Notas_01.sql
- Carga_Itens_Notas_02.sql
- Carga_Itens_Notas_03.sql
- Carga_Itens_Notas_04.sql
- Carga_Itens_Notas_05.sql
- Carga_Itens_Notas_06.sql
- Carga_Itens_Notas_07.sql

Alguns arquivos demorarão mais para serem carregados, mas, ao final, você terá o seu banco com todos os dados recuperados e estará pronto para continuar o curso!

-----------------------------------------------------------------------
# 03Para saber mais: erro na importação


- [](https://cursos.alura.com.br/suggestions/new/mysql-consultas-sql/140667/question)

O erro que é apresentado é decorrente a importação dos arquivos que contém caracteres codificados em um conjunto de caracteres (charmap) que não é suportado pelo MySQL.

Para solucionar o problema tente realizar uma nova tentativa de importação dos dados. Para isso, siga os passos abaixo:

- Baixe e extraia o arquivo [RecuperacaoAmbiente.zip](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/RecuperacaoAmbiente.zip):

![Gif que simula a extração de arquivos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/rgIQcrL.gif)

- Exclua o schema `suco_vendas`, essa etapa evitará possíveis interferências em configurações antigas:

![Gif do workbench. Nela o usuário clica com o botão direito em suco_vendas em seguida, seleciona a opção Drop Schema. Em seguida a opçao Drop Now](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/4QCVyiE.gif)

- Agora iremos criar o Schema suco_vendas. Para isso, na aba Schemas, com o botão direito do mouse, clique em **Create Schema**:

![Na aba Schema, ao clicar com o botão direito do mouse, seleciona a opção create schema.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/Yl64JUg.gif)

- Em seguida, nomeie o schema sucos_vendas. E clique em **Apply** para as seguintes etapas.

![Gif que simula a criação do Schema](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/mFvvlHj.gif)

- Para a importação de cada arquivos. Selecione a opção **Open SQL Script**, selecione o arquivo correspondente e **execute**.

![Gif SQL Workbench. Ao selecionear em file é escolhido o arquivo em seguida é executado o script](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/01/zsGlj35.gif).

Você fará essa ação para os demais arquivos, Cargas_Itens_Notas e Carga_Tabelas_Cadastrais.

-----------------------------------------------------------------------
# 04História do SQL

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55577

## Transcrição

No vídeo que mostrarei agora, vou falar um pouco sobre a história da linguagem SQL, as suas vantagens e desvantagens, e como dividimos os grupos de comandos de SQL.

O vídeo que vou apresentar a seguir é o mesmo presente no [curso de Introdução ao SQL com MySQL](https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql), então quem já assistiu àquele curso, se quiser, terá uma chance de recapitular e quem não o viu poderá conhecer a história do SQL e suas características agora.

Vamos iniciar contando a história da linguagem SQL, para compreendermos quais foram os motivos, como surgiu e o seu histórico.

A linguagem SQL foi desenvolvida no começo dos anos 70, na cidade de São José, Califórnia, em um projeto chamado _System R_ da IBM, do inglês _International Business Machines_, cujo objetivo era comprovar a viabilidade da implementação de um modelo relacional, que um estudioso chamado Codd estava propondo.

Esse estudioso elaborou uma forma estruturada de realizar consultas nos bancos de dados que estavam surgindo, chamados “bancos de dados relacionais”.

Naquela época, os bancos de dados ainda não possuíam relacionamento entre as tabelas nas quais os dados eram armazenados. Era a categoria de banco de dados mais antigo, a sequencial, que efetuava a consulta dos registros de maneira sequencial, ou seja, um após o outro.

Com o surgimento dos bancos de dados relacionais (ou DBMS, do inglês, _Data Base Management System_, “Sistema de Gerenciamento de Banco de Dados), Codd considerou criar uma linguagem que facilitasse a extração e manipulação de dados, além da manipulação das estruturas desse banco aproveitando a característica de relacionamento entre eles.

Porém, não era apenas a IBM que estava trabalhando com os novos bancos de dados relacionais. Por volta dos anos 80, a Oracle, dentre outras empresas, também estava buscando maneiras mais fáceis de manipular essas novas estruturas.

Mais para o final dos anos 80 e início dos 90, o órgão americano, o **ANSI** (da sigla _American National Standard Institute_), estabeleceu alguns padrões para as consultas dos bancos de dados relacionais.

Então, foi criada a linguagem _SQL_, do inglês _Structured English Query Language_, que traduzindo seria algo como “linguagem de consulta estruturada em inglês”. No inglês, geralmente, é pronunciado _SEQUEL_ e não SQL, soletrando as letras - diferentemente do português, em que normalmente lemos como “ésse quê éle”.

O principal objetivo da linguagem SQL é padronizar a maneira como os registros são consultados nos bancos de dados relacionais. Atualmente, os bancos relacionais aderem ao padrão SQL, que vai além das consultas: é usado também, na criação, alteração, estruturação e manipulação do banco de dados, além da maneira como banco de dados interage com a segurança, entre outros usos.

Entre as vantagens do banco de dados relacional, a primeira é que essa padronização utilizando a linguagem SQL tem um custo reduzido do **_aprendizado_**. Por exemplo, o profissional com conhecimento sobre o SQL da Oracle conseguirá manipular facilmente o MySQL ou SQL Server da Microsoft. Por mais que existam diferenças - principalmente na parte de funções -, a adaptação do profissional não é uma questão complicada.

Outra vantagem, é a **_portabilidade_**. Por exemplo, é mais simples migrar sistemas que usam Oracle para SQL Server ou para MySQL, ou vice-versa. Lembrando que quanto mais for utilizado o SQL Standard definido pelo ANSI, mais fácil será essa portabilidade no futuro. Então, é útil evitar as funções específicas do banco de dados e permitir que o programa realize essa tarefa.

Já a **_longevidade_** é a garantia de que os seus relatórios ou processos utilizando o SQL irão funcionar por um longo período, já que estarão sempre adaptados ao padrão ANSI. Ou seja, ao efetuar um upgrade de banco de dados o seu sistema não ficará fora de serviço.

Outro benefício é a **_comunicação_**. O fato da maioria utilizar SQL permite a facilidade de comunicação entre os sistemas. Como, por exemplo, processos de ETL, (_extract, transform and load_), ou de integração entre sistemas que ficam mais simples de serem desenvolvidos, já que ambos utilizam o SQL padrão.

Por último temos a **_liberdade de escolha_**. Por existir um padrão de linguagem, se a empresa for optar pelo uso de um banco de dados relacional não ficará presa à linguagem de comunicação, por exemplo, já que são bem semelhantes. Ao tomar essa decisão, a corporação irá utilizar outros critérios de escolha, como performance, hardware, custo, entre outros.

Contudo, essa padronização não possui apenas vantagens, há algumas desvantagens - ainda que poucas. A primeira é a privação da **_criatividade_**. O SQL possui limitações que podem não atender às novas demandas no mercado na linguagem SQL, principalmente com o surgimento das redes sociais e dos enormes volumes de dados, o chamado _big data_. Ou seja, há uma carência nas coletas de dados que estão trafegando na internet.

Para tal, estão surgindo outros bancos que usam padrões diferentes dos bancos de dados relacionais, o chamado _NoSQL_. Estes atendem de forma mais eficiente as demandas de tabelas de _big data_ , como no caso das redes sociais. Lembrando que estamos nos referindo a estruturas que escapam do padrão ANSI e que, por isso, exigem um aprendizado mais específico.

Outro ponto é a escassez de estruturação da linguagem SQL, já que ela não possui _if_, _for_ e _when_, isto é, comandos condicionais como as demais linguagens de programação.

Para conseguir suprir essa carência da estruturação, os bancos de dados relacionais da Oracle, SQL e MySQL criaram suas linguagens próprias internas que realizam esse conjunto de estruturação usando a linguagem SQL, mas que acaba se afastando um pouco do padrão ANSI.

Falando um pouco sobre o padrão ANSI, este possui três grupos de comandos. O primeiro, é o **_DDLs_**, ou _Data Definition Language_ (linguagem de definição de dados). Os DDLs são a parte da linguagem SQL que permite a manipulação das estruturas do banco de dados. Como, por exemplo, criar um banco, tabelas, índices, apagar as tabelas e alterar a política de crescimento de índice. Ou seja, os comandos que envolvem a estrutura do banco de dados relacionais são os comandos do tipo DDL.

O segundo grupo de comandos são os chamados **_DML_**, ou _Data Manipulation Language_ (linguagem de manipulação de dados). Esse grupo visa gerenciar os dados: incluindo, alterando e excluindo informações nas estruturas do banco, como as tabelas. Além disso, realizam as consultas, buscam as informações das estruturas e exibiremos para o usuário.

Finalmente, chegamos nos comandos **_DCL_**, ou _Data Control Language_ ("linguagem de controle de dados"). Este grupo nos permite administrar o banco de dados como, por exemplo, o controle de acesso, o gerenciamento do usuário, gerenciar o que cada usuário(a) pode ou não visualizar, gerenciar o banco ao nível de estrutura (como a política de crescimento, como e onde será armazenado no disco), administrar os processos, saber quantos processos estão sendo executados, controle de log e assim por diante.

Nesse vídeo quis mostrar uma visão geral para vocês, não somente a história do SQL, mas também as suas características, vantagens, desvantagens e comandos dessa linguagem.

-----------------------------------------------------------------------
# 07História do MYSQL

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55578

## Transcrição

Da mesma maneira que, no vídeo anterior, reapresentei um conteúdo gravado para o [curso de Introdução ao SQL com MySQL](https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql), vou exibir a seguir mais um vídeo presente naquele curso, desta vez sobre a história do MySQL.

Vale o mesmo argumento: quem já fez o curso introdutório pode revisar aqui o conteúdo ou seguir para a próxima atividade; quem não assistiu ao vídeo e não tem familiaridade com o tema terá a oportunidade de vê-lo agora.

Agora, iremos entender sobre **a história do MySQL** e mencionar algumas de suas características.

Já conversamos um pouco sobre a história do SQL, quando os bancos relacionais estavam começando a ser popularizados. À época, três desenvolvedores, o David Axmark, Allan Larsson e Michael Widenius, buscaram elaborar uma interface SQL que fosse compatível com o que estava surgindo no mercado de banco de dados.

No início, eles utilizaram APIs de terceiros para efetuar os comandos SQL que buscavam informações de alguns outros bancos de dados de mercado. Porém, não obtiveram um retorno satisfatório e, por esse motivo, começaram a desenvolver sua própria API de consulta - e não apenas isso, também o seu próprio banco de dados, utilizando a linguagem C++.

Foi a partir disso que se iniciou o projeto MySQL. Ele se tornou bastante popular, primeiramente por ser apresentado como um software livre (_open source_), isto é, a comunidade teria acesso ao código-fonte para realizar alterações e contribuir com melhorias para o banco de dados. Além disso, se mostrou um banco de dados bastante ágil para a época, mais rápido que os concorrentes, além de apresentar um excelente mecanismo de multitarefas e de multiusuário.

Com isso, o MySQL mostrou que o seu servidor poderia ser usado e suportava bem a escalabilidade robusta em missão crítica, como, por exemplo, em um banco que nunca pode parar a operação dos serviços prestados.

> **Missão crítica:** todo sistema tecnológico fundamental para que os serviços de uma empresa continuem operando sem interrupções.

Como consequência, o MySQL se popularizou como software livre, inclusive de modo corporativo. No ano de 2008, o **MySQL AB**, empresa que gerenciava o código desse banco de dados, foi comprada por um bilhão de dólares por uma empresa chamada _Sun Microsystems_, uma empresa grande que a princípio atuava na área de hardware e depois começou a entrar para o ramo de software. Essa companhia também era responsável pela criação do Java.

Em 2009, após um ano da compra do MySQL, a _Sun Microsystems_ foi comprada pela Oracle, que passou a ter propriedade sobre todos os produtos. Por esse motivo, a Oracle é hoje dona do Java e do MySQL. Houve uma grande movimentação no mercado naquele tempo, já que a Oracle possuía o seu banco de dados relacional robusto e o MySQL estava se mostrando um concorrente à altura.

Quando o MySQL foi vendido, a comunidade _open source_ criou outro banco de dados, o **MariaDB**, que se tornou o sucessor em código aberto do MySQL.

Devido à sua popularidade, sendo uma opção de baixo custo para as empresas do mercado corporativo e de mercado online (que vinha crescendo bastante a partir dos 2009 e 2010), a Oracle manteve o desenvolvimento do MySQL.

A Oracle permitiu que os usuários pudessem escolher entre usar o programa como produto _open source_, sob os termos da licença GNU _(GNU's Not Unix!)_ ou comprar a licença padrão comercial do MySQL. Para esse último caso, a Oracle oferecia algumas vantagens para as empresas que comprassem o MySQL de forma corporativa, como suporte mais rápido e acesso à alguma documentação específica.

Porém, a licença oferecida de forma aberta ainda mantém a eficiência e características apresentadas antes do MySQL ser comprado por essas empresas gigantes da área de tecnologia.

Lembrando que o MySQL é um banco de dados relacional e compatível com a linguagem SQL. Por isso, vamos aprender nesse treinamento o SQL utilizando o MySQL.

O servidor do MySQL é robusto até certo ponto, já que deriva de características de multiacesso, integridade de dados, efetua o relacionamento entre tabelas, trabalha a concorrência quando vários usuários tentam acessar o mesmo dado na mesma tabela, realiza o controle de transações, entre outros processos. Essa robustez é uma característica importante no que diz respeito ao **servidor** do MySQL.

Outro aspecto importante é a **_portabilidade_** do banco de dados. O MySQL pode ser transacionado entre diversos sistemas. Isso significa que consigo desenvolver o banco de dados MySQL em Windows e posteriormente utilizar no Linux ou Unix, sendo assim, interplataforma.

Ademais, o banco MySQL provém várias APIs que permitem acessar os dados do MySQL usando .Net, Java, Python, PHP, JavaScript e JQuery, por exemplo. Isto é, as linguagens de programação que são mais usadas no mercado possuem APIs nativas para acesso ao MySQL.

Outro atributo importante é o **_multithreads_**. O MySQL usa uma programação de _threads_ utilizando diretamente o _Kernel_ do sistema operacional, permitindo aumentar a velocidade de transações, além de facilitar a integração da ferramenta com hardwares, possibilitando a escalabilidade da performance. Isto quer dizer que, caso tenha um MySQL usando um servidor com determinado número de CPUs, é possível acrescentar mais CPUs que o banco de dados se adapta usando o máximo do hardware disponível.

O banco de dados MySQL atua com diversas **formas de armazenamento** que se adaptam às características das suas necessidades. Por exemplo, algumas formas priorizam a velocidade, enquanto outras o alto volume de armazenamento, tudo dependendo do objetivo pelo qual você utiliza o MySQL. Discutiremos mais sobre isso em treinamentos futuros, quando abordarmos a parte de administração.

A **_velocidade_** é outro aspecto fundamental. O MySQL é considerado um dos bancos mais rápidos do mercado, sobretudo quando são utilizadas funcionalidades ligadas à internet. Como exemplo, podemos citar sites de e-commerce e de aplicações de internet, já que as nuvens da Amazon, do Google e da Microsoft (Azure) disponibilizam instâncias de MySQL com uma alta escalabilidade.

Já sobre **_segurança_**, o banco de dados MySQL possui internamente diversos mecanismos de segurança, o que o torna bastante seguro para o mercado. Além disso, permite a segregação dos dados por usuários de acesso, isto é, a pessoa possui acesso somente ao que lhe for permitido.

O MySQL também permite o armazenamento de uma quantidade enorme de dados, tornando a sua **_capacidade_** alta, a depender das formas de armazenamento. Se for escolhida uma forma que prioriza o volume de dados, há um limite hoje de até 65 mil terabytes de dados armazenados. Claro, recuperar e manipular esse volume de informação pode ser um pouco difícil e depender de muito hardware. A maioria das aplicações corporativas não precisam desse tamanho todo de armazenamento para trabalharem.

Já referente à **_aplicabilidade_**, o MySQL não se aplica somente a utilidades de internet - apesar de ser preferido por desenvolvedores web -, mas também aplicações de desktop ou corporativas, essas chamadas de _On Premises_, nas quais o banco de dados é instalado no próprio servidor da empresa. Esses bancos possuem o que chamamos ODBCs _(Open Database Connectivity_, comum em bancos baseados em Windows) ou JDBCs _(Java Database Connectivity_, comum em bancos baseados em Java), que permitem realizar acessos rápidos ao banco de dados MySQL em aplicações desktop.

Finalmente, falaremos um pouco sobre o **_log_**. No MySQL há um forte gerenciamento de log, que registra tudo o que fazemos no banco. Isso é um ponto interessante quando é necessário realizar uma recuperação de dados ou se for preciso fazer o que é chamado réplica de servidores, técnica bastante usada quando temos um servidor chamado _master_ e outro _slave_, existindo uma sincronização de dados entre eles.

Por esse motivo, é um dos bancos de dados mais usados em nuvem, já que esse tipo de banco possui diversas replicações em diferentes lugares do planeta para que, caso um CPD (Centro de Processamento de Dados) caia, outro continue operando e a aplicação siga tendo alta disponibilidade de acesso.

Isso é um pouco da história e características do banco MySQL, que vamos usar nesse treinamento para mostrar como funciona a linguagem SQL.


-----------------------------------------------------------------------
# 08Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Instale o MySQL, conforme o vídeo [**Instalando o MySQL Server**](https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql/task/54324), da aula 1 do curso [**Introdução ao SQL: Manipule dados com MySQL**](https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql).

2) Abra o MYSQL Workbench. Use a conexão LOCALHOST.

3) Clique com o Botão da direita do mouse sobre a lista das bases e escolha _Create Schema_.

4) Insira o nome Sucos_Vendas. Clique em _Apply_ duas vezes.

5) Faça Download do arquivo RecuperacaoAmbiente.zip.

6) Descompacte o arquivo.

7) Selecione, na área Navigator, em Administration.

8) Selecione o link Data Import/Restore.

9) Na opção Import From Dump Project Folder escolha o diretório DumpSucosVendas.

10) Selecione Start Import.

11) Verifique na base Sucos_Vendas se as tabelas foram criadas.

12) Existe outra maneira que importar através de script. Basta executar todos os arquivos .SQL compactados no arquivo RecuperacaoAmbiente.zip.

-----------------------------------------------------------------------
# 01Conhecendo o banco de dados

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55579

## Transcrição

Para construir consultas em um banco de dados, é fundamental conhecer o banco com que se vai trabalhar. Já sabemos que toda base é composta por tabelas, que cada uma delas possui uma chave primária, e que se relacionam por meio de um mecanismo de chaves estrangeiras. Portanto, ao trabalhar com um banco, é importante identificar as tabelas que estão à disposição, o que significa cada campo e qual o seu tipo, quais são as chaves primárias e como as tabelas se relacionam entre si (ou seja, entender quais são as chaves estrangeiras).

Para obter todas essas informações, uma opção é consultar a **documentação** do banco de dados. Em empresas pequenas, é comum que a pessoa que irá consultar o banco seja a mesma que o projetou (e, por isso, esse documento talvez não tenha sido elaborado). Independentemente do tamanho da empresa, nem sempre teremos à disposição uma documentação satisfatória.

Por meio do MySQL Workbench também temos a possibilidade de conhecer tudo que está incluso no nosso banco. Então, nesse vídeo, vamos abrir o MySQL Workbench, entrar na nossa conexão e verificar o que temos na nossa base "sucos_vendas".

Começaremos clicando na seta à esquerda do nome "sucos_vendas" para abrir um menu com mais informações sobre a base. Veremos quatro grupos de componentes: _tables_, _views_, _stored procedures_ e _functions_ - nosso foco agora serão as tabelas (_tables_).

Ao abrir o menu _tables_, notaremos que há cinco tabelas: "itens_notas_fiscais", "notas_fiscais", "tabela_de_clientes", "tabela_de_produtos" e "tabela_de_vendedores".

Pelos próprios nomes, já temos uma boa noção do que elas tratam: "tabelas_de_vendedores" é a lista de vendodores, "tabela_de_produtos" são os produtos vendidos pela empresa de sucos, "tabela_de_clientes" é a lista de clientes, "notas_fiscais" e "itens_notas_fiscais" são referentes às notas fiscais.

> Normalmente uma nota fiscal é composta por um cabeçalho seguido de uma lista dos itens comprados pelo cliente, então é comum representar uma nota fiscal com duas tabelas - uma com os cabeçalhos e outra com os itens.

Quando eu nomeei essas tabelas, me preocupei mais com a didática do que com a nomenclatura, então ficou fácil deduzir o que significa cada tabela. Em projeto reais, no entanto, você não vai encontrar esses nomes amigáveis. Você pode se deparar com nomenclaturas como "tb018665" ou "tabCli", nomes que não te darão muitas pistas, principalmente porque, dentro das empresas, existem regras de nomenclaturas para as tabelas.

Assim sendo, é interessante usar o MySQL Workbench para descobrir o que cada tabela contém e como ela se relaciona com outras tabelas. A seguir, vamos descobrir de que trata "tabela_de_clientes".

Abrindo o menu de "tabelas_de_clientes", veremos quatro subgrupos: _Columns_ (colunas, que também podemos chamar de "campos"), _Indexes_ (índices), _Foreign Keys_ (chaves estrangeiras) e _Triggers_.

> Nesse curso, não vamos nos aprofundar em _triggers_, pois não têm uma relação estreita com consultas SQL, e também não focaremos em índices. Como eu já havia explicado sobre organização de banco de dados em um curso anterior, vale lembrar que índices são estruturas que nos auxiliam a encontrar elementos mais rapidamente. Isso é uma regra no MySQL: para toda chave primária ou estrangeira, o MySQL automaticamente criará um índice. Isso ocorre porque a chave primária é uma coluna que não pode se repetir, assim, toda vez que eu insiro um item novo em uma tabela, o banco de dados faz uma busca nessa tabela para verificar se esse item já existe, e o índice facilitará muito nessa busca. O mesmo vale para a chave estrangeira: se há duas tabelas que se relacionam e eu quero incluir um novo registro na tabela-filha cujo campo tem uma relação de chave estrangeira com a tabela-pai, essa inclusão só é possível se esse campo existir na tabela-pai. Então, o banco de dados fará uma busca e só permitirá o novo registro se essa condição for atendida. Também nesse caso o índice funciona como um facilitador.

Em "tabela_de_clientes", vamos abrir o subgrupo _Columns_ e conferir uma lista das colunas que compõem essa tabela ("CPF", "NOME", "ENDERECO_1", "ENDERECO_2", "BAIRRO", "CIDADE", "ESTADO", "CEP", "DATA_DE_NASCIMENTO", "IDADE", "SEXO", LIMITE_DE_CREDITO", "VOLUME_DE_COMPRA" e "PRIMEIRA_COMPRA"). Se você clicar sobre o nome de uma das colunas, é possível ver mais detalhes no painel esquerdo inferior. Dentre essas informações, o que mais nos interessa é saber se o campo em questão é uma chave primária ou não, e com que tipo de dado estamos lidando. Clicando na coluna "CPF", por exemplo, verificamos que se trata de uma chave primária, pois vem acompanhada da sigla **PK** (em inglês, _primary key_), e que é um **varchar(11)**, ou seja, um texto de 11 caracteres.

Em seguida, exploraremos o subgrupo _Indexes_ de "tabela_de_clientes", no qual podemos ver os índices _states_. Nesse caso, essa tabela tem apenas chave primária, então há apenas um índice associado à chave primária. Não há chaves estrangeiras, ou seja, essa tabela não tem um relacionamento com nenhuma outra - não é filha de uma tabela-pai. E também não há _triggers_.

Diferentemente disso, ao abrir _indexes_ da tabela "notas_fiscais", verifica-se que existem três índices. O de nome "_PRIMARY_" é referente à chave primária e os índices "MATRICULA" e "CPF" me dão pistas de que estão relacionados a chaves estrangeiras. Como esperado, abrindo o subgrupo _foreing keys_ dessa tabela, veremos duas chaves estrangeiras cujos nomes o banco produziu automaticamente. Selecionando uma dessas chaves, são mostradas informações mais detalhadas, no painel abaixo, sobre o relacionamento entre tabelas.

Assim sendo, essa é uma das maneiras de conhecer o seu banco de dados. Mas existe também uma forma mais visual de analisar as tabelas e seus relacionamentos. Inclusive, muitas pessoas preferem ver a documentação por meio dessa representação mais visual e, no caso de bancos com poucas tabelas, até imprimir esse esquema e deixar ao alcance para consultas.

Para gerar esse esquema visual, vamos até a barra superior do programa e selecionamos **"Database > Reverse Engineer..."**. Em outras palavras, faremos uma engenharia reversa no nosso banco que já existe. Na caixa de diálogo que será aberta, selecionamos a nossa conexão usual, clicamos em "_Next_" duas vezes, selecionamos a base "sucos_vendas", clicamos em _"Next"_ mais duas vezes e, em seguida, em _"Execute"_.

Com isso, será gerado um diagrama que representa as tabelas e suas relações. Você pode dar zoom, arrastar e organizar os elementos do esquema da maneira que preferir.

![Diagrama com cinco retângulos, inteligados por linhas. Cada retângulo representa uma tabela do banco de dados e contém o nome da tabela e uma lista de suas colunas e tipos. O retângulo de "notas_fiscais" está interligado com "tabelas_de_clientes", "tabelas_de_vendedores" e "itens_notas_fiscais". O retângulo de "tabelas_de_produtos" está interligado com "itens_notas_fiscais".](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/Transcri%C3%A7%C3%A3o/Aula+2/Imagens/diagrama_workbench.png)

Temos então várias tabelas, em cada uma delas há informações sobre campos e tipos. A tabela de produtos, a de clientes e a de vendedores são cadastrais, ou seja, nenhuma outra "chega" nelas.

Temos também a tabela "notas_fiscais" com dados do cabeçalho das notas fiscais. Este deve conter o número identificador da nota, o cliente e o vendedor. É essencial lembrar que o cliente e o vendedor que eu coloco no cabeçalho da nota fiscal precisam necessariamente existir nas tabelas cadastrais! Então, se você clicar sobre a linha que conecta "notas_fiscais" e "tabela_de_clientes", é possível ver em destaque quais são os campos que estão relacionados entre essas duas tabelas (no caso, trata-se do "CPF").

Entre "notas_fiscais" e "tabela_de_vendedores", os que campos que se relacionam são os de "MATRICULA". Entre "notas_fiscais" e "itens_notas_fiscais" são os campos de "NUMERO" (da nota fiscal). E entre "itens_notas_fiscais" e "tabela_de_produtos", os campos de "CODIGO_DO_PRODUTO".

Dessa forma, podemos utilizar esse diagrama como guia para as consultas. Normalmente, quando se tem um analista responsável por um banco de dados numa empresa, ele acaba até decorando as tabelas, os campos e os relacionamentos e sequer precisa consultar esse diagrama de entidades! Mas essa é uma ótima forma de melhor se familiarizar com seu banco de dados.

-----------------------------------------------------------------------
# 03Revisando consultas

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55580

## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/Revisao%20Consultas.sql)

Agora que temos uma noção do conteúdo da nossa base de dados, podemos começar a fazer consultas. No MySQL Workbench, criaremos um novo _script_ SQL, clicando no primeiro ícone da barra superior do programa (ou usando o atalho "Ctrl + T").

De início, é importante escolher a base de dados com que vamos trabalhar. Para selecionar um banco, basta dar um clique duplo sobre seu nome e ele ficará destacado em negrito, significando que está selecionado. Por exemplo, posso escolher "sakila" (um banco padrão do MySQL Workbench) e tudo que eu fizer será aplicado a esta base. Nesse sentido, como pretendo me dedicar à base "sucos_vendas", darei um clique duplo nela.

Outra alternativa é "forçar" a conexão com um banco através do comando `USE`. Em nosso _script_, digitamos:

```undefined
USE sucos_vendas;
```

Em seguida, execute o _script_, clicando no terceiro ícone da barra acima da área de digitação (um símbolo de raio).

> Não se esqueça de colocar um ponto e vírgula (**;**) ao final de cada linha.

> Na sintaxe SQL, não há distinção entre letras maiúsculas e minúsculas, portanto você pode digitar `USE` ou `use`. Opto pela primeira opção para destacar as partes que são comandos SQL.

Com o banco selecionado, vamos examinar as tabelas. Para conferir todo o conteúdo da "tabela_de_clientes", por exemplo, basta usar o comando `SELECT`, seguido das colunas que gostaríamos de ver (separadas por vírgula), seguidas de `FROM` e o nome da tabela a que estamos nos referindo:

```sql
SELECT CPF, NOME, ENDERECO_1, ENDERECO_2, BAIRRO, CIDADE, ESTADO, CEP, DATA_DE_NASCIMENTO, IDADE, SEXO, LIMITE_DE_CREDITO, VOLUME_DE_COMPRA, PRIMEIRA_COMPRA FROM tabela_de_clientes;
```

Selecionaremos esse trecho do _script_ e clicaremos no botão de execução. Ao rodar o código, logo abaixo teremos uma tabela como retorno. Note que, caso algum termo esteja escrito incorretamente, o programa acusará um erro na área _output_ (saída), no painel inferior. Se isso ocorrer, corrija e execute novamente.

À direita do resultado da consulta, há três opções de visualização. A padrão é _Result Grid_, que organiza os dados em forma de grade. _Form Editor_ mostra o resultado com um leiaute semelhante a uma entrada de dados, com opções de navegação na parte superior dessa área. Já _Field Types_ foca nos tipos de dados dos resultados das seleções. Ademais, também temos a aba _Query Stats_, que nos informa sobre o tempo de execução da _query_ (consulta).

Voltando ao nosso ambiente, um modo mais simples de consultar todos os campos de uma tabela é usar o asterisco em vez de escrever o nome de todas as colunas:

```sql
SELECT * FROM tabela_de_clientes;
```

Em outras palavras, ao colocar o asterisco, estamos indicando que queremos consultar **todos** os campos da tabela. O código é diferente, porém o resultado é o mesmo.

Vale destacar que nem sempre há necessidade de consultar todas as colunas, é possível especificar apenas os campos desejados:

```sql
SELECT CPF, NOME FROM tabela_de_clientes;
```

Em consultas SQL, existe a opção do uso de _alias_, que funciona como um apelido que atribuímos a determinado campo. Isso é feito com o uso de `as`:

```vbnet
SELECT CPF as IDENTIFICADOR, NOME as CLIENTE FROM tabela_de_clientes;
```

Nesse caso, "identificador" representa o CPF e "cliente" representa o NOME. Assim, quando o script for executado, notaremos que as colunas do resultado são os _aliases_ e não os nomes originais dos campos (CPF e NOME).

Como expliquei anteriormente, as nomenclaturas usadas para tabelas nem sempre são facilmente identificáveis e, às vezes, isso também ocorre em relação às colunas das tabelas. Nesses casos, o uso de _aliases_ nos auxilia nas leituras dos dados, pois tornam os campos mais reconhecíveis.

Outro cenário em que os _aliases_ são relevantes são as consultas que empregam o `JOIN`. A cláusula `JOIN` (que aprenderemos mais adiante no curso) permite a junção de duas tabelas em uma mesma consulta e, nesse processo, pode ser que essas tabelas tenham campos com os mesmos nomes. Aqui, então, o uso de _aliases_ é interessante para distinguir esses campos.

A seguir, vamos consultar a "tabela_de_produtos":

```sql
SELECT * FROM tabela_de_produtos;
```

Até agora, fizemos consultas que abrangiam tudo de uma tabela, mas por meio da cláusula `WHERE` temos a opção de segregar os dados que nos interessa ver:

```sql
SELECT * FROM tabela_de_produtos WHERE CODIGO_DO_PRODUTO ="1000889";
```

Nesse caso, determinamos uma **condição lógica** (`CODIGO_DO_PRODUTO = "1000889"`) de modo que o resultado dessa consulta mostra apenas o produto que possui esse código específico. Aqui, trata-se do "Sabor da Montanha - 700ml - Uva".

> Às vezes, o editor de texto do MySQL Workbench traz opções de preenchimento automático enquanto digitamos. Por exemplo, caso você erre o nome de uma tabela, ele possivelmente trará uma caixa de sugestões com nomes de tabelas que existem no seu banco de dados.

"CODIGO_DO_PRODUTO" é uma chave primária, no entanto, qualquer campo pode ser usado para filtrar resultados, por exemplo, sabor:

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR = "Uva";
```

Essa consulta retorna apenas um produto, pois somente um suco tem sabor uva. Trocando o valor "uva" por "limão", nenhum produto será mostrado, pois não há sucos com esse sabor. Já ao escrever "laranja", são cinco os produtos que atendem a essa condição.

Mas qual é a grande diferença interna na execução da consulta com `WHERE CODIGO_DO_PRODUTO = '1000889'` e da consulta com `WHERE SABOR = 'Uva'`? A resposta está na performance!

Buscas com condições de filtro que possuem chaves primárias (como "CODIGO_DO_PRODUTO") são mais rápidas, pois chaves primárias têm índices que facilitam muito esse processo. "SABOR", por outro lado, não é uma chave primária nem estrangeira, logo não tem índice e consequentemente resulta numa busca um pouco mais lenta.

Como nosso banco de dados atual é relativamente pequeno, essa lentidão não é perceptível, porém essa diferença de performance pode ser problemática em bancos mais volumosos. Uma forma de solucionar esse problema é atribuindo um índice à coluna, algo que aprenderemos mais para frente, em outro curso de MySQL.

Seguindo com as consultas, agora vamos fazer um filtro referente à embalagem:

```sql
SELECT * FROM tabela_de_produtos WHERE EMBALAGEM = 'PET';
```

Ao executar esse _script_, note que na tabela o valor "PET" está escrito com letras **maiúsculas**. O que será que acontece se eu fizer a consulta usando letras **minúsculas**?

```sql
SELECT * FROM tabela_de_produtos WHERE EMBALAGEM = 'pet';
```

O resultado é o mesmo! Como vimos anteriormente, o MySQL não distingue entre letras maiúsculas e minúsculas, ele fará a busca da mesma forma.

Também podemos fazer seleções usando valores como critérios. Na nossa base, temos o produto "Videira do Campo - 1,5 Litros - Melancia" cujo "PRECO_DE_LISTA" é 19.51. Vamos criar um filtro usando esse valor como critério:

```sql
SELECT * FROM tabela_de_produtos WHERE PRECO_DE_LISTA = 19.51
```

Ao rodar essa consulta, o MySQL retorna vazio. Mas por que isso acontece, se vimos que existe um produto que corresponde a esse filtro? Ao verificar mais detalhes sobre "PRECO_DE_LISTA", vê-se que é um dado do tipo _float_. Isso significa que é um **ponto flutuante**, ou seja, não é **exatamente 19.51** mas, sim, um número com muitas casas decimais além das que estamos vendo. Em outras palavras, não corresponde completamente à condição que descrevemos.

Para solucionar esse problema e filtrar um valor cravado, bem específico, podemos usar os operadores `BETWEEN` (entre) e `AND` (e):

```sql
SELECT * FROM tabela_de_produtos WHERE PRECO_DE_LISTA BETWEEN 19.50 AND 19.52;
```

Assim, selecionamos tudo de "tabela_de_produtos" cujo "PRECO_DE_LISTA" está entre 19.50 e 19.52. Percebemos que fazer buscas com campos _float_ é um pouquinho mais complicado.

Dessa forma, nesse vídeo procurei fazer uma apresentação dos comandos de `SELECT` (com o asterisco ou especificando campos), usando alguns filtros simples que usam **=*_, *_>**, **≥*_, *_<**, **≤** ou `BETWEEN` entre dois valores. Foi uma revisão do que vimos no [curso de Introdução ao SQL com MySQL](https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql).

-----------------------------------------------------------------------
# 05Consultas condicionais

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55581

## Transcrição

Até agora, para segregar dados de uma consulta, usamos a cláusula `WHERE` seguida de uma condição, por exemplo:

```sql
SELECT * from tab WHERE X = A;
```

Uma expressão condicional pode ser verdadeira (V) ou falsa (F). Quando for verdadeira, o elemento avaliado será exibido no resultado da consulta. Quando for falsa, será omitido.

Esse resultado depende do uso do sinal lógico, que pode ser o de igualdade (**=**), de diferença (**≠**), maior (**>**), menor (**<**), maior ou igual (**≥**), menor ou igual (**≤**). Caso a caso, podemos verificar se uma expressão é verdadeira ou falsa, e analisar os dados resultantes.

Os filtros que criamos até então são bastante simples, portanto vamos incrementá-los colocando os operadores `AND` e `OR` no meio das expressões. Por exemplo:

```sql
SELECT * FROM tab WHERE X = A OR Y = B;
SELECT * FROM tab WHERE X = A AND Y = B;
```

No exemplo acima, temos duas consultas condicionais, cada qual composta por duas **expressões** - `X = A` e `Y = B` - separadas por um operador lógico no meio.

Cada uma das expressões em uma condição pode ser verdadeira ou falsa e, a depender do operador lógico entre elas, a expressão como um todo (a condição completa) também poderá ser considerada verdadeira ou falsa. Vamos ver isso mais a fundo a seguir.

O operador `OR` determina que, se uma das expressões for verdadeira, a expressão completa será verdadeira. Somente no caso de as duas expressões serem falsas que a expressão completa também será falsa. Veja uma tabela que resume os possíveis resultados para `X = A OR Y = B`:

|**Condição**|**Resultado**|
|---|---|
|(V) OR (V)|Verdadeiro|
|(V) OR (F)|Verdadeiro|
|(F) OR (V)|Verdadeiro|
|(F) OR (F)|Falso|

Diferente disso, o operador `AND` estabelece que, somente se **todas** as expressões forem verdadeiras, a expressão completa também será verdadeira. Se uma delas for falsa, a expressão toda é falsa. Veja, a seguir, uma tabela que resume essa explicação:

|**Condição**|**Resultado**|
|---|---|
|(V) OR (V)|Verdadeiro|
|(V) OR (F)|Falso|
|(F) OR (V)|Falso|
|(F) OR (F)|Falso|

Outro operador importante é o `NOT`, que é aplicado para inverter o resultado de uma expressão. Observe o seguinte exemplo:

```java
NOT (X = A OR Y = B);
NOT (X = A AND Y = B);
```

No primeiro caso, se a expressão interna `X = A OR Y = B` for verdadeira, o operador `NOT` torna o resultado falso. Por outro lado, se a expressão interna for falsa, colocando o `NOT` acabamos com uma expressão verdadeira. O mesmo serve para o segundo caso: se a expressão interna `X = A AND Y = B`for verdadeira, o resultado com o `NOT` será falso e vice-versa.

Veja a tabela que resume as possíveis conclusões para `NOT (X = A OR Y = B)`. O resultado só será verdadeiro quando ambas expressões forem falsas:

|**Condição**|**Resultado**|
|---|---|
|(V) OR (V)|Falso|
|(V) OR (F)|Falso|
|(F) OR (V)|Falso|
|(F) OR (F)|Verdadeiro|

E, para `NOT (X = A AND Y = B)`, o resultado só será falso quando ambas expressões forem verdadeiras:

|**Condição**|**Resultado**|
|---|---|
|(V) OR (V)|Falso|
|(V) OR (F)|Verdadeiro|
|(F) OR (V)|Verdadeiro|
|(F) OR (F)|Verdadeiro|

Como o MySQL trabalha com esses tipos de consultas condicionais? Vejamos alguns exemplos, preenchendo a seguinte tabela com os resultados obtidos.

|**X**|**Y**|**Expr1**||**Expr2**||**Result**|
|---|---|---|---|---|---|---|
|A|B||||||
|C|E||||||
|A|F||||||
|F|B||||||

> Para melhor visualização, vários elementos da tabela foram omitidos. A tabela completa pode ser encontrada no projeto do curso.

**Exemplo 1:** A condição é `X = A`. A partir disso, o MySQL percorrerá a coluna "X", comparando cada valor com a constante `A`. Sempre que X for igual a `A`, o MySQL gravará na memória que, naquela instância, a expressão é verdadeira:

|**X**|**Y**|**Expr1**||**Expr2**||**Result**|
|---|---|---|---|---|---|---|
|A|B|A = A|V|||V|
|C|E|C = A|F|||F|
|A|F|A = A|V|||V|
|F|B|F = A|F|||F|

Portanto, ao fazer uma consulta com a condição `X = A`, o MySQL retornará apenas os registros que constam como **verdadeiro**. No caso da tabela acima, seria um retorno de duas linhas (a primeira e a terceira).

**Exemplo 2:** A condição é `X = A OR Y = B`. Dessa vez, o MySQL percorrerá o campo "X" (comparando-o com `A`) e o campo "Y" (comparando-o com `B`), gravando os resultados parciais de cada expressão.

Como se trata de uma condição com o operador `OR`, sabemos que somente quando as duas expressões forem falsas que a expressão como um todo também será falsa:

|**X**|**Y**|**Expr1**||**Expr2**||**Result**|
|---|---|---|---|---|---|---|
|A|B|A = A|V|B = B|V|V|
|C|E|C = A|F|E = B|F|F|
|A|F|A = A|V|F = B|F|V|
|F|B|F = A|F|B = B|V|V|

Ou seja, com base na nossa tabela, ao realizar uma consulta com a condição `X = A OR Y = B`, nosso retorno terá três registros (os verdadeiros).

**Exemplo 3:** A condição é `X = A AND Y = B`. O processo será parecido com o anterior, porém dessa vez estamos trabalhando com o operador `AND`. Ou seja, somente quando as duas expressões forem verdadeiras que a expressão como um todo também será verdadeira:

|**X**|**Y**|**Expr1**||**Expr2**||**Result**|
|---|---|---|---|---|---|---|
|A|B|A = A|V|B = B|V|V|
|C|E|C = A|F|E = B|F|F|
|A|F|A = A|V|F = B|F|F|
|F|B|F = A|F|B = B|V|F|

O retorno dessa consulta terá apenas um registro (a primeira linha).

**Exemplo 4:** A condição é `NOT (X = A OR Y = B)`. Nesse caso, o MySQL percorrerá com a expressão interna `X = A OR Y = B` (cuja tabela será igual ao exemplo 3) e, em seguida, o `NOT` será responsável por inverter os valores da coluna "Result":

|**X**|**Y**|**Expr1**||**Expr2**||**Result**|
|---|---|---|---|---|---|---|
|A|B|A = A|V|B = B|V|F|
|C|E|C = A|F|E = B|F|V|
|A|F|A = A|V|F = B|F|V|
|F|B|F = A|F|B = B|V|V|

Seguindo o padrão, os registros selecionados na consulta serão os verdadeiros.

**Exemplo 5:** A condição é `X = A AND NOT (Y = B)`. Perceba que o `NOT` será aplicado somente a uma das expressões. O MySQL percorrerá a coluna "X", comparando os valores à constante `A`. Depois, percorrerá o campo "Y", comparando os valores à `B`:

|**X**|**Y**|**Expr1**||**Expr2**||**Result**|
|---|---|---|---|---|---|---|
|A|B|A = A|V|B = B|V||
|C|E|C = A|F|E = B|F||
|A|F|A = A|V|F = B|F||
|F|B|F = A|F|B = B|V||

Em seguida, por causa do operador `NOT`, os resultados da expressão 2 serão invertidos:

|**X**|**Y**|**Expr1**||**Expr2**||**Result**|
|---|---|---|---|---|---|---|
|A|B|A = A|V|B = B|F||
|C|E|C = A|F|E = B|V||
|A|F|A = A|V|F = B|V||
|F|B|F = A|F|B = B|F||

E, por fim, aplicaremos o operador `AND` - somente quando as duas expressões forem verdadeiras que a expressão como um todo também será verdadeira:

|**X**|**Y**|**Expr1**||**Expr2**||**Result**|
|---|---|---|---|---|---|---|
|A|B|A = A|V|B = B|F|F|
|C|E|C = A|F|E = B|V|F|
|A|F|A = A|V|F = B|V|V|
|F|B|F = A|F|B = B|F|F|

A seleção resultante terá apenas o terceiro registro da tabela acima. Assim, examinamos vários cenários possíveis relativos às consultas condicionais.

Para finalizar esse vídeo, vamos resolver, passo a passo, uma expressão mais complexa:

```r
((NOT (V AND F)) AND (V OR F)) OR F
```

Nesse contexto, já temos os resultados das expressões (verdadeiras ou falsas), falta destrinchar essa operação para chegar ao resultado. Começaremos de dentro para fora, ou seja, a partir das expressões internas.

Seguindo a lógica que aprendemos, a condição `V AND F` resulta em falso (F), então podemos substituí-la assim:

```r
((NOT (F)) AND (V OR F)) OR F
```

Quanto à condição `V OR F`, sabemos que resulta em verdadeiro (V):

```r
((NOT (F)) AND (V)) OR F
```

Em seguida, respeitando os parênteses, vamos solucionar a expressão `NOT (F)`. O operador `NOT` inverte o resultado, logo temos verdadeiro:

```scss
((V) AND (V)) OR F
```

Agora, resolveremos `V AND V`. Como aprendemos, quando tratamos do operador `AND`, se ambas expressões são verdadeiras, a expressão como um todo também será verdadeira:

```r
(V) OR F
```

E, por fim, `V OR F` resulta em verdadeiro. Sendo assim, constatamos que a expressão `((NOT (V AND F)) AND (V OR F)) OR F` é verdadeira.

Chegamos a todas essas conclusões através da lógica, um campo de estudo que vem da filosofia e também se aplica à área de informática (não somente no SQL - programadores de diversos setores precisam lidar com condições e operadores que vimos nesse material).

Dessa forma, nota-se que depois do `WHERE` podemos encontrar condições bastante complexas, com `AND`, `OR`, `NOT` e parênteses, mas nas seleções das tabelas nós visualizamos apenas aquilo que a expressão está atestando. Nesse material, então, procurei mostrar mais a teoria dessa parte de lógica e, no próximo vídeo, vamos colocar na prática com o MySQL.

-----------------------------------------------------------------------
# 07Aplicando consultas condicionais

## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/Consultas%20Condicionais.sql).

Então, vamos colocar em prática os conceitos de condições lógicas que estudamos previamente, usando `AND`, `OR`, `NOT` e assim por diante. Começaremos criando um novo script SQL e nos certificando de que estamos com a base de dados "sucos_vendas" selecionada.

Nossa primeira consulta será simples, com uma condição que já aprendemos como trabalhar:

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR = 'Manga';
```

Ao executar o script, você pode verificar na coluna "SABOR" que todos os registros encontrados têm valor "manga". Então, vamos incrementar nossa consulta, adicionando mais uma expressão à condição:

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR = 'Manga' OR TAMANHO = '470 ml';
```

Com essa seleção, vamos filtrar apenas os registros que tenham sabor manga **ou** tamanho de 470 ml (**ou** até mesmo os dois). Executando o script, podemos reparar que o primeiro item do resultado atende às duas expressões; os quatro produtos seguintes têm sabor manga, porém tamanhos diferentes de 470 ml; e o último registro tem 470 ml, no entanto, é sabor laranja.

A seguir, criaremos uma consulta com `AND`:

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR = 'Manga' AND TAMANHO = '470 ml';
```

Nesse caso, como usamos o `AND`, o retorno terá apenas um registro - nessa tabela, é o único produto cujo sabor é manga **E** o tamanho é igual a 470 ml **ao mesmo tempo**.

Agora, vamos inserir o `NOT`, para fazer a seleção inversa: uma consulta de todos os registros **exceto** os que têm sabor manga **e** tamanho 470 ml **ao mesmo tempo**:

```sql
SELECT * FROM tabela_de_produtos WHERE NOT (SABOR = 'Manga' AND TAMANHO = '470 ml');
```

Dessa consulta obteremos um resultado bem extenso. Já se colocarmos o `NOT` em combinação com `OR`, o retorno não será tão abrangente:

```sql
SELECT * FROM tabela_de_produtos WHERE NOT (SABOR = 'Manga' OR TAMANHO = '470 ml');
```

Desse script resulta uma seleção em que não veremos nenhum registro com sabor manga e nenhum registro com tamanho 470 ml.

Há ainda outras formas de usar o `NOT`. Podemos, por exemplo, inseri-lo na frente de apenas uma das expressões:

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR = 'Manga' AND NOT (TAMANHO = '470 ml');
```

Nesse caso, procuraremos itens que tenham sabor manga **E** que o tamanho **não** seja 470 ml. Isso é, ao rodar o script, na tabela resultante você encontrará todos os produtos com sabor manga **exceto** os que tem tamanho 470 ml - qualquer outro tamanho será apresentado.

Existem mais condições lógicas além das que expliquei no vídeo anterior. Uma delas é o `IN`, que pode ser interpretado como "contido":

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR IN ('Laranja', 'Manga');
```

Com esse script, estamos selecionando todos os produtos da "tabela_de_produtos" cujo sabor está **contido** na lista `('Laranja', 'Manga')`. Essa consulta é equivalente à seguinte:

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR = 'Laranja' OR SABOR = 'Manga';
```

Ou seja, também procuramos registros cujo sabor seja laranja ou manga.

Além disso, temos a opção de criar condições que mesclam diferentes colunas. Para exemplificar, vamos fazer outra consulta com o operador `IN`, desta vez com a tabela de clientes:

```sql
SELECT * FROM tabela_de_clientes WHERE CIDADE IN ('Rio de Janeiro', 'São Paulo') AND IDADE >= 20;
```

Rodando esse script, teremos como resultado uma tabela com todos os clientes cuja cidade consta como Rio de Janeiro **ou** como São Paulo, **e** cuja idade seja maior ou igual a 20.

Ademais, há sempre a possibilidade de criar consultas mais complexas:

```sql
SELECT * FROM tabela_de_clientes WHERE CIDADE IN ('Rio de Janeiro', 'São Paulo') AND (IDADE >= 20 AND IDADE <= 22);
```

É interessante fazer uso dos parênteses, como em `(IDADE >= 20 AND IDADE <=22)`, para manter a ordem em seu script. Mesmo que não acarrete diferenças na execução da consulta, trata-se de uma boa prática de organização. Nesse caso, estamos unindo condições que dizem respeito ao mesmo campo. Um código bem indentado e com uma boa estrutura facilita bastante na hora de ler, interpretar e corrigir problemas.

Assim, nesse vídeo buscamos colocar em prática toda a teoria que aprendemos anteriormente, aplicando os operadores e sinais lógicos em uma variedade de consultas.

-----------------------------------------------------------------------
# 08Selecionar vendas

Qual seria o comando SQL para selecionar todos os itens de notas fiscais cuja quantidade seja maior que 60 e preço menor ou igual a 3?

- Alternativa correta
    
    ```sql
    SELECT * FROM itens_notas_fiscais 
    WHERE QUANTIDADE >= 60 AND PRECO <= 3;
    ```
    
    Alternativa errada! Não é maior ou igual a 60. É maior que 60.
    
- Alternativa correta
    
    ```sql
    SELECT * FROM itens_notas_fiscais 
    WHERE QUANTIDADE > 60 AND PRECO <= 3;
    ```
    
    Alternativa correta! Este comando irá obter a resposta contida no enunciado.
    
- Alternativa correta
    
    ```sql
    SELECT * FROM notas_fiscais 
    WHERE QUANTIDADE >= 60 AND PRECO <= 3;
    ```


-----------------------------------------------------------------------
# 09Usando o LIKE

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55583

## Transcrição

> [Você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/Consultas%20LIKE.sql)

Vamos aprender mais um comando que filtra informações de uma seleção: o operador `LIKE`. Normalmente, ele é usado assim:

```sql
SELECT * FROM tab WHERE campo LIKE '<condição>';
```

Nesse exemplo, "tab" refere-se a uma tabela, e "campo" é a coluna que se está consultando. Após o `LIKE`, escrevemos o critério de busca entre **aspas simples**. Esse critério deve ser um texto e pode vir acompanhado do símbolo de porcentagem, também chamado de _percent_ (**%**).

O `%` é usado para representar qualquer registro genérico que venha **antes ou depois** do texto que estamos procurando. Ele é como um caractere curinga em determinado trecho de uma `string`, equivalente ao `*` quando manipulamos arquivos.

Vamos ver na prática para ficar mais claro. Digamos que nós temos a seguinte lista de nomes:

|**Nomes**|
|---|
|João da Silva Filho|
|Pedro Almeida Soares|
|Margarida Silva Soares|
|José da Silva Almeida|
|Carlos Soares da Silva|
|Pedro Filho de Almeida|
|Jorge da Silva Filho|
|Antônio Almeida Soares|
|Jonas Soares Filho|
|Vitor Filho Soares|

Ao realizar uma busca com a condição `LIKE '%SOARES%'`, estaremos procurando todas as pessoas cujo nome **contenha** "SOARES". Essa consulta retornaria os seguintes nomes:

|**Nomes**|
|---|
|Pedro Almeida Soares|
|Margarida Silva Soares|
|Carlos Soares da Silva|
|Antônio Almeida Soares|
|Jonas Soares Filho|
|Vitor Filho Soares|

Note que, em alguns casos, "SOARES" aparece no final (como Pedro Almeida **Soares**), mas em outros está no meio do nome (como Carlos **Soares** da Silva). Obtemos esse resultado porque usamos o símbolo `%` antes e depois de "SOARES".

Também podemos trabalhar com limites, por exemplo, buscando nomes que **terminem** com "SOARES". Com esse propósito, nossa condição será `LIKE '%SOARES'`, sem o símbolo _percent_ ao fim. O resultados será:

|**Nomes**|
|---|
|Pedro Almeida Soares|
|Margarida Silva Soares|
|Antônio Almeida Soares|
|Vitor Filho Soares|

Dessa forma, a consulta não retornará os nomes "Carlos **Soares** da Silva" nem "Jonas **Soares** Filho", pois o texto que estamos buscando está no meio (e não no fim) dos nomes.

Agora que entendemos como esse operador funciona, vamos ao MySQL Workbench criar algumas consultas na base "sucos_vendas". Em um script novo, digitaremos o seguinte:

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR LIKE '%Maça%';
```

Perceba que usamos um _percent_ antes e outro depois do texto que vamos buscar. Ao executar o script, podemos verificar que a seleção retorna produtos com dois sabores diferentes: Maçã e Cereja/Maçã. Este último está presente no resultado por causa do primeiro `%` que colocamos na consulta: há outros caracteres antes, mas contém "Maça", que era o nosso critério de busca.

Vale lembrar que o `LIKE` pode ser uma parcela de uma expressão mais complexa, é possível combiná-lo com outros operadores, por exemplo:

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR LIKE '%Maça%' AND
EMBALAGEM = 'PET';
```

Ou seja, buscaremos todos os produtos que contêm "Maça" no campo "SABOR" **E** cuja embalagem é PET.

Então, esses foram alguns exemplos de uso do comando `LIKE`.


-----------------------------------------------------------------------
# 11Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Para que possam ser efetuadas as consultas na base de dados, é preciso conhecer as suas tabelas e seus relacionamentos. Para isso, vá no Workbench e verifique se o banco de dados _Sucos_Vendas_ está disponível.

2) Expandindo a árvore de estrutura de base de dados sobre _Sucos_Vendas_, podemos ver os componentes de um banco de dados. Para as consultas, um dos elementos mais importantes são as tabelas que podem ser vistas em mais detalhe até a sua estrutura de campos.

![1.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/1.png)

1) Vá no menu e selecione Database / Reverse Engineer.

2) Clique em Next duas vezes e depois escolha o banco no qual a engenharia reversa será efetuada.

3) Continue no assistente confirmando as seleções padrões até o final.

4) Você poderá ver um esquema visual das suas tabelas. Este esquema pode ser um guia para suas consultas.

![2.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/2.png)

5) Sabendo como é nossa base, podemos fazer nossas consultas. Selecione um novo script de SQL, com a base de dados selecionada, e digite:

```sql
USE sucos_vendas;
SELECT CPF, NOME, ENDERECO_1, ENDERECO_2, BAIRRO, CIDADE, ESTADO,
CEP, DATA_DE_NASCIMENTO,
IDADE, SEXO, LIMITE_DE_CREDITO, VOLUME_DE_COMPRA, PRIMEIRA_COMPRA
FROM tabela_de_clientes;
```

![3.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/3.png)

Aqui veremos todos os campos da tabela Tabela_de_Clientes. Isso porque os campos foram selecionados um a um.

6) Digite abaixo:

```sql
SELECT * FROM tabela_de_clientes;
```

![4.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/4.png)

Este resultado foi semelhante a consulta anterior. Isso porque, ao colocar * estamos selecionado todos os campos.

7) Digite:

```sql
SELECT CPF, NOME FROM tabela_de_clientes;
```

![5.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/5.png)

Agora podemos ver que não é necessário selecionar todos os campos de uma tabela. Basta eu destacar os campos que serão vistos.

8) Digite:

```vbnet
SELECT CPF as INDENTIFICADOR, NOME AS CLIENTE FROM tabela_de_clientes;
```

![6.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/6.png)

Nem sempre o nome original da coluna é o nome que queremos que seja retornado pela consulta. Por isso, podemos criar Alias (Apelidos) para os campos escrevendo algo após o comando AS.

9) Podemos filtrar nossa consulta. Digite:

```sql
SELECT * FROM tabela_de_produtos WHERE CODIGO_DO_PRODUTO = '1000889';
```

![7.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/7.png)

Aqui, o nosso retorno foi uma linha, porque selecionamos um filtro através da chave primária, que não repete.

10) Mas podemos implementar filtros que retornem mais linhas. Veja:

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR = 'Uva';
```

![8.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/8.png)

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR = 'Laranja';
```

![9.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/9.png)

```sql
SELECT * FROM tabela_de_produtos WHERE EMBALAGEM = 'PET';
```

![10.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/10.png)

```sql
SELECT * FROM tabela_de_produtos WHERE EMBALAGEM = 'pet';
```

![11.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/11.png)

Os filtros usados acima retornam mais linhas. Podemos usar qualquer coluna como critério.

11) Existem comandos de filtro aplicados a valores:

```sql
SELECT * FROM tabela_de_produtos WHERE PRECO_DE_LISTA > 19.50;
```

![12.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/12.png)

```sql
SELECT * FROM tabela_de_produtos WHERE PRECO_DE_LISTA BETWEEN 19.50 AND 19.52;
```

![13.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/13.png)

Neste caso podemos usar >,>=, <, <=, =, <> e Between. Assim podemos aplicar filtros sobre os valores que retornem mais valores.

12) É possível aplicar consultas condicionais usando operadores AND e OR. O retorno vai depender do significado do AND e OR numa estrutura lógica. Digite:

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR = 'Manga'
OR TAMANHO = '470 ml';
```

![14.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/14.png)

Aqui retornamos ou um filtro (Sabor = `Manga`) ou outro ( Tamanho = `470 ml`). Isso porque usamos o operador OR.

13) Digite:

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR = 'Manga'
AND TAMANHO = '470 ml';
```

![15.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/15.png)

Agora, por causa do operador AND, o retorno somente ocorrerá quando as duas condições ocorrerem na mesma linha da tabela.

14) Podemos usar parte de um texto para ser usado como critério de localização de registros da tabela. Digite abaixo:

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR LIKE '%Maça%';
```

![16.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/16.png)

Aqui iremos buscar todos os registros cujo sabor possua a palavra _Maça_. Não importa se no início, no meio ou no final do texto.

15) Podemos mesclar condições LIKE com outras. Digite:

```sql
SELECT * FROM tabela_de_produtos WHERE SABOR LIKE '%Maça%'
AND EMBALAGEM = 'PET';
```

![17.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/02/17.png)

Por fim, faremos a consulta do texto “Maça” apenas para embalagens PET.


-----------------------------------------------------------------------
# 01Usando DISTINCT para visualizar a tabela

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55584

## Transcrição

> [Você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/Consultas%20DISTINCT.sql)

Nas aulas anteriores, falamos de condições que são aplicadas sobre o filtro da seleção, mais especificamente operadores que usamos depois do `WHERE`. Agora vamos ver alguns comandos empregados **sobre o que queremos visualizar**. Em outras palavras, o filtro será aplicado e sobre o resultado do filtro ainda vamos impor outras condições.

O primeiro comando que vamos aprender é o `DISTINCT`, que pode ser traduzido como "distinto, diferente". Ele retornará somente linhas com valores diferentes e vamos usá-lo **depois do `SELECT` e antes da exibição dos campos**.

Por exemplo, se a consulta empregar o asterisco, o `DISTINCT` virá antes dele: `SELECT DISTINCT *`. Se, em vez disso, a consulta utilizar campos, o `DISTINCT` aparecerá antes deles:`SELECT DISTINCT CODIGO, NOME`).

Vamos a um exemplo. Considere a seguinte tabela que mostra sete pares de valores:

|**Valor 1**|**Valor 2**|
|---|---|
|A|X|
|A|Y|
|A|Z|
|B|X|
|A|X|
|B|X|
|A|Z|

Observando essas informações, constatamos que a linha 1 é igual à linha 5 (formando o par A,X). Além disso, outros registros que se repetem estão nas linhas 3 e 7 (A,Z); e nas linhas 4 e 6 (B,X).

Se executarmos o script `SELECT * FROM tabela`, nosso retorno terá todas as sete linhas. Entretanto, se adicionarmos o `DISTINCT` a essa consulta, o MySQL trará uma seleção somente com as linhas que são diferentes em si:

```sql
SELECT DISTINCT * FROM tabela;
```

|**Valor 1**|**Valor 2**|
|---|---|
|A|X|
|A|Y|
|A|Z|
|B|X|

Observe que, dessa forma, nenhuma combinação igual é exibida. Dos sete registros da tabela, veremos apenas quatro.

Vamos ao MySQL Workbench para testar esse comando na nossa tabela "sucos_vendas". Criaremos um novo script SQL e começaremos com uma seleção sem o `DISTINCT`:

```sql
SELECT EMBALAGEM, TAMANHO FROM tabela_de_produtos;
```

Essa consulta trata uma série de linhas e num instante é possível perceber que há registros que se repetem. Por exemplo, a combinação **Garrafa com 700ml** (linhas 1 e 3) ou a combinação **PET com 2 Litros** (linhas 6, 7 e 8).

No entanto, temos a opção de incluir o `DISTINCT` para mudar essa situação:

```sql
SELECT DISTINCT EMBALAGEM, TAMANHO FROM tabela_de_produtos;
```

Desse modo, o retorno será bem mais reduzido, porque mostrará apenas as combinações que não se repetem.

Vale lembrar que podemos aplicar junto com `DISTINCT`todas aquelas condições de filtro que aprendemos anteriormente, por exemplo:

```sql
SELECT DISTINCT EMBALAGEM, TAMANHO FROM tabela_de_produtos WHERE SABOR = 'Laranja';
```

Nesse caso, o MySQL mostrará apenas os _distincts_ com sabor laranja:

|EMBALAGEM|TAMANHO|
|---|---|
|PET|2 Litros|
|Garrafa|470 ml|
|PET|1 Litro|
|Lata|200 ml|
|PET|1.5 Litros|

Essa consulta seria útil se, por exemplo, um cliente dessa empresa de sucos perguntasse: "Quais são as embalagens e os tamanhos disponíveis para o suco de frutas do sabor laranja?"

Examinando o resultado, poderíamos responder: "O suco de laranja é oferecido em PET de 2 litros, garrafa de 470 ml, PET de 1 litro, lata de 350 ml e PET de 1,5 litro."

Vamos ver um último exemplo, incluindo mais um campo à seleção:

```sql
SELECT DISTINCT EMBALAGEM, TAMANHO, SABOR FROM tabela_de_produtos;
```

Nesse caso, obteremos mais registros do que na consulta anterior, pois com uma coluna a mais ("SABOR") o número de combinações aumenta. Observe que as cinco linhas que apareceram na penúltima seleção também estão presentes nessa última consulta, já que continuam a atender as condições.

Então, nesse vídeo, conseguimos explorar um pouquinho mais sobre o uso do `DISTINCT`.


-----------------------------------------------------------------------
# 03Limitando a saída da consulta

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55585

## Transcrição

> [Você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/Consultas%20LIMIT.sql)

Vamos aprender agora a limitar a saída de uma consulta.

Às vezes, criamos seleções que retornam 1 milhão de registros, mas estamos na fase de desenvolvimento de um projeto e não queremos, de fato, ver 1 milhão de linhas, o objetivo era saber se a consulta funcionaria e se ela traria os dados esperados. Nesses casos, podemos **limitar** a saída de dados usando o comando `LIMIT`, que no caso do MySQL estará sempre no final da _query_, por exemplo:

```sql
SELECT campos FROM tabela WHERE condicao LIMIT 5;
```

O número que colocamos depois de `LIMIT`dirá quantas linhas serão exibidas. Para ver em um exemplo, considere a seguinte tabela:

|**Nomes**|
|---|
|João da Silva Filho|
|Pedro Almeida Soares|
|Margarida Silva Soares|
|José da Silva Almeida|
|Carlos Soares da Silva|
|Pedro Filho de Almeida|
|Jorge da Silva Filho|
|Antônio Almeida Soares|
|Jonas Soares Filho|
|Vitor Filho Soares|

E vamos imaginar que rodamos o código a seguir:

```sql
SELECT * FROM tabela LIMIT 4;
```

O resultado dessa consulta traria os **quatro primeiros** registros da tabela original:

|**Nomes**|
|---|
|João da Silva Filho|
|Pedro Almeida Soares|
|Margarida Silva Soares|
|José da Silva Almeida|

Mas. além de limitar os **primeiros** registros, o `LIMIT` também pode conter itens do **meio** da tabela original, da seguinte forma:

```sql
SELECT * FROM tabela LIMIT 2,3;
```

Essa seleção retornará os seguintes registros:

|**Nomes**|
|---|
|Pedro Almeida Soares|
|Margarida Silva Soares|
|José da Silva Almeida|

Ou seja, o primeiro número depois do termo `LIMIT` determina a partir de qual registro queremos ver, e o segundo número define a quantidade de itens a serem mostrados. Nesse caso, a partir do **segundo** item da tabela original, vemos **três** registros.

> É necessário lembrar que as tabelas do MySQL se iniciam no índice 0. Sendo assim, o retorno correto de `SELECT * FROM tabela LIMIT 2,3` seria o seguinte:

|**Nomes**|
|---|
|Margarida Silva Soares|
|José da Silva Almeida|
|Carlos Soares da Siva|

Vamos, então, ver como o `LIMIT` funciona no nosso banco de dados "sucos_vendas", no MySQL Workbench. Criaremos um novo script e digitaremos a consulta a seguir:

```sql
SELECT * FROM tabela_de_produtos;
```

Note que os primeiros cinco itens do retorno são os de código: 1000889, 1002334, 1002767, 1004327 e 1013793, nessa ordem. Vamos ver se conseguimos criar uma seleção com `LIMIT` que mostre apenas esses cinco registros:

```sql
SELECT * FROM tabela_de_produtos LIMIT 5;
```

Rodando esse script e verificando os códigos dos produtos, saberemos que nossa consulta fez exatamente o que queríamos.

Já se nosso objetivo for selecionar **três linhas** a partir do código 1002767, que é o **terceiro registro** da tabela, faremos:

```sql
SELECT * FROM tabela_de_produtos LIMIT 2,3;
```

Vale lembrar que o MySQL considera a primeira linha como linha 0, portanto se vamos começar a seleção na linha 3, por isso, o primeiro número após o `LIMIT` será 2. Da mesma forma, se queremos que a seleção se inicie na primeira linha, podemos escrever o seguinte:

```sql
SELECT * FROM tabela_de_produtos LIMIT 0, 2;
```

Essa consulta retornará a linha 0 e a linha 1 (registros 1 e 2).


-----------------------------------------------------------------------
# 05Ordenando a saída da consulta

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55586

## Transcrição

> [Você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/Consultas%20ORDER.sql)

Quando fazemos uma seleção de dados num banco, eles são exibidos na ordem natural que a informação está armazenada na tabela. Mas nós podemos, através do comando `ORDER BY`, fazer com que o resultado da consulta venha **ordenado** por determinados critérios. Basta especificar o campo pelo qual se deseja organizar os dados, por exemplo:

```vbnet
SELECT * FROM tab ORDER BY campo
```

Para ver uma demonstração de como esse comando funciona, considere a seguinte tabela de nomes:

|**Nome**|
|---|
|João da Silva Filho|
|Pedro Almeida Soares|
|Margarida Silva Soares|
|José da Silva Almeida|
|Carlos Soares da Silva|
|Pedro Filho de Almeida|
|Jorge da Silva Filho|
|Antônio Almeida Soares|
|Jonas Soares Filho|
|Vitor Filho Soares|

No momento, não há nenhum critério na ordem desses dados. Poderíamos, então, rodar uma consulta com o `ORDER BY` especificando a coluna em questão e, dessa forma, os nomes apareceriam **do menor para o maior**:

|**Nome**|
|---|
|Antônio Almeida Soares|
|Carlos Soares da Silva|
|João da Silva Filho|
|Jonas Soares Filho|
|Jorge da Silva Filho|
|José da Silva Almeida|
|Margarida Silva Soares|
|Pedro Almeida Soares|
|Pedro Filho de Almeida|
|Vitor Filho Soares|

Nesse caso, como não estamos lidando com dados numéricos, "do menor para o maior" é o mesmo que "alfabeticamente". Se fosse do maior para o menor, seria de Z a A.

Com o `ORDER BY` também é possível especificar a **direção** da ordenação. Podemos escolher que os dados sejam exibidos de forma **ascendente** (ou seja, crescente, do menor para o maior), com o comando `ASC`. A outra opção é exibi-los de forma **descendente** (decrescente), usando `DESC`.

> Caso não seja especificado `ASC` ou `DESC`, o MySQL automaticamente optará pela ordem ascendente.

Além disso, também podemos escolher dois campos, ao mesmo tempo, como critério de seleção. Com esse intuito, faríamos uma consulta com `ORDER BY CAMPO1, CAMPO2` e o resultado seria algo parecido com o seguinte:

|**CAMPO1**|**CAMPO2**|
|---|---|
|A|1|
|A|2|
|A|3|
|B|1|
|B|2|
|B|3|
|C|1|
|C|2|
|C|3|

Nesse caso,temos o "CAMPO1" ordenado alfabeticamente, onde naturalmente todas as letras "A" estão no começo. Esses registros de letra "A", por sua vez, estão organizados de acordo com a ordem crescente do "CAMPO2", que é numérico. Só a partir da quarta linha teremos o "CAMPO1" com as letras "B", ordenadas conforme a ordem crescente do "CAMPO2", e assim por diante.

Agora que entendemos o conceito do `ORDER BY`, vamos ao MySQL Workbench para criar algumas consultas na base "sucos_vendas". Criaremos um novo script e começaremos com a seleção de todos os itens da tabela de produtos:

```sql
SELECT * FROM tabela_de_produtos;
```

Vamos, então, rodar uma seleção com `ORDER BY` em uma coluna com dados numéricos:

```vbnet
SELECT * FROM tabela_de_produtos ORDER BY PRECO_DE_LISTA;
```

Verificando o resultado, notaremos que os registros estão ordenados conforme a ordem **crescente** da coluna "PRECO_DE_LISTA", começando no valor R$2,808 e indo até R$38,012.

Para mudar a direção da ordenação, vamos inserir o comando `DESC` na nossa consulta, depois do nome do campo:

```sql
SELECT * FROM tabela_de_produtos ORDER BY PRECO_DE_LISTA DESC;
```

Dessa vez, os registros aparecerão de acordo com a ordem **descendente** da coluna "PRECO_DE_LISTA", do R$38,012 ao R$2,808.

A seguir, faremos uma seleção nessa mesma tabela, porém ordenando pelo campo "NOME_DO_PRODUTO", que tem dados em formato de texto:

```vbnet
SELECT * FROM tabela_de_produtos ORDER BY NOME_DO_PRODUTO;
```

O resultado estará ordenado pela ordem **alfabética** dos nomes dos produtos. Caso nosso objetivo seja ver na ordem contrária, precisaremos acrescentar o comando `DESC`:

```sql
SELECT * FROM tabela_de_produtos ORDER BY NOME_DO_PRODUTO DESC;
```

Por fim, vamos fazer um teste usando um **critério composto**:

```vbnet
SELECT * FROM tabela_de_produtos ORDER BY EMBALAGEM, NOME_DO_PRODUTO;
```

Sabemos que existem três tipos de embalagem no nosso banco: garrafa, lata e PET. Executando a consulta, obteremos um resultado que primeiramente respeitará à ordem crescente (alfabética) do campo "EMBALAGEM", começando portanto por "GARRAFA". Dentre os registros cuja embalagem é garrafa, teremos a ordem crescente pelo campo "NOME_DO_PRODUTO" (nosso segundo critério). Só depois poderemos ver registros com embalagem "LATA" (também em ordem alfabética dos nomes dos produtos) e, em seguida, "PET".

É possível deixar essa consulta ainda mais específica, acrescentando a direção da ordenação que queremos para **cada um dos campos**:

```sql
SELECT * FROM tabela_de_produtos ORDER BY EMBALAGEM DESC, NOME_DO_PRODUTO ASC;
```

Dessa vez, porque usamos `DESC` para o primeiro critério, a ordem das embalagens começará do maior para o menor (no caso, de "PET" a "GARRAFA") e, dentre os itens de cada tipo de embalagem, os nomes dos produtos estarão organizados em ordem alfabética, pois usamos o `ASC` para o segundo critério, "NOME_DO_PRODUTO".


-----------------------------------------------------------------------
# 07Agrupando os resultados

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55587

## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/Consultas%20GROUPBY.sql)

No vídeo anterior, aprendemos como ordenar resultados. Agora, vamos estudar como agrupá-los. **Agrupar** é juntar campos que são repetidos e, nos casos de campos numéricos, em meio a essa junção temos a opção de aplicar fórmulas matemáticas, que podem ser de soma, de média, de máximo ou mínimo valor, entre outros.

Para ficar mais fácil de entender, vamos ver em um exemplo. Observe a tabela a seguir, em que a coluna "X" apresenta letras e a coluna "Y" mostra valores numéricos:

|**X**|**Y**|
|---|---|
|A|2|
|A|1|
|B|2|
|B|3|
|B|1|
|C|1|
|C|5|
|C|2|
|D|3|

O comando que vamos aprender é o `GROUP BY`, que apresentará o resultado agrupando valores numéricos por uma chave de critério:

```sql
SELECT X, SUM(Y) FROM tab GROUP BY X;
```

O `GROUP BY`será responsável por agrupar as linhas em que "X" tem o mesmo valor. Por exemplo: as linhas 1 e 2 serão unidas em uma só, e o campo "Y" terá o valor "3", por causa da fórmula de soma `SUM(Y)` aplicada na consulta. O retorno dessa seleção será o seguinte:

|**X**|**Y**|
|---|---|
|A|3|
|B|6|
|C|8|
|D|3|

Acabamos de conhecer a fórmula `SUM` (soma), vamos ver mais quatro opções. A fórmula `MAX` (máximo) exibirá o maior valor:

```sql
SELECT X, MAX(Y) FROM tab GROUP BY X;
```

|**X**|**Y**|
|---|---|
|A|2|
|B|3|
|C|5|
|D|3|

Na tabela original, a letra "A" aparece duas vezes. Os valores de "Y" nessas ocorrências são 2 e 1. Como estamos usando a fórmula `MAX(Y)`, o valor exibido será o maior, no caso, o número 2. O mesmo vale para a letra "B", que tem três ocorrências cujos valores de "Y" são 2, 3 e 1, nessa ordem. Com o uso de `MAX(Y)`, o valor exibido será 3, e assim em diante.

Já a fórmula `MIN`(mínimo) fará o contrário - exibirá o menor valor:

```sql
SELECT X, MIN(Y) FROM tab GROUP BY X;
```

|**X**|**Y**|
|---|---|
|A|1|
|B|1|
|C|1|
|D|3|

A fórmula `AVG` (do inglês, _average_) fará uma **média** dos valores:

```sql
SELECT X, AVG(Y) FROM tab GROUP BY X;
```

|**X**|**Y**|
|---|---|
|A|1.5|
|B|2|
|C|2.666|
|D|3|

Ou seja, no caso da letra "A", o MySQL verá quais são os valores de "Y" (2 e 1) e fará a média deles, chegando a 1,5. No caso de "B", serão computados os valores 2, 3 e 1 e, feita a média, o resultado exibido será 2 e assim por diante.

E a fórmula `COUNT` mostrará o número de ocorrência:

|**X**|**Y**|
|---|---|
|A|2|
|B|3|
|C|3|
|D|1|

No caso de "A", temos duas linhas, então o valor exibido é 2. No caso de "B", temos três linhas, então o resultado é 3, e assim em diante. Então, essas são as cinco fórmulas que podemos usar com o `GROUP BY`.

Um detalhe importante: quando omitimos os campos de agregação e utilizamos apenas a fórmula, não é necessário colocar a cláusula `GROUP BY`. Por exemplo:

```sql
SELECT SUM(Y) FROM tab;
```

||
|---|
|20|

O MySQL irá somar todos os campos de "Y" e simplesmente mostrar o resultado. Se, em vez disso, usássemos `MIN`, o retorno seria 1, pois o menor valor de "Y" na tabela é 1. Com `MAX`, teríamos 5. Com `AVG`, a média daria 2.22. Com `COUNT` obteríamos 9.

Então, vamos ao MySQL Workbench criar alguns exemplos na base "sucos_vendas". Criaremos um novo script e começaremos consultando toda a tabela de clientes:

```sql
SELECT * FROM tabela_de_clientes;
```

Em seguida, vamos restringir um pouco essa consulta, selecionando apenas o estado e o limite de crédito na tabela:

```sql
SELECT ESTADO, LIMITE_DE_CREDITO FROM tabela_de_clientes;
```

Ao fazer essa consulta, veremos uma lista em que cada linha mostra o estado e o limite de crédito de um cliente. Se nosso objetivo for saber o total de limite de crédito de cada estado, usaremos o `GROUP BY`:

```vbnet
SELECT ESTADO, SUM(LIMITE_DE_CREDITO) as LIMITE_TOTAL FROM tabela_de_clientes GROUP BY ESTADO;
```

> Sempre que uma fórmula for usada, é necessário usar um _alias_ ("apelido") para o campo. No nosso caso, definimos "LIMITE_TOTAL" como _alias_ da soma dos limites de crédito.

O retorno mostrará os limites de crédito somados agrupados por estado: em São Paulo, o limite total é R$810.000,00 e, no Rio de Janeiro, é R$995.000,00.

Faremos, agora, uma consulta relativa às embalagens e aos preços de lista presentes na tabela de produtos:

```sql
SELECT EMBALAGEM, PRECO_DE_LISTA FROM tabela_de_produtos;
```

Vamos supor que precisamos descobrir qual é o preço mais caro de cada tipo de embalagem (PET, garrafa e lata):

```vbnet
SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) as MAIOR_PRECO FROM tabela_de_produtos GROUP BY EMBALAGEM;
```

Com essa consulta, constatamos que o produto mais caro que vem em garrafas tem o valor de R$13,312. O mais caro com embalagem PET é R$38,012. E o de lata custa R$4,56.

Além disso, é possível criar seleções com o comando `COUNT`:

```vbnet
SELECT EMBALAGEM, COUNT(*) as CONTADOR FROM tabela_de_produtos GROUP BY EMBALAGEM;
```

O retorno nos mostrará a quantidade de produtos que existem com cada tipo de embalagem: 11 tem embalagem garrafa, 15 vem em PET e 5 em lata.

Vale lembrar que podemos aplicar **critérios de filtro** juntamente do `ORDER BY`e do `GROUP BY`. Como exemplo, primeiramente vamos selecionar os limites de crédito agrupados por bairro:

```vbnet
SELECT BAIRRO, SUM(LIMITE_DE_CREDITO) as LIMITE FROM tabela_de_clientes GROUP BY BAIRRO;
```

E, para filtrar a consulta, usaremos uma cláusula `WHERE` para ver apenas os limites de crédito dos bairros da cidade do Rio de Janeiro:

```sql
SELECT BAIRRO, SUM(LIMITE_DE_CREDITO) as LIMITE FROM tabela_de_clientes WHERE CIDADE = 'Rio de Janeiro' GROUP BY BAIRRO;
```

Ademais, é possível usar mais de um campo no `GROUP BY`:

```vbnet
SELECT ESTADO, BAIRRO, SUM(LIMITE_DE_CREDITO) as LIMITE FROM tabela_de_clientes GROUP BY ESTADO, BAIRRO;
```

Note que adicionamos o campo "ESTADO" no início da seleção (`SELECT ESTADO`) e também no fim, depois de `GROUP BY`. Na primeira ocorrência, estamos determinando como exibiremos os dados, já na segunda indicamos como queremos que sejam agrupados.

Em seguida, aplicaremos um filtro que irá restringir a consulta somente à cidade do Rio de Janeiro:

```sql
SELECT ESTADO, BAIRRO, SUM(LIMITE_DE_CREDITO) as LIMITE FROM tabela_de_clientes WHERE CIDADE = 'Rio de Janeiro' GROUP BY ESTADO, BAIRRO;
```

Ou seja, estamos selecionando estado, bairro e a soma dos limites de crédito somente da cidade do Rio de Janeiro, agrupando esses dados por estado e bairro.

E, por fim, se nossa meta for visualizar esse resultado de forma **ordenada**, podemos ainda incluir o `ORDER BY`:

```vbnet
SELECT ESTADO, BAIRRO, SUM(LIMITE_DE_CREDITO) as LIMITE FROM tabela_de_clientes 
WHERE CIDADE = 'Rio de Janeiro' 
GROUP BY ESTADO, BAIRRO 
ORDER BY BAIRRO;
```

Dessa forma, veremos que o retorno respeitará a ordem alfabética dos bairros, começando por Água Santa, Barra da Tijuca, Cidade Nova e assim por diante. Essa última consulta é mais complexa, pois estamos agrupando, filtrando e ordenando dados em uma única seleção.

> Aviso, quando realizamos o agrupamento é importante destacar que podemos receber o erro 1055 que acontece porque o MySQL tem um modo de operação chamado "only_full_group_by", o qual determina que todas as colunas contidas no SELECT também estejam presentes na cláusula GROUP BY (que realiza o processo de agregação dos registros).


-----------------------------------------------------------------------
# 09Usando a condição HAVING

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55588

## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/Consultas%20HAVING.sql)

Nesse vídeo, conheceremos o `HAVING`, que é um filtro que se aplica ao resultado de um agregação. Ou seja, não o usamos no `SELECT` em si, mas sobre o resultado de um `SELECT`que é agrupado.

Para exemplificar, vamos rever a tabela que usamos no vídeo anterior, na qual temos a coluna "X" apresentando letras e a coluna "Y" mostrando valores numéricos:

|**X**|**Y**|
|---|---|
|A|2|
|A|1|
|B|2|
|B|3|
|B|1|
|C|1|
|C|5|
|C|2|
|D|3|

Nessa tabela, executaremos uma seleção com o comando `GROUP BY` que aprendemos anteriormente, agrupando os valores iguais de "X" e somando os de "Y:

```sql
SELECT X, SUM(Y) FROM tab GROUP BY X;
```

|**X**|**Y**|
|---|---|
|A|3|
|B|6|
|C|8|
|D|3|

Desse resultado, vamos supor que queremos apenas as linhas em que a soma de "Y" seja maior ou igual a 6. No caso, seriam as letras B e C. Então, aplicaremos o `HAVING` depois do `GROUP BY`:

```sql
SELECT X, SUM(Y) FROM tab GROUP BY X HAVING SUM(Y) >= 6;
```

|**X**|**Y**|
|---|---|
|B|6|
|C|8|

Agora que entendemos o conceito, vamos criar alguns exemplos na nossa base "sucos_vendas". Abriremos o MySQL Workbench, criaremos um novo script e começaremos com uma seleção da tabela de clientes, consultando a soma dos limites de crédito agrupados por estado:

```vbnet
SELECT ESTADO, SUM(LIMITE_DE_CREDITO) as SOMA_LIMITE FROM tabela_de_clientes 
GROUP BY ESTADO;
```

O retorno mostrará que, no estado de São Paulo, temos o total de limite de crédito de R$810.000,00 e, no estado do Rio de Janeiro, R$995.000,00. Agora, se nosso objetivo for listar apenas os estados cuja soma do limite de crédito for maior que R$900.000,00, parece natural que usemos a cláusula `WHERE`:

```vbnet
SELECT ESTADO, SUM(LIMITE_DE_CREDITO) as SOMA_LIMITE FROM tabela_de_clientes
WHERE SOMA_LIMITE > 900000
GROUP BY ESTADO;
```

No entanto, ao tentar rodar essa consulta, obteremos um erro! O problema é que, quando o `WHERE` é aplicado, o agrupamento ainda não ocorreu. A solução será usar o `HAVING`, que virá **depois** do `GROUP BY`:

```sql
SELECT ESTADO, SUM(LIMITE_DE_CREDITO) as SOMA_LIMITE FROM tabela_de_clientes
GROUP BY ESTADO
HAVING SUM(LIMITE_DE_CREDITO) > 900000;
```

Ou seja, primeiro agrupamos e depois aplicamos a condição. Dessa vez, nossa consulta retornará com sucesso.

Nesse último caso, usamos `SUM(LIMITE_DE_CREDITO)` tanto no `SELECT` quanto no `HAVING`, entretanto não há necessidade de sempre usar o mesmo critério. Para exemplificar, primeiro vamos selecionar as embalagens, o maior preço e o menor preço, agrupando-os pelo tipo de embalagem:

```vbnet
SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) as MAIOR_PRECO, 
MIN(PRECO_DE_LISTA) as MENOR_PRECO FROM tabela_de_produtos 
GROUP BY EMBALAGEM;
```

|**EMBALAGEM**|**MAIOR_PRECO**|**MENOR_PRECO**|
|---|---|---|
|Garrafa|13.312|3.768|
|PET|38.012|7.004|
|Lata|4.56|2.808|

E, com o intuito de usar o `HAVING`, filtraremos esse resultado, buscando apenas os produtos cuja soma dos preços de lista seja menor ou igual a R$80,00:

```sql
SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) as MAIOR_PRECO, 
MIN(PRECO_DE_LISTA) as MENOR_PRECO FROM tabela_de_produtos 
GROUP BY EMBALAGEM
HAVING SUM(PRECO_DE_LISTA) <= 80;
```

No `SELECT` utilizamos `MAX`e `MIN`, enquanto no `HAVING` usamos o `SUM` - essa consulta ilustra que não há necessidade de escolher os mesmos critérios. No retorno, veremos que a embalagem PET não aparece mais, pois não satisfaz a nova condição que impomos (`SUM(PRECO_DE_LISTA) <=80`).

Para finalizar, vale lembrar que temos a opção de acrescentar mais condições ao `HAVING`, criando um filtro composto com os operadores `OR` e `AND`, por exemplo:

```sql
SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) as MAIOR_PRECO, 
MIN(PRECO_DE_LISTA) as MENOR_PRECO FROM tabela_de_produtos 
GROUP BY EMBALAGEM
HAVING SUM(PRECO_DE_LISTA) <= 80 AND MAX(PRECO_DE_LISTA) >= 5;
```

Com essa nova condição (`MAX(PRECO_DE_LISTA) >= 5`), vamos notar que a embalagem "lata" também não aparecerá mais, já que seu valor máximo do preço de lista é R$4,56.


-----------------------------------------------------------------------
# 11Classificar resultados

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55589

## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/Consultas%20CASE.sql)

A seguir, aprenderemos sobre a expressão `CASE` (em português, "caso"). Esse comando serve para se fazer testes em um ou mais campos e, **quando** determinada condição for atendida, **então** seguiremos por um caminho, **senão** continuamos por outro.

O `CASE` vem acompanhado dos termos `WHEN` (quando), `THEN` (então), `ELSE` (senão) e `END` (fim). Veja a seguir um exemplo da estrutura desse comando:

```vbnet
CASE
    WHEN <condição1> THEN <Valor1>
    WHEN <condição2> THEN <Valor2>
    (...)
    WHEN <condiçãoN> THEN <ValorN>
    ELSE ValorELSE
END
```

Ou seja, analisamos uma condição e, caso seja satisfeita, o MySQL registra um valor determinado. Podemos ter várias dessas condições em um `CASE` e, ao final, se nenhuma delas for atendida, o `ELSE` é executado, funcionando como desvio para um outro valor já estabelecido.

Esse comando é bastante usado para classificar registros. Como exemplo, observe a seguinte tabela que tem o campo "X" que representa clientes e o campo "Y" que mostra a nota de cada um deles:

|**X**|**Y**|
|---|---|
|Cliente 1|8|
|Cliente 2|6|
|Cliente 3|9|
|Cliente 4|10|
|Cliente 5|4|
|Cliente 6|5|
|Cliente 7|7|

Queremos classificar as pessoas dessa tabela da seguinte forma: clientes com nota entre 8 e 10 são "ÓTIMO"; os com nota entre 7 e 8 são "BOM"; entre 5 e 7 são "MÉDIO"; e clientes cuja nota não se encaixa em nenhum desses critérios (ou seja, que **não** têm nota entre 5 e 10) são "RUIM". Para substituir a saída por essa classificação, executamos um script com `CASE`:

```sql
SELECT X,
CASE
    WHEN Y>=8 AND Y<=10 THEN 'OTIMO'
    WHEN Y>=7 AND Y<8 THEN 'BOM'
    WHEN Y>5 AND Y<7 THEN 'MEDIO'
    ELSE 'RUIM'
END
FROM tabela;
```

|**X**||
|---|---|
|Cliente 1|OTIMO|
|Cliente 2|MEDIO|
|Cliente 3|OTIMO|
|Cliente 4|OTIMO|
|Cliente 5|RUIM|
|Cliente 6|MEDIO|
|Cliente 7|BOM|

Esse é apenas um exemplo de como usar o `CASE`. Existe uma série de opções do que pode ser colocado depois do `THEN`, não precisa ser necessariamente um valor, como fizemos. Seria válido aplicar uma constante ou uma conta matemática, por exemplo: **quando** uma condição X for satisfeita, **então** faça uma conta Y, **senão** faça uma conta Z.

Então, vamos colocar esse conhecimento em prática. Abriremos o MySQL Workbench, criaremos um novo script e começaremos consultando a tabela de produtos do banco "sucos_vendas":

```sql
SELECT * FROM tabela_de_produtos;
```

Digamos que nossa intenção é classificar os produtos entre "baratos", "em conta" ou "caros". Faremos uma consulta usando o comando `CASE` e o campo "PRECO_DE_LISTA":

```vbnet
SELECT NOME_DO_PRODUTO, PRECO_DE_LISTA,
CASE 
    WHEN PRECO_DE_LISTA >= 12 THEN 'PRODUTO CARO'
    WHEN PRECO_DE_LISTA >= 7 AND PRECO_DE_LISTA < 12 THEN 'PRODUTO EM CONTA'
    ELSE 'PRODUTO BARATO' 
END AS STATUS_PRECO 
FROM tabela_de_produtos;
```

Ao final da seleção, coloca-se o `END` para encerrar o `CASE` e cria-se um _alias_. Ao rodar a consulta, teremos um retorno com as colunas "NOME_DO_PRODUTO", "PRECO_DE_LISTA" e "STATUS_PRECO", com uma relação de quais produtos estão baratos, quais estão em conta e quais estão caros.

Aplicando uma das fórmulas que aprendemos na aula anterior, podemos fazer, por exemplo, uma seleção que apresenta a média (_average_) de preços de produtos baratos, em conta ou caros, agrupados por tipo de embalagem:

```vbnet
SELECT EMBALAGEM,
CASE 
    WHEN PRECO_DE_LISTA >= 12 THEN 'PRODUTO CARO'
    WHEN PRECO_DE_LISTA >= 7 AND PRECO_DE_LISTA < 12 THEN 'PRODUTO EM CONTA'
    ELSE 'PRODUTO BARATO' 
END AS STATUS_PRECO, AVG(PRECO_DE_LISTA) AS PRECO_MEDIO
FROM tabela_de_produtos
GROUP BY EMBALAGEM, 
CASE 
    WHEN PRECO_DE_LISTA >= 12 THEN 'PRODUTO CARO'
    WHEN PRECO_DE_LISTA >= 7 AND PRECO_DE_LISTA < 12 THEN 'PRODUTO EM CONTA'
    ELSE 'PRODUTO BARATO' 
END
```

Note que o `CASE` completo precisa ser inserido no `GROUP BY`.

Ao analisar o retorno, podemos ver no primeiro registro que os sucos em **garrafa** que custam menos de R$7 (**barato**) tem uma **média** de preço de R$5,23. No segundo registro, notamos que os PETs em conta tem uma média de preço de R$9,10, e assim por diante.

Assim, notamos que é possível misturar vários tipos de comandos em um única seleção. Cabe ainda nessa consulta inserirmos um `ORDER BY EMBALAGEM` ao final do script e o resultado será a mesma lista, porém respeitando a ordem alfabética dos tipos de embalagem. Com essa nova organização, ficará mais fácil de verificar, por exemplo, que não existem embalagens PET baratas e que todos os sucos em lata custam menos de R$7 (baratos).

É possível até incluir uma cláusula `WHERE` para filtrar somente os produtos com sabor de manga. Veja como fica a consulta completa:

```vbnet
SELECT EMBALAGEM,
CASE 
    WHEN PRECO_DE_LISTA >= 12 THEN 'PRODUTO CARO'
    WHEN PRECO_DE_LISTA >= 7 AND PRECO_DE_LISTA < 12 THEN 'PRODUTO EM CONTA'
    ELSE 'PRODUTO BARATO' 
END AS STATUS_PRECO, AVG(PRECO_DE_LISTA) AS PRECO_MEDIO
FROM tabela_de_produtos
WHERE sabor = 'Manga'
GROUP BY EMBALAGEM, 
CASE 
    WHEN PRECO_DE_LISTA >= 12 THEN 'PRODUTO CARO'
    WHEN PRECO_DE_LISTA >= 7 AND PRECO_DE_LISTA < 12 THEN 'PRODUTO EM CONTA'
    ELSE 'PRODUTO BARATO' 
END 
ORDER BY EMBALAGEM;
```

Nesse caso, podemos observar na primeira linha do resultado, por exemplo, que a média de preços de sucos de manga baratos vendidos em garrafas é de R$5,17. Mesclando tudo que já estudamos nesse curso, já somos capazes de criar consultas bastante específicas e complexas.


-----------------------------------------------------------------------
# 13Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Voltando ao Workbench, vamos ver formas diferentes de exibir os resultados. Digite:

```sql
SELECT EMBALAGEM, TAMANHO FROM tabela_de_produtos;
```

![1.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/1.png)

Veja que temos linhas onde o conjunto EMBALAGEM / TAMANHO se repete.

2) Agora digite o comando:

```sql
SELECT DISTINCT EMBALAGEM, TAMANHO FROM tabela_de_produtos;
```

![2.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/2.png)

O simples fato de incluirmos a cláusula _DISTINCT_ faz com que os registros não se repitam.

1) Podemos aplicar filtros a seleção com _DISTINCT_.

```sql
SELECT DISTINCT EMBALAGEM, TAMANHO FROM tabela_de_produtos
WHERE SABOR = 'Laranja';
```

![3.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/3.png)

2) E podemos acrescentar mais campos à seleção DISTINCT.

```sql
SELECT DISTINCT EMBALAGEM, TAMANHO, SABOR FROM tabela_de_produtos;
```

![4.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/4.png)

3) Podemos limitar o número de linhas exibidas na saída. Digite:

```sql
SELECT * FROM tabela_de_produtos LIMIT 5;
```

![5.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/5.png)

Temos acima nossa saída limitada aos primeiros 5 registros.

4) Podemos exibir os registros dentro de um intervalo de linhas. Digite:

```sql
SELECT * FROM tabela_de_produtos LIMIT 2,3;
```

![6.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/6.png)

5) As saídas de uma comando SELECT podem ser apresentadas de forma ordenada. Veja abaixo:

```vbnet
SELECT * FROM tabela_de_produtos ORDER BY PRECO_DE_LISTA;
```

![7.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/7.png)

Temos os valores ordenados por preço de lista, do menor para o maior.

6) Podemos mudar esta ordem. Digite:

```sql
SELECT * FROM tabela_de_produtos ORDER BY PRECO_DE_LISTA DESC;
```

![8.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/8.png)

7) Os valores podem vir ordenados alfabeticamente quando incluímos um campo texto no critério de ordenação. Digite:

```vbnet
SELECT * FROM tabela_de_produtos ORDER BY NOME_DO_PRODUTO;
```

![9.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/9.png)

8) Também, no critério de ordenação do tipo texto, podemos mudar a ordem para do maior para o menor. Digite:

```sql
SELECT * FROM tabela_de_produtos ORDER BY NOME_DO_PRODUTO DESC;
```

![10.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/10.png)

9) O critério de ordenação pode ser diferente para cada tipo. Veja o exemplo abaixo onde usamos dois campos como critério de ordenação e a ordem diferente para cada um deles:

```sql
SELECT * FROM tabela_de_produtos ORDER BY EMBALAGEM DESC, NOME_DO_PRODUTO ASC;
```

![11.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/11.png)

10) Os dados podem ser agrupados. Quando isso acontece, temos que aplicar um critério de agrupamento para os campos numéricos. Podemos usar SUM, AVG, MAX, MIN, e outros mais. Digite o comando abaixo:

```sql
SELECT ESTADO, LIMITE_DE_CREDITO FROM tabela_de_clientes;
```

![12.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/12.png)

Note que temos várias linhas para RJ e SP. Como fazemos para somar todos os limites de crédito para RJ e SP?

11) A solução está no comando abaixo:

```vbnet
SELECT ESTADO, SUM(LIMITE_DE_CREDITO) AS LIMITE_TOTAL FROM tabela_de_clientes GROUP BY ESTADO;
```

![13.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/13.png)

12) Podemos usar outros critérios como o valor máximo.

```vbnet
SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) AS MAIOR_PRECO FROM tabela_de_Produtos GROUP BY EMBALAGEM;
```

![14.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/14.png)

Aqui vemos o maior preço de lista para cada tipo de embalagem.

13) O comando COUNT conta o número de ocorrências na tabela. Digite:

```vbnet
SELECT EMBALAGEM, COUNT(*) AS CONTADOR FROM tabela_de_produtos GROUP BY EMBALAGEM;
```

![15.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/15.png)

Temos acima o número de produtos PET, Garrafa e Lata.

14) O filtro pode ser aplicado sobre o agrupamento, como uma consulta qualquer. Digite:

```sql
SELECT BAIRRO, SUM(LIMITE_DE_CREDITO) AS LIMITE FROM tabela_de_clientes
WHERE CIDADE = 'Rio de Janeiro' GROUP BY BAIRRO;
```

![16.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/16.png)

15) Além disso, o agrupamento também pode ser feito por mais de um campo. Digite:

```vbnet
SELECT ESTADO, BAIRRO, SUM(LIMITE_DE_CREDITO) AS LIMITE FROM tabela_de_clientes
GROUP BY ESTADO, BAIRRO;
```

![17.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/17.png)

16) Podemos mesclar agrupamento com ordenação. Digite:

```vbnet
SELECT ESTADO, BAIRRO, SUM(LIMITE_DE_CREDITO) AS LIMITE FROM tabela_de_clientes
WHERE CIDADE = 'Rio de Janeiro'
GROUP BY ESTADO, BAIRRO
ORDER BY BAIRRO;
```

![18.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/18.png)

17) Veja a consulta abaixo:

```vbnet
SELECT ESTADO, SUM(LIMITE_DE_CREDITO) AS SOMA_LIMITE FROM tabela_de_clientes
GROUP BY ESTADO;
```

![19.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/19.png)

18) Queremos aplicar um filtro sobre o resultado desta consulta. Logo digite:

```vbnet
SELECT ESTADO, SUM(LIMITE_DE_CREDITO) AS SOMA_LIMITE FROM tabela_de_clientes
WHERE SOMA_LIMITE > 900000
GROUP BY ESTADO;
```

Veja que a consulta acima vai ocasionar um erro.

19) Usamos o HAVING para filtrar a saída de uma consulta usando como critério o valor agrupado. Digite:

```sql
SELECT ESTADO, SUM(LIMITE_DE_CREDITO) AS SOMA_LIMITE FROM tabela_de_clientes
GROUP BY ESTADO HAVING SUM(LIMITE_DE_CREDITO) > 900000;
```

![20.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/20.png)

20) O critério usado no HAVING não precisa ser o mesmo usado no filtro. Veja o comando abaixo:

```vbnet
SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) AS MAIOR_PRECO,
MIN(PRECO_DE_LISTA) AS MENOR_PRECO FROM tabela_de_produtos
GROUP BY EMBALAGEM;
```

![21.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/21.png)

Ele usa o MIN para agrupamento.

21) Porém, na consulta abaixo, o critério do HAVING pede a soma. Digite:

```sql
SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) AS MAIOR_PRECO,
MIN(PRECO_DE_LISTA) AS MENOR_PRECO FROM tabela_de_produtos
GROUP BY EMBALAGEM HAVING SUM(PRECO_DE_LISTA) <= 80;
```

![22.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/22.png)

22) No HAVING podemos usar mais de um critério usando AND ou OR.

```sql
SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) AS MAIOR_PRECO,
MIN(PRECO_DE_LISTA) AS MENOR_PRECO FROM tabela_de_produtos
GROUP BY EMBALAGEM HAVING SUM(PRECO_DE_LISTA) <= 80 AND MAX(PRECO_DE_LISTA) >= 5;
```

![23.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/23.png)

23) O comando CASE permite que possa ser classificado cada registro da tabela. Digite o comando abaixo:

```vbnet
SELECT NOME_DO_PRODUTO, PRECO_DE_LISTA,
CASE
   WHEN PRECO_DE_LISTA >= 12 THEN 'PRODUTO CARO'
   WHEN PRECO_DE_LISTA >= 7 AND PRECO_DE_LISTA < 12 THEN 'PRODUTO EM CONTA'
   ELSE 'PRODUTO BARATO'
END AS STATUS_PRECO
FROM tabela_de_produtos;
```

![24.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/24.png)

Com o CASE foi possível classificar os produtos como CARO, BARATO ou EM CONTA conforme o valor do seu preço de lista.

24) Podemos usar o CASE como critério de agrupamento, Digite o comando abaixo:

```vbnet
SELECT EMBALAGEM,
CASE
   WHEN PRECO_DE_LISTA >= 12 THEN 'PRODUTO CARO'
   WHEN PRECO_DE_LISTA >= 7 AND PRECO_DE_LISTA < 12 THEN 'PRODUTO EM CONTA'
   ELSE 'PRODUTO BARATO'
END AS STATUS_PRECO, AVG(PRECO_DE_LISTA) AS PRECO_MEDIO
FROM tabela_de_produtos
WHERE sabor = 'Manga'
GROUP BY EMBALAGEM,
CASE
   WHEN PRECO_DE_LISTA >= 12 THEN 'PRODUTO CARO'
   WHEN PRECO_DE_LISTA >= 7 AND PRECO_DE_LISTA < 12 THEN 'PRODUTO EM CONTA'
   ELSE 'PRODUTO BARATO'
END
ORDER BY EMBALAGEM;
```

![25.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/03/25.png)


-----------------------------------------------------------------------
# 01Usando JOINS

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55590

## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/Consultas%20INNER%20JOIN.sql)

Nesse vídeo, aprenderemos sobre as estruturas de `JOIN`, que permitem unir duas ou mais tabelas dentro de uma única consulta SQL. Basta que essas tabelas tenham um campo em comum.

Até agora, somente realizamos seleções de uma tabela por vez, no entanto, haverá ocasiões em que será necessário consultar informações que estão separadas, parte em uma tabela e parte em outra. Nesses contextos, aplicaremos os `JOIN`s.

A seguir, veremos alguns exemplos, usando duas tabelas:

|**Nome**|**Identificador**|
|---|---|
|João|1|
|Maria|3|
|Pedro|4|
|Cláudia|6|

 

|**Identificador**|**Hobby**|
|---|---|
|1|Praia|
|3|Futebol|
|5|Fotografia|
|8|Artesanato|

Na primeira tabela (**à _esquerda_** do vídeo), temos o nome de quatro clientes e seus respectivos números identificadores. Na segunda tabela (**à _direita_**), são apresentados os números identificadores de quatro clientes e seus respectivos hobbies. Note que Pedro e Cláudia (números 4 e 6) não têm hobbies correspondentes na segunda tabela. Por outro lado, fotografia e artesanato são atividades atreladas a clientes que não estão cadastrados na primeira tabela (números 5 e 8). De resto, percebemos que João (identificador 1), gosta de ir à praia e que o hobby de Maria (identificador 3) é o futebol.

Então, o primeiro tipo de `JOIN` que conheceremos é o `INNER JOIN`:

```sql
SELECT A.NOME, B.HOBBY FROM 
TABELA_ESQUERDA A
INNER JOIN TABELA_DIREITA B
ON A.IDENTIFICADOR = B.IDENTIFICADOR;
```

|**Nome**|**Hobby**|
|---|---|
|João|Praia|
|Maria|Futebol|

Vamos entender por partes o que cada pedaço dessa consulta significa. Em `TABELA_ESQUERDA A`, estamos declarando "A" como o _alias_ da primeira tabela, à esquerda. Um processo semelhante é feito em `TABELA_DIREITA B`. Assim, quando escrevemos `SELECT A.NOME, B.HOBBY`, vamos selecionar o campo "NOME" da tabela A e o campo "HOBBY" da tabela B. Ao final, temos a expressão `ON A.IDENTIFICADOR = B.IDENTIFICADOR`, na qual especificamos qual é campo em comum dessas tabelas. E o comando `INNER JOIN` é responsável por retornar somente os registros que têm correspondência nas duas tabelas. Nesse caso, são apenas João e Maria (identificadores 1 e 3).

Outro tipo de comando `JOIN` é o `LEFT JOIN`:

```sql
SELECT A.NOME, B.HOBBY FROM 
TABELA_ESQUERDA A
LEFT JOIN TABELA_DIREITA B
ON A.IDENTIFICADOR = B.IDENTIFICADOR;
```

_Left_, em inglês, significa "esquerda" e, no nosso contexto, representa a primeira tabela, à esquerda, a que vem **antes** do comando `JOIN`. Com essa consulta, o MySQL trará **todos** os elementos da tabela A e somente os correspondentes da tabela B:

|**Nome**|**Hobby**|
|---|---|
|João|Praia|
|Maria|Futebol|
|Pedro|NULL|
|Cláudia|NULL|

Assim, todos os clientes da primeira tabela estarão no retorno, inclusive aqueles que não têm hobby (Pedro e Cláudia). Nesses casos, a coluna "HOBBY" apresentará valor _null_ (nulo).

Da mesma maneira que existe o `LEFT JOIN`, temos o `RIGHT JOIN`, que trará todos os elementos da tabela da **direita** (ou seja, a que vem **depois** do comando `JOIN`) e somente os correspondentes da esquerda:

```sql
SELECT A.NOME, B.HOBBY FROM 
TABELA_ESQUERDA A
RIGHT JOIN TABELA_DIREITA B
ON A.IDENTIFICADOR = B.IDENTIFICADOR;
```

|**Nome**|**Hobby**|
|---|---|
|João|Praia|
|Maria|Futebol|
|NULL|Fotografia|
|NULL|Artesanato|

Todos os hobbies da tabela B estarão no retorno, inclusive aqueles cujo identificador de cliente não aparece na outra tabela (fotografia e artesanato). Nesses casos, na coluna "NOME" aparecerá com o valor _null_.

Além disso, existe também o `FULL JOIN`:

```sql
SELECT A.NOME, B.HOBBY FROM 
TABELA_ESQUERDA A
FULL JOIN TABELA_DIREITA B
ON A.IDENTIFICADOR = B.IDENTIFICADOR;
```

Com esse comando, **todos** os elementos tanto de uma quanto da outra tabela aparecerão no resultado. Os registros que não tiverem correspondência, apresentarão a coluna com valor nulo:

|**Nome**|**Hobby**|
|---|---|
|João|Praia|
|Maria|Futebol|
|Pedro|NULL|
|Cláudia|NULL|
|NULL|Fotografia|
|NULL|Artesanato|

Portanto, a consulta nos informa que João gosta de praia; Maria curte futebol; Pedro e Cláudia não tem hobby; e não há clientes cadastrados que gostem de fotografia ou artesanato.

Por fim, temos o `CROSS JOIN` (junção cruzada), que retorna o produto cartesiano das duas tabelas. Ele tem uma estrutura ligeiramente diferente das anteriores, sem nenhuma condição de união. Ou seja, quando não especificamos qual é o campo que liga as tabelas, o MySQL fará o `CROSS JOIN`:

```css
SELECT A.NOME, B.HOBBY FROM
TABELA_ESQUERDA A, TABELA-DIREITA B;
```

|**Nome**|**Hobby**|
|---|---|
|João|Praia|
|Maria|Praia|
|Pedro|Praia|
|Cláudia|Praia|
|João|Futebol|
|Maria|Futebol|
|Pedro|Futebol|
|Cláudia|Futebol|
|...|...|

Ou seja, o resultado mostrará todas as combinações possíveis. Como temos quatro clientes na tabela A e quatro hobbies na tabela B, o resultado apresentará 16 combinações.

Agora, vamos fazer alguns exemplos práticos no MySQL Workbench. Criaremos um novo script e iniciaremos consultando a tabela de vendedores e a de notas fiscais:

```sql
SELECT * FROM tabela_de_vendedores;
SELECT * FROM notas_fiscais;
```

Analisando o retorno, verificamos que a primeira tabela apresenta dados dos vendedores e a segunda mostra informações de notas fiscais. Elas têm um campo em comum: "MATRICULA". Por meio dessa relação, é possível criar uma consulta que junte informações de ambas:

```sql
SELECT * FROM tabela_de_vendedores A
INNER JOIN notas_fiscais B
ON A.MATRICULA = B.MATRICULA;
```

> Os campos em comum usados no `JOIN` não precisam ter o mesmo nome. O importante é que tenham o **mesmo conteúdo** para que a relação entre tabelas seja viável.

O retorno mostrará todos os campos da tabela A e todos os campos da tabela B, unidos em um só resultado. Será possível ver os dados de cada nota fiscal emitida, **junto** das informações do vendedor associado a ela.

Com essas duas tabelas, também podemos usar outros comandos com o `JOIN`, como o `GROUP BY`. Por exemplo, se nossa meta for descobrir quantas notas fiscais cada vendedor emitiu:

```sql
SELECT A.MATRICULA, A.NOME, COUNT(*) FROM
tabela_de_vendedores A
INNER JOIN notas_fiscais B
ON A.MATRICULA = B.MATRICULA
GROUP BY A.MATRICULA, A.NOME;
```

O mesmo resultado será obtido se fizéssemos um `CROSS JOIN` entre essas tabelas e filtrássemos (com `WHERE`) apenas os registros que têm correspondência no número da matrícula:

```sql
SELECT A.MATRICULA, A.NOME, COUNT(*) FROM
tabela_de_vendedores A, notas_fiscais B
WHERE A.MATRICULA = B.MATRICULA
GROUP BY A.MATRICULA, A.NOME;
```

Entre essas duas opções, recomendo o uso da primeira, porque com o `INNER JOIN` é mais fácil de compreender as junções (principalmente quando ficam complexas) e também por ser a forma mais moderna. A segunda opção era comum há uns 20 anos, quando estruturas como `INNER JOIN`, `LEFT JOIN` e `RIGHT JOIN` ainda não existiam, e há quem ainda opte por ela, mas eu particularmente prefiro o `INNER JOIN`.

Assim, nesse vídeo fizemos um apanhado dos tipos de `JOIN`e nos aprofundamos um pouco, na prática, no uso do `INNER JOIN`.


-----------------------------------------------------------------------
# 03Exemplos de LEFT e RIGHT JOIN

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55591

## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/Consultas%20LEFT%20e%20RIGHT%20JOIN.sql)

Nesse vídeo, vamos nos aprofundar no `LEFT JOIN`, que é o comando de junção de tabelas que mostrará **todos** os elementos da tabela **à esquerda** do `JOIN`(ou seja, a que vem antes do `JOIN`) e somente os correspondentes da tabela à direita.

Vamos abrir o MySQL Workbench, criar um novo script e começar com uma seleção que trará a contagem de clientes cadastrados:

```sql
SELECT COUNT(*) FROM tabela_de_clientes;
```

> Lembrete: quando omitimos os campos selecionados e somente usamos uma fórmula, não há necessidade de usar o `GROUP BY`. É o que acabamos de fazer com a fórmula `COUNT`.

O retorno revela que existem 15 clientes cadastrados. Em seguida, vamos consultar para quantas pessoas foram emitidas notas fiscais, verificando a quantidade de CPFs diferentes que aparecem na tabela de notas fiscais:

```sql
SELECT CPF, COUNT(*) FROM notas_fiscais GROUP BY CPF;
```

Ao contar os registros, saberemos que apenas 14 clientes receberam nota fiscal. Ou seja, dos 15 cadastrados, 1 deles nunca comprou suco de frutas na nossa empresa.

Para descobrir quem é esse cliente, primeiro vamos rodar uma consulta com `INNER JOIN` para descobrir quais registros apresentam correspondências no campo "CPF":

```sql
SELECT DISTINCT A.CPF, A.NOME, B.CPF FROM tabela_de_clientes A
INNER JOIN notas_fiscais B ON A.CPF = B.CPF;
```

Ou seja, o retorno mostrará os CPFs e os nomes dos clientes para os quais foram emitidas notas - são as 14 pessoas que vimos anteriormente. No entanto, substituindo o `INNER JOIN` pelo `LEFT JOIN`, o resultado será diferente:

```sql
SELECT DISTINCT A.CPF, A.NOME, B.CPF FROM tabela_de_clientes A
LEFT JOIN notas_fiscais B ON A.CPF = B.CPF;
```

Agora, veremos **todos** os elementos da tabela de clientes e apenas os correspondentes da tabela de notas fiscais. Analisando o resultado, encontraremos o cliente Fábio Carvalho que tem um campo nulo, ou seja, que nunca comprou na empresa, então nunca recebeu nota fiscal e, consequentemente, seu CPF não tem consta na tabela de notas fiscais.

Desse modo, se o gerente da empresa de sucos nos pedisse para investigar quais clientes cadastrados nunca realizaram uma compra, uma maneira de encontrar a resposta é filtrar os registros que apresentam o campo `B.CPF` nulo (no caso, apenas o Fábio):

```sql
SELECT DISTINCT A.CPF, A.NOME, B.CPF FROM tabela_de_clientes A
LEFT JOIN notas_fiscais B ON A.CPF = B.CPF
WHERE B.CPF IS NULL;
```

> `IS`, em inglês, significa "é/está". Logo, no comando `WHERE B.CPF IS NULL`, buscamos campos que têm valor _null_.

Lembrando que sempre temos a opção de incrementar nossos filtros. Um exemplo seria refinar a busca pelo ano da data da venda, que é uma informação que encontramos na tabela de notas fiscais:

```sql
SELECT DISTINCT A.CPF, A.NOME, B.CPF FROM tabela_de_clientes A
LEFT JOIN notas_fiscais B ON A.CPF = B.CPF
WHERE B.CPF IS NULL AND YEAR(B.DATA_VENDA) = 2015;
```

Nesse caso, utilizamos o operador `AND`, então nosso retorno será vazio, porque não há registros que atendam às duas condições **ao mesmo tempo**.

Quanto ao `RIGHT JOIN`, sabemos que ele tem quase a mesma mecânica do `LEFT JOIN`, exceto que trará todos os elementos da tabela **à direita** do comando `JOIN` e somente os correspondentes da outra tabela. Para fazer uma demonstração, podemos realizar a mesma consulta que fizemos anteriormente, invertendo os nomes das tabelas:

```sql
SELECT DISTINCT A.CPF, A.NOME, B.CPF FROM notas_fiscais B
RIGHT JOIN tabela_de_clientes A ON A.CPF = B.CPF;
```

Apesar da consulta ligeiramente diferente, como invertemos as tabelas, o resultado é o mesmo que obtivemos com o `LEFT JOIN`.


-----------------------------------------------------------------------
# 05Exemplos de FULL e CROSS JOIN

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55592

## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/Consultas%20FULL%20e%20CROSS%20JOIN.sql)

Nesse vídeo, faremos alguns exemplos com `CROSS JOIN` e `FULL JOIN`.

Durante a explicação, vamos aproveitar para aprender como realizar essas consultas sem utilizar os _aliases_ para as tabelas. No vídeo anterior, por exemplo, apelidamos a tabela de clientes de "A" e a tabela de notas fiscais de "B" e, para nos referir aos seus respectivos campos, usamos essas letras como prefixos (`A.NOME`e `B.CPF`). Agora, veremos que também é possível usar os próprios nomes das tabelas.

Quanto aos prefixos e sufixos, notaremos que eles são obrigatórios somente quando lidamos com campos em comum nas tabelas. Costumamos usá-los porque, em geral, não sabemos de antemão se os campos se repetem, porém por vezes os prefixos são opcionais e vamos demonstrar isso.

Então, começaremos abrindo um novo script no MySQL Workbench e selecionando a tabela de vendedores:

```sql
SELECT * FROM tabela_de_vendedores;
```

Uma das colunas do resultado é "BAIRRO", referente ao local onde o vendedor possui escritório. Consultando a tabela de clientes, veremos que ela também contém esse campo:

```sql
SELECT * FROM tabela_de_clientes;
```

Sabendo dessa relação entre as tabelas, criaremos uma seleção com `JOIN`:

```sql
SELECT * FROM tabela_de_vendedores INNER JOIN tabela_de_clientes
ON tabela_de_vendedores.BAIRRO = tabela_de_clientes.BAIRRO;
```

> Note que nessa seleção não usamos _alias_! Em vez disso, utilizamos os próprios nomes das tabelas como prefixo, como em `tabela_de_vendedores.BAIRRO`. Inclusive, quando digitamos o ponto depois do nome da tabela, o MySql Workbench até mostra algumas sugestões de preenchimento para agilizar o processo.

O retorno mostrará os clientes que estão em bairros onde há escritórios da empresa de sucos. Nessa consulta, obtemos somente 7 registros, o que significa que 8 clientes estão em bairros que não têm escritório, pois no vídeo anterior descobrimos que são 15 clientes cadastrados no total.

No momento, essa seleção traz **todos** os campos das duas tabelas, então vamos melhorar essa organização e trazer somente os quatro campos que nos interessam:

```sql
SELECT tabela_de_vendedores.BAIRRO,
tabela_de_vendedores.NOME,
tabela_de_clientes.BAIRRO,
tabela_de_clientes.NOME  FROM tabela_de_vendedores INNER JOIN tabela_de_clientes
ON tabela_de_vendedores.BAIRRO = tabela_de_clientes.BAIRRO;
```

Assim, fica mais fácil de visualizar as informações.

Para demonstrar um ponto interessante sobre os prefixos, acrescentaremos também a coluna "DE_FERIAS", da tabela de vendedores:

```sql
SELECT tabela_de_vendedores.BAIRRO,
tabela_de_vendedores.NOME,
tabela_de_vendedores.DE_FERIAS,
tabela_de_clientes.BAIRRO,
/* ... */
```

A coluna "DE_FERIAS" não existe na tabela de clientes, ela está presente apenas na de vendedores. Isso nos permite omitir o prefixo, pois o MySQL consegue deduzir e localizar sozinho o campo a que nos referimos, já que ele só existe em uma tabela. No caso de "BAIRRO" e "NOME", por exemplo, o prefixo é **obrigatório** para se fazer a distinção, pois são **campos em comum** nas duas tabelas que estamos usando:

```sql
SELECT tabela_de_vendedores.BAIRRO,
tabela_de_vendedores.NOME,
DE_FERIAS,
/* ... */
```

A seguir, vamos rodar a consulta com `LEFT JOIN`:

```sql
SELECT tabela_de_vendedores.BAIRRO,
tabela_de_vendedores.NOME,
DE_FERIAS,
tabela_de_clientes.BAIRRO,
tabela_de_clientes.BAIRRO,
tabela_de_clientes.NOME  FROM tabela_de_vendedores LEFT JOIN tabela_de_clientes
ON tabela_de_vendedores.BAIRRO = tabela_de_clientes.BAIRRO;
```

Essa seleção retornará **todos os vendedores e apenas os clientes correspondentes**. Encontraremos, por exemplo, o registro da vendedora Roberta Martins, cujo bairro (Copacabana) não tem correspondência na tabela de clientes. Chegamos a essa conclusão porque a terceira e a quarta coluna estão com valor _null_. Ou seja, o seu escritório não está em um lugar estratégico, pois não há clientes cadastrados que comprem sucos nesse bairro.

Substituindo o comando por `RIGHT JOIN`, o MySQL trará **todos os clientes e apenas os vendedores correspondentes**. Com esse resultado, é possível verificar vários compradores que moram em bairros em que não há escritórios da empresa de sucos, como Água Santa e Brás - os três primeiros campos são nulos. Esse tipo de análise seria interessante, por exemplo, para investigar onde há mais demanda para abrir um novo escritório.

Podemos ver todas essas informações ao mesmo tempo usando o `FULL JOIN` - todos os vendedores, inclusive os que tem escritórios nos bairros onde não há compradores; e todos os clientes, inclusive os que moram em bairros em que não há escritórios da empresa de sucos:

```sql
SELECT tabela_de_vendedores.BAIRRO,
tabela_de_vendedores.NOME,
DE_FERIAS,
tabela_de_clientes.BAIRRO,
tabela_de_clientes.BAIRRO,
tabela_de_clientes.NOME  FROM tabela_de_vendedores FULL JOIN tabela_de_clientes
ON tabela_de_vendedores.BAIRRO = tabela_de_clientes.BAIRRO;
```

Ao executar essa consulta, o programa vai alegar um erro. Como foi explicado no começo do curso, a linguagem SQL segue o padrão _ANSI_, que respeita uma série de regras, mas nem todo gerenciador de banco de dados realiza 100% do que esse padrão especifica. O `FULL JOIN` está contido no padrão _ANSI_, porém o MySQL não suporta esse comando. Ou seja, não conseguiremos fazer o `FULL JOIN` no MySQL Workbench. Existe, no entanto, uma alternativa para o `FULL JOIN` que é fazer o `LEFT JOIN` e o `RIGHT JOIN` simultaneamente. Nesse momento, ainda não aprendemos como fazer essa união de consultas, então vamos reservar esse erro e, mais adiante, quando estudarmos mais sobre o assunto, voltaremos a ele.

Para finalizar esse vídeo, vamos criar um exemplo com `CROSS JOIN`, lembrando que esse comando não requer que seja especificado o campo em comum nem que seja escrito o termo `CROSS JOIN`:

```sql
SELECT tabela_de_vendedores.BAIRRO,
tabela_de_vendedores.NOME, 
DE_FERIAS,
tabela_de_clientes.BAIRRO,
tabela_de_clientes.NOME FROM tabela_de_vendedores, tabela_de_clientes;
```

Assim, o resultado será uma análise combinatória entre bairros de vendedores e bairros de clientes.


-----------------------------------------------------------------------
# 07Juntando consultas

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55593

## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/Consultas%20UNION.sql)

Nesse vídeo, aprenderemos sobre o comando `UNION`, que é responsável por juntar duas consultas. Para exemplificar, vamos supor que fizemos duas consultas separadas e cada uma delas retornou uma das seguintes tabelas:

|**Identificador**|**Hobby**|
|---|---|
|1|Praia|
|3|Futebol|
|5|Fotografia|
|8|Artesanato|

 

|**Identificador**|**Hobby**|
|---|---|
|12|Cinema|
|14|Computador|
|15|Ver TV|
|18|Tênis|

Ao rodar o comando `UNION` com essas duas consultas, será retornada uma lista única com todos os registros:

|**Identificador**|**Hobby**|
|---|---|
|1|Praia|
|3|Futebol|
|5|Fotografia|
|8|Artesanato|
|12|Cinema|
|14|Computador|
|15|Ver TV|
|18|Tênis|

Note que há uma restrição para esse comando: é necessário que as tabelas que serão unidas tenham o mesmo número e tipo de campo. No caso, não tivemos problemas, pois as duas tabelas têm duas colunas e os tipos dos campos correspondem.

> Os nomes das colunas em si não precisam ser iguais para que o `UNION` funcione. Veremos mais adiante o que acontece quando temos nomes diferentes.

Agora, vamos modificar a segunda tabela para que haja um registro idêntico ao da primeira (praia):

|**Identificador**|**Hobby**|
|---|---|
|1|Praia|
|14|Computador|
|15|Ver TV|
|18|Tênis|

Executando o `UNION` simples, o `DISTINCT` automaticamente será aplicado, de forma que os **registros iguais também serão unidos**. No caso, o registro "praia" será mostrado um única vez:

|**Identificador**|**Hobby**|
|---|---|
|1|Praia|
|3|Futebol|
|5|Fotografia|
|8|Artesanato|
|14|Computador|
|15|Ver TV|
|18|Tênis|

Mas se nosso objetivo seja unir **sem aplicar o `DISTINCT`**, então utilizaremos a cláusula `UNION ALL`:

|**Identificador**|**Hobby**|
|---|---|
|1|Praia|
|3|Futebol|
|5|Fotografia|
|8|Artesanato|
|1|Praia|
|14|Computador|
|15|Ver TV|
|18|Tênis|

Observe que agora o registro "praia" aparece duas vezes.

Vamos criar alguns exemplos na nossa base "sucos_vendas". Abriremos o MySQL Workbench, criaremos um novo script e começaremos com duas seleções:

```sql
SELECT DISTINCT BAIRRO FROM tabela_de_clientes;
SELECT DISTINCT BAIRRO FROM tabela_de_vendedores;
```

Como resultado, teremos duas tabelas - uma apresentará 11 registros referentes aos bairros dos clientes, outra mostrará 4 bairros onde há escritórios dos vendedores. Note que alguns dados se cruzam: Tijuca, por exemplo, é um elemento que aparece em ambas.

A seguir, vamos executar um comando com `UNION`:

```sql
SELECT DISTINCT BAIRRO FROM tabela_de_clientes
UNION
SELECT DISTINCT BAIRRO FROM tabela_de_vendedores;
```

No retorno, note que Tijuca é o terceiro item e não se repete mais na lista. Por ser comum às duas tabelas, esse bairro torna-se um registro só. Em outras palavras, o `DISTINCT`foi aplicado. Para mudar esse cenário, teríamos que rodar o `UNION ALL`:

```sql
SELECT DISTINCT BAIRRO FROM tabela_de_clientes
UNION ALL
SELECT DISTINCT BAIRRO FROM tabela_de_vendedores;
```

Nesse caso, Tijuca aparecerá duas vezes.

É interessante notar que o `DISTINCT` funciona somente se os registros forem **idênticos em todos os campos** que aparecem na consulta. Para fazer uma demonstração, vamos acrescentar o campo "NOME" na seleção:

```sql
SELECT DISTINCT BAIRRO, NOME FROM tabela_de_clientes
UNION
SELECT DISTINCT BAIRRO, NOME FROM tabela_de_vendedores;
```

> Perceba que o campo "NOME" no primeiro `SELECT` refere-se aos nomes dos clientes, enquanto no segundo é relativo aos vendedores.

Nesse contexto, o `DISTINCT` só vai agrupar registros caso o bairro **E** o nome forem iguais.

Podemos continuar incrementando a consulta, colocando mais campos:

```sql
SELECT DISTINCT BAIRRO, NOME, 'CLIENTE' as TIPO FROM tabela_de_clientes
UNION
SELECT DISTINCT BAIRRO, NOME, 'VENDEDOR' as TIPO FROM tabela_de_vendedores;
```

Note que as consultas permanecem com o mesmo número de colunas e os tipos das colunas correspondem. Além do mais, usamos o _alias_ "TIPO" nos dois `SELECT`s para a nova coluna.

Entretando, ao optar por apelidos diferentes em cada `SELECT`, apenas o primeiro será considerado. Os nomes das colunas correspondem aos da primeira seleção:

```sql
SELECT DISTINCT BAIRRO, NOME, 'CLIENTE' as TIPO_CLIENTE FROM tabela_de_clientes
UNION
SELECT DISTINCT BAIRRO, NOME, 'VENDEDOR' as TIPO_VENDEDOR FROM tabela_de_vendedores;
```

No retorno, vê-se que a terceira coluna é "TIPO_CLIENTE", o _alias_ "TIPO_VENDEDOR" foi ignorado. Independentemente do nome, os valores permanecem os mesmos.

A título de exemplo, vamos tentar rodar um `UNION` com número de colunas diferentes, incluindo o campo "CPF" da tabela de clientes:

```sql
SELECT DISTINCT BAIRRO, NOME, 'CLIENTE' as TIPO_CLIENTE, CPF FROM tabela_de_clientes
UNION
SELECT DISTINCT BAIRRO, NOME, 'VENDEDOR' as TIPO_VENDEDOR, MATRICULA FROM tabela_de_vendedores;
```

O MySQL Workbench acusará um problema, como esperado, pois temos 3 colunas no primeiro `SELECT` e duas no outro. Podemos resolver essa situação adicionando uma coluna ao segundo `SELECT`. No caso, vamos adicionar a matrícula, que é do mesmo **tipo** da coluna "CPF":

```sql
SELECT DISTINCT BAIRRO, NOME, 'CLIENTE' as TIPO_CLIENTE, CPF FROM tabela_de_clientes
UNION
SELECT DISTINCT BAIRRO, NOME, 'VENDEDOR' as TIPO_VENDEDOR, MATRICULA FROM tabela_de_vendedores;
```

Assim, solucionamos o erro. Perceba, no entanto, que o nome da última coluna será "CPF". Como vimos há pouco, serão considerados apenas os nomes do primeiro `SELECT`.

Finalmente, vamos retomar aquele problema que tivemos no último vídeo, quando descobrimos que o MySQL não suporta o `FULL JOIN`. Agora que conhecemos o comando `UNION`, somos capazes de simular o `FULL JOIN` ao fazer a união de uma consulta `LEFT JOIN` com outra `RIGHT JOIN`:

```sql
SELECT tabela_de_vendedores.BAIRRO,
tabela_de_vendedores.NOME, DE_FERIAS,
tabela_de_clientes.BAIRRO,
tabela_de_clientes.NOME  FROM tabela_de_vendedores LEFT JOIN tabela_de_clientes
ON tabela_de_vendedores.BAIRRO = tabela_de_clientes.BAIRRO
UNION
SELECT tabela_de_vendedores.BAIRRO,
tabela_de_vendedores.NOME, DE_FERIAS,
tabela_de_clientes.BAIRRO,
tabela_de_clientes.NOME  FROM tabela_de_vendedores RIGHT JOIN tabela_de_clientes
ON tabela_de_vendedores.BAIRRO = tabela_de_clientes.BAIRRO;
```

Os dois `SELECT`s tem a mesma quantidade de colunas e os tipos dos campos correspondem, então a consulta será bem-sucedida. Enfim, poderemos analisar em uma única consulta quais são os bairros que têm clientes e vendedores (por exemplo, Tijuca); quais possuem vendedores mas não dispõem de compradores cadastrados (Copacabana); e em quais moram clientes porém não têm vendedores (por exemplo, Água Santa). Essas eram exatamanente as informações que esperávamos do `FULL JOIN`, ou seja, esse comando pode ser simulado com o `LEFT JOIN` e o `RIGHT JOIN` com o `UNION` entre eles.


-----------------------------------------------------------------------
# 09Subconsultas

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55594

## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/Consultas%20SUB%20CONSULTAS.sql)

Nesse vídeo, vamos estudar sobre as **subconsultas**, que nada mais são do que consultas dentro de outras consultas. Para exemplificar, vamos usar duas tabelas. Na tabela 1, temos o campo "X" que apresenta letras e o campo "Y" que possui valores numéricos. Na tabela 2, temos apenas o campo "Y", também com números:

|**X**|**Y**|
|---|---|
|A|2|
|A|1|
|B|2|
|B|3|
|B|1|
|C|1|
|C|5|
|C|2|
|D|3|

 

|**Y**|
|---|
|1|
|2|

Nosso primeiro objetivo será fazer uma consulta que liste todos os registros da tabela 1 cujo Y está presente na tabela 2. Como sabemos que a tabela 2 contém apenas dois valores (1 e 2), uma opção seria usar a cláusula `WHERE` junto do `IN`:

```sql
SELECT X, Y FROM tab1
WHERE Y IN (1,2);
```

A condição `WHERE Y IN (1,2)` significa que vamos filtrar registros cujo Y esteja **dentro** do conjunto de valores `(1,2)`:

|**X**|**Y**|
|---|---|
|A|2|
|A|1|
|B|2|
|B|1|
|C|1|
|C|2|

Assim, a consulta retornará exatamente o que queríamos. **Entretanto**, se um novo valor for adicionado à tabela 2, seremos obrigados a reescrever o script para que continue funcionando do modo que desejamos. Por exemplo, acrescentando um registro à tabela 2:

|**Y**|
|---|
|1|
|2|
|3|

Precisaríamos embutir manualmente o novo valor no script:

```sql
SELECT X, Y FROM tab1
WHERE Y IN (1,2,3);
```

> Essa prática é um exemplo de **_hardcoding_**. Caso ache interessante, você pode pesquisar mais sobre o assunto.

Essa situação se tornará insustentável, se a tabela 2 for modificada constantemente. Uma solução, então, é usar uma subconsulta:

```sql
SELECT X, Y FROM tab1
WHERE Y IN (SELECT Y FROM tab2);
```

Dessa forma, vamos filtrar registros cujo Y esteja dentro do conjunto de valores resultantes da subconsulta `SELECT Y FROM tab2` (que, por sua vez, retorna todos os valores da tabela 2). Teremos uma consulta dentro de outra - ou seja, uma subconsulta. E o resultado seria o seguinte:

|**X**|**Y**|
|---|---|
|A|2|
|A|1|
|B|2|
|B|3|
|B|1|
|C|1|
|C|2|
|D|3|

A seguir, criaremos outro exemplo. Vejamos a consulta a seguir e o seu retorno (que chamaremos de tabela 3):

```vbnet
SELECT X, SUM(Y) as NEW_Y FROM tab1 GROUP BY X;
```

|**X**|**NEW_Y**|
|---|---|
|A|3|
|B|6|
|C|8|
|D|3|

Vamos supor que precisamos filtrar os valores da tabela 3 cujo "NEW_Y" seja igual a 3. Usando uma subconsulta, poderíamos fazer o seguinte:

```vbnet
SELECT Z.X, Z.NEW_Y FROM (SELECT X, SUM(Y) as NEW_Y FROM tab1 GROUP BY X) Z WHERE Z.NEW_Y = 3;
```

No trecho `FROM (SELECT X, SUM(Y) as NEW_Y FROM tab1 GROUP BY X) Z`, estamos usando como subconsulta o `SELECT` que fizemos anteriormente (cujo retorno é a tabela 3). Além disso, declaramos "Z" como _alias_ e, por fim, colocamos a condição desejada: `WHERE Z.NEW_Y = 3`:

|**X**|**NEW_Y**|
|---|---|
|A|3|
|D|3|

Para tornar a explicação mais clara, vamos praticar com alguns exemplos no nosso banco de dados "sucos_vendas". Abriremos o MySQL Workbench, criaremos um novo script e começaremos consultando os bairros da tabela de vendedores:

```sql
SELECT DISTINCT BAIRRO FROM tabela_de_vendedores;
```

O retorno mostrará que existem 4 bairros onde há escritórios de vendedores: Tijuca, Jardins, Copacabana e Santo Amaro. Em seguida, vamos selecionar os clientes cujos bairros têm escritórios de vendedores. Uma forma de buscar esses dados é a seguinte:

```sql
SELECT * FROM tabela_de_clientes WHERE BAIRRO 
IN ('Tijuca','Jardins','Copacabana','Santo Amaro');
```

Com essa consulta, conseguiremos as informações que desejamos, porém digitar os nomes dos bairros um a um não é conveniente, visto que a qualquer momento podem surgir novos escritórios em outros bairros e seremos forçados a reescrever a consulta.

Então, vamos encontrar uma forma melhor de buscar esses dados. Sabemos que a lista **Tijuca, Jardins, Copacabana, Santo Amaro** é o retorno de `SELECT DISTINCT BAIRRO FROM tabela_de_vendedores`. Desse modo, podemos usar essa seleção como uma subconsulta:

```sql
SELECT * FROM tabela_de_clientes WHERE BAIRRO 
IN (SELECT DISTINCT BAIRRO FROM tabela_de_vendedores);
```

Em outras palavras: da tabela de clientes, vamos selecionar clientes cujo bairro esteja **dentro** de que conjunto? Do resultado de `SELECT DISTINCT BAIRRO FROM tabela_de_vendedores`. Assim, obtemos o mesmo retorno, porém de uma forma mais sustentável - se os bairros dos vendedores mudarem, a consulta continua funcionando.

Vamos fazer outro exemplo, dessa vez consultando o maior preço de cada tipo de embalagem:

```vbnet
SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) as PRECO_MAXIMO FROM tabela_de_produtos
GROUP BY EMBALAGEM;
```

Assim, descobrimos que a garrafa mais cara custa R$13,31; o PET mais caro é R$38,01; e a lata, R$4,56. Então, faremos uma seleção das embalagens cujo preço mais caro é maior ou igual que R$10. Utilizaremos nossa última consulta como uma subconsulta com apelido "X":

```vbnet
SELECT X.EMBALAGEM, X.PRECO_MAXIMO FROM 
(SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) AS PRECO_MAXIMO FROM tabela_de_produtos
GROUP BY EMBALAGEM) X WHERE X.PRECO_MAXIMO >= 10;
```

Assim, o MySQL está interpretando a subconsulta como se fosse uma tabela com _alias_ "X", então `X.EMBALAGEM` e `X.PRECO_MAXIMO` referem-se à seleção dos campos dessa tabela "X". Ao final, temos a cláusula `WHERE` que filtra apenas os preços maiores ou iguais a R$10. O resultado dessa consulta mostra que apenas embalagens PET e garrafas têm o preço máximo maior que R$10.

Com esse exemplo, constatamos que uma consulta pode assumir o papel de uma tabela - foi o que ocorreu com a subconsulta apelidada de "X". Inclusive, seria possível até usar `JOIN` e outros comandos nesses casos.

-----------------------------------------------------------------------
# 11Visão

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55595


## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/visao.sql)

Falaremos, a seguir, de uma estrutura importante no MySQL chamada **visão**, que é uma tabela lógica, resultado de uma consulta. Ao realizar uma _query_ (seja simples ou complexa) podemos salvá-la com um nome (por exemplo, "V") e mais tarde referenciar essa visão como se fosse uma tabela (`SELECT * FROM V`).

As visões (ou _views_) são bastante úteis quando precisamos disponibilizar parte do nosso banco de dados para uma pessoa externa, pois criamos uma tabela lógica com limites que garantam a segurança das informações e concedemos acesso somente a essa visão.

Como a _view_ é uma consulta, ela tem um custo. Toda vez que referenciamos uma visão, pelos bastidores do banco de dados estamos executando uma seleção. Assim sendo, se a visão for um `SELECT` muito complexo, ao acessá-la o desempenho pode ser prejudicado.

Como exemplo, usaremos uma tabela que tem o campo "X" com letras e o campo "Y" com números:

|**X**|**Y**|
|---|---|
|A|2|
|A|1|
|B|2|
|B|3|
|B|1|
|C|1|
|C|5|
|C|2|
|D|4|

Vamos supor que fizemos a seguinte seleção, que agupa os valores iguais de "X" e traz a soma dos respectivos "Y":

```vbnet
SELECT X, SUM(Y) as NEW_Y FROM tab1 GROUP BY X;
```

E obtemos um retorno que chamaremos de tabela 2:

|**X**|**NEW_Y**|
|---|---|
|A|3|
|B|6|
|C|8|
|D|4|

Daremos um nome a esse `SELECT` que executamos, criando uma visão chamada "VW_VIEW". Então, se rodarmos `SELECT * FROM VW_VIEW`, teremos como retorno o resultado de `SELECT X, SUM(Y) as NEW_Y FROM tab1 GROUP BY X` (a tabela 2). Ou seja, é como se essa _view_ fosse uma subconsulta.

Com essa visão podemos, por exemplo, fazer um `JOIN` com outra tabela ou até com outras visões. Testaremos esse conceito usando a seguinte tabela (que chamaremos de tabela 3):

|**W**|**Y**|
|---|---|
|F|3|
|G|6|
|H|8|
|I|8|
|J|3|
|K|6|
|L|3|
|M|3|
|N|4|

Vamos fazer a seguinte consulta com `INNER JOIN`:

```sql
SELECT VW_VIEW.X, TAB3.W FROM VW_VIEW
INNER JOIN TAB3 ON VW_VIEW.NEW_Y = TAB3.Y;
```

E o retorno será o seguinte:

|**X**|**W**|
|---|---|
|A|F|
|B|G|
|C|H|
|C|I|
|A|J|
|B|K|
|A|L|
|A|M|
|D|N|

Vamos ao MySQL Workbench para praticar no nosso banco de dados. Criaremos um novo script e repetiremos a consulta que fizemos no vídeo passado, selecionando os maiores preços de acordo com as embalagens:

```vbnet
SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) AS MAIOR_PRECO FROM tabela_de_produtos
GROUP BY EMBALAGEM;
```

E, novamente, usaremos esse `SELECT` como uma subconsulta para ver apenas os preços máximos que são maiores ou iguais a 10:

```vbnet
SELECT X.EMBALAGEM, X.MAIOR_PRECO FROM
(SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) AS MAIOR_PRECO FROM tabela_de_produtos
GROUP BY EMBALAGEM) X WHERE X.MAIOR_PRECO >= 10;
```

Até este ponto é o que fizemos no vídeo anterior. Agora, criaremos uma _view_ com o conteúdo dessa subconsulta. No painel à esquerda do programa, dentro da base "sucos_vendas" que está em negrito, vamos clicar em "_Views_", com o botão direito do mouse. Em seguida, selecionaremos "_Create View..._" e uma nova aba será aberta. Nela, vamos digitar o seguinte código:

```sql
CREATE VIEW 'VW_MAIORES_EMBALAGENS' AS
SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) AS MAIOR_PRECO FROM tabela_de_produtos
GROUP BY EMBALAGEM
```

Dessa forma, estamos criando uma visão com nome "VW_MAIORES_EMBALAGENS".

> É padrão usar as letras "VW" no início dos nomes das _views_, essa prática facilita a identificação das visões na hora de programar.

A seguir, clicaremos em "_Apply_", depois em "OK". Uma caixa de diálogos será aberta, mostrando o script que o programa vai executar. Note que o código está ligeiramente diferente, em vez do `CREATE VIEW` que digitamos, temos `CREATE OR REPLACE VIEW`. Essa mudança significa que o MySQL vai criar a visão **ou** subtituí-la, caso já exista. Vamos pressionar "_Apply_" mais uma vez e, então, "_Finish_".

Agora, no painel à esquerda, é possível expandir o subgrupo _Views_ e, dentro dele, temos a visão que acabamos de criar. Analisando o conteúdo de "vw_maiores_embalagens", veremos as colunas "EMBALAGEM" e "MAIOR_PRECO". Ou seja, a visão tem um comportamento igual ao de uma tabela.

Voltando ao nosso script, agora que criamos a visão podemos refazer a última seleção de um jeito alternativo, substituindo a subconsulta pela nova _view_:

```sql
SELECT X.EMBALAGEM, X.MAIOR_PRECO FROM
vw_maiores_embalagens X WHERE X.MAIOR_PRECO >= 10;
```

Também temos a opção de fazer, por exemplo, um `JOIN` com informações da tabela de produtos e dados da visão:

```sql
SELECT A.NOME_DO_PRODUTO, A.EMBALAGEM, A.PRECO_DE_LISTA, X.MAIOR_PRECO
FROM tabela_de_produtos A INNER JOIN vw_maiores_embalagens X
ON A.EMBALAGEM = X.EMBALAGEM;
```

Trata-se de um `INNER JOIN` entre uma tabela e a _view_ que criamos que, nos bastidores, está executando o agrupamento dos maiores preços de cada tipo de embalagem.

Com essa seleção, verificamos no primeiro registro, por exemplo, que o suco "Sabor da Montanha - 700 ml - Uva" em garrafa custa R$6,30 e o produto mais caro vendido em garrafa é R$13,31. Para descobrir qual é o item em garrafa mais caro, basta encontrar o registro em que a embalagem é garrafa e o preço de lista também é R$13,31 - é o "Festival de Sabores - 2 Litros - Açaí".

Podemos, inclusive, criar um indicador de porcentagem para saber o quão mais barato está cada produto, comparado ao valor da coluna "MAIOR_PRECO":

```vbnet
SELECT A.NOME_DO_PRODUTO, A.EMBALAGEM, A.PRECO_DE_LISTA, X.MAIOR_PRECO,
((A.PRECO_DE_LISTA / X.MAIOR_PRECO) -1) * 100 AS PERCENTUAL
FROM tabela_de_produtos A INNER JOIN vw_maiores_embalagens X
ON A.EMBALAGEM = X.EMBALAGEM;
```

Dessa forma, concluímos que "Sabor da Montanha - 700 ml - Uva" vendido em garrafa é 52% mais barato que a garrafa mais cara. Já "Festival de Sabores - 2 Litros - Açaí" é 0% mais barato, pois é justamente a garrafa mais cara.

Conhecendo visões, portanto, já começamos a fazer alguns relatórios, até mesmo calculando indicadores como percentual de preços. Juntando vários conceitos de SQL, estamos adquirindo noções de como construir relatórios para os clientes a partir da análise de informações dos bancos de dados.


-----------------------------------------------------------------------
# 13Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Aqui veremos como conectar as consultas de tabelas diferentes. Chamamos esta união de JOIN.

2) Veja o conteúdo de duas tabelas digitando os comandos abaixo:

```sql
SELECT * FROM tabela_de_vendedores;
```

![1.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/1.png)

```sql
SELECT * FROM notas_fiscais;
```

![2.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/2.png)

1) Podemos conectar essas duas tabelas pelo campo em comum (MATRICULA). Digite:

```sql
SELECT * FROM tabela_de_vendedores A
INNER JOIN notas_fiscais B
ON A.MATRICULA = B.MATRICULA;
```

![3.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/3.png)

2) Podemos aplicar agrupamentos ao resultado da consulta que conecta uma ou mais tabelas:

```sql
SELECT A.MATRICULA, A.NOME, COUNT(*) FROM
tabela_de_vendedores A
INNER JOIN notas_fiscais B
ON A.MATRICULA = B.MATRICULA
GROUP BY A.MATRICULA, A.NOME;
```

![4.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/4.png)

3) Nem sempre todas as linhas podem ser conectadas. Existem outros tipos de JOINs que nos permite identificar quem não pode ser conectado. Veja a consulta abaixo:

```sql
SELECT COUNT(*) FROM tabela_de_clientes;
```

![5.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/5.png)

Ela mostra que temos 15 clientes.

4) Vamos fazer um JOIN com a tabela de notas fiscais e ver quantos clientes possuem notas emitidas. Digite:

![6.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/6.png)

Se você contar verá que, na consulta acima, temos 14 linhas. Existe um cliente que está no cadastro mas não teve nota fiscal emitida.

5) Podemos usar o LEFT JOIN. Digite:

```sql
SELECT DISTINCT A.CPF, A.NOME, B.CPF FROM tabela_de_clientes A
LEFT JOIN notas_fiscais B ON A.CPF = B.CPF
```

![7.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/7.png)

O cliente que possui o CPF vindo da tabela de notas com o valor nulo, é o cliente que nunca emitiu nota fiscal.

6) A seleção correta seria:

```sql
SELECT DISTINCT A.CPF, A.NOME, B.CPF FROM tabela_de_clientes A
LEFT JOIN notas_fiscais B ON A.CPF = B.CPF
WHERE B.CPF IS NULL;
```

![8.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/8.png)

7) Podemos juntar duas ou mais consultas, Desde que os campos selecionados sejam os mesmos. Digite:

```sql
SELECT DISTINCT BAIRRO FROM tabela_de_clientes
UNION
SELECT DISTINCT BAIRRO FROM tabela_de_vendedores;
```

![9.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/9.png)

8) O UNION ALL não faz a seleção com um DISTINCT. As linhas se repetem se existirem em ambas as tabelas. Digite:

```sql
SELECT DISTINCT BAIRRO FROM tabela_de_clientes
UNION ALL
SELECT DISTINCT BAIRRO FROM tabela_de_vendedores;
```

![10.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/10.png)

Veja que Santo Amaro aparece duas vezes. Uma vindo da tabela de clientes e outra da tabela de produtos.

9) Podemos simular o FULL JOIN, que não é suportado pelo MYSQL, usando o LEFT JOIN e RIGHT JOIN com UNION. Digite:

```sql
SELECT tabela_de_vendedores.BAIRRO,
tabela_de_vendedores.NOME, DE_FERIAS,
tabela_de_clientes.BAIRRO,
tabela_de_clientes.NOME  FROM tabela_de_vendedores LEFT JOIN tabela_de_clientes
ON tabela_de_vendedores.BAIRRO = tabela_de_clientes.BAIRRO
UNION
SELECT tabela_de_vendedores.BAIRRO,
tabela_de_vendedores.NOME, DE_FERIAS,
tabela_de_clientes.BAIRRO,
tabela_de_clientes.NOME  FROM tabela_de_vendedores RIGHT JOIN tabela_de_clientes
ON tabela_de_vendedores.BAIRRO = tabela_de_clientes.BAIRRO;
```

![11.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/11.png)

10) As sub-consultas permitem que possa ser feita seleções usando como critérios outras seleções. Digite:

```sql
SELECT * FROM tabela_de_clientes WHERE BAIRRO 
IN (SELECT DISTINCT BAIRRO FROM tabela_de_vendedores);
```

![12.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/12.png)

11) Podemos aplicar uma consulta, em vez de sobre uma tabela, sobre outra consulta. Digite:

```vbnet
SELECT X.EMBALAGEM, X.PRECO_MAXIMO FROM 
(SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) AS PRECO_MAXIMO FROM tabela_de_produtos
GROUP BY EMBALAGEM) X WHERE X.PRECO_MAXIMO >= 10;
```

![13.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/13.png)

12) Podemos transformar uma consulta numa visão (View) que depois pode ser usada em outras consultas como uma tabela. Crie a visão. Para isso, expanda na árvore do canto esquerdo, onde temos o nome do banco, e vá em Views.

![14.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/14.png)

13) Botão da direita do mouse sobre Views e crie uma nova visão.

![15.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/15.png)

14) Digite o seguinte comando:

```sql
CREATE VIEW `VW_MAIORES_EMBALAGENS` AS
SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) AS PRECO_MAXIMO FROM tabela_de_produtos
GROUP BY EMBALAGEM
```

15) Clique em Apply e siga os passos até a criação da visão.

16) Podemos manipular a visão como uma tabela. Digite:

```sql
SELECT * FROM VW_MAIORES_EMBALAGENS;
```

![16.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/16.png)

17) Logo a consulta:

```vbnet
SELECT X.EMBALAGEM, X.PRECO_MAXIMO FROM 
(SELECT EMBALAGEM, MAX(PRECO_DE_LISTA) AS PRECO_MAXIMO FROM tabela_de_produtos
GROUP BY EMBALAGEM) X WHERE X.PRECO_MAXIMO >= 10;
```

![17.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/17.png)

Pode ser substituída por:

```sql
SELECT X.EMBALAGEM, X.PRECO_MAXIMO FROM 
VW_MAIORES_EMBALAGENS X WHERE X.PRECO_MAXIMO >= 10;
```

![18.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/04/18.png)


-----------------------------------------------------------------------
# 01Funções de string

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55596


## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/Consultas%20string.sql)

Nesse vídeo, estudaremos **funções**. São nelas que residem as maiores diferenças entre os vários bancos que utilizam SQL. Neste curso, estamos conhecendo essa linguagem usando o **MySQL**. A maior parte do que aprendemos até agora (como `DISTINCT` e `JOIN`) é muito parecido ou igual entre o MySQL, o Oracle ou o SQL Server, por exemplo, citando os três principais bancos relacionais do mercado.

Ao tratar de funções, no entanto, nos deparamos com algumas diferenças — como você utiliza uma função em um banco nem sempre é igual à do outro banco. Quando temos um projeto desenvolvido em SQL para MySQL e desejamos migrá-lo para Oracle ou SQL Server, uma ação muito importante é verificar o uso das funções e fazer a conversão pontual delas.

A seguir, veremos alguns exemplos de funções e vamos classificá-las em três grandes grupos: **funções escalares**, que utilizam textos; **funções de data** que, como o próprio nome sugere, manipulam datas; e **funções matemáticas**, que realizam operações entre campos _float_ ou inteiros na nossa base de dados.

É humanamente impossível saber de cabeça todas as funções que o MySQL disponibiliza, mas por sorte temos a internet para nos ajudar. Um dos recursos que podemos acessar é o [site da documentação oficial do MySQL](https://dev.mysql.com/doc/). Essa documentação é muito bem detalhada e aborda tudo o que precisamos saber sobre MySQL. Nesse site, podemos clicar em "_MySQL Reference Manual_", selecionar "_MySQL 8.0 Reference Manual_" e seremos redirecionados para a [página do Manual de Referência do MySQL 8.0](https://dev.mysql.com/doc/refman/8.0/en/), que é a versão que estamos usando. À esquerda, veremos o índice de capítulos, dentre eles haverá um chamado "[_Functions and Operators_](https://dev.mysql.com/doc/refman/8.0/en/functions.html)", no qual encontraremos uma lista de funções que podemos utilizar no banco de dados.

Outro site interessante é o [w3school.com](https://www.w3schools.com/), que também nos oferece uma gama de materiais específicos sobre bancos de dados relacionais, inclusive o MySQL, que é o nosso foco. Nesse vídeo, para abordar as funções de texto, vamos usar esse site como apoio, pois ele é mais simples e fácil de visualizar do que a documentação oficial.

Então, começaremos na [página de funções do MySQL](https://www.w3schools.com/sql/sql_ref_mysql.asp). À esquerda, abaixo do título "_String Functions_", temos uma lista enorme de funções de textos. A seguir, vamos revisar algumas das mais importantes.

> No vídeo, ao navegar pelos sites, optamos pela tradução automática do inglês para o português para tornar o conteúdo mais acessível. Nesse processo, algumas funções também tiveram seus nomes traduzidos. Para que elas funcionem, precisamos usar o nome original, em inglês.

A [função `CONCAT()`](https://www.w3schools.com/sql/func_mysql_concat.asp) concatena _strings_. Ou seja, aplicando `CONCAT()` sobre duas _strings_, é possível uni-las em uma única sequência de texto. Podemos juntar um número ilimitado de _strings_, separando-as com vírgula:

```vbnet
SELECT CONCAT("SQL ", "Tutorial ", "is ", "fun!") AS ConcatenatedString; 
```

A [função `LTRIM()`](https://www.w3schools.com/sql/func_mysql_ltrim.asp) tira espaços à esquerda (_left_) de um texto. _Trim_, em português, significa "aparar" e é exatamente isso que a função faz:

```vbnet
SELECT LTRIM("     SQL Tutorial") AS LeftTrimmedString;
```

A [função `RTRIM()`](https://www.w3schools.com/sql/func_mysql_rtrim.asp), por outro lado, vai remover os espaços à direita (_right_) da _string_:

```vbnet
SELECT RTRIM("SQL Tutorial     ") AS RightTrimmedString;
```

Já se o nosso objetivo for aparar o texto dos dois lados, podemos usar a [função `TRIM()`](https://www.w3schools.com/sql/func_mysql_trim.asp), que retira espaços tanto da direita quanto da esquerda. Os espaços no meio da _string_ não são removidos:

```sql
SELECT TRIM('    SQL Tutorial    ') AS TrimmedString;
```

Outro exemplo interessante é a [função `LCASE()`](https://www.w3schools.com/sql/func_mysql_lcase.asp), que transforma um texto que está em caixa-alta (ou seja, em maiúsculas) deixando-o com letras minúsculas (em inglês, _lowercase_):

```cpp
SELECT LCASE("SQL Tutorial is FUN!");
```

Uma alternativa é o [`LOWER()`](https://www.w3schools.com/sql/func_mysql_lower.asp), que faz o mesmo processo:

```sql
SELECT LOWER("SQL Tutorial is FUN!");
```

Já a [função `UCASE()`](https://www.w3schools.com/sql/func_mysql_ucase.asp) fará o contrário, deixando toda a _string_ em maiúsculas (em inglês, _uppercase_):

```cpp
SELECT UCASE("SQL Tutorial is FUN!");
```

Um equivalente a essa função é o [`UPPER()`](https://www.w3schools.com/sql/func_mysql_upper.asp):

```sql
SELECT UPPER("SQL Tutorial is FUN!");
```

A [função `SUBSTRING()`](https://www.w3schools.com/sql/func_mysql_substring.asp) também é bastante usada. Com ela, conseguimos retirar um pedaço de texto de dentro de uma _string_ maior. Para usá-la, devemos informar três parâmetros: a _string_ original, a posição onde começaremos a retirada do texto e o número de caracteres que vamos extrair a partir da posição que especificamos:

```sql
SELECT SUBSTRING("SQL Tutorial", 5, 3) AS ExtractString;
```

Nesse caso, o texto original é "**SQL Tutorial**", vamos começar a extrair a partir do **quinto elemento** (a letra T, maiúscula) e pegaremos **três caracteres**. Então, a _subtring_ resultante será "Tut".

A [função `LENGTH()`](https://www.w3schools.com/sql/func_mysql_length.asp) retorna o tamanho de uma _string_:

```vbnet
SELECT LENGTH("SQL Tutorial") AS LengthOfString;
```

Nesse caso, o retorno será 12, pois o espaço também é contado.

Existe uma série de funções úteis e você pode continuar explorando o site para conhecê-las um pouco melhor. Não vamos nos aprofundar neste vídeo, mas você pode, por exemplo, ler mais sobre a [função `INSTR()`](https://www.w3schools.com/sql/func_mysql_instr.asp), que faz uma pesquisa para saber se uma _string_ está dentro de outra _string_.

Dependendo dos nossos objetivos, podemos sempre consultar a documentação do MySQL ou fóruns na internet para buscar uma função específica que resolva o problema que estamos enfrentando em determinado projeto.

Agora, vamos ao MySQL Workbench criar alguns exemplos com funções. Abriremos um novo script e começaremos com a seguinte consulta:

```java
SELECT LTRIM('    OLÁ')
```

Note que fizemos um `SELECT` sem o `FROM`, sem selecionar uma tabela. É como se fôssemos exibir uma constante. Para nomear a coluna, usaremos a expressão `AS`:

```csharp
 SELECT LTRIM('    OLÁ') AS RESULTADO;
```

Dessa forma, aplicamos `LTRIM()` sobre uma _string_ que contém vários espaços e o resultado será o texto "OLÁ", com os espaços **à esquerda** aparados. Podemos fazer algo semelhante com `RTRIM()`:

```csharp
SELECT RTRIM('OLÁ     ') AS RESULTADO;
```

Nesse caso, aparamos os espaços **à direita**. Se nossa meta for remover espaços de ambos os lados de um texto, manipularemos o texto com a função `TRIM()`:

```sql
SELECT TRIM('    OLÁ    ') AS RESULTADO;
```

> O MySQL Workbench dará sugestões de preenchimento automático à medida que digitamos, dando alguns palpites de funções.

A seguir, vamos concatenar _strings_:

```csharp
SELECT CONCAT('OLÁ', ' ', 'TUDO BEM','?') AS RESULTADO;
```

Note que um dos parâmetros é um **espaço**. Sem ele, as palavras "OLÁ" e "TUDO" apareceriam juntas.

Também é possível fazer testes com as funções de texto que transformam letras minúsculas em maiúsculas:

```sql
SELECT UPPER('olá, tudo bem?') AS RESULTADO;
```

E vice-versa:

```sql
SELECT LOWER('OLÁ, TUDO BEM?') AS RESULTADO;
```

Para extrair uma sequência de _strings_ dentro de um texto maior, optamos pela função `SUBSTRING()`:

```sql
SELECT SUBSTRING('OLÁ, TUDO BEM?', 6) AS RESULTADO;
```

Perceba que informamos apenas dois parâmetros. O primeiro é o texto original e o segundo é a posição onde começamos a extrair a _substring_ - a sexta posição, ocupada pela letra T. Na falta do terceiro parâmetro que especifique quantos caracteres retirar, o MySQL continuará até o fim do texto. Assim, o resultado dessa consulta será "TUDO BEM?".

Caso seja esclarecida a quantidade de caracteres desejada, então o retorno será diferente:

```sql
SELECT SUBSTRING('OLÁ, TUDO BEM?', 6, 4) AS RESULTADO;
```

Nesse caso, a _substring_ começa no T e, contando quatro caracteres a partir dessa letra, termina na letra O. O resultado será a palavra "TUDO".

Esses foram alguns exemplos livres utilizando dados bem simples para embasar nossos conhecimentos de funções que manipulam textos. Em um cenário real, usaremos essas funções dentro de um `SELECT` com informações presentes em tabelas, por exemplo:

```sql
SELECT CONCAT(NOME, ' (', CPF, ') ') AS RESULTADO FROM TABELA_DE_CLIENTES;
```

Veja que, dessa vez, selecionamos uma tabela com o `FROM`. Para cada linha do nosso `SELECT`, a função `CONCAT()` foi aplicada com campos diferentes da tabela — o nome e o CPF entre parênteses de cada cliente.

-----------------------------------------------------------------------
# 03Funções de datas

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55597

## Transcrição

`SELECT CURRENT_TIMESTAMP() AS DIA_HOJE, DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 5 DAY) AS RESULTADO;`

Dessa forma, o retorno mostrará a data de hoje (na coluna que nomeamos "DIA_HOJE") e o resultado da** substração **de 5 dias na segunda coluna.

E, por fim, faremos um exemplo usando as tabelas do nosso banco de dados "sucos_vendas". Primeiramente, vamos verificar todas as datas em que foram emitidas notas fiscais:

```sql
SELECT DISTINCT DATA_VENDA FROM NOTAS_FISCAIS;
```

Agora, utilizaremos as funções `DAYNAME()` e `MONTHNAME()` para que seja mostrado no resultado o dia da semana e o mês em que as vendas ocorreram, bem como o ano (com a função `YEAR()`):

```scss
SELECT DISTINCT DATA_VENDA,
DAYNAME(DATA_VENDA) AS DIA, MONTHNAME(DATA_VENDA) AS MES, YEAR(DATA_VENDA) AS ANO FROM NOTAS_FISCAIS;
```

Assim, além da primeira coluna informando a data, haverá outras três colunas mostrando o dia da semana, o nome do mês e o ano das vendas.

-----------------------------------------------------------------------
# 05Funções matemáticas

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55598

## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/Consultas%20matem%C3%A1ticas.sql)

Neste vídeo, estudaremos **funções matemáticas**. Novamente nos apoiaremos nas explicações da [página de funções MySQL do w3schools.com](https://www.w3schools.com/sql/sql_ref_mysql.asp). Nesse site, à esquerda, temos à disposição uma extensa lista de funções matemáticas sob o título "_Numeric Functions_". Veremos algumas delas a seguir.

Começando por ordem alfabética, a [função `ABS()`](https://www.w3schools.com/sql/func_mysql_abs.asp) nos fornecerá o valor absoluto de um número. Em seguida, temos `ACOS()`, `ASIN()` e `ATAN()` referentes ao cosseno, ao seno e à tangente - operações de cunho mais científico e que não usamos com frequência.

A seguir, veremos um nome que nos é familiar: [`AVG()`](https://www.w3schools.com/sql/func_mysql_avg.asp), que traz a média dos números. Todas as operações agregadoras que aplicamos anteriormente quando aprendemos sobre `GROUP BY` - `SUM()`, `MAX()`, `MIN()` - estão nessa lista.

Existem também as funções de arredondamento, como [`CEILING()`](https://www.w3schools.com/sql/func_mysql_ceiling.asp), [`FLOOR()`](https://www.w3schools.com/sql/func_mysql_floor.asp) e [`ROUND()`](https://www.w3schools.com/sql/func_mysql_round.asp). Logo, veremos alguns exemplos práticos para entendê-las melhor. Outra função interessante é a `SQRT()`, que retorna a raiz quadrada de um valor.

De modo geral, as funções matemáticas são pouco usadas, até mesmo para aplicações mais comerciais. As exceções são as expressões escritas por extenso, com as quais calculamos adições, subtrações, multiplicações e divisões.

Vamos ao MySQL Workbench fazer alguns testes. Abriremos um novo script e começaremos com um exemplo de expressão numérica:

```vbnet
SELECT (23+((25-2)/2)*45) AS RESULTADO;
```

Executando o código, obtemos o resultado 540,5.

As funções `CEILING()`, `FLOOR()` e `ROUND()` serão muito úteis para arredondar valores com muitas casas decimais:

```scss
SELECT CEILING(12.33333232323) AS RESULTADO;
```

`CEILING()` (em português, "teto") arredondará "para cima", ou seja, para o **próximo número inteiro**, independentemente dos valores nas casas decimais. Logo, essa consulta retornará 13.

Já `ROUND()` arredondará "para cima" somente se a primeira casa decimal for 5 ou maior:

```scss
SELECT ROUND(12.33333232323) AS RESULTADO;
SELECT ROUND(12.7777232323) AS RESULTADO;
```

No caso, a primeira consulta retorna 12, já o resultado da segunda é 13. Quanto a `FLOOR()` (em português, "chão"), o valor será sempre arredondado "para baixo":

```scss
SELECT FLOOR(12.7777232323) AS RESULTADO;
```

Com esse valor, nosso retorno será 12, independentemente dos números nas casas decimais.

Outra função útil, especialmente para a realização de simulações, é o `RAND()`, que nos entrega um número aleatório:

```csharp
SELECT RAND() AS RESULTADO; 
```

Podemos rodar várias vezes esse mesmo `SELECT` e, a cada vez, teremos um número diferente. Esses retornos são convenientes para simular vendas e outros dados numéricos hipotéticos para fazer testes em nossos sistemas.

Vejamos um exemplo com a nossa base "sucos_vendas". Primeiro, vamos selecionar o número, a quantidade e o preço dos registros da tabela "itens_notas_fiscais":

```sql
SELECT NUMERO, QUANTIDADE, PRECO
 FROM ITENS_NOTAS_FISCAIS;
```

Para descobrir o faturamento, basta multiplicar a quantidade pelo preço de cada item. Podemos apresentar esse resultado numa nova coluna chamada "faturamento":

```vbnet
SELECT NUMERO, QUANTIDADE, PRECO, QUANTIDADE * PRECO AS FATURAMENTO
 FROM ITENS_NOTAS_FISCAIS;
```

Veremos, no entanto, que os valores na coluna de faturamento vêm com muitas casas decimais. Como estamos lidando com preços, bastaria que tivessem apenas duas casas. Como solução, utilizaremos a função `ROUND()`:

```vbnet
 SELECT NUMERO, QUANTIDADE, PRECO, ROUND(QUANTIDADE * PRECO, 2) AS FATURAMENTO
 FROM ITENS_NOTAS_FISCAIS;
```

Note que essa função de arredondamento aceita um segundo parâmetro que corresponde à quantidade de casas decimais que desejamos ver. Dessa forma, aprendemos um pouco mais sobre as funções matemáticas.


-----------------------------------------------------------------------
# 07Conversão de dados

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55599

## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/Consultas%20Conver.sql)

Um processo bastante recorrente quando trabalhamos com SQL é a **conversão de dados**. Cada campo das tabelas tem um tipo que condiz com seu conteúdo e que não deve mudar, porém nem sempre esse tipo será apropriado para certas manipulações (como algumas funções). Às vezes, precisamos exibir datas em um formato específico, convertidas em _string_, ou usar um dado de tipo numérico como texto, por exemplo. Não convém modificar o tipo da coluna na base de dados, visto que foi criada assim para melhor conveniência. A solução é a conversão de dados no momento em que formos usá-los — tal como em uma função.

Vamos começar aprendendo sobre conversão de datas em _strings_, que é um processo extenso, com inúmeros parâmetros e que merece uma explicação mais detalhada. Como apoio, usaremos o **Manual de Referências** da documentação oficial do MySQL, mais especificamente [o subcapítulo "_Date and Time Functions_", com ênfase na função `DATE_FORMAT()`](https://dev.mysql.com/doc/refman/5.7/en/date-and-time-functions.html#function_date-format).

Essa é uma função específica para conversão do tipo data para _strings_. O primeiro parâmetro dela é a data, enquanto o segundo parâmetro indica o formato — este é o ponto mais trabalhoso.

No Manual, na descrição da função `DATE_FORMAT()`, há uma tabela com uma série de **especificadores** que se iniciam com o símbolo de porcentagem (%). Cada um deles é responsável por um tipo diferente de conversão e se relaciona com um segmento em particular da data (segundo, minuto, hora etc.). Para ficar mais claro, vamos criar alguns testes no MySQL Workbench.

Abriremos um novo script e começaremos com uma consulta simples, selecionando a data atual no formato _timestamp_:

```csharp
SELECT CURRENT_TIMESTAMP() AS RESULTADO;
```

O retorno será um dado no formato de data. A título de exemplo, vamos tentar rodar uma função de texto com esse dado em formato de data:

```sql
SELECT CONCAT('O dia de hoje é: ', CURRENT_TIMESTAMP()) AS RESULTADO;
```

A função `CONCAT()` teoricamente manipula somente textos. Ao executar a consulta acima, no entanto, ela consegue trabalhar com um dado em formato de data, pois se trata de uma **conversão implícita**. Vale ressaltar, no entanto, que nem todas as funções são capazes de realizar essa conversão automaticamente.

Note que essa data é exibida no formato padrão (ano, mês, dia, horas, minutos e segundos). Agora, com a função `DATE_FORMAT()` e os **especificadores** que vimos há pouco, podemos modificar essa visualização. Vamos começar usando `%Y`:

```less
SELECT CONCAT('O dia de hoje é: ', 
DATE_FORMAT(CURRENT_TIMESTAMP(),'%Y') ) AS RESULTADO;
```

Nosso primeiro parâmetro é a data atual. Já o segundo parâmetro diz respeito ao formato: na tabela que consultamos, no Manual de Referências, a descrição de `%Y` indica a conversão do ano com **quatro** dígitos. Podemos optar por outro formato, por exemplo, usando o `%y` (com "y" minúsculo) e a exibição do ano terá apenas **dois** dígitos:

```less
SELECT CONCAT('O dia de hoje é: ', 
DATE_FORMAT(CURRENT_TIMESTAMP(),'%y') ) AS RESULTADO;
```

Ademais, é possível concatenar com outros **especificadores** e até símbolos, como a barra:

```less
SELECT CONCAT('O dia de hoje é: ', 
DATE_FORMAT(CURRENT_TIMESTAMP(),'%m/%y') ) AS RESULTADO;
```

Agora, teremos mês e ano. No caso, `%m` exibirá o número do mês com dois dígitos. Se nosso objetivo for apresentar o mês com apenas um dígito, nós vamos à tabela e procuramos como fazer essa mudança — com `%c`.

Um padrão bastante usado é o dia, seguido do mês (com dois dígitos) e o ano (com quatro dígitos):

```less
SELECT CONCAT('O dia de hoje é: ', 
DATE_FORMAT(CURRENT_TIMESTAMP(),'%d/%m/%Y') ) AS RESULTADO;
```

Ademais, podemos acrescentar o dia da semana (com `%W`):

```less
SELECT CONCAT('O dia de hoje é: ', 
DATE_FORMAT(CURRENT_TIMESTAMP(),'%W, %d/%m/%Y') ) AS RESULTADO;
```

Também temos a opção de adicionar o número da semana (com `%U`). Ou seja, se o resultado mostrar o número 15, quer dizer que estamos na 15ª semana do ano:

```less
SELECT CONCAT('O dia de hoje é: ', 
DATE_FORMAT(CURRENT_TIMESTAMP(),'%d/%m/%Y - %U') ) AS RESULTADO;
```

> Note que, além das barras que separam a data, também podemos usar vírgulas e traços.

É possível fazer diversas combinações a depender do formato de exibição de nossa preferência. Você pode continuar testando esses formatos no seu projeto, consultando a tabela do Manual de Referências.

Finalmente, aprenderemos sobre a função `CONVERT()`, que faz a conversão de um tipo para outro (especificado como segundo parâmetro). Por exemplo, vamos transformar um valor numérico em `char`:

```sql
SELECT CONVERT(23.3, CHAR) AS RESULTADO;
```

No retorno, é difícil distinguir o **tipo** desse registro. Para confirmar a conversão, podemos executar uma função que só admite textos, como o `SUBSTRING()`:

```sql
SELECT SUBSTRING(CONVERT(23.3, CHAR),1,1) AS RESULTADO;
```

Dessa vez, o retorno será 2, o que quer dizer que a função `SUBSTRING()` identificou "23.3" como um texto e fez a extração da _substring_ (um caractere a partir do primeiro).

Funções e conversões são tópicos extremamente amplos, neste curso não convém nos prolongar em explicações detalhadas sobre esses assuntos. Passamos por alguns exemplos e agora você já pode prosseguir com seus estudos, consultando a documentação e buscando em fóruns online quando necessário.

-----------------------------------------------------------------------

# 09Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com a próxima aula.

1) Nesta aula iremos ver exemplos de funções.

2) Primeiro vimos as funções do tipo texto. Veja alguns exemplos com seus respectivos retornos:

```csharp
SELECT LTRIM('    OLÁ') AS RESULTADO;
```

![1.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/1.png)

```csharp
SELECT RTRIM('OLÁ     ') AS RESULTADO;
```

![2.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/2.png)

```sql
SELECT TRIM('    OLÁ    ') AS RESULTADO;
```

![3.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/3.png)

```csharp
SELECT CONCAT('OLÁ', ' ', 'TUDO BEM','?') AS RESULTADO;
```

![4.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/4.png)

```sql
SELECT UPPER('olá, tudo bem?') AS RESULTADO;
```

![5.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/5.png)

```sql
SELECT LOWER('OLÁ, TUDO BEM?') AS RESULTADO;
```

![6.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/6.png)

```sql
SELECT SUBSTRING('OLÁ, TUDO BEM?', 6) AS RESULTADO;
```

![7.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/7.png)

```sql
SELECT SUBSTRING('OLÁ, TUDO BEM?', 6, 4) AS RESULTADO;
```

![8.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/8.png)

```sql
SELECT CONCAT(NOME, ' (', CPF, ') ') AS RESULTADO FROM TABELA_DE_CLIENTES;
```

![9.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/9.png)

1) Temos as funções de datas. Execute os comandos abaixo:

```csharp
SELECT CURDATE();
```

![10.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/10.png)

```csharp
SELECT CURRENT_TIME();
```

![11.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/11.png)

```csharp
SELECT CURRENT_TIMESTAMP();
```

![12.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/12.png)

```sql
SELECT YEAR(CURRENT_TIMESTAMP());
```

![13.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/13.png)

```sql
SELECT DAY(CURRENT_TIMESTAMP());
```

![14.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/14.png)

```sql
SELECT MONTH(CURRENT_TIMESTAMP());
```

![15.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/15.png)

```scss
SELECT MONTHNAME(CURRENT_TIMESTAMP());
```

![16.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/16.png)

```sql
SELECT DATEDIFF(CURRENT_TIMESTAMP(), '2019-01-01') AS RESULTADO;
```

![17.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/17.png)

```sql
SELECT DATEDIFF(CURRENT_TIMESTAMP(), '1965-09-04') AS RESULTADO;
```

![18.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/18.png)

```sql
SELECT CURRENT_TIMESTAMP() AS DIA_HOJE
, DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 5 DAY) AS RESULTADO;
```

![19.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/19.png)

```scss
SELECT DISTINCT DATA_VENDA,
DAYNAME(DATA_VENDA) AS DIA, MONTHNAME(DATA_VENDA) AS MES
, YEAR(DATA_VENDA) AS ANO FROM NOTAS_FISCAIS;
```

![20.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/20.png)

2) Alguns exemplos de funções matemáticas:

```vbnet
SELECT (23+((25-2)/2)*45) AS RESULTADO;
```

![21.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/21.png)

```scss
SELECT CEILING(12.33333232323) AS RESULTADO;
```

![22.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/22.png)

```scss
SELECT ROUND(12.7777232323) AS RESULTADO;
```

![23.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/23.png)

```scss
SELECT FLOOR(12.7777232323) AS RESULTADO;
```

![24.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/24.png)

```csharp
SELECT RAND() AS RESULTADO;
```

![25.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/25.png)

```vbnet
SELECT NUMERO, QUANTIDADE, PRECO, QUANTIDADE * PRECO AS FATURAMENTO
 FROM ITENS_NOTAS_FISCAIS;
```

![26.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/26.png)

```vbnet
 SELECT NUMERO, QUANTIDADE, PRECO, ROUND(QUANTIDADE * PRECO, 2) AS FATURAMENTO
 FROM ITENS_NOTAS_FISCAIS;
```

![27.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/27.png)

3) Temos também funções de conversão. Execute os exemplos abaixo:

```csharp
SELECT CURRENT_TIMESTAMP() AS RESULTADO;
```

![28.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/28.png)

```sql
SELECT CONCAT('O dia de hoje é : ', CURRENT_TIMESTAMP()) AS RESULTADO;
```

![29.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/29.png)

```less
SELECT CONCAT('O dia de hoje é : ',

DATE_FORMAT(CURRENT_TIMESTAMP(),'%W, %d/%m/%Y - %U') ) AS RESULTADO;
```

![30.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/30.png)

```sql
SELECT SUBSTRING(CONVERT(23.3, CHAR),1,1) AS RESULTADO;
```

![31.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/05/31.png)


-----------------------------------------------------------------------

# 01Relatório de vendas válidas

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55600

## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/06/Vendas%20v%C3%A1lidas.sql)

Nesse momento, já somos capazes de colocar em prática todo o nosso conhecimento de SQL relativo às consultas. Vamos revisar e adaptar tudo que aprendemos neste curso para atender a um pedido do gerente de vendas da empresa de sucos: ele solicitou um relatório para evidenciar, dentre todas as vendas realizadas, quais foram válidas e quais foram inválidas.

Primeiramente, vamos esclarecer o que é uma **venda válida**. Na tabela de clientes, há uma coluna chamada "VOLUME_DE_COMPRA" que corresponde ao volume máximo de suco que cada cliente pode comprar em um mês. Para saber se esse número foi respeitado, podemos consultar a tabela de itens de notas fiscais e compará-lo à quantidade adquirida por cada cliente em cada mês. Vendas válidas são aquelas que não extrapolam esse limite **mensal**.

Então, devemos entregar um relatório sobre vendas válidas e inválidas ao gerente de vendas para que possa ser analisado se o parâmetro de volume de compras está sendo considerado durante as negociações com os clientes.

Agora que compreendemos nossa meta, aos poucos vamos construir uma seleção que atenda essa demanda. Começaremos abrindo o MySQL Workbench e criando um script. Nosso **_primeiro passo_** será descobrir o volume total de vendas para cada cliente dentro de um mês, lembrando que o mês é o fator limitante.

Vamos consultar a tabela de itens das notas fiscais e a tabela de notas fiscais para saber o que cada uma delas pode nos mostrar:

```sql
SELECT * FROM ITENS_NOTAS_FISCAIS;
SELECT * FROM NOTAS_FISCAIS;
```

As informações que nos interessam estão em tabelas diferentes: os dados sobre o cliente (**CPF**) e a **data da venda** estão na tabela de notas fiscais, enquanto a **quantidade** das vendas consta na tabela de itens das notas fiscais. Para unificar essa visualização, vamos fazer uma seleção com `INNER JOIN`:

```sql
SELECT * FROM NOTAS_FISCAIS NF
INNER JOIN ITENS_NOTAS_FISCAIS INF
ON NF.NUMERO = INF.NUMERO;
```

Note que criamos um _alias_ para cada tabela ("NF" e "INF") e usamos o número das notas fiscais como campo em comum para realizar essa junção. Como usamos o asterisco, o retorno mostrará **todas** as colunas de ambas as tabelas, mas não precisamos de todas essas informações. Então, vamos refazer essa consulta, selecionando apenas as colunas relevantes para nosso relatório:

```sql
SELECT NF.CPF, NF.DATA_VENDA, INF.QUANTIDADE FROM NOTAS_FISCAIS NF
INNER JOIN ITENS_NOTAS_FISCAIS INF
ON NF.NUMERO = INF.NUMERO;
```

Agora, vejamos o formato das datas. Tendo em vista nosso objetivo, seria interessante agrupar as vendas **mensalmente**, porém no momento as datas na coluna "DATA_VENDA" são exibidas dia a dia. Para trocar esse formato, usaremos a função `DATE_FORMAT()`:

```sql
SELECT NF.CPF, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m') AS MES_ANO, INF.QUANTIDADE FROM NOTAS_FISCAIS NF
INNER JOIN ITENS_NOTAS_FISCAIS INF
ON NF.NUMERO = INF.NUMERO;
```

Dessa forma, usamos os **especificadores** `%Y` e `%m` para exibir somente o ano e o mês de cada venda. Ademais, renomeamos o campo "DATA_VENDA" para "MES_ANO".

Analisando o retorno, há vários registros cujo CPF e a data são iguais. Os quatro primeiros registros, por exemplo, são vendas realizadas em janeiro de 2015 para o cliente de CPF 7771579779. Se temos vendas no **mesmo mês** para o **mesmo cliente**, podemos agrupá-las por esses campos:

```sql
SELECT NF.CPF, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m') AS MES_ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE_VENDAS FROM NOTAS_FISCAIS NF
INNER JOIN ITENS_NOTAS_FISCAIS INF
ON NF.NUMERO = INF.NUMERO
GROUP BY NF.CPF, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m');
```

> Note que, no `GROUP BY`, inserimos a função `DATE_FORMAT()` inteira e não somente o campo "NF.DATA_VENDA". Nem sempre essa inclusão é necessária, dependerá do resultado da função, mas para garantir o sucesso, colocamos a função completa (sem o _alias_!).

Com essa seleção, além de agrupar registros por CPF e data, também aplicamos `SUM()` aos valores da coluna "QUANTIDADE" e a esse total demos o nome de "QUANTIDADE_VENDAS". Assim, o retorno será uma lista em que cada registro corresponde à quantidade de vendas para um determinado cliente em um determinado mês. Em outras palavras, concluímos nosso **_primeiro passo_**.

Antes de continuar, vamos fazer um **comentário** no script para não nos esquecer dessa seleção. Na linha acima da consulta, vamos digitar o seguinte texto:

```css
/* CONSULTA COM VENDAS DE CLIENTES POR MES */
```

O comentário é um texto que não altera a execução do código, o programa irá ignorar esse trecho quando estiver rodando. No SQL, basta colocar os símbolos `/*` no início, e `*/` ao final. Quanto maior e mais complexo nosso script ficar, mais importante é colocar comentários para lembrarmos o que cada parte faz.

O **_segundo passo_** é mais simples: exibir o volume de compra permitido para cada cliente. Encontraremos essa informação na tabela de clientes, à qual daremos o _alias_ "TC":

```sql
SELECT * FROM TABELA_DE_CLIENTES TC;
```

Novamente, temos uma consulta que retorna mais colunas do que necessitamos. Vamos selecionar apenas os campos relevantes:

```vbnet
SELECT TC.CPF, TC.NOME, TC.VOLUME_DE_COMPRA AS QUANTIDADE_LIMITE
FROM TABELA_DE_CLIENTES TC;
```

Assim, obtemos o CPF, o nome e o volume de compra de cada cliente — terminamos o **_segundo passo_**. Podemos também fazer um comentário sobre essa consulta para nos lembrarmos dela:

```sql
/* LIMITE DE COMPRA POR CLIENTE */
SELECT TC.CPF, TC.NOME, TC.VOLUME_DE_COMPRA AS QUANTIDADE_LIMITE
FROM TABELA_DE_CLIENTES TC;
```

Por fim, o **_terceiro passo_** será comparar as tabelas resultantes do primeiro e do segundo passo. Faremos um `INNER JOIN` entre elas:

```sql
SELECT NF.CPF, TC.NOME, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m') AS MES_ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE_VENDAS, TC.VOLUME_DE_COMPRA AS QUANTIDADE_LIMITE FROM NOTAS_FISCAIS NF
INNER JOIN ITENS_NOTAS_FISCAIS INF
ON NF.NUMERO = INF.NUMERO
INNER JOIN TABELA_DE_CLIENTES TC 
ON TC.CPF = NF.CPF
GROUP BY NF.CPF, TC.NOME, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m');
```

Assim, fizemos um `JOIN` cujo campo em comum é o CPF. Além do mais, incluímos as colunas "TC.NOME" e "TC.VOLUME_DE_COMPRA" no início do `SELECT` para serem exibidas no retorno. Também inserimos "TC.NOME" no `GROUP BY` ao final da seleção.

Ao tentar executar, receberemos um erro. O problema está no trecho `TC.VOLUME_DE_COMPRA`. Quando agrupamos registros, somos obrigados a especificar o que deve ser feito com os campos numéricos. Por exemplo, em `SUM(INF.QUANTIDADE)` temos a indicação de que os valores devem ser somados. Já em `TC.VOLUME_DE_COMPRA` não há especificação. Uma solução, então, é usar a função `MAX()` para que a coluna exiba o maior valor:

```sql
SELECT NF.CPF, TC.NOME, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m') AS MES_ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE_VENDAS, MAX(TC.VOLUME_DE_COMPRA) AS QUANTIDADE_LIMITE FROM NOTAS_FISCAIS NF
INNER JOIN ITENS_NOTAS_FISCAIS INF
ON NF.NUMERO = INF.NUMERO
INNER JOIN TABELA_DE_CLIENTES TC 
ON TC.CPF = NF.CPF
GROUP BY NF.CPF, TC.NOME, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m');
```

> Note que também poderíamos usar `MIN()` já que o volume de compra é constante para cada CPF - ou seja, nesse caso, o valor máximo e o mínimo são o mesmo. O uso de `SUM()`, no entanto, não funcionaria, pois os valores seriam somados e o volume permitido aumentaria.

Com essa consulta, cada registro exibirá o CPF e o nome do cliente, o mês e o ano das vendas, a soma das quantidades adquiridas no mês em questão e o volume de compras permitido. O primeiro registro, por exemplo, informa que em janeiro de 2015, Érica Carvalho comprou 24316 sucos do seu volume máximo de 24500 — está abaixo de seu limite, ou seja, é uma venda válida. Já no quinto registro, sabemos que em maio do mesmo ano ela extrapolou o volume permitido (26385 de 24500), então trata-se de uma venda inválida.

Em outras palavras, já somos capazes de averiguar se cada venda foi válida ou não, ao subtrair a quantidade limite da quantidade de vendas. Mas não convém enviar o relatório do jeito que está agora, pois o gerente teria que calcular os valores linha a linha. Em vez disso, criaremos um script que faça essa operação por nós e automaticamente mostre se é uma venda válida ou não.

Vamos usar a última seleção como uma subconsulta com _alias_ "X". Em seguida, incluiremos uma coluna chamada "DIFERENCA" que exiba o resultado de `X.QUANTIDADE_LIMITE - X.QUANTIDADE_VENDAS`:

```vbnet
SELECT X.CPF, X.NOME, X.MES_ANO, X.QUANTIDADE_VENDAS, X.QUANTIDADE_LIMITE,
X.QUANTIDADE_LIMITE - X.QUANTIDADE_VENDAS AS DIFERENCA
FROM (
SELECT NF.CPF, TC.NOME, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m') AS MES_ANO, 
SUM(INF.QUANTIDADE) AS QUANTIDADE_VENDAS , MAX(TC.VOLUME_DE_COMPRA) AS QUANTIDADE_LIMITE FROM NOTAS_FISCAIS NF
INNER JOIN ITENS_NOTAS_FISCAIS INF
ON NF.NUMERO = INF.NUMERO
INNER JOIN TABELA_DE_CLIENTES TC 
ON TC.CPF = NF.CPF
GROUP BY NF.CPF, TC.NOME, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m')) X;
```

Depois, para facilitar a leitura desses dados, vamos acrescentar uma coluna que apresente o texto "válida" ou "inválida" conforme o resultado da coluna "DIFERENCA". **Quando** negativo, a venda é inválida; **senão**, é válida:

```vbnet
SELECT X.CPF, X.NOME, X.MES_ANO, X.QUANTIDADE_VENDAS, X.QUANTIDADE_LIMITE,
X.QUANTIDADE_LIMITE - X.QUANTIDADE_VENDAS AS DIFERENCA,
CASE 
    WHEN (X.QUANTIDADE_LIMITE - X.QUANTIDADE_VENDAS) < 0 THEN 'INVÁLIDA'
    ELSE 'VÁLIDA' 
END AS STATUS_VENDA
FROM (
SELECT NF.CPF, TC.NOME, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m') AS MES_ANO, 
SUM(INF.QUANTIDADE) AS QUANTIDADE_VENDAS , 
MAX(TC.VOLUME_DE_COMPRA) AS QUANTIDADE_LIMITE FROM NOTAS_FISCAIS NF
INNER JOIN ITENS_NOTAS_FISCAIS INF
ON NF.NUMERO = INF.NUMERO
INNER JOIN TABELA_DE_CLIENTES TC 
ON TC.CPF = NF.CPF
GROUP BY NF.CPF, TC.NOME, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m')) X;
```

Agora que temos a coluna "STATUS_VENDA" nos informando se cada venda é válida ou não, o campo "DIFERENCA" se torna desnecessário, então podemos retirá-lo da consulta:

```vbnet
SELECT X.CPF, X.NOME, X.MES_ANO, X.QUANTIDADE_VENDAS, X.QUANTIDADE_LIMITE,
CASE 
    WHEN (X.QUANTIDADE_LIMITE - X.QUANTIDADE_VENDAS) < 0 THEN 'INVÁLIDA'
    ELSE 'VÁLIDA' 
END AS STATUS_VENDA
FROM (
SELECT NF.CPF, TC.NOME, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m') AS MES_ANO, 
SUM(INF.QUANTIDADE) AS QUANTIDADE_VENDAS , 
MAX(TC.VOLUME_DE_COMPRA) AS QUANTIDADE_LIMITE FROM NOTAS_FISCAIS NF
INNER JOIN ITENS_NOTAS_FISCAIS INF
ON NF.NUMERO = INF.NUMERO
INNER JOIN TABELA_DE_CLIENTES TC 
ON TC.CPF = NF.CPF
GROUP BY NF.CPF, TC.NOME, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m')) X;
```

Essa seleção nos permitirá analisar todas as vendas mensais por CPF e rapidamente avaliar quais delas estavam dentro do limite de cada cliente. Por exemplo, veremos que Fernando Cavalcante realizou várias compras inválidas mas, ao mesmo tempo, ele tinha um limite menor que o de Érica Carvalho.

Desse modo, conseguimos reunir em uma consulta todos os dados pertinentes para o relatório que foi solicitado pelo gerente de vendas da empresa de sucos.

-----------------------------------------------------------------------
# 02A consulta do relatório

Nesta aula construímos um relatório que apresentou os clientes que tiveram vendas inválidas. Complemente este relatório listando somente os que tiveram vendas inválidas e calculando a diferença entre o limite de venda máximo e o realizado, em percentuais.

Dica:

Capture a SQL final da aula.

Filtre somente as linhas onde

(X.QUANTIDADE_LIMITE - X.QUANTIDADE_VENDAS) < 0

Liste a coluna de X.QUANTIDADE_LIMITE

Crie uma nova coluna fazendo a fórmula:

(1 - (X.QUANTIDADE_LIMITE/X.QUANTIDADE_VENDAS)) * 100

-----------------------------------------------------------------------
# 03Relatório de vendas por sabor

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55601

## Transcrição

> [Aqui você pode fazer o download completo do projeto realizado neste vídeo e continuar seus estudos.](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/06/Vendas%20por%20sabor.sql)

Nesse vídeo, criaremos mais um relatório a pedido da área comercial da empresa de sucos de frutas. A solicitação é um acompanhamento sobre as vendas do ano de 2016 por sabores e eles gostariam de ver as informações no seguinte modelo:

|**Sabor**|**Ano**|**Quantidade vendida**|**Participação**|
|---|---|---|---|
|Açaí|2016|10024014.20|23.66|
|Melancia|2016|6128138.08|14.47|
|Manga|2016|5725137.08|13.51|
|...|...|...|...|

> Para melhor visualização, vários elementos da tabela foram omitidos. A tabela completa pode ser encontrada no projeto do curso.

Na primeira coluna, são apresentados os sabores dos sucos. Na segunda, o ano analisado (2016). Na terceira coluna, temos a quantidade vendida no ano todo, em litros. Os dados devem ser ordenados do maior para o menor em relação a esta coluna. E, por fim, temos o percentual de participação.

Por exemplo: açaí foi o sabor mais vendido de 2016, com o total de 10.024.014 litros, que representam 23,66% do volume de sucos vendidos nesse ano. O sabor de melancia aparece em segundo lugar, com 6.128.138 litros, correspondentes a 14,47% do total de vendas.

Agora que compreendemos a tarefa, vamos ao MySQL Workbench para abrir um novo _script_ e analisar onde se encontram esses dados e como os consultamos.

Para nosso relatório, precisamos de três informações que estão em três tabelas diferentes. **Quantidade** de vendas encontra-se na tabela de itens de notas fiscais. Os **sabores** são listados na tabela de produtos. E o **ano** das vendas está na tabela de notas fiscais, na coluna "DATA_VENDA". Primeiro juntaremos essas tabelas com o comando `JOIN`.

Nossa primeira junção será entre a tabela de produtos e a tabela de itens de notas fiscais, que têm "CODIGO_DO_PRODUTO" como campo em comum:

```sql
SELECT * FROM
TABELA_DE_PRODUTOS TP
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO;
```

Em seguida, faremos mais um `INNER JOIN` com a tabela de notas fiscais, dessa vez usando o campo em comum "NUMERO". Essa junção é importante para acessarmos a data, presente nas notas fiscais:

```sql
SELECT * FROM
TABELA_DE_PRODUTOS TP
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO;
```

E, depois, vamos selecionar apenas as colunas relevantes para o relatório (sabor, quantidade e data). Ou seja, substituiremos o asterisco pelos campos que nos interessam, cuidando para colocar os prefixos corretos, já que cada coluna pertence a uma tabela distinta — sabor, à tabela de produtos; o ano, à tabela de notas fiscais; e quantidade, à de itens de notas fiscais:

```sql
SELECT TP.SABOR, NF.DATA_VENDA, INF.QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO;
```

Quando ocorrerem erros na execução dos scripts, você pode checar a aba "_Output_", no painel inferior do programa, para mais detalhes. É comum cometer erros de digitação ou confundir-se com os nomes dos campos, por exemplo. Esses pequenos "tropeços" também acontecem em cenários reais, com pessoas mais experientes. O importante é continuar se dedicando!

Essa seleção retornará os dados de **todas as vendas**, uma a uma.

Lembrando que o foco do relatório é 2016, nossa primeira meta será agrupar os registros anualmente (ignorando dia e mês). Então, vamos modificar o formato da data para que mostre somente o ano. Aplicaremos a função `YEAR` sobre a data da venda:

```sql
SELECT TP.SABOR, YEAR(NF.DATA_VENDA) AS ANO, INF.QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO;
```

Em seguida, **agruparemos** os registros pelo ano e pelo sabor, somando os valores da coluna "QUANTIDADE". Usaremos `GROUP BY`:

```sql
SELECT TP.SABOR, YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
GROUP BY TP.SABOR, YEAR(NF.DATA_VENDA);
```

Quanto mais complexa for a consulta, mais demorado pode ser o retorno. Essa última seleção, por exemplo, é mais pesada do que as que vínhamos fazendo até então.

Com esses dados agrupados, **filtraremos** apenas os registros cujo ano é 2016. Usaremos a **cláusula `WHERE`** (depois do `JOIN`, mas antes do `GROUP BY`). E, finalmente, vamos organizar o resultado do maior para o menor (**ordem descendente**), de acordo com os valores da coluna "QUANTIDADE". Basta adicionar o **comando `ORDER BY`** ao final da consulta:

```sql
SELECT TP.SABOR, YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY TP.SABOR, YEAR(NF.DATA_VENDA)
ORDER BY SUM(INF.QUANTIDADE) DESC;
```

> Os registros que obtemos são diferentes da tabela-modelo que vimos no início do vídeo, pois são resultados de bancos de dados distintos.

Assim, conseguimos ver o ranqueamento dos sabores que foram mais vendidos em 2016: manga, melancia, laranja, maçã, açaí e assim por diante. Por enquanto, vamos reservar essa seleção, adicionando um **comentário** para lembrarmos o que ela retorna:

```sql
/* QUANTIDADE VENDIDA POR SABOR ANO 2016 */
SELECT TP.SABOR, YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY TP.SABOR, YEAR(NF.DATA_VENDA)
ORDER BY SUM(INF.QUANTIDADE) DESC;
```

A seguir, focaremos na **coluna de participação**. Para calcular esse percentual, dividimos a quantidade vendida de cada sabor pela **quantidade total** de sucos vendidos, então multiplicamos o resultado por 100.

Para obter a **quantidade total**, basta reutilizar a última seleção, removendo as duas ocorrências de `TP.SABOR`:

```sql
/* QUANTIDADE TOTAL 2016*/
SELECT YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY YEAR(NF.DATA_VENDA)
ORDER BY SUM(INF.QUANTIDADE) DESC;
```

Logo, sabemos que a quantidade total é 3626240 litros! Agora, precisamos fazer a junção desta tabela com aquela que reservamos há pouco, com a quantidade vendida por sabor em 2016.

Para facilitar o entendimento, primeiramente vamos copiá-las uma abaixo da outra, **retirando os dois comandos `ORDER BY`**. Não é preciso rodar o script ainda, estamos construindo a consulta passo a passo:

```sql
/* QUANTIDADE VENDIDA POR SABOR ANO 2016 */
SELECT TP.SABOR, YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY TP.SABOR, YEAR(NF.DATA_VENDA)

/* QUANTIDADE TOTAL 2016*/
SELECT YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY YEAR(NF.DATA_VENDA)
```

Depois, vamos colocá-las entre parênteses (seguidos de `AS`) para transformá-las em subconsultas, atribuindo-lhes _aliases_ "VENDA_SABOR" e "VENDA_TOTAL":

```sql
(SELECT TP.SABOR, YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY TP.SABOR, YEAR(NF.DATA_VENDA)) AS VENDA_SABOR

(SELECT YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY YEAR(NF.DATA_VENDA)) AS VENDA_TOTAL
```

Então, faremos um `INNER JOIN` entre essas duas subconsultas. É interessante lembrar que os `INNER JOIN`s não precisam necessariamente ser feitos com tabelas, podemos aplicá-los em subconsultas. No nosso caso, a coluna "ANO" será o campo em comum:

```sql
SELECT * FROM
(SELECT TP.SABOR, YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY TP.SABOR, YEAR(NF.DATA_VENDA)) AS VENDA_SABOR
INNER JOIN
(SELECT YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY YEAR(NF.DATA_VENDA)) AS VENDA_TOTAL
ON VENDA_SABOR.ANO = VENDA_TOTAL.ANO;
```

Finalmente, vamos executar a seleção. As três primeiras colunas do resultado são referentes à primeira subconsulta, em que "QUANTIDADE" é o volume de suco vendido de cada sabor. As duas colunas seguintes são referentes à segunda subconsulta, onde "QUANTIDADE" é o volume total de suco vendido.

Selecionaremos somente os campos que nos interessam e adicionaremos a coluna "PARTICIPACAO". Como vimos antes, o cálculo desse percentual é a divisão da quantidade vendida de cada sabor pela quantidade total de sucos vendidos, multiplicado por 100:

```vbnet
SELECT VENDA_SABOR.SABOR, VENDA_SABOR.ANO, VENDA_SABOR.QUANTIDADE,
(VENDA_SABOR.QUANTIDADE/VENDA_TOTAL.QUANTIDADE) * 100, 2 AS PARTICIPACAO FROM 
(SELECT TP.SABOR, YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY TP.SABOR, YEAR(NF.DATA_VENDA)) AS VENDA_SABOR
INNER JOIN 
(SELECT YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY YEAR(NF.DATA_VENDA)) AS VENDA_TOTAL
ON VENDA_SABOR.ANO = VENDA_TOTAL.ANO;
```

No campo "PARTICIPACAO", aplicaremos a função `ROUND()` para exibir duas casas decimais. Por fim, vamos ordenar a consulta, aplicando um `ORDER BY`:

```vbnet
SELECT VENDA_SABOR.SABOR, VENDA_SABOR.ANO, VENDA_SABOR.QUANTIDADE,
ROUND((VENDA_SABOR.QUANTIDADE/VENDA_TOTAL.QUANTIDADE) * 100, 2) AS PARTICIPACAO FROM 
(SELECT TP.SABOR, YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY TP.SABOR, YEAR(NF.DATA_VENDA)) AS VENDA_SABOR
INNER JOIN 
(SELECT YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM 
TABELA_DE_PRODUTOS TP 
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY YEAR(NF.DATA_VENDA)) AS VENDA_TOTAL
ON VENDA_SABOR.ANO = VENDA_TOTAL.ANO
ORDER BY VENDA_SABOR.QUANTIDADE DESC;
```

Visualizando esse ranqueamento dos sabores mais vendidos, reconhecemos, por exemplo, em primeiro lugar o suco de manga, com 613309 litros vendidos, representando 16,91% das vendas totais de 2016. Note que, com o uso do `ROUND()`, a participação que antes mostrava 16,9131% passou a ter apenas duas casas decimais (16,91%) — assim, a leitura ficou mais simples.

Conseguimos, então, criar o relatório conforme o modelo solicitado pela área de vendas da empresa de sucos!


-----------------------------------------------------------------------
# 05Consolidando o seu conhecimento

Chegou a hora de você seguir todos os passos realizados por mim durante esta aula. Caso já tenha feito, excelente. Se ainda não, é importante que você execute o que foi visto nos vídeos para poder continuar com os próximos cursos que tenham este como pré-requisito.

1) Vamos por em prática o nosso conhecimento.

2) Primeiro montamos uma seleção que determina se as vendas mensais por cliente são válidas ou não. Consideramos válidas vendas abaixo da quantidade limite e não válidas acima da quantidade limite existente no cadastro do cliente. A consulta é a mostrada abaixo:

```sql
SELECT X.CPF, X.NOME, X.MES_ANO, X.QUANTIDADE_VENDAS, X.QUANTIDADE_LIMITE,
CASE WHEN (X.QUANTIDADE_LIMITE - X.QUANTIDADE_VENDAS) < 0 THEN 'INVÁLIDA'
ELSE 'VÁLIDA' END AS STATUS_VENDA
FROM (SELECT NF.CPF, TC.NOME, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m') AS MES_ANO
, SUM(INF.QUANTIDADE) AS QUANTIDADE_VENDAS
, MAX(TC.VOLUME_DE_COMPRA) AS QUANTIDADE_LIMITE FROM NOTAS_FISCAIS NF
INNER JOIN ITENS_NOTAS_FISCAIS INF
ON NF.NUMERO = INF.NUMERO
INNER JOIN TABELA_DE_CLIENTES TC
ON TC.CPF = NF.CPF
GROUP BY NF.CPF, TC.NOME, DATE_FORMAT(NF.DATA_VENDA, '%Y-%m')) X;
```

![1.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/06/1.png)

1) Outro exemplo de relatório é o que determina a venda por sabores, para o ano de 2016, apresentando o percentual de participação de cada um destes sabores, ordenados.

```vbnet
SELECT VENDA_SABOR.SABOR, VENDA_SABOR.ANO, VENDA_SABOR.QUANTIDADE,
ROUND((VENDA_SABOR.QUANTIDADE/VENDA_TOTAL.QUANTIDADE) * 100, 2) AS PARTICIPACAO FROM
(SELECT TP.SABOR, YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM
TABELA_DE_PRODUTOS TP
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY TP.SABOR, YEAR(NF.DATA_VENDA)) AS VENDA_SABOR
INNER JOIN
(SELECT YEAR(NF.DATA_VENDA) AS ANO, SUM(INF.QUANTIDADE) AS QUANTIDADE FROM
TABELA_DE_PRODUTOS TP
INNER JOIN ITENS_NOTAS_FISCAIS INF ON TP.CODIGO_DO_PRODUTO = INF.CODIGO_DO_PRODUTO
INNER JOIN NOTAS_FISCAIS NF ON NF.NUMERO = INF.NUMERO
WHERE YEAR(NF.DATA_VENDA) = 2016
GROUP BY YEAR(NF.DATA_VENDA)) AS VENDA_TOTAL
ON VENDA_SABOR.ANO = VENDA_TOTAL.ANO
ORDER BY VENDA_SABOR.QUANTIDADE DESC
```

![2.png](https://cdn3.gnarususercontent.com.br/1221-mysqlconsultasavancadas/06/2.png)

-----------------------------------------------------------------------
# 07Conclusão

https://cursos.alura.com.br/course/mysql-consultas-sql/task/55602

## Transcrição

Parabéns! Você completou o curso de consultas avançadas com SQL, usando MySQL! Vamos relembrar o que vimos nesse treinamento.

Começamos conhecendo a **história do SQL e do MySQL**. Em seguida, recuperamos o ambiente de trabalho e quem ainda não tinha o MySQL no computador aproveitou o material do curso introdutório para aprender como fazer essa instalação. Depois, recuperamos a base de dados "sucos_vendas" e exploramos o esquema de tabelas contido nesse banco, analisando seus conteúdos e suas relações.

Com esse conhecimento em mãos, partimos para as consultas. A princípio, realizamos seleções básicas, revisando conceitos do [curso de Introdução ao SQL com MySQL](https://cursos.alura.com.br/course/mysql-manipule-dados-com-sql), como a implementação de filtros simples. Depois, aprendemos sobre **consultas condicionais**, nas quais utilizamos operações lógicas, como maior, menor, maior ou igual, menor ou igual, `AND`, `OR` e `IN`, que significa "dentro de um determinado conjunto".

Entendemos a **estrutura do `LIKE`**, que é um modo especial para selecionar um conjunto específico de caracteres dentro dos campos, e estudamos o **`DISTINCT`**, um comando que restringe a saída, não permitindo que dados repetidos apareçam no retorno da consulta SQL. Ainda nesse âmbito, aprendemos a **limitar as seleções** (com `LIMIT`), tendo então a opção de não visualizar todos os registros, somente uma parcela em particular que nos interesse.

Ver os dados de forma **ordenada** (seja alfabeticamente ou por outro indicador) é imprescindível e, sem esse aspecto, o SQL não faria muito sentido. Nesse curso, aprendemos como efetuar a ordenação dos registros por meio `ORDER BY`, usando critérios mistos e especificando a direção em que as informações devem aparecer (de forma ascendente ou descendente).

Outra cláusula importante que estudamos é o `GROUP BY`, que nos permite **agrupar dados** — no caso de campos numéricos, aplicando fórmulas de soma, máximo ou mínimo. Para a elaboração de relatórios, o `GROUP BY` é um comando marcante.

Também passamos pela **cláusula `HAVING`** que, apesar de pouco usada no dia a dia, é bastante útil por possibilitar o uso de um dado numérico agrupado dentro de uma condição de filtro. Ademais, vimos o **`CASE` (acompanhado do `WHEN`)**, uma ótima ferramenta para classificação. Com essa expressão, podemos avaliar dados numéricos, por exemplo, e determinar o que aparecerá na saída.

Em seguida, nos aprofundamos nos diversos **tipos de `JOIN`**, comandos que juntam tabelas em um único `SELECT`. Descobrimos que, dependendo do tipo usado, obtemos resultados bem diferentes. Depois, falamos um pouco sobre o **`UNION`**, que permite unir duas consultas em uma só. Vimos as distinções entre `UNION` e `UNION ALL` e focamos nas peculiaridades desse comando: é preciso que as tabelas em questão tenham o mesmo número de campos e que seus tipos coincidam.

Estudamos as **subconsultas** (ou seja, consultas dentro de outras consultas) e partindo desse conceito também aprendemos sobre as _views_ no SQL.

Depois, estudamos as **funções**. Neste tópico, nos aprofundamos nas funções de _string_, que manipulam textos. Também vimos as funções de data, que permitem a extração de informações como dia ou hora, bem com a soma e a subtração de datas. Checamos as funções matemáticas, com as quais podemos fazer operações complexas ou efetuar, por exemplo, o arredondamento de valores. E, por fim, falamos das funções de conversão, responsáveis por converter os tipos dos campos. Às vezes, durante uma consulta SQL, é fundamental fazer essas conversões.

Finalizamos o treinamento com a simulação de dois casos específicos. Em um deles, consultamos os dados para averiguar quais clientes haviam respeitado seus limites de compra mensal, conforme seu cadastro. No outro, criamos um relatório da participação nas vendas dos produtos por sabor, no ano de 2016. Nesses dois cenários, aplicamos diversos conceitos que aprendemos ao longo do treinamento, numa mesma consulta SQL.

Espero que este curso tenha te estimulado a se aprofundar mais na linguagem SQL, principalmente em relação às consultas — ainda existe muito o que ser estudado sobre esse assunto. Com os conceitos que vimos, você já é capaz de realizar diversas tarefas no seu dia a dia profissional. Além disso, com essa base de conhecimentos, você também pode continuar seus estudos da linguagem SQL, através de livros e da internet.

Muito obrigado pela preferência! Espero vê-los em outros cursos de SQL!

-----------------------------------------------------------------------



-----------------------------------------------------------------------



-----------------------------------------------------------------------



-----------------------------------------------------------------------

