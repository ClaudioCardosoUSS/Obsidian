---
type: "9"
fonte: https://www.alura.com.br/
tags:
  - nota/cursos
---

Tópico:: #Java #JPA #Spring_Boot

## Transcrição

Olá, pessoal! Meu nome é Eric Monné, sou instrutor Java aqui na Alura e gostaria de dar as boas-vindas a todas as pessoas estudantes do programa Oracle Next Education a mais um desafio de back-end. Para fins de acessibilidade, sou uma pessoa de pele clara, cabelo, olhos e barba escuros. Estou com uma camiseta preta, em um cômodo com um guarda-roupa branco com luz azulada atrás de mim e é possível ver meu microfone aqui no canto direito da tela.

Hoje, o desafio que trago para vocês é o desafio do Fórum Hub. Imagino que a essa altura todas as pessoas já estejam familiarizadas com o Fórum da Alura. O Fórum da Alura é um espaço onde podem trocar conhecimentos, criar tópicos para solucionar dúvidas com nossos instrutores e instrutoras, e também utilizar para tirar as dúvidas de outras pessoas, desenvolvendo um pouco mais o seu conhecimento e ajudando a explicar para as outras pessoas aquilo que conhecemos. É sempre uma boa forma de expandir nossos conhecimentos e praticá-los.

Vocês podem criar tópicos. Cada tópico deve ser construído com título e com uma mensagem. Cada tópico pertence a uma pessoa usuária. Apenas pessoas usuárias cadastradas podem criar novos tópicos e cada tópico também está dentro de um curso. Portanto, é bastante importante prestar atenção a essas regras de negócio enquanto estiver construindo a sua aplicação.

Vamos testar então aqui a nossa aplicação. Vamos ver como ela funciona? Estou aqui no _Insomnia_ (ferramenta que ajuda a testar os nossos endpoints). Vou realizar algumas requisições e vamos ver se elas vão funcionar ou não. Primeira requisição, vou testar a listagem de todos os tópicos. Está demorando um pouco para carregar, mas foi. Temos aqui três tópicos cadastrados no nosso banco de dados.

Vamos tentar então listar um único tópico. Vou tentar aqui o tópico 3. Vamos verificar. Ok, tópico 3 funcionando. Vamos tentar então deletar um tópico. Não temos tópico número 4. Vamos tentar deletar o tópico de número 3 e não deveria funcionar. Por quê? Porque estamos aqui com regras de segurança e de autenticação. Vocês devem se lembrar que apenas pessoas usuárias cadastradas, pessoas usuárias logadas, podem realizar postagens na nossa plataforma.

Nesse desafio, vocês vão precisar se preocupar com esse tipo de segurança também. Porque não queremos que qualquer pessoa que esteja vendo ali possa deletar o tópico de um outro usuário, possa sabotar o seu banco de dados e tornar a sua aplicação menos segura, menos robusta. Então, você vai precisar realizar a autenticação da sua pessoa usuária para garantir que a sua aplicação está funcionando corretamente.

Vamos testar aqui o nosso endpoint. E está funcionando. Na parte de registro, recebemos aqui um token do tipo _Bearer_. Vamos copiar esse token e vamos para a parte de registrar tópico. Aqui também está no tipo _JSON_. Todo tópico vai precisar então ter uma mensagem, ter o nome do curso, ter um título. Também vai precisar ter uma data de criação, mas isso pode estar configurado no seu código, porque a sua pessoa usuária não deveria informar a data de criação. Isso deve ser a data do momento que ela estiver postando.

Além disso, também é importante que haja uma relação entre a pessoa autora e o tópico. A pessoa autora é aquela que pode depois alterar o tópico, atualizar o tópico. Não deveria ser possível que outras pessoas alterassem as informações daquele tópico sem a permissão da pessoa autora.

Vamos testar então a criação de um novo tópico. Vamos para o URL agora `localhost:8080/topicos`. E aqui podemos ver um pouco das nossas regras de criação. Então todo tópico precisa ter um título. Nesse caso aqui "Me ajuda nessa dúvida". Precisa ter o nome do curso. Colocamos "Java". Precisa ter uma mensagem. "Estou com dúvida". Uma mensagem que não ajuda muito nossos instrutores e instrutoras a resolver a dúvida da pessoa estudante. Mas vamos testar aqui só para dar um exemplo. Enviamos a requisição e erro 403. _Forbidden_. O acesso continua.

Vamos ir aqui na aba _Auth_ e selecionar _Bearer Token_, que é o tipo de token que estamos utilizando. Aqui colamos o token que recebemos lá da nossa autenticação e vamos testar novamente. Vamos ver. Agora sim, criou um novo tópico com ID número 5. Vamos pedir para listar todos os tópicos e ver se recebemos esse tópico. Aqui temos um tópico número 4, um tópico número 5.

Vamos atualizar o tópico. Vamos mudar aqui o nosso tópico de número 5. Vamos mudar a mensagem para "Não tenho mais dúvida". Título "Dúvida solucionada". Vamos ver se conseguimos. E ok, conseguimos porque já tinha deixado o _Bearer_ preparado aqui.

Vamos tentar então deletar esse tópico. Para conseguirmos deletar o tópico, também vamos precisar vir aqui na aba _Auth_ e colocar o _Bearer Token_. Não vamos precisar de um corpo, só vamos precisar escolher o tópico para ser deletado. Escolhi o tópico de número 5. Vamos ver se conseguimos. Ok, 200 ok. Então conseguimos deletar esse tópico. Vamos verificar aqui na listagem de todos os tópicos. E ok, acabamos com os tópicos de 1 a 4 apenas. Agora não temos mais o tópico de número 5.

Agora, pode ser que você esteja se perguntando, professor, como faço para lembrar todas essas regras de negócio, para saber como começar, para dar o pontapé inicial no meu desafio? E a minha recomendação para você é que se lembre que o _Trello_ é o seu melhor amigo.

Temos aqui o _Trello_ disponibilizado do Challenge. Na coluna de ferramentas temos um card específico para descrever exatamente o desafio. Temos um card com todo o conteúdo básico e o conteúdo adicional, o conteúdo extra, para te ajudar na completude, na realização do seu desafio. Temos uma coluna de _backlog_ na qual você tem um card para cada tarefa que precisa realizar. Então está tudo muito bem discriminado, tudo muito bem explicado.

Esse desafio também exige que você crie um _readme_ bem construído. Pense que a pessoa que vai estar ali visualizando a sua aplicação, a sua página no GitHub, ela não vai ter a possibilidade de ver um front-end da sua aplicação funcionando. Então o _readme_ vai ser importante para você mostrar para a pessoa como funciona, para explicar as tecnologias que utilizou, para contar sobre os desafios que enfrentou e oferecer um panorama de como foi realizar e o que a sua pessoa usuária pode esperar com aquela aplicação.

Com tudo isso em mãos, você já tem tudo aquilo que é necessário para realizar esse desafio. Lembre-se sempre do valor da comunidade. A união faz a força e temos uma comunidade no _Discord_ para provar isso. Essa comunidade é um espaço muito legal para você compartilhar o seu código, receber dicas das suas colegas. Você pode ajudar também suas colegas que estejam tendo dificuldades com o desafio. Vocês podem trocar informações, trocar conhecimentos. Essa é uma etapa fundamental do seu processo de aprendizagem. Então, por favor, não deixe de realizá-la.

Vou encerrar por aqui. Espero vê-los novamente em breve. Qualquer coisa, podem contar conosco para resolver todas as suas dúvidas. Até mais!

-----------------------------------------------------------------------
# Trello do desafio
Clique [AQUI](https://trello.com/b/OKIUKgxe/alura-f%C3%B3rum-challenge-one-sprint-01) para acessar o quadro do desafio.

https://trello.com/b/OKIUKgxe/alura-f%C3%B3rum-challenge-one-sprint-01


Trello é uma ferramenta de colaboração ou gestão de projetos que contribui para o sucesso empresarial e a organização pessoal. Permite-lhe organizar as suas tarefas em quadros, assim como criar um quadro e atribuí-lo a cada membro da sua equipa.

Para ser mais produtivo, entrar em contato com uma ferramenta de gerenciamento de projetos, controlar seu tempo e dividir suas tarefas em atividades menores, sugerimos que você use Trello como ajuda.

![](https://cdn1.gnarususercontent.com.br/1/103811/3cedba37-e8e4-4796-bfdd-71b5f7c9b481.png)


-----------------------------------------------------------------------
# Para saber mais
Separamos alguns materiais que podem ajudá-lo quando você tiver alguma dúvida teórica =]

- [Como escrever um README incrível no seu Github](https://www.alura.com.br/artigos/escrever-bom-readme)

Documentação Oficial:

- [Class HttpClient](https://docs.oracle.com/en/java/javase/11/docs/api/java.net.http/java/net/http/HttpClient.html)
- [Class HttpRequest](https://docs.oracle.com/en/java/javase/11/docs/api/java.net.http/java/net/http/HttpRequest.html)
- [Interface HttpResponse](https://docs.oracle.com/en/java/javase/11/docs/api/java.net.http/java/net/http/HttpResponse.html)

Artigos:

- [REST: Conceito e fundamentos | Alura](https://www.alura.com.br/artigos/rest-conceito-e-fundamentos)
- [Primeiros passos com o Spring Framework | Alura](https://www.alura.com.br/artigos/primeiros-passos-spring)
- [Criando um projeto com Spring Boot em 5 minutos](https://www.alura.com.br/artigos/desafio-alura-criando-um-projeto-com-spring-boot-em-5-minutos)
- [Spring: Quais os Benefícios desse Framework Java? | Alura](https://www.alura.com.br/artigos/spring-conheca-esse-framework-java)

Alura+:

- [O que é REST?](https://cursos.alura.com.br/extra/alura-mais/o-que-e-rest--c119)
- [O que é o Spring Framework?](https://cursos.alura.com.br/extra/alura-mais/o-que-e-o-spring-framework--c658)



-----------------------------------------------------------------------



