---
type: "4"
fonte: 
tags:
  - nota/ccb
---

Tópico:: #CCB-Reuniões 

#Reuniao_Encarregado_Manutencao
[[CCB-Reuniões]]
Em 15/12/2024 houve reunião de [[Reunião Encarregado Manutenção]]

Na reunião Trimestral do Pereira Barreto, foram comentados os seguintes tópicos abaixo:
Na reunião do dia [[2025-01-17]] foi comentado sobre os assuntos abaixo:
- [ ] Definir um banheiro para cadeirante.
- [ ] Comprar bebedouros Suspensos (irmãs e Irmãos).
- [ ] Comprar novos Cones de sinalização para o Estacionamento.
- [ ] Instalar Exaustor na Cozinha da Administração.
- [ ] Trocar telhas da área do Lanche.
- [ ] Pintar ferragens da área do Lanche.
- [ ] Instalar ferragens no corredor que leva a área do Lanche.
-----------------------------------------------------------------------
