---
type: 
fonte: 
tags:
  - nota/ccb
aliases:
---

Tópico:: #CCB-Reuniões 

#Reuniao_Trimestral_Pereira_Barreto

Em 15/12/2024 houve reunião de Encarregado de Manutenção.
O que foi Deliberado?
[[CCB-Reuniões]]
Na reunião do dia **15/12/2024** foi comentado sobre os assuntos abaixo:
- [ ] Definir um banheiro para cadeirante.
- [ ] Continuar com as demais atividade disponíveis na seção de avarias.